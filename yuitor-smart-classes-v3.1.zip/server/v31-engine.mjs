import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export const IST_TIMEZONE = "Asia/Kolkata";

export const SUSPEND_TERMINATE_REASONS = [
  "Fee / Payment Default",
  "Attendance Irregularity",
  "Code of Conduct Violation",
  "Academic Policy Breach",
  "Duplicate / Invalid Account",
  "Document Verification Failed",
  "Requested by Student / Parent / Staff",
  "Contract / Session Completed",
  "Administrative Review",
  "Other",
];

export const MAIL_THEMES = {
  yuitor_navy: {
    key: "yuitor_navy",
    name: "Yuitor Dark Navy (Official)",
    headerBg: "#101B3D",
    headerText: "#FFFFFF",
    accent: "#2563EB",
    pageBg: "#F1F5F9",
    cardBg: "#FFFFFF",
    textColor: "#0F172A",
    mutedColor: "#475569",
    borderColor: "#E2E8F0",
  },
  yuitor_violet: {
    key: "yuitor_violet",
    name: "Yuitor Royal Violet",
    headerBg: "#3B0764",
    headerText: "#FFFFFF",
    accent: "#7C3AED",
    pageBg: "#F5F3FF",
    cardBg: "#FFFFFF",
    textColor: "#1E1B4B",
    mutedColor: "#4C1D95",
    borderColor: "#DDD6FE",
  },
  yuitor_emerald: {
    key: "yuitor_emerald",
    name: "Yuitor Academic Green",
    headerBg: "#064E3B",
    headerText: "#FFFFFF",
    accent: "#16A34A",
    pageBg: "#ECFDF5",
    cardBg: "#FFFFFF",
    textColor: "#064E3B",
    mutedColor: "#334155",
    borderColor: "#BBF7D0",
  },
  yuitor_clean: {
    key: "yuitor_clean",
    name: "Minimal Slate Clean",
    headerBg: "#1E293B",
    headerText: "#FFFFFF",
    accent: "#0284C7",
    pageBg: "#F8FAFC",
    cardBg: "#FFFFFF",
    textColor: "#0F172A",
    mutedColor: "#64748B",
    borderColor: "#CBD5E1",
  },
};

export function getIstDateParts(inputDate = new Date()) {
  const date = inputDate instanceof Date ? inputDate : new Date(inputDate);
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: IST_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const parts = {};
  for (const part of fmt.formatToParts(date)) {
    if (part.type !== "literal") parts[part.type] = part.value;
  }
  return parts;
}

export function getIstDateKey(inputDate = new Date()) {
  const p = getIstDateParts(inputDate);
  return `${p.year}-${p.month}-${p.day}`;
}

export function getIstTimestamp(inputDate = new Date()) {
  const p = getIstDateParts(inputDate);
  return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}:${p.second} IST`;
}

export function isFutureIstDate(dateStr) {
  const clean = String(dateStr || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(clean)) return false;
  return clean > getIstDateKey();
}

export function diffDaysIst(startDateKey, endDateKey = getIstDateKey()) {
  const a = String(startDateKey || "").trim().slice(0, 10);
  const b = String(endDateKey || "").trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(a) || !/^\d{4}-\d{2}-\d{2}$/.test(b)) return 0;
  const msA = Date.parse(`${a}T00:00:00Z`);
  const msB = Date.parse(`${b}T00:00:00Z`);
  return Math.floor((msB - msA) / 86400000);
}

export function normalizeClassCode(raw) {
  const s = String(raw || "").trim().toLowerCase();
  if (!s) return "";
  const match = s.match(/(?:class\s*)?(\d{1,2})(?:st|nd|rd|th)?/);
  if (match) return match[1];
  return s.replace(/\s+/g, " ");
}

export function sanitizeMailHtml(html) {
  let out = String(html || "");
  // Strip dangerous container tags completely
  out = out.replace(/<\s*(script|iframe|object|embed|applet|form|input|button|textarea|select|meta|link|base|svg|math)[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, "");
  out = out.replace(/<\s*(script|iframe|object|embed|applet|form|input|button|textarea|select|meta|link|base)[^>]*\/?>/gi, "");
  // Strip inline JS event handlers (onclick, onerror, onload, etc.)
  out = out.replace(/\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "");
  // Strip javascript:, vbscript:, data:text/html in href/src/action/style
  out = out.replace(/(href|src|action|background)\s*=\s*(?:"\s*(?:javascript|vbscript|data\s*:\s*text\/html)[^"]*"|'\s*(?:javascript|vbscript|data\s*:\s*text\/html)[^']*'|[^\s>]*(?:javascript|vbscript):[^\s>]*)/gi, '$1="#"');
  out = out.replace(/expression\s*\([^)]*\)/gi, "");
  out = out.replace(/url\s*\(\s*['"]?\s*javascript:[^)]*\)/gi, "");
  return out.trim();
}

export function escapeHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function renderPlaceholders(template, vars = {}) {
  let out = String(template || "");
  for (const [k, v] of Object.entries(vars)) {
    const token = new RegExp(`\\{\\{\\s*${k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*\\}\\}`, "gi");
    out = out.replace(token, String(v ?? ""));
  }
  return out;
}

export function applyMailTheme(themeKey, innerHtml, options = {}) {
  const theme = MAIL_THEMES[themeKey] || MAIL_THEMES.yuitor_navy;
  const brandName = escapeHtml(options.brandName || "YUITOR Smart Classes");
  const supportEmail = escapeHtml(options.supportEmail || "support@yuitor.in");
  const supportPhone = escapeHtml(options.supportPhone || "+91-98765-43210");
  const subjectTitle = escapeHtml(options.subject || "Official Communication from Yuitor");
  const unsubscribeLink = options.unsubscribeLink ? String(options.unsubscribeLink) : "";
  const safeBody = sanitizeMailHtml(innerHtml);

  const footerUnsub = unsubscribeLink
    ? `<p style="margin:10px 0 0;font-size:12px;color:${theme.mutedColor};">Prefer not to receive promotional course offers? <a href="${escapeHtml(unsubscribeLink)}" style="color:${theme.accent};text-decoration:underline;">Unsubscribe from promotional emails</a>. (Important account &amp; academic notifications will continue.)</p>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${subjectTitle}</title></head>
<body style="margin:0;padding:0;background:${theme.pageBg};font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:${theme.textColor};">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:${theme.pageBg};padding:24px 12px;">
    <tr>
      <td align="center">
        <table role="presentation" width="640" cellspacing="0" cellpadding="0" style="max-width:640px;width:100%;background:${theme.cardBg};border:1px solid ${theme.borderColor};border-radius:14px;overflow:hidden;">
          <tr>
            <td style="background:${theme.headerBg};color:${theme.headerText};padding:24px 28px;">
              <div style="font-size:20px;font-weight:800;letter-spacing:0.5px;">${brandName}</div>
              <div style="font-size:13px;opacity:0.86;margin-top:4px;">${subjectTitle}</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px;font-size:15px;line-height:1.68;color:${theme.textColor};">
              ${safeBody}
            </td>
          </tr>
          <tr>
            <td style="background:#F8FAFC;border-top:1px solid ${theme.borderColor};padding:18px 28px;font-size:12px;line-height:1.6;color:${theme.mutedColor};">
              <div><strong>Need Assistance?</strong> Contact Yuitor Support at <a href="mailto:${supportEmail}" style="color:${theme.accent};">${supportEmail}</a> | Helpline: ${supportPhone}</div>
              <div style="margin-top:6px;">&copy; ${new Date().getFullYear()} ${brandName}. All rights reserved. Sent in IST (Asia/Kolkata).</div>
              ${footerUnsub}
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

export const DEFAULT_V31_TEMPLATES = [
  {
    template_key: "student_welcome_admission",
    name: "Student Welcome & Admission Confirmation",
    audience: "student",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Welcome to Yuitor — Your Admission is Confirmed!",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p><strong>Your admission is successful. Welcome to the Yuitor family. Yuitor congratulates you.</strong></p>
<p>We are delighted to have you onboard. Your student profile has been verified and activated with the following academic details:</p>
<table style="width:100%;border-collapse:collapse;margin:16px 0;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;">
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Student Name</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{name}}</td></tr>
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Class / Program</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{class_name}}</td></tr>
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>School Name</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{school_name}}</td></tr>
  <tr><td style="padding:10px 14px;"><strong>Enrolled Course(s)</strong></td><td style="padding:10px 14px;">{{course}}</td></tr>
</table>
<p><strong>Recommended Next Steps:</strong></p>
<ol style="padding-left:20px;margin:10px 0 18px;">
  <li>Sign in to your Student Panel to view your class batch start date, timings, and assigned teacher.</li>
  <li>Download your study schedule and join live/classroom sessions on time.</li>
  <li>Keep your profile details updated so you never miss attendance, exam, or fee notifications.</li>
</ol>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Open Student Portal</a></p>
<p>Wishing you great academic success ahead!<br/>Warm regards,<br/><strong>Admissions &amp; Academic Team — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "teacher_welcome_profile",
    name: "Teacher Onboarding & Welcome Mail",
    audience: "teacher",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Welcome to the Yuitor Faculty Team!",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p><strong>Your admission is successful. Welcome to the Yuitor family. Yuitor congratulates you.</strong></p>
<p>Your faculty profile has been completed and verified on the Yuitor platform. Here is a summary of your onboarding details:</p>
<table style="width:100%;border-collapse:collapse;margin:16px 0;background:#F8FAFC;border:1px solid #E2E8F0;">
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Faculty Member</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{name}}</td></tr>
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Assigned Subject(s)</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{course}}</td></tr>
  <tr><td style="padding:10px 14px;"><strong>Date of Onboarding</strong></td><td style="padding:10px 14px;">{{ist_date}}</td></tr>
</table>
<p><strong>Next Steps for Faculty:</strong></p>
<ol style="padding-left:20px;margin:10px 0 18px;">
  <li>Log in to the Teacher Panel to review your assigned batches, class schedules, and seat rosters.</li>
  <li>Upload lesson notes, assignments, and daily attendance directly from your dashboard.</li>
  <li>Reach out to the Academic Coordinator for any syllabus or timetable support.</li>
</ol>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Access Teacher Panel</a></p>
<p>Warm regards,<br/><strong>Academic Administration — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "staff_welcome_profile",
    name: "Staff Onboarding & Welcome Mail",
    audience: "staff",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Welcome to the Yuitor Staff & Operations Team!",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p><strong>Your admission is successful. Welcome to the Yuitor family. Yuitor congratulates you.</strong></p>
<p>Your staff profile has been completed and verified. You now have access to your designated operations modules inside the Yuitor Staff Panel.</p>
<p><strong>Next Steps:</strong></p>
<ol style="padding-left:20px;margin:10px 0 18px;">
  <li>Log in to your Staff Panel to review daily tasks, inquiry follow-ups, and branch assignments.</li>
  <li>Follow institutional communication and student-support standards at all times.</li>
  <li>Contact HR / Branch Admin if you need additional module permissions.</li>
</ol>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Open Staff Panel</a></p>
<p>Warm regards,<br/><strong>Operations &amp; HR Team — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "account_suspended",
    name: "Account Suspension Notice (Student / Teacher / Staff)",
    audience: "all",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Important Notice: Your Yuitor Account Has Been Suspended",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>We are writing to formally inform you that your Yuitor account (<strong>{{role}}</strong>) has been temporarily <strong>suspended</strong> effective <strong>{{ist_date}}</strong>.</p>
<div style="background:#FEF2F2;border-left:4px solid #DC2626;padding:14px 18px;border-radius:8px;margin:16px 0;">
  <div style="font-weight:700;color:#991B1B;margin-bottom:6px;">Suspension Reason: {{reason}}</div>
  <div style="color:#7F1D1D;"><strong>Administrative Note:</strong> {{note}}</div>
</div>
<p><strong>What This Means &amp; Next Steps:</strong></p>
<ul style="padding-left:20px;margin:10px 0 18px;">
  <li>Your portal access and active sessions have been paused immediately.</li>
  <li>To resolve this matter and request account reactivation, please contact the Yuitor Administration / Support Desk with your registered email or phone number.</li>
  <li>Once verified and cleared by an administrator, your access will be restored without loss of historical records.</li>
</ul>
<p>Regards,<br/><strong>Administration Desk — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "account_terminated",
    name: "Account Termination Notice (Student / Teacher / Staff)",
    audience: "all",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Official Notice: Your Yuitor Account Has Been Terminated",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>This email serves as official confirmation that your Yuitor account (<strong>{{role}}</strong>) has been <strong>terminated</strong> effective <strong>{{ist_date}}</strong>.</p>
<div style="background:#FEF2F2;border-left:4px solid #DC2626;padding:14px 18px;border-radius:8px;margin:16px 0;">
  <div style="font-weight:700;color:#991B1B;margin-bottom:6px;">Termination Reason: {{reason}}</div>
  <div style="color:#7F1D1D;"><strong>Administrative Note:</strong> {{note}}</div>
</div>
<p><strong>Important Next Steps:</strong></p>
<ul style="padding-left:20px;margin:10px 0 18px;">
  <li>All active login sessions have been revoked immediately.</li>
  <li>For fee settlement, clearance certificates, or appeal inquiries, please contact Yuitor Support within 7 working days.</li>
  <li>Your archived academic/service records remain safely preserved for official reference.</li>
</ul>
<p>Regards,<br/><strong>Administration Desk — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "account_reactivated",
    name: "Account Reactivation Confirmation",
    audience: "all",
    category: "transactional",
    theme_key: "yuitor_emerald",
    subject: "Good News: Your Yuitor Account Has Been Reactivated",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>We are pleased to inform you that your Yuitor account has been <strong>reactivated</strong> as of <strong>{{ist_date}}</strong>.</p>
<p>You may now log in again using your registered credentials and resume full access to your classes, study materials, and dashboard.</p>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#16A34A;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Sign In to Yuitor</a></p>
<p>Warm regards,<br/><strong>Administration Desk — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "class_changed",
    name: "Student Class Update Notification",
    audience: "student",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Your Class Assignment Has Been Updated on Yuitor",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>Your academic class on Yuitor Smart Classes has been updated by the administration:</p>
<table style="width:100%;border-collapse:collapse;margin:16px 0;background:#F8FAFC;border:1px solid #E2E8F0;">
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Previous Class</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{old_class}}</td></tr>
  <tr><td style="padding:10px 14px;"><strong>New Class</strong></td><td style="padding:10px 14px;"><strong>{{new_class}}</strong></td></tr>
</table>
<p><strong>What Changed:</strong> Your Student Panel batches, subjects, and eligible course offers have been updated immediately to match <strong>{{new_class}}</strong>.</p>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">View Updated Batches</a></p>
<p>Warm regards,<br/><strong>Academic Team — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "fee_invoice_reminder",
    name: "Fee Summary & Invoice Communication",
    audience: "student",
    category: "transactional",
    theme_key: "yuitor_navy",
    subject: "Yuitor Fee Summary & Payment Details — {{course}}",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>Please find below the latest fee summary for your enrollment at Yuitor Smart Classes:</p>
<table style="width:100%;border-collapse:collapse;margin:16px 0;background:#F8FAFC;border:1px solid #E2E8F0;">
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Course / Subjects</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{course}}</td></tr>
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Total Fee</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{total_fee}}</td></tr>
  <tr><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;"><strong>Amount Paid</strong></td><td style="padding:10px 14px;border-bottom:1px solid #E2E8F0;">{{paid_fee}}</td></tr>
  <tr><td style="padding:10px 14px;"><strong>Remaining Balance</strong></td><td style="padding:10px 14px;"><strong>{{remaining_fee}}</strong></td></tr>
</table>
<p>You can download your invoice or pay any remaining balance securely through your Student Panel.</p>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Open Fee Dashboard</a></p>
<p>Warm regards,<br/><strong>Accounts Department — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "cross_sell_weekly_offer",
    name: "Student Weekly Cross-Sell Course Offer",
    audience: "student",
    category: "promotional",
    theme_key: "yuitor_violet",
    subject: "Special {{discount}}% Off Offer on Additional Courses for {{class_name}} — Yuitor",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<div style="background:#EEF2FF;border-left:4px solid #7C3AED;padding:16px 18px;border-radius:8px;margin:16px 0;font-size:16px;font-weight:600;color:#1E1B4B;">
  Yuitor ki taraf se aapko ek offer diya gaya hai. Agar aap ek aur course add karte hain to aapko {{discount}}% off milega.
</div>
<p>As an active <strong>{{class_name}}</strong> student, you have unlocked an exclusive <strong>{{discount}}% discount</strong> (Week {{week_number}} Offer) when you enroll in another course for your current class:</p>
<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:14px 18px;margin:16px 0;">
  <div style="font-weight:700;margin-bottom:8px;">Available Courses for {{class_name}}:</div>
  {{course}}
</div>
<p><strong>How to Claim:</strong></p>
<ol style="padding-left:20px;margin:10px 0 18px;">
  <li>Log in to your Student Panel using the button below.</li>
  <li>Your <strong>{{discount}}% cross-sell discount</strong> is automatically applied at checkout (cannot be combined with other coupon codes).</li>
  <li>Start attending live classes and accessing study material immediately after enrollment.</li>
</ol>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#7C3AED;color:#FFFFFF;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;">Claim {{discount}}% Off Now</a></p>
<p style="font-size:12px;color:#64748B;">To stop receiving promotional course offers, click here: <a href="{{unsubscribe_link}}" style="color:#2563EB;">Unsubscribe</a>.</p>
<p>Warm regards,<br/><strong>Academic Growth Team — Yuitor Smart Classes</strong></p>`,
  },
  {
    template_key: "general_announcement",
    name: "Official Long-Form Announcement / Circular",
    audience: "all",
    category: "transactional",
    theme_key: "yuitor_clean",
    subject: "Important Update from Yuitor Smart Classes",
    body_html: `<p>Dear <strong>{{name}}</strong>,</p>
<p>We are sharing an important update from Yuitor Smart Classes regarding upcoming academic schedules, examinations, and institutional resources.</p>
<p>{{course}}</p>
<p>Please log in to your portal for complete details and reach out to our support desk if you have any questions.</p>
<p style="margin:22px 0;"><a href="{{login_link}}" style="display:inline-block;background:#2563EB;color:#FFFFFF;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600;">Go to Yuitor Portal</a></p>
<p>Warm regards,<br/><strong>Yuitor Smart Classes Administration</strong></p>`,
  },
];

function safeAddColumn(db, table, colDef) {
  try {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${colDef}`);
  } catch {
    // Column already exists
  }
}

export function ensureV31Schema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS v31_mail_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      template_key TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      audience TEXT NOT NULL DEFAULT 'all',
      category TEXT NOT NULL DEFAULT 'transactional',
      theme_key TEXT NOT NULL DEFAULT 'yuitor_navy',
      subject TEXT NOT NULL,
      body_html TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_by INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS v31_mail_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dedupe_key TEXT,
      user_id INTEGER,
      to_email TEXT NOT NULL,
      subject TEXT NOT NULL,
      template_key TEXT,
      category TEXT NOT NULL DEFAULT 'transactional',
      theme_key TEXT DEFAULT 'yuitor_navy',
      status TEXT NOT NULL DEFAULT 'queued',
      attempts INTEGER NOT NULL DEFAULT 0,
      error_message TEXT DEFAULT '',
      rendered_html TEXT DEFAULT '',
      sent_at_ist TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_v31_mail_logs_dedupe ON v31_mail_logs(dedupe_key);
    CREATE INDEX IF NOT EXISTS idx_v31_mail_logs_status ON v31_mail_logs(status);

    CREATE TABLE IF NOT EXISTS v31_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER,
      actor_name TEXT DEFAULT 'System',
      actor_role TEXT DEFAULT 'admin',
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT DEFAULT '',
      summary TEXT NOT NULL,
      before_json TEXT DEFAULT '{}',
      after_json TEXT DEFAULT '{}',
      ist_timestamp TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_v31_audit_action ON v31_audit_logs(action);

    CREATE TABLE IF NOT EXISTS v31_cross_sell_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      master_switch INTEGER NOT NULL DEFAULT 0,
      post_4_week_behavior TEXT NOT NULL DEFAULT 'stop',
      updated_by INTEGER,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS v31_cross_sell_offers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      offer_start_date_ist TEXT NOT NULL,
      last_sent_week INTEGER NOT NULL DEFAULT 0,
      last_sent_at_ist TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Safe column migrations on existing tables
  safeAddColumn(db, "users", "deleted_at TEXT DEFAULT ''");
  safeAddColumn(db, "users", "deleted_by INTEGER");
  safeAddColumn(db, "users", "suspended_reason TEXT DEFAULT ''");
  safeAddColumn(db, "users", "suspended_note TEXT DEFAULT ''");
  safeAddColumn(db, "users", "terminated_reason TEXT DEFAULT ''");
  safeAddColumn(db, "users", "terminated_note TEXT DEFAULT ''");
  safeAddColumn(db, "users", "promo_unsubscribed INTEGER NOT NULL DEFAULT 0");
  safeAddColumn(db, "users", "welcome_mail_sent_at TEXT DEFAULT ''");
  safeAddColumn(db, "users", "photo_url TEXT DEFAULT ''");
  safeAddColumn(db, "users", "dob TEXT DEFAULT ''");
  safeAddColumn(db, "users", "address TEXT DEFAULT ''");
  safeAddColumn(db, "users", "school_name TEXT DEFAULT ''");
  safeAddColumn(db, "users", "unsubscribe_token TEXT DEFAULT ''");

  safeAddColumn(db, "student_profiles", "enrolled_subjects_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "student_profiles", "course_duration TEXT DEFAULT ''");
  safeAddColumn(db, "student_profiles", "total_fee REAL DEFAULT 0");
  safeAddColumn(db, "student_profiles", "paid_fee REAL DEFAULT 0");
  safeAddColumn(db, "student_profiles", "remaining_fee REAL DEFAULT 0");
  safeAddColumn(db, "student_profiles", "subject_addons_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "student_profiles", "school_name TEXT DEFAULT ''");
  safeAddColumn(db, "student_profiles", "address TEXT DEFAULT ''");
  safeAddColumn(db, "student_profiles", "dob TEXT DEFAULT ''");

  safeAddColumn(db, "teacher_profiles", "subjects_taught_json TEXT DEFAULT '[]'");
  safeAddColumn(db, "teacher_profiles", "contract_end_date TEXT DEFAULT ''");
  safeAddColumn(db, "teacher_profiles", "contract_duration TEXT DEFAULT ''");
  safeAddColumn(db, "teacher_profiles", "total_seats INTEGER DEFAULT 30");
  safeAddColumn(db, "teacher_profiles", "active_student_count INTEGER DEFAULT 0");
  safeAddColumn(db, "teacher_profiles", "referrals_count INTEGER DEFAULT 0");
  safeAddColumn(db, "teacher_profiles", "dob TEXT DEFAULT ''");

  safeAddColumn(db, "staff_profiles", "dob TEXT DEFAULT ''");
  safeAddColumn(db, "batches", "start_date TEXT DEFAULT ''");
  safeAddColumn(db, "batches", "duration TEXT DEFAULT ''");
  safeAddColumn(db, "batches", "total_seats INTEGER DEFAULT 30");
  safeAddColumn(db, "batches", "class_name TEXT DEFAULT ''");

  // Seed cross-sell settings (Master Switch OFF by default, post_4_week_behavior = 'stop')
  db.prepare(`
    INSERT OR IGNORE INTO v31_cross_sell_settings (id, master_switch, post_4_week_behavior)
    VALUES (1, 0, 'stop')
  `).run();

  // Seed default rewritten templates (insert only missing keys so admin edits persist)
  const insertTpl = db.prepare(`
    INSERT OR IGNORE INTO v31_mail_templates
      (template_key, name, audience, category, theme_key, subject, body_html)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  for (const tpl of DEFAULT_V31_TEMPLATES) {
    insertTpl.run(
      tpl.template_key,
      tpl.name,
      tpl.audience,
      tpl.category,
      tpl.theme_key,
      tpl.subject,
      tpl.body_html
    );
  }

  // Ensure every user has an unsubscribe_token
  const missingTokens = db.prepare("SELECT id FROM users WHERE COALESCE(unsubscribe_token, '') = ''").all();
  if (missingTokens.length > 0) {
    const updTok = db.prepare("UPDATE users SET unsubscribe_token = ? WHERE id = ?");
    for (const row of missingTokens) {
      updTok.run(crypto.randomBytes(16).toString("hex"), row.id);
    }
  }

  // Auto-migrate existing suspended / terminated users so their verification_status & is_active stay consistent
  try {
    db.prepare(`
      UPDATE users
      SET verification_status = 'suspended'
      WHERE LOWER(COALESCE(verification_status, '')) = 'suspended' AND is_active = 1
    `).run();
    db.prepare(`
      UPDATE users
      SET is_active = 0
      WHERE LOWER(COALESCE(verification_status, '')) IN ('suspended', 'terminated', 'deleted')
    `).run();
  } catch {
    // ignore
  }
}

export function isUserBlockedStatus(user) {
  if (!user) return { blocked: true, status: "unknown" };
  const vs = String(user.verification_status || "").toLowerCase();
  const hasDeleted = Boolean(user.deleted_at && String(user.deleted_at).trim());
  if (hasDeleted || vs === "deleted") return { blocked: true, status: "deleted" };
  if (vs === "suspended") return { blocked: true, status: "suspended" };
  if (vs === "terminated") return { blocked: true, status: "terminated" };
  if (Number(user.is_active) === 0 && (vs === "suspended" || vs === "terminated" || vs === "inactive" || vs === "rejected")) {
    return { blocked: true, status: vs || "suspended" };
  }
  return { blocked: false, status: vs || "active" };
}

export function classifyUserStatusTab(user) {
  const vs = String(user?.verification_status || "").toLowerCase();
  const hasDeleted = Boolean(user?.deleted_at && String(user.deleted_at).trim());
  if (hasDeleted || vs === "deleted") return "others";
  if (vs === "suspended") return "suspended";
  if (vs === "terminated") return "terminated";
  if (vs === "pending" || vs === "rejected" || vs === "exited" || vs === "alumni" || vs === "inactive" || Number(user?.is_active) === 0) {
    return "others";
  }
  return "active";
}

export function logV31Audit(db, {
  actorId = null,
  actorName = "System",
  actorRole = "admin",
  action,
  entityType,
  entityId = "",
  summary,
  before = {},
  after = {},
}) {
  try {
    db.prepare(`
      INSERT INTO v31_audit_logs
        (actor_id, actor_name, actor_role, action, entity_type, entity_id, summary, before_json, after_json, ist_timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      actorId ?? null,
      String(actorName || "System"),
      String(actorRole || "admin"),
      String(action || "update"),
      String(entityType || "system"),
      String(entityId ?? ""),
      String(summary || ""),
      JSON.stringify(before || {}),
      JSON.stringify(after || {}),
      getIstTimestamp()
    );
  } catch {
    // Non-fatal
  }
}

export function getMailTemplate(db, templateKey) {
  return db.prepare("SELECT * FROM v31_mail_templates WHERE template_key = ? LIMIT 1").get(templateKey) || null;
}

export function getAppBaseUrl(deps = {}) {
  return String(deps.appUrl || process.env.APP_URL || "http://localhost:3000").replace(/\/+$/, "");
}

export async function sendV31Mail(db, deps = {}, options = {}) {
  const {
    to,
    userId = null,
    templateKey = null,
    subject: customSubject,
    bodyHtml: customBodyHtml,
    themeKey: customThemeKey,
    category: customCategory,
    vars = {},
    dedupeKey = "",
    maxAttempts = 2,
    forceResend = false,
  } = options;

  const recipient = String(to || "").trim().toLowerCase();
  if (!recipient || !recipient.includes("@")) {
    return { ok: false, skipped: true, reason: "invalid_email" };
  }

  // 1. Duplicate mail guard (max 1 per action unless forceResend)
  if (dedupeKey && !forceResend) {
    const existing = db.prepare(`
      SELECT id, status FROM v31_mail_logs
      WHERE dedupe_key = ? AND status IN ('sent', 'skipped_unsubscribed')
      LIMIT 1
    `).get(dedupeKey);
    if (existing) {
      return { ok: true, skipped: true, duplicate: true, logId: existing.id };
    }
  }

  // Load template if specified
  const tpl = templateKey ? getMailTemplate(db, templateKey) : null;
  const category = String(customCategory || tpl?.category || "transactional").toLowerCase();
  const themeKey = String(customThemeKey || tpl?.theme_key || "yuitor_navy");

  // 2. Unsubscribe check: stops PROMOTIONAL mails only; TRANSACTIONAL always continues
  let userRow = null;
  if (userId) {
    userRow = db.prepare("SELECT id, email, full_name, promo_unsubscribed, unsubscribe_token FROM users WHERE id = ? LIMIT 1").get(userId);
  } else {
    userRow = db.prepare("SELECT id, email, full_name, promo_unsubscribed, unsubscribe_token FROM users WHERE LOWER(email) = ? LIMIT 1").get(recipient);
  }

  if (category === "promotional" && userRow) {
    const csRow = db.prepare("SELECT status FROM v31_cross_sell_offers WHERE user_id = ? LIMIT 1").get(userRow.id);
    if (Number(userRow.promo_unsubscribed) === 1 || csRow?.status === "unsubscribed") {
      const res = db.prepare(`
        INSERT INTO v31_mail_logs
          (dedupe_key, user_id, to_email, subject, template_key, category, theme_key, status, attempts, error_message, sent_at_ist)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'skipped_unsubscribed', 0, 'User unsubscribed from promotional emails', ?)
      `).run(
        dedupeKey || null,
        userRow.id,
        recipient,
        String(customSubject || tpl?.subject || "Yuitor Mail"),
        templateKey || null,
        category,
        themeKey,
        getIstTimestamp()
      );
      return { ok: true, skipped: true, unsubscribed: true, logId: Number(res.lastInsertRowid) };
    }
  }

  const baseUrl = getAppBaseUrl(deps);
  const unsubToken = userRow?.unsubscribe_token || "";
  const unsubscribeLink = unsubToken ? `${baseUrl}/api/public/unsubscribe/${unsubToken}` : `${baseUrl}/`;

  const mergedVars = {
    name: userRow?.full_name || "Member",
    login_link: `${baseUrl}/student`,
    unsubscribe_link: unsubscribeLink,
    ist_date: getIstTimestamp(),
    course: "",
    discount: "",
    class_name: "",
    school_name: "",
    reason: "",
    note: "",
    role: "",
    old_class: "",
    new_class: "",
    total_fee: "",
    paid_fee: "",
    remaining_fee: "",
    week_number: "",
    ...vars,
  };

  const finalSubject = renderPlaceholders(customSubject || tpl?.subject || "Yuitor Smart Classes", mergedVars);
  const rawBody = renderPlaceholders(customBodyHtml || tpl?.body_html || "<p>Hello from Yuitor.</p>", mergedVars);
  const fullHtml = applyMailTheme(themeKey, rawBody, {
    subject: finalSubject,
    unsubscribeLink: category === "promotional" ? unsubscribeLink : "",
  });

  const insertLog = db.prepare(`
    INSERT INTO v31_mail_logs
      (dedupe_key, user_id, to_email, subject, template_key, category, theme_key, status, attempts, rendered_html, sent_at_ist)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'queued', 0, ?, ?)
  `).run(
    dedupeKey || null,
    userRow?.id ?? userId ?? null,
    recipient,
    finalSubject,
    templateKey || null,
    category,
    themeKey,
    fullHtml,
    getIstTimestamp()
  );
  const logId = Number(insertLog.lastInsertRowid);

  let lastError = "";
  let attempts = 0;
  let delivered = false;

  const sender = typeof deps.sendEmailDirect === "function" ? deps.sendEmailDirect : null;

  for (let i = 0; i < Math.max(1, maxAttempts); i++) {
    attempts += 1;
    try {
      if (sender) {
        const result = await sender({
          to: recipient,
          subject: finalSubject,
          html: fullHtml,
          text: finalSubject,
        });
        if (result && result.ok === false && !result.simulated) {
          throw new Error(result.error || "SMTP delivery returned failure");
        }
      }
      delivered = true;
      break;
    } catch (err) {
      lastError = String(err?.message || err || "Delivery failed");
      if (i + 1 < maxAttempts) {
        await new Promise((r) => setTimeout(r, 150));
      }
    }
  }

  db.prepare(`
    UPDATE v31_mail_logs
    SET status = ?, attempts = ?, error_message = ?, sent_at_ist = ?
    WHERE id = ?
  `).run(
    delivered ? "sent" : "failed",
    attempts,
    delivered ? "" : lastError,
    getIstTimestamp(),
    logId
  );

  return {
    ok: delivered,
    logId,
    status: delivered ? "sent" : "failed",
    attempts,
    error: delivered ? "" : lastError,
    renderedHtml: fullHtml,
    subject: finalSubject,
  };
}

export async function sendBatchedV31Mails(db, deps, items = [], batchSize = 20) {
  const results = [];
  const size = Math.max(1, Math.min(50, Number(batchSize) || 20));
  for (let i = 0; i < items.length; i += size) {
    const chunk = items.slice(i, i + size);
    const chunkRes = await Promise.all(chunk.map((item) => sendV31Mail(db, deps, item)));
    results.push(...chunkRes);
  }
  return results;
}

export function getCrossSellSettings(db) {
  const row = db.prepare("SELECT * FROM v31_cross_sell_settings WHERE id = 1").get();
  return {
    masterSwitch: Number(row?.master_switch || 0) === 1,
    post4WeekBehavior: row?.post_4_week_behavior === "hold_40" ? "hold_40" : "stop",
    updatedAt: row?.updated_at || "",
  };
}

export function getStudentPurchasedCourseIds(db, userId) {
  const ids = new Set();
  try {
    const rows = db.prepare(`
      SELECT DISTINCT course_id FROM enrollments
      WHERE student_id = ? AND course_id IS NOT NULL
        AND LOWER(COALESCE(status, 'active')) NOT IN ('cancelled', 'refunded')
    `).all(userId);
    for (const r of rows) ids.add(Number(r.course_id));
  } catch {
    // ignore
  }
  try {
    const rows2 = db.prepare(`
      SELECT DISTINCT course_id FROM payments
      WHERE student_id = ? AND course_id IS NOT NULL
        AND LOWER(COALESCE(verification_status, '')) IN ('paid', 'captured', 'success', 'verified', 'completed')
    `).all(userId);
    for (const r of rows2) ids.add(Number(r.course_id));
  } catch {
    // ignore
  }
  return ids;
}

export function getStudentCurrentClass(db, userId) {
  const sp = db.prepare("SELECT class_level FROM student_profiles WHERE user_id = ? LIMIT 1").get(userId);
  return String(sp?.class_level || "").trim();
}

export function getCoursesForClass(db, className) {
  const targetCode = normalizeClassCode(className);
  if (!targetCode) return [];
  const all = db.prepare(`
    SELECT id, title, slug, category, class_range, board, duration_months, monthly_fee, yearly_fee, description, is_active
    FROM courses
    WHERE COALESCE(is_active, 1) = 1
    ORDER BY id ASC
  `).all();
  return all.filter((c) => {
    const candidates = [c.class_range, c.category, c.title].filter(Boolean);
    for (const raw of candidates) {
      const text = String(raw).toLowerCase();
      // Check range like "Classes 9-10" or "Classes 9–10"
      const rangeMatch = text.match(/(\d{1,2})\s*[-–to]+\s*(\d{1,2})/);
      if (rangeMatch && /^\d+$/.test(targetCode)) {
        const n = Number(targetCode);
        if (n >= Number(rangeMatch[1]) && n <= Number(rangeMatch[2])) return true;
      }
      const cCode = normalizeClassCode(raw);
      if (cCode && cCode === targetCode) return true;
    }
    return false;
  });
}

export function computeWeeklyDiscountPercent(daysElapsed, post4WeekBehavior = "stop") {
  const days = Math.max(0, Number(daysElapsed) || 0);
  if (days < 7) return { weekNumber: 1, discountPercent: 10, expired: false };
  if (days < 14) return { weekNumber: 2, discountPercent: 20, expired: false };
  if (days < 21) return { weekNumber: 3, discountPercent: 30, expired: false };
  if (days < 28) return { weekNumber: 4, discountPercent: 40, expired: false };
  if (post4WeekBehavior === "hold_40") {
    return { weekNumber: Math.floor(days / 7) + 1, discountPercent: 40, expired: false };
  }
  return { weekNumber: Math.floor(days / 7) + 1, discountPercent: 0, expired: true };
}

export function computeStudentCrossSellState(db, userId, nowDate = new Date()) {
  const settings = getCrossSellSettings(db);
  const user = db.prepare(`
    SELECT id, role, full_name, email, is_active, verification_status, deleted_at, promo_unsubscribed, created_at
    FROM users WHERE id = ? LIMIT 1
  `).get(userId);

  if (!user || user.role !== "student") {
    return { eligible: false, reason: "not_student", discountPercent: 0, availableCourses: [], settings };
  }

  // Strictly ACTIVE students only (never Suspended / Terminated / Exited / Alumni / Deleted)
  const vs = String(user.verification_status || "").toLowerCase();
  const blockedStatuses = new Set(["suspended", "terminated", "exited", "alumni", "inactive", "deleted", "rejected"]);
  if (Number(user.is_active) !== 1 || blockedStatuses.has(vs) || (user.deleted_at && String(user.deleted_at).trim())) {
    return { eligible: false, reason: "student_not_active", discountPercent: 0, availableCourses: [], settings };
  }

  const className = getStudentCurrentClass(db, userId);
  if (!className) {
    return { eligible: false, reason: "no_class_assigned", discountPercent: 0, availableCourses: [], settings };
  }

  // Ensure offer tracking row exists
  let offerRow = db.prepare("SELECT * FROM v31_cross_sell_offers WHERE user_id = ? LIMIT 1").get(userId);
  if (!offerRow) {
    const startKey = getIstDateKey(user.created_at ? new Date(user.created_at) : nowDate);
    db.prepare(`
      INSERT OR IGNORE INTO v31_cross_sell_offers (user_id, offer_start_date_ist, last_sent_week, status)
      VALUES (?, ?, 0, 'active')
    `).run(userId, startKey);
    offerRow = db.prepare("SELECT * FROM v31_cross_sell_offers WHERE user_id = ? LIMIT 1").get(userId);
  }

  if (offerRow.status === "purchased") {
    return { eligible: false, reason: "already_purchased_cross_sell", discountPercent: 0, availableCourses: [], offerRow, settings };
  }
  if (offerRow.status === "unsubscribed" || Number(user.promo_unsubscribed) === 1) {
    return { eligible: false, reason: "unsubscribed", discountPercent: 0, availableCourses: [], offerRow, settings };
  }
  if (offerRow.status === "stopped") {
    return { eligible: false, reason: "stopped", discountPercent: 0, availableCourses: [], offerRow, settings };
  }

  const purchasedIds = getStudentPurchasedCourseIds(db, userId);
  const classCourses = getCoursesForClass(db, className);
  const unpurchased = classCourses.filter((c) => !purchasedIds.has(Number(c.id)));

  if (unpurchased.length === 0) {
    return { eligible: false, reason: "no_unpurchased_courses_in_class", discountPercent: 0, availableCourses: [], className, offerRow, settings };
  }

  const todayIst = getIstDateKey(nowDate);
  const daysElapsed = diffDaysIst(offerRow.offer_start_date_ist, todayIst);
  const { weekNumber, discountPercent, expired } = computeWeeklyDiscountPercent(daysElapsed, settings.post4WeekBehavior);

  if (expired || discountPercent <= 0) {
    return {
      eligible: false,
      reason: "offer_window_expired",
      discountPercent: 0,
      weekNumber,
      daysElapsed,
      className,
      availableCourses: [],
      offerRow,
      settings,
    };
  }

  const pricedCourses = unpurchased.map((c) => {
    const monthlyBase = Math.max(0, Number(c.monthly_fee || 0));
    const yearlyBase = Math.max(0, Number(c.yearly_fee || 0));
    const basePrice = yearlyBase > 0 ? yearlyBase : monthlyBase;
    const discountAmount = Math.round((basePrice * discountPercent) / 100);
    const finalPrice = Math.max(0, basePrice - discountAmount);
    const monthlyFinal = Math.max(0, monthlyBase - Math.round((monthlyBase * discountPercent) / 100));
    return {
      id: c.id,
      title: c.title,
      subject: c.title,
      class_level: c.category || className,
      duration: c.duration_months ? `${c.duration_months} Months` : "12 Months",
      monthlyFee: monthlyBase,
      monthlyFinalPrice: monthlyFinal,
      yearlyFee: yearlyBase,
      basePrice,
      discountPercent,
      discountAmount,
      finalPrice,
    };
  });

  const message = `Yuitor ki taraf se aapko ek offer diya gaya hai. Agar aap ek aur course add karte hain to aapko ${discountPercent}% off milega.`;

  return {
    eligible: true,
    reason: "eligible",
    userId,
    studentName: user.full_name,
    email: user.email,
    className,
    offerStartDateIst: offerRow.offer_start_date_ist,
    daysElapsed,
    weekNumber,
    discountPercent,
    message,
    availableCourses: pricedCourses,
    offerRow,
    settings,
  };
}

export function calculateServerSideCourseCheckout(db, { userId, courseId, basePrice, couponCode = "", useCrossSell = true }) {
  const cleanBase = Math.max(0, Number(basePrice) || 0);
  const cleanCoupon = String(couponCode || "").trim();
  const cs = computeStudentCrossSellState(db, userId);
  const isCourseEligibleForCrossSell = Boolean(
    useCrossSell &&
    cs.eligible &&
    cs.discountPercent > 0 &&
    cs.availableCourses.some((c) => Number(c.id) === Number(courseId))
  );

  // Enforce NO STACKING between cross-sell offer and normal coupon codes
  if (isCourseEligibleForCrossSell && cleanCoupon) {
    return {
      ok: false,
      code: "COUPON_STACKING_NOT_ALLOWED",
      error: "Cross-sell discount cannot be combined with coupon codes. Please remove the coupon to use your cross-sell offer or disable cross-sell.",
      basePrice: cleanBase,
      discountPercent: 0,
      discountAmount: 0,
      finalPrice: cleanBase,
      appliedCrossSell: false,
    };
  }

  if (isCourseEligibleForCrossSell) {
    const discountAmount = Math.round((cleanBase * cs.discountPercent) / 100);
    const finalPrice = Math.max(0, cleanBase - discountAmount);
    return {
      ok: true,
      basePrice: cleanBase,
      discountPercent: cs.discountPercent,
      discountAmount,
      finalPrice,
      appliedCrossSell: true,
      weekNumber: cs.weekNumber,
    };
  }

  return {
    ok: true,
    basePrice: cleanBase,
    discountPercent: 0,
    discountAmount: 0,
    finalPrice: cleanBase,
    appliedCrossSell: false,
  };
}

export function markCrossSellPurchased(db, userId, courseId = null) {
  try {
    db.prepare(`
      INSERT INTO v31_cross_sell_offers (user_id, offer_start_date_ist, last_sent_week, status, updated_at)
      VALUES (?, ?, 0, 'purchased', datetime('now'))
      ON CONFLICT(user_id) DO UPDATE SET status = 'purchased', updated_at = datetime('now')
    `).run(userId, getIstDateKey());
    logV31Audit(db, {
      actorId: userId,
      actorName: "Student",
      actorRole: "student",
      action: "cross_sell_purchased",
      entityType: "cross_sell_offer",
      entityId: String(userId),
      summary: `Cross-sell offer completed and stopped after purchase${courseId ? ` (Course #${courseId})` : ""}`,
      after: { status: "purchased", courseId },
    });
  } catch {
    // ignore
  }
}

export async function runCrossSellWeeklyDispatch(db, deps = {}, { dryRun = false, nowDate = new Date() } = {}) {
  const settings = getCrossSellSettings(db);
  if (!dryRun && !settings.masterSwitch) {
    return {
      ok: true,
      dryRun: false,
      masterSwitch: false,
      skippedAll: true,
      reason: "Master Switch is OFF",
      eligibleCount: 0,
      eligibleStudents: [],
      sentCount: 0,
      failedCount: 0,
    };
  }

  const students = db.prepare(`
    SELECT id, full_name, email FROM users
    WHERE role = 'student' AND is_active = 1
      AND COALESCE(deleted_at, '') = ''
      AND LOWER(COALESCE(verification_status, 'approved')) NOT IN ('suspended', 'terminated', 'exited', 'alumni', 'inactive', 'deleted', 'rejected')
      AND COALESCE(promo_unsubscribed, 0) = 0
  `).all();

  const eligibleStudents = [];
  const mailQueue = [];
  const baseUrl = getAppBaseUrl(deps);

  for (const stu of students) {
    const state = computeStudentCrossSellState(db, stu.id, nowDate);
    if (!state.eligible) continue;

    const alreadySentThisWeek = Number(state.offerRow?.last_sent_week || 0) >= Number(state.weekNumber);
    const previewItem = {
      userId: stu.id,
      name: stu.full_name,
      email: stu.email,
      className: state.className,
      weekNumber: state.weekNumber,
      discountPercent: state.discountPercent,
      alreadySentThisWeek,
      courses: state.availableCourses.map((c) => `${c.title} (₹${c.finalPrice} instead of ₹${c.basePrice})`),
      message: state.message,
    };
    eligibleStudents.push(previewItem);

    if (!dryRun && !alreadySentThisWeek && stu.email) {
      const coursesHtml = `<ul style="margin:6px 0;padding-left:20px;">${state.availableCourses
        .map(
          (c) =>
            `<li><strong>${escapeHtml(c.title)}</strong> — <span style="text-decoration:line-through;color:#64748B;">₹${c.basePrice}</span> <strong style="color:#16A34A;">₹${c.finalPrice}</strong> (${c.discountPercent}% OFF)</li>`
        )
        .join("")}</ul>`;

      mailQueue.push({
        userId: stu.id,
        to: stu.email,
        templateKey: "cross_sell_weekly_offer",
        category: "promotional",
        dedupeKey: `cross_sell:${stu.id}:week_${state.weekNumber}`,
        vars: {
          name: stu.full_name,
          class_name: state.className,
          discount: String(state.discountPercent),
          week_number: String(state.weekNumber),
          course: coursesHtml,
          login_link: `${baseUrl}/student`,
        },
        _weekNumber: state.weekNumber,
      });
    }
  }

  let sentCount = 0;
  let failedCount = 0;

  if (!dryRun && mailQueue.length > 0) {
    const results = await sendBatchedV31Mails(db, deps, mailQueue, 20);
    const updSent = db.prepare(`
      UPDATE v31_cross_sell_offers
      SET last_sent_week = ?, last_sent_at_ist = ?, updated_at = datetime('now')
      WHERE user_id = ?
    `);
    results.forEach((res, idx) => {
      const item = mailQueue[idx];
      if (res.ok && !res.skipped) {
        sentCount += 1;
        updSent.run(item._weekNumber, getIstTimestamp(), item.userId);
      } else if (!res.ok) {
        failedCount += 1;
      }
    });
  }

  return {
    ok: true,
    dryRun,
    masterSwitch: settings.masterSwitch,
    post4WeekBehavior: settings.post4WeekBehavior,
    eligibleCount: eligibleStudents.length,
    eligibleStudents,
    sentCount,
    failedCount,
  };
}

export function getStudentClassFilteredBatches(db, userId) {
  const className = getStudentCurrentClass(db, userId);
  const targetCode = normalizeClassCode(className);
  if (!targetCode) return { className: "", batches: [] };

  let rows = [];
  try {
    rows = db.prepare(`
      SELECT
        b.id, b.name, b.code, b.room_name, b.seat_limit, b.total_seats,
        b.schedule_days, b.start_time, b.end_time, b.start_date, b.duration, b.class_name, b.teacher_id,
        c.title AS course_title, c.category AS course_category, c.duration_months AS course_duration_months,
        u.full_name AS teacher_name
      FROM batches b
      LEFT JOIN courses c ON c.id = b.course_id
      LEFT JOIN users u ON u.id = b.teacher_id
      WHERE COALESCE(b.is_active, 1) = 1
      ORDER BY b.id DESC
    `).all();
  } catch {
    rows = [];
  }

  // Filter strictly by student's current class!
  const matched = rows.filter((b) => {
    const code = normalizeClassCode(b.class_name || b.course_category || b.name || b.course_title);
    return code && code === targetCode;
  });

  const batches = matched.map((b) => {
    let activeCount = 0;
    try {
      const cnt = db.prepare(`
        SELECT COUNT(*) AS c FROM enrollments e
        JOIN users u ON u.id = e.student_id
        WHERE e.batch_id = ? AND u.is_active = 1 AND COALESCE(u.deleted_at, '') = ''
          AND LOWER(COALESCE(u.verification_status, 'approved')) NOT IN ('suspended', 'terminated', 'deleted')
      `).get(b.id);
      activeCount = Number(cnt?.c || 0);
    } catch {
      activeCount = 0;
    }
    const totalSeats = Math.max(1, Number(b.seat_limit || b.total_seats || 30));
    const timing = b.schedule_days
      ? `${b.schedule_days} · ${b.start_time || "16:00"} – ${b.end_time || "17:30"} IST`
      : "Mon–Sat · 4:00 PM – 5:30 PM IST";
    const duration =
      b.duration || (b.course_duration_months ? `${b.course_duration_months} Months` : "12 Months");
    return {
      id: b.id,
      name: b.name || b.course_title || `Class ${targetCode} Batch`,
      subject: b.course_title || b.name || "Core Subject",
      className,
      startDate: b.start_date || getIstDateKey(),
      duration,
      teacherName: b.teacher_name || "Assigned Faculty",
      timing,
      roomName: b.room_name || "",
      totalSeats,
      activeStudents: activeCount,
      vacantSeats: Math.max(0, totalSeats - activeCount),
    };
  });

  // Fallback to class-matched active courses if no explicit batch rows exist yet for that class
  if (batches.length === 0) {
    const classCourses = getCoursesForClass(db, className);
    for (const c of classCourses) {
      batches.push({
        id: `course-${c.id}`,
        name: c.title,
        subject: c.title,
        className,
        startDate: getIstDateKey(),
        duration: c.duration_months ? `${c.duration_months} Months` : "Full Academic Session",
        teacherName: "Yuitor Senior Faculty",
        timing: "Schedule shared on orientation",
        roomName: "",
        totalSeats: 30,
        activeStudents: 0,
        vacantSeats: 30,
      });
    }
  }

  return { className, batches };
}

export function saveBase64ProfilePhoto(dataUrl, uploadsDir, userId) {
  const raw = String(dataUrl || "").trim();
  const match = raw.match(/^data:(image\/(?:jpeg|jpg|png));base64,([A-Za-z0-9+/=]+)$/i);
  if (!match) {
    return { ok: false, error: "Only JPG and PNG images are allowed." };
  }
  const mime = match[1].toLowerCase();
  const buf = Buffer.from(match[2], "base64");
  const maxBytes = 2 * 1024 * 1024; // 2 MB limit
  if (buf.length === 0 || buf.length > maxBytes) {
    return { ok: false, error: "Photo size must be under 2 MB." };
  }
  // Verify magic bytes (JPEG FF D8 FF, PNG 89 50 4E 47)
  const isJpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  if (!isJpeg && !isPng) {
    return { ok: false, error: "Invalid image file signature. Upload a genuine JPG or PNG photo." };
  }

  const ext = isPng || mime.includes("png") ? "png" : "jpg";
  const dir = uploadsDir || path.resolve(process.cwd(), "uploads");
  fs.mkdirSync(dir, { recursive: true });
  const filename = `profile_${userId}_${Date.now()}.${ext}`;
  fs.writeFileSync(path.join(dir, filename), buf);
  return { ok: true, photoUrl: `/uploads/${filename}` };
}
