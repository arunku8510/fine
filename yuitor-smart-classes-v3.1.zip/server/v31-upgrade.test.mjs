import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import {
  ensureV31Schema,
  sanitizeMailHtml,
  applyMailTheme,
  isUserBlockedStatus,
  classifyUserStatusTab,
  isFutureIstDate,
  getIstTimestamp,
  sendV31Mail,
  sendBatchedV31Mails,
  computeStudentCrossSellState,
  calculateServerSideCourseCheckout,
  markCrossSellPurchased,
  runCrossSellWeeklyDispatch,
  getStudentClassFilteredBatches,
  saveBase64ProfilePhoto,
  logV31Audit,
  DEFAULT_V31_TEMPLATES,
} from "./v31-engine.mjs";

function createTestDb() {
  const db = new DatabaseSync(":memory:");
  db.exec(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      role TEXT NOT NULL,
      password_hash TEXT DEFAULT '',
      verification_status TEXT DEFAULT 'approved',
      is_active INTEGER DEFAULT 1,
      mobile_verified INTEGER DEFAULT 1,
      avatar_url TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE student_profiles (
      user_id INTEGER PRIMARY KEY,
      roll_number TEXT,
      class_level TEXT,
      board TEXT DEFAULT 'UP Board',
      course_duration_months INTEGER DEFAULT 12,
      enrollment_status TEXT DEFAULT 'active'
    );
    CREATE TABLE teacher_profiles (
      user_id INTEGER PRIMARY KEY,
      qualification TEXT DEFAULT 'M.Sc',
      experience_years INTEGER DEFAULT 3
    );
    CREATE TABLE courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE,
      category TEXT DEFAULT 'Class 10',
      class_range TEXT DEFAULT '',
      board TEXT DEFAULT 'UP Board',
      description TEXT DEFAULT '',
      duration_months INTEGER DEFAULT 12,
      monthly_fee INTEGER DEFAULT 800,
      yearly_fee INTEGER DEFAULT 8640,
      is_active INTEGER DEFAULT 1
    );
    CREATE TABLE batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT,
      course_id INTEGER,
      teacher_id INTEGER,
      seat_limit INTEGER DEFAULT 30,
      schedule_days TEXT DEFAULT 'Mon-Sat',
      start_time TEXT DEFAULT '04:00 PM',
      end_time TEXT DEFAULT '05:30 PM',
      start_date TEXT DEFAULT '2026-04-01',
      room_name TEXT DEFAULT 'Room A',
      is_active INTEGER DEFAULT 1
    );
    CREATE TABLE enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      course_id INTEGER NOT NULL,
      batch_id INTEGER,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER,
      course_id INTEGER,
      amount INTEGER DEFAULT 0,
      verification_status TEXT DEFAULT 'verified',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token_hash TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_user_id INTEGER,
      target_user_id INTEGER,
      action TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  ensureV31Schema(db);
  return db;
}

test("v3.1 HTML sanitizer strips scripts, inline handlers, javascript: URLs, and embeds theme safely", () => {
  const dirty = `
    <div onclick="alert(1)">
      <h2>Hello {{name}}</h2>
      <script>evil()</script>
      <img src="x" onerror="steal()">
      <a href="javascript:alert(2)">Bad</a>
      <a href="https://yuitor.com/login">Good Link</a>
    </div>`;
  const clean = sanitizeMailHtml(dirty);
  assert.equal(/<script/i.test(clean), false);
  assert.equal(/onerror/i.test(clean), false);
  assert.equal(/onclick/i.test(clean), false);
  assert.equal(/javascript:/i.test(clean), false);
  assert.ok(clean.includes("https://yuitor.com/login"));

  const themed = applyMailTheme("yuitor_navy", clean, {
    subject: "Welcome",
    brandName: "Yuitor Smart Classes",
  });
  assert.ok(themed.includes("#101B3D"));
  assert.ok(themed.includes("Good Link"));
  assert.equal(/<script/i.test(themed), false);
});

test("v3.1 Default rewritten templates contain mandatory welcome sentence and Hinglish cross-sell copy", () => {
  const welcomeTpl = DEFAULT_V31_TEMPLATES.find((t) => t.template_key === "student_welcome_admission");
  assert.ok(welcomeTpl, "student_welcome_admission template must exist");
  assert.ok(
    welcomeTpl.body_html.includes(
      "Your admission is successful. Welcome to the Yuitor family. Yuitor congratulates you."
    )
  );

  const csTpl = DEFAULT_V31_TEMPLATES.find((t) => t.template_key === "cross_sell_weekly_offer");
  assert.ok(csTpl, "cross_sell_weekly_offer template must exist");
  assert.ok(
    csTpl.body_html.includes(
      "Yuitor ki taraf se aapko ek offer diya gaya hai. Agar aap ek aur course add karte hain to aapko {{discount}}% off milega."
    )
  );
  assert.ok(csTpl.body_html.includes("{{unsubscribe_link}}"));
});

test("v3.1 Status classification & blocked login guards enforce Active/Suspended/Terminated/Others tabs", () => {
  assert.equal(isUserBlockedStatus({ verification_status: "approved", is_active: 1 }).blocked, false);
  assert.equal(isUserBlockedStatus({ verification_status: "suspended", is_active: 0 }).blocked, true);
  assert.equal(isUserBlockedStatus({ verification_status: "terminated", is_active: 0 }).blocked, true);
  assert.equal(
    isUserBlockedStatus({ verification_status: "approved", is_active: 1, deleted_at: "2026-01-01" }).blocked,
    true
  );

  assert.equal(classifyUserStatusTab({ verification_status: "approved", is_active: 1 }), "active");
  assert.equal(classifyUserStatusTab({ verification_status: "suspended", is_active: 0 }), "suspended");
  assert.equal(classifyUserStatusTab({ verification_status: "terminated", is_active: 0 }), "terminated");
  assert.equal(classifyUserStatusTab({ verification_status: "deleted", is_active: 0, deleted_at: "2026-01-01" }), "others");
  assert.equal(classifyUserStatusTab({ verification_status: "rejected", is_active: 0 }), "others");
});

test("v3.1 Duplicate mail guard, unsubscribe promo-only rule, and batched bulk sends work reliably", async () => {
  const db = createTestDb();
  db.prepare("INSERT INTO users (full_name, email, phone, role, promo_unsubscribed) VALUES (?, ?, ?, ?, ?)").run(
    "Aarav Sharma",
    "aarav@example.com",
    "9876543210",
    "student",
    1
  );
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get("aarav@example.com");

  let sentCount = 0;
  const mockSend = async () => {
    sentCount++;
    return { ok: true, messageId: `msg-${sentCount}` };
  };

  // Promotional mail MUST be skipped for unsubscribed user
  const promoRes = await sendV31Mail(
    db,
    { sendEmailDirect: mockSend },
    {
      userId: user.id,
      to: user.email,
      templateKey: "cross_sell_weekly_offer",
      category: "promotional",
      vars: { name: user.full_name, discount: "10", course: "Science", login_link: "https://yuitor.com/login" },
      dedupeKey: "promo-test-1",
    }
  );
  assert.equal(promoRes.skipped, true);
  assert.equal(promoRes.unsubscribed, true);
  assert.equal(sentCount, 0);

  // Transactional mail MUST STILL SEND even when promo_unsubscribed = 1
  const tx1 = await sendV31Mail(
    db,
    { sendEmailDirect: mockSend },
    {
      userId: user.id,
      to: user.email,
      templateKey: "account_suspended",
      category: "transactional",
      vars: { name: user.full_name, reason: "Fee Non-Payment", note: "Clear dues" },
      dedupeKey: "suspend-action-101",
    }
  );
  assert.equal(tx1.ok, true);
  assert.equal(sentCount, 1);

  // Duplicate guard MUST block a second send with the same dedupeKey
  const txDup = await sendV31Mail(
    db,
    { sendEmailDirect: mockSend },
    {
      userId: user.id,
      to: user.email,
      templateKey: "account_suspended",
      category: "transactional",
      vars: { name: user.full_name, reason: "Fee Non-Payment", note: "Clear dues" },
      dedupeKey: "suspend-action-101",
    }
  );
  assert.equal(txDup.skipped, true);
  assert.equal(txDup.duplicate, true);
  assert.equal(sentCount, 1);

  // Batched bulk send test
  const batchRes = await sendBatchedV31Mails(
    db,
    { sendEmailDirect: mockSend },
    [
      { to: "a1@example.com", subject: "Test 1", bodyHtml: "<p>Hi 1</p>", dedupeKey: "b-1" },
      { to: "a2@example.com", subject: "Test 2", bodyHtml: "<p>Hi 2</p>", dedupeKey: "b-2" },
    ],
    1
  );
  assert.equal(batchRes.length, 2);
  assert.equal(batchRes.filter((r) => r.ok && !r.skipped).length, 2);
});

test("v3.1 Cross-Sell Engine: default OFF, active-only, W1-W4 progression, tamper-proof checkout, no coupon stacking, stops on purchase", async () => {
  const db = createTestDb();

  // Verify default settings: Master Switch OFF (0), Post-4-week = 'stop'
  const settings = db.prepare("SELECT * FROM v31_cross_sell_settings WHERE id = 1").get();
  assert.equal(settings.master_switch, 0);
  assert.equal(settings.post_4_week_behavior, "stop");

  // Seed 2 Class 10 courses and 1 Class 11 course
  db.prepare("INSERT INTO courses (title, slug, category, monthly_fee, yearly_fee) VALUES (?, ?, ?, ?, ?)").run(
    "Class 10 Maths",
    "c10-maths",
    "Class 10",
    1000,
    10000
  );
  db.prepare("INSERT INTO courses (title, slug, category, monthly_fee, yearly_fee) VALUES (?, ?, ?, ?, ?)").run(
    "Class 10 Science",
    "c10-sci",
    "Class 10",
    1000,
    10000
  );
  db.prepare("INSERT INTO courses (title, slug, category, monthly_fee, yearly_fee) VALUES (?, ?, ?, ?, ?)").run(
    "Class 11 Physics",
    "c11-phy",
    "Class 11",
    1200,
    12000
  );

  // Seed Active student & Suspended student in Class 10
  const stu1 = Number(
    db
      .prepare(
        "INSERT INTO users (full_name, email, phone, role, verification_status, is_active) VALUES (?, ?, ?, 'student', 'approved', 1)"
      )
      .run("Riya Verma", "riya@example.com", "9999999901").lastInsertRowid
  );
  db.prepare(
    "INSERT INTO student_profiles (user_id, roll_number, class_level, enrollment_status) VALUES (?, 'YTR-101', 'Class 10', 'active')"
  ).run(stu1);

  const stuSusp = Number(
    db
      .prepare(
        "INSERT INTO users (full_name, email, phone, role, verification_status, is_active) VALUES (?, ?, ?, 'student', 'suspended', 0)"
      )
      .run("Suspended Kid", "susp@example.com", "9999999902").lastInsertRowid
  );
  db.prepare(
    "INSERT INTO student_profiles (user_id, roll_number, class_level, enrollment_status) VALUES (?, 'YTR-102', 'Class 10', 'active')"
  ).run(stuSusp);

  // Enroll stu1 in Course 1 (Class 10 Maths)
  db.prepare("INSERT INTO enrollments (student_id, course_id, status) VALUES (?, 1, 'active')").run(stu1);

  // When Master Switch is OFF, dispatch skips cleanly
  const offDispatch = await runCrossSellWeeklyDispatch(
    db,
    { sendEmailDirect: async () => ({ ok: true }) },
    { dryRun: false }
  );
  assert.equal(offDispatch.skippedAll, true);

  // Turn Master Switch ON
  db.prepare("UPDATE v31_cross_sell_settings SET master_switch = 1 WHERE id = 1").run();

  // Suspended student is NEVER eligible
  const suspState = computeStudentCrossSellState(db, stuSusp);
  assert.equal(suspState.eligible, false);

  // Active student is eligible in Week 1 (10% off) for Course 2 (Class 10 Science ONLY, NOT Class 11 Physics)
  const w1 = computeStudentCrossSellState(db, stu1);
  assert.equal(w1.eligible, true);
  assert.equal(w1.weekNumber, 1);
  assert.equal(w1.discountPercent, 10);
  assert.equal(w1.availableCourses.length, 1);
  assert.equal(w1.availableCourses[0].title, "Class 10 Science");
  assert.equal(w1.availableCourses[0].monthlyFinalPrice, 900);

  // Simulate Week 3 (15 days after offer start) => 30% discount
  const fifteenDaysAgo = new Date(Date.now() - 15 * 86400000).toISOString().slice(0, 10);
  db.prepare("UPDATE v31_cross_sell_offers SET offer_start_date_ist = ? WHERE user_id = ?").run(fifteenDaysAgo, stu1);
  const w3 = computeStudentCrossSellState(db, stu1);
  assert.equal(w3.weekNumber, 3);
  assert.equal(w3.discountPercent, 30);

  // Server-side checkout rejects stacking normal coupon with cross-sell discount
  const stacked = calculateServerSideCourseCheckout(db, {
    userId: stu1,
    courseId: 2,
    basePrice: 1000,
    couponCode: "YUITOR10",
  });
  assert.equal(stacked.ok, false);
  assert.equal(stacked.code, "COUPON_STACKING_NOT_ALLOWED");

  // Server-side checkout computes tamper-proof 30% discount
  const quote = calculateServerSideCourseCheckout(db, {
    userId: stu1,
    courseId: 2,
    basePrice: 1000,
    couponCode: "",
  });
  assert.equal(quote.ok, true);
  assert.equal(quote.discountPercent, 30);
  assert.equal(quote.basePrice, 1000);
  assert.equal(quote.discountAmount, 300);
  assert.equal(quote.finalPrice, 700);

  // Simulate post-4-week (35 days ago): default 'stop' -> 0% / not eligible; 'hold_40' -> 40%
  const thirtyFiveDaysAgo = new Date(Date.now() - 35 * 86400000).toISOString().slice(0, 10);
  db.prepare("UPDATE v31_cross_sell_offers SET offer_start_date_ist = ? WHERE user_id = ?").run(thirtyFiveDaysAgo, stu1);
  assert.equal(computeStudentCrossSellState(db, stu1).eligible, false);

  db.prepare("UPDATE v31_cross_sell_settings SET post_4_week_behavior = 'hold_40' WHERE id = 1").run();
  const held = computeStudentCrossSellState(db, stu1);
  assert.equal(held.eligible, true);
  assert.equal(held.discountPercent, 40);

  // Purchase stops cross-sell immediately
  markCrossSellPurchased(db, stu1, 2);
  const afterBuy = computeStudentCrossSellState(db, stu1);
  assert.equal(afterBuy.eligible, false);
});

test("v3.1 Student Class-Filtered Batches, DOB validation, JPG/PNG magic-byte photo validation, and IST Audit Logs", () => {
  const db = createTestDb();
  db.prepare(
    "INSERT INTO users (full_name, email, phone, role) VALUES ('Prof. Mehta', 'mehta@example.com', '9800000001', 'teacher')"
  ).run();
  const tid = db.prepare("SELECT id FROM users WHERE email = 'mehta@example.com'").get().id;

  db.prepare(
    "INSERT INTO users (full_name, email, phone, role) VALUES ('Kabir', 'kabir@example.com', '9800000002', 'student')"
  ).run();
  const sid = db.prepare("SELECT id FROM users WHERE email = 'kabir@example.com'").get().id;
  db.prepare("INSERT INTO student_profiles (user_id, class_level) VALUES (?, 'Class 9')").run(sid);

  const c9 = Number(
    db
      .prepare("INSERT INTO courses (title, slug, category, duration_months) VALUES ('Class 9 Maths', 'c9-m', 'Class 9', 12)")
      .run().lastInsertRowid
  );
  const c10 = Number(
    db
      .prepare("INSERT INTO courses (title, slug, category, duration_months) VALUES ('Class 10 Maths', 'c10-m', 'Class 10', 12)")
      .run().lastInsertRowid
  );

  db.prepare(
    "INSERT INTO batches (name, course_id, teacher_id, start_date, schedule_days, start_time, end_time, is_active) VALUES ('Batch 9A', ?, ?, '2026-05-01', 'Mon-Fri', '4:00 PM', '5:00 PM', 1)"
  ).run(c9, tid);
  db.prepare(
    "INSERT INTO batches (name, course_id, teacher_id, start_date, schedule_days, start_time, end_time, is_active) VALUES ('Batch 10A', ?, ?, '2026-05-01', 'Mon-Fri', '5:30 PM', '6:30 PM', 1)"
  ).run(c10, tid);

  // Immediately shows ONLY Class 9 batch
  const b9 = getStudentClassFilteredBatches(db, sid);
  assert.equal(b9.batches.length, 1);
  assert.equal(b9.batches[0].name, "Batch 9A");
  assert.equal(b9.batches[0].teacherName, "Prof. Mehta");

  // After Class Change to Class 10, hides Class 9 and shows Class 10 immediately
  db.prepare("UPDATE student_profiles SET class_level = 'Class 10' WHERE user_id = ?").run(sid);
  const b10 = getStudentClassFilteredBatches(db, sid);
  assert.equal(b10.batches.length, 1);
  assert.equal(b10.batches[0].name, "Batch 10A");

  // Future IST DOB validation
  assert.equal(isFutureIstDate("2099-01-01"), true);
  assert.equal(isFutureIstDate("2008-05-15"), false);

  // Photo magic-byte validation (reject fake PNG, accept valid PNG)
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "yuitor-v31-test-"));
  const badPhoto = saveBase64ProfilePhoto(
    "data:image/png;base64," + Buffer.from("NOT_A_PNG").toString("base64"),
    tmpDir,
    sid
  );
  assert.equal(badPhoto.ok, false);

  // Minimal valid 1x1 PNG bytes
  const validPngB64 =
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
  const goodPhoto = saveBase64ProfilePhoto(`data:image/png;base64,${validPngB64}`, tmpDir, sid);
  assert.equal(goodPhoto.ok, true);
  assert.ok(goodPhoto.photoUrl.startsWith("/uploads/profile_"));
  fs.rmSync(tmpDir, { recursive: true, force: true });

  // IST Audit Log
  logV31Audit(db, {
    actorId: tid,
    actorName: "Prof. Mehta",
    actorRole: "admin",
    action: "student_class_change",
    entityType: "student",
    entityId: String(sid),
    summary: "Class 9 -> Class 10",
  });
  const logged = db.prepare("SELECT * FROM v31_audit_logs WHERE action = 'student_class_change'").get();
  assert.ok(logged);
  assert.ok(getIstTimestamp().endsWith("IST"));
});
