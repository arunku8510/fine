(() => {
  "use strict";

  if (window.YuitorUI) return;

  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* --------------------------------------------------------------------------
   * 1. Non-blocking Toast Notifications
   * ------------------------------------------------------------------------ */
  let toastStack = null;
  function ensureToastStack() {
    if (toastStack && document.body.contains(toastStack)) return toastStack;
    toastStack = document.createElement("div");
    toastStack.className = "yu-toast-stack";
    toastStack.setAttribute("aria-live", "polite");
    document.body.appendChild(toastStack);
    return toastStack;
  }

  const Toast = {
    show(message, type = "info", durationMs = 3800) {
      const text = String(message || "").trim();
      if (!text) return null;
      const stack = ensureToastStack();
      const el = document.createElement("div");
      el.className = `yu-toast yu-toast--${["success", "error", "warn", "info"].includes(type) ? type : "info"}`;
      const iconMap = {
        success: "✓",
        error: "!",
        warn: "⚠",
        info: "i",
      };
      el.innerHTML = `
        <span class="yu-toast-icon" aria-hidden="true">${iconMap[type] || "i"}</span>
        <span class="yu-toast-msg">${esc(text)}</span>
        <button type="button" class="yu-toast-close" aria-label="Dismiss notification">&times;</button>
      `;
      const dismiss = () => {
        el.classList.add("is-leaving");
        setTimeout(() => {
          if (el.parentNode) el.parentNode.removeChild(el);
        }, 180);
      };
      el.querySelector(".yu-toast-close")?.addEventListener("click", dismiss);
      stack.appendChild(el);
      if (durationMs > 0) {
        setTimeout(dismiss, durationMs);
      }
      return el;
    },
    success(msg, ms) {
      return Toast.show(msg, "success", ms);
    },
    error(msg, ms) {
      return Toast.show(msg, "error", ms || 5200);
    },
    warn(msg, ms) {
      return Toast.show(msg, "warn", ms || 4500);
    },
    info(msg, ms) {
      return Toast.show(msg, "info", ms);
    },
  };

  /* --------------------------------------------------------------------------
   * 2. Breadcrumbs
   * ------------------------------------------------------------------------ */
  function renderBreadcrumbs(items = []) {
    const clean = (Array.isArray(items) ? items : []).filter((it) => it && it.label);
    if (!clean.length) return "";
    return `
      <nav class="yu-breadcrumbs" aria-label="Breadcrumb">
        <ol class="yu-bc-list">
          ${clean
            .map((it, idx) => {
              const isLast = idx === clean.length - 1;
              const sep = idx > 0 ? `<li class="yu-bc-sep" aria-hidden="true">/</li>` : "";
              if (isLast || (!it.tab && !it.href && !it.action)) {
                return `${sep}<li class="yu-bc-item is-current" aria-current="page">${esc(it.label)}</li>`;
              }
              return `${sep}<li class="yu-bc-item"><button type="button" class="yu-bc-link" data-yu-bc-tab="${esc(
                it.tab || ""
              )}" data-yu-bc-sub="${esc(it.sub || "")}" data-yu-bc-role="${esc(it.role || "")}">${esc(it.label)}</button></li>`;
            })
            .join("")}
        </ol>
      </nav>
    `;
  }

  function bindBreadcrumbs(rootEl, onSelect) {
    if (!rootEl || typeof onSelect !== "function") return;
    rootEl.querySelectorAll("[data-yu-bc-tab]").forEach((btn) => {
      btn.addEventListener("click", () => {
        onSelect({
          tab: btn.getAttribute("data-yu-bc-tab") || "",
          sub: btn.getAttribute("data-yu-bc-sub") || "",
          role: btn.getAttribute("data-yu-bc-role") || "",
        });
      });
    });
  }

  /* --------------------------------------------------------------------------
   * 3. Floating Fixed "Manage" Row Action Menu (never clipped by scroll boxes)
   * ------------------------------------------------------------------------ */
  let activeMenuEl = null;
  let activeMenuCleanup = null;

  function closeManageMenu() {
    if (typeof activeMenuCleanup === "function") {
      try {
        activeMenuCleanup();
      } catch {
        // ignore cleanup errors
      }
    }
    if (activeMenuEl && activeMenuEl.parentNode) {
      activeMenuEl.parentNode.removeChild(activeMenuEl);
    }
    activeMenuEl = null;
    activeMenuCleanup = null;
  }

  function openManageMenu(anchorEl, items = []) {
    if (!anchorEl) return;
    const wasSame = activeMenuEl && activeMenuEl._anchor === anchorEl;
    closeManageMenu();
    if (wasSame) return;

    const validItems = (Array.isArray(items) ? items : []).filter(Boolean);
    if (!validItems.length) return;

    const menu = document.createElement("div");
    menu.className = "yu-manage-menu";
    menu.setAttribute("role", "menu");
    const inDark = Boolean(anchorEl.closest(".portal-dark"));
    if (inDark) menu.classList.add("is-dark");
    menu._anchor = anchorEl;

    validItems.forEach((item) => {
      if (item.divider) {
        const div = document.createElement("div");
        div.className = "yu-manage-divider";
        menu.appendChild(div);
        return;
      }
      if (item.href) {
        const a = document.createElement("a");
        a.className = `yu-manage-item${item.danger ? " is-danger" : ""}`;
        a.href = item.href;
        if (item.target) a.target = item.target;
        a.rel = "noopener noreferrer";
        a.setAttribute("role", "menuitem");
        a.innerHTML = `<span class="yu-manage-label">${esc(item.label)}</span>${
          item.badge ? `<span class="yu-manage-badge">${esc(item.badge)}</span>` : ""
        }`;
        a.addEventListener("click", (e) => {
          e.stopPropagation();
          closeManageMenu();
        });
        menu.appendChild(a);
        return;
      }
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `yu-manage-item${item.danger ? " is-danger" : ""}${item.primary ? " is-primary" : ""}`;
      btn.setAttribute("role", "menuitem");
      if (item.disabled) btn.disabled = true;
      btn.innerHTML = `<span class="yu-manage-label">${esc(item.label)}</span>${
        item.badge ? `<span class="yu-manage-badge">${esc(item.badge)}</span>` : ""
      }`;
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeManageMenu();
        if (typeof item.onClick === "function" && !item.disabled) {
          item.onClick();
        }
      });
      menu.appendChild(btn);
    });

    document.body.appendChild(menu);
    activeMenuEl = menu;

    // Smart viewport positioning
    const rect = anchorEl.getBoundingClientRect();
    const mw = Math.max(menu.offsetWidth || 200, 195);
    const mh = menu.offsetHeight || 220;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = rect.right - mw;
    if (left < 8) left = Math.min(vw - mw - 8, Math.max(8, rect.left));
    let top = rect.bottom + 6;
    if (top + mh > vh - 12 && rect.top - mh - 6 > 8) {
      top = rect.top - mh - 6;
    } else if (top + mh > vh - 8) {
      top = Math.max(8, vh - mh - 8);
    }
    menu.style.left = `${Math.round(left)}px`;
    menu.style.top = `${Math.round(top)}px`;

    const onOutside = (e) => {
      if (!menu.contains(e.target) && !anchorEl.contains(e.target)) {
        closeManageMenu();
      }
    };
    const onKey = (e) => {
      if (e.key === "Escape") closeManageMenu();
    };
    const onScroll = () => closeManageMenu();

    setTimeout(() => {
      document.addEventListener("click", onOutside, true);
      document.addEventListener("keydown", onKey);
      window.addEventListener("resize", onScroll);
      window.addEventListener("scroll", onScroll, true);
    }, 0);

    activeMenuCleanup = () => {
      document.removeEventListener("click", onOutside, true);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onScroll);
      window.removeEventListener("scroll", onScroll, true);
    };
  }

  /* --------------------------------------------------------------------------
   * 4. Reusable DataTable Enhancer (Columns, Sort, Search, Filter, Pagination,
   *    Sticky Header, Bulk Select, Empty States, Clickable Rows)
   * ------------------------------------------------------------------------ */
  function parseCellSortValue(text) {
    const raw = String(text || "").trim();
    if (!raw || raw === "-" || raw === "—") return { kind: "empty", val: "" };
    // Currency / number detection (e.g., "₹1,250", "85.5%", "120")
    const cleanedNum = raw.replace(/[₹,$%\s,+]/g, "");
    if (/^-?\d+(\.\d+)?$/.test(cleanedNum) && cleanedNum.length <= 15) {
      return { kind: "num", val: Number(cleanedNum) };
    }
    // ISO / standard dates
    if (/^\d{4}-\d{2}-\d{2}/.test(raw)) {
      const t = Date.parse(raw);
      if (!Number.isNaN(t)) return { kind: "num", val: t };
    }
    return { kind: "str", val: raw.toLowerCase() };
  }

  function csvEscape(cellText) {
    const s = String(cellText ?? "").replace(/\s+/g, " ").trim();
    if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  }

  function exportRowsToCsv(filename, headers, rowsCells) {
    const lines = [];
    if (headers.length) lines.push(headers.map(csvEscape).join(","));
    rowsCells.forEach((row) => lines.push(row.map(csvEscape).join(",")));
    const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || `yuitor-export-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  }

  function enhanceSingleTable(table, opts = {}) {
    if (!table || table.dataset.yuEnhanced === "1" || table.dataset.yuNoEnhance === "1") return;
    const thead = table.querySelector("thead");
    const tbody = table.querySelector("tbody");
    if (!thead || !tbody) return;
    const headerRow = thead.querySelector("tr");
    if (!headerRow) return;

    const origHeaders = Array.from(headerRow.children);
    if (!origHeaders.length) return;

    table.dataset.yuEnhanced = "1";
    table.classList.add("yu-dt-table");

    const tableId =
      table.getAttribute("data-yu-table") ||
      "tbl_" +
        origHeaders
          .map((th) => th.textContent.trim().toLowerCase().replace(/[^a-z0-9]+/g, "_"))
          .join("_")
          .slice(0, 48);

    const noPaginate = table.dataset.yuNoPaginate === "1" || table.dataset.yuServerPaged === "1" || Boolean(table.closest("[data-save-test-marks-form]"));
    const hasNativeCheckboxes = Boolean(thead.querySelector("input[type='checkbox']") || tbody.querySelector("input[type='checkbox']"));
    const bulkMode = table.getAttribute("data-yu-bulk") || (table.dataset.yuNoBulk === "1" ? "" : "default");
    const injectBulk = Boolean(bulkMode) && !hasNativeCheckboxes && !table.closest("[data-save-test-marks-form]");

    const scroller = table.closest(".portal-table-scroll") || table.parentElement;
    if (scroller && scroller.classList.contains("portal-table-scroll")) {
      scroller.classList.add("yu-dt-scroll");
    }

    // Wrap around scroller (or table) with toolbar + bulk bar + pager
    const wrapper = document.createElement("div");
    wrapper.className = "yu-dt-wrap";
    wrapper.dataset.yuTableId = tableId;
    const targetNode = scroller && scroller.classList.contains("portal-table-scroll") ? scroller : table;
    targetNode.parentNode.insertBefore(wrapper, targetNode);

    const toolbar = document.createElement("div");
    toolbar.className = "yu-dt-toolbar";
    const bulkBar = document.createElement("div");
    bulkBar.className = "yu-dt-bulkbar hidden";
    const pager = document.createElement("div");
    pager.className = "yu-dt-pager";

    wrapper.appendChild(toolbar);
    wrapper.appendChild(bulkBar);
    wrapper.appendChild(targetNode);
    wrapper.appendChild(pager);

    // Optional Bulk Checkbox Injection
    if (injectBulk) {
      const bulkTh = document.createElement("th");
      bulkTh.className = "yu-dt-check-col";
      bulkTh.setAttribute("data-yu-no-sort", "1");
      bulkTh.setAttribute("data-yu-locked", "1");
      bulkTh.innerHTML = `<input type="checkbox" class="yu-dt-check-all" aria-label="Select all visible rows" />`;
      headerRow.insertBefore(bulkTh, headerRow.firstChild);

      Array.from(tbody.querySelectorAll("tr")).forEach((tr) => {
        if (tr.children.length === 1 && tr.children[0].colSpan > 1) return;
        const td = document.createElement("td");
        td.className = "yu-dt-check-col";
        td.setAttribute("data-no-row-click", "1");
        td.innerHTML = `<input type="checkbox" class="yu-dt-row-check" aria-label="Select row" />`;
        tr.insertBefore(td, tr.firstChild);
      });
    }

    const headers = Array.from(headerRow.children);
    const colOffset = injectBulk ? 1 : 0;

    // Identify data rows (ignore pure empty placeholder rows)
    const rawRows = Array.from(tbody.querySelectorAll("tr")).filter((tr) => {
      if (tr.children.length === 1 && Number(tr.children[0].colSpan || 1) > 1) return false;
      return true;
    });

    // Determine filterable column (status/role/stage)
    let filterColIdx = table.hasAttribute("data-yu-filter-col") ? Number(table.getAttribute("data-yu-filter-col")) + colOffset : -1;
    if (filterColIdx < 0 && rawRows.length >= 2) {
      headers.forEach((th, idx) => {
        if (filterColIdx >= 0) return;
        const label = th.textContent.trim().toLowerCase();
        if (["status", "stage", "type", "role", "category", "mode", "priority"].some((k) => label === k || label.includes(k))) {
          filterColIdx = idx;
        }
      });
    }

    // Collect filter values
    const filterValues = new Set();
    if (filterColIdx >= 0) {
      rawRows.forEach((tr) => {
        const cell = tr.children[filterColIdx];
        const v = (cell?.textContent || "").replace(/\s+/g, " ").trim();
        if (v && v !== "-" && v.length <= 42) filterValues.add(v);
      });
    }

    // Load saved column visibility
    const storageKey = `yu_dt_cols_v1_${tableId}`;
    let hiddenCols = new Set();
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      if (Array.isArray(saved)) hiddenCols = new Set(saved.map(Number));
    } catch {
      hiddenCols = new Set();
    }

    const lockedCols = new Set();
    headers.forEach((th, i) => {
      const txt = th.textContent.trim().toLowerCase();
      if (th.hasAttribute("data-yu-locked") || ["manage", "action", "actions", ""].includes(txt)) {
        lockedCols.add(i);
        hiddenCols.delete(i);
      }
    });

    const applyColVisibility = () => {
      headers.forEach((th, i) => {
        const hide = hiddenCols.has(i) && !lockedCols.has(i);
        th.style.display = hide ? "none" : "";
      });
      rawRows.forEach((tr) => {
        Array.from(tr.children).forEach((td, i) => {
          const hide = hiddenCols.has(i) && !lockedCols.has(i);
          td.style.display = hide ? "none" : "";
        });
      });
      try {
        localStorage.setItem(storageKey, JSON.stringify(Array.from(hiddenCols)));
      } catch {
        // ignore storage quota
      }
    };

    // State
    let searchTerm = "";
    let filterVal = "";
    let sortCol = -1;
    let sortDir = 1;
    let page = 1;
    let pageSize = noPaginate ? 9999 : Number(table.getAttribute("data-yu-page-size") || 15);
    const selectedSet = new Set();

    // Empty row element
    const emptyRow = document.createElement("tr");
    emptyRow.className = "yu-dt-empty-row hidden";
    emptyRow.innerHTML = `<td colspan="${Math.max(1, headers.length)}" class="yu-dt-empty-cell">No matching records found. <button type="button" class="yu-dt-clear-btn">Clear filters</button></td>`;
    tbody.appendChild(emptyRow);

    // Build Toolbar UI
    const filterOptionsHtml =
      filterValues.size > 1
        ? `<select class="yu-dt-filter" aria-label="Filter rows">
             <option value="">All ${esc(headers[filterColIdx]?.textContent.trim() || "Status")}</option>
             ${Array.from(filterValues)
               .sort()
               .map((v) => `<option value="${esc(v)}">${esc(v)}</option>`)
               .join("")}
           </select>`
        : "";

    const toggleableCols = headers
      .map((th, i) => ({ idx: i, label: th.textContent.trim(), locked: lockedCols.has(i) }))
      .filter((c) => !c.locked && c.label);

    toolbar.innerHTML = `
      <div class="yu-dt-tl-left">
        <label class="yu-dt-search-wrap">
          <input type="search" class="yu-dt-search" placeholder="Search table..." aria-label="Search table" />
        </label>
        ${filterOptionsHtml}
      </div>
      <div class="yu-dt-tl-right">
        ${
          !noPaginate
            ? `<select class="yu-dt-pagesize" aria-label="Rows per page">
                 <option value="10" ${pageSize === 10 ? "selected" : ""}>10 / page</option>
                 <option value="15" ${pageSize === 15 ? "selected" : ""}>15 / page</option>
                 <option value="25" ${pageSize === 25 ? "selected" : ""}>25 / page</option>
                 <option value="50" ${pageSize === 50 ? "selected" : ""}>50 / page</option>
                 <option value="9999">All</option>
               </select>`
            : ""
        }
        ${
          toggleableCols.length > 1
            ? `<div class="yu-dt-cols-wrap">
                 <button type="button" class="portal-btn-ghost portal-btn-sm yu-dt-cols-btn">Columns ▾</button>
                 <div class="yu-dt-cols-pop hidden">
                   <div class="yu-dt-cols-head">
                     <span>Show / Hide Columns</span>
                     <button type="button" class="yu-dt-cols-reset">Show all</button>
                   </div>
                   <div class="yu-dt-cols-list">
                     ${toggleableCols
                       .map(
                         (c) => `
                       <label class="yu-dt-col-opt">
                         <input type="checkbox" data-yu-col-idx="${c.idx}" ${hiddenCols.has(c.idx) ? "" : "checked"} />
                         <span>${esc(c.label)}</span>
                       </label>`
                       )
                       .join("")}
                   </div>
                 </div>
               </div>`
            : ""
        }
        <button type="button" class="portal-btn-ghost portal-btn-sm yu-dt-csv-btn">CSV</button>
      </div>
    `;

    // Mark sortable headers
    headers.forEach((th, i) => {
      const txt = th.textContent.trim().toLowerCase();
      if (th.hasAttribute("data-yu-no-sort") || lockedCols.has(i) || ["manage", "action", "actions", ""].includes(txt)) {
        return;
      }
      th.classList.add("yu-dt-sortable");
      th.setAttribute("tabindex", "0");
      th.title = `Sort by ${th.textContent.trim()}`;
      const ind = document.createElement("span");
      ind.className = "yu-dt-sort-ind";
      ind.textContent = "⇅";
      th.appendChild(ind);

      const triggerSort = () => {
        if (sortCol === i) {
          sortDir = sortDir === 1 ? -1 : 1;
        } else {
          sortCol = i;
          sortDir = 1;
        }
        headers.forEach((h, hi) => {
          const s = h.querySelector(".yu-dt-sort-ind");
          if (!s) return;
          if (hi === sortCol) {
            h.classList.add("is-sorted");
            s.textContent = sortDir === 1 ? "▲" : "▼";
          } else {
            h.classList.remove("is-sorted");
            s.textContent = "⇅";
          }
        });
        page = 1;
        renderTableView();
      };
      th.addEventListener("click", triggerSort);
      th.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          triggerSort();
        }
      });
    });

    const extractRowPayload = (tr) => {
      const cells = Array.from(tr.children);
      return {
        uid: tr.getAttribute("data-row-view-uid") || tr.getAttribute("data-uid") || tr.getAttribute("data-id") || "",
        email: tr.getAttribute("data-email") || "",
        phone: tr.getAttribute("data-phone") || "",
        name: tr.getAttribute("data-name") || "",
        cells: cells.map((c) => c.textContent.replace(/\s+/g, " ").trim()),
        tr,
      };
    };

    const updateBulkBar = (visibleRows) => {
      if (!injectBulk) return;
      const count = selectedSet.size;
      if (count <= 0) {
        bulkBar.classList.add("hidden");
        bulkBar.innerHTML = "";
      } else {
        bulkBar.classList.remove("hidden");
        bulkBar.innerHTML = `
          <span class="yu-dt-bulk-count"><strong>${count}</strong> selected</span>
          <div class="yu-dt-bulk-actions">
            ${
              typeof opts.onBulkAction === "function"
                ? `<button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-bulk-act="mail">Bulk Mail</button>
                   <button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-bulk-act="whatsapp">Bulk WhatsApp</button>`
                : ""
            }
            <button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-bulk-act="csv">Export Selected CSV</button>
            <button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-bulk-act="clear">Clear</button>
          </div>
        `;
        bulkBar.querySelectorAll("[data-yu-bulk-act]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const act = btn.getAttribute("data-yu-bulk-act");
            if (act === "clear") {
              selectedSet.clear();
              rawRows.forEach((tr) => {
                const cb = tr.querySelector(".yu-dt-row-check");
                if (cb) cb.checked = false;
                tr.classList.remove("is-selected");
              });
              const allCb = headerRow.querySelector(".yu-dt-check-all");
              if (allCb) allCb.checked = false;
              updateBulkBar(visibleRows);
              return;
            }
            const selectedRows = Array.from(selectedSet).map(extractRowPayload);
            if (act === "csv") {
              const visHdrs = headers
                .map((h, i) => ({ h, i }))
                .filter(({ i }) => !hiddenCols.has(i) && !headers[i].classList.contains("yu-dt-check-col") && !lockedCols.has(i));
              exportRowsToCsv(
                `${tableId}-selected.csv`,
                visHdrs.map(({ h }) => h.textContent.replace(/[⇅▲▼]/g, "").trim()),
                selectedRows.map((r) => visHdrs.map(({ i }) => r.cells[i] || ""))
              );
              Toast.success(`Exported ${selectedRows.length} selected rows to CSV.`);
              return;
            }
            if (typeof opts.onBulkAction === "function") {
              opts.onBulkAction(act, selectedRows, table);
            }
          });
        });
      }

      const checkAll = headerRow.querySelector(".yu-dt-check-all");
      if (checkAll) {
        const checkedVis = visibleRows.filter((tr) => selectedSet.has(tr)).length;
        checkAll.checked = visibleRows.length > 0 && checkedVis === visibleRows.length;
        checkAll.indeterminate = checkedVis > 0 && checkedVis < visibleRows.length;
      }
    };

    const getFilteredSortedRows = () => {
      const q = searchTerm.trim().toLowerCase();
      let list = rawRows.filter((tr) => {
        if (filterVal && filterColIdx >= 0) {
          const cv = (tr.children[filterColIdx]?.textContent || "").replace(/\s+/g, " ").trim();
          if (cv !== filterVal) return false;
        }
        if (q) {
          const full = tr.textContent.replace(/\s+/g, " ").toLowerCase();
          if (!full.includes(q)) return false;
        }
        return true;
      });
      if (sortCol >= 0) {
        list = list.slice().sort((a, b) => {
          const av = parseCellSortValue(a.children[sortCol]?.textContent || "");
          const bv = parseCellSortValue(b.children[sortCol]?.textContent || "");
          if (av.kind === "empty" && bv.kind !== "empty") return 1;
          if (bv.kind === "empty" && av.kind !== "empty") return -1;
          if (av.kind === "num" && bv.kind === "num") return (av.val - bv.val) * sortDir;
          return String(av.val).localeCompare(String(bv.val), undefined, { numeric: true }) * sortDir;
        });
      }
      return list;
    };

    const renderTableView = () => {
      const filtered = getFilteredSortedRows();
      const total = filtered.length;
      const totalPages = noPaginate ? 1 : Math.max(1, Math.ceil(total / pageSize));
      if (page > totalPages) page = totalPages;
      if (page < 1) page = 1;

      const startIdx = noPaginate ? 0 : (page - 1) * pageSize;
      const endIdx = noPaginate ? total : Math.min(total, startIdx + pageSize);
      const pageRows = filtered.slice(startIdx, endIdx);
      const pageSet = new Set(pageRows);

      // Reorder tbody rows when sorted
      if (sortCol >= 0) {
        filtered.forEach((tr) => tbody.appendChild(tr));
        rawRows.forEach((tr) => {
          if (!pageSet.has(tr) && !filtered.includes(tr)) tbody.appendChild(tr);
        });
      }
      tbody.appendChild(emptyRow);

      rawRows.forEach((tr) => {
        tr.style.display = pageSet.has(tr) ? "" : "none";
      });

      if (total === 0) {
        emptyRow.classList.remove("hidden");
      } else {
        emptyRow.classList.add("hidden");
      }

      applyColVisibility();
      updateBulkBar(pageRows);

      // Pager footer
      if (total === 0) {
        pager.innerHTML = `<span class="yu-dt-info">0 records</span>`;
      } else if (noPaginate || totalPages <= 1) {
        pager.innerHTML = `<span class="yu-dt-info">Showing ${total} ${total === 1 ? "row" : "rows"}</span>`;
      } else {
        const nums = [];
        const winStart = Math.max(1, page - 2);
        const winEnd = Math.min(totalPages, page + 2);
        for (let p = winStart; p <= winEnd; p++) nums.push(p);
        pager.innerHTML = `
          <span class="yu-dt-info">Showing ${startIdx + 1}–${endIdx} of ${total}</span>
          <div class="yu-dt-pages">
            <button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-pg="${page - 1}" ${page <= 1 ? "disabled" : ""}>Prev</button>
            ${nums
              .map(
                (p) =>
                  `<button type="button" class="${
                    p === page ? "portal-btn-primary" : "portal-btn-ghost"
                  } portal-btn-sm" data-yu-pg="${p}">${p}</button>`
              )
              .join("")}
            <button type="button" class="portal-btn-ghost portal-btn-sm" data-yu-pg="${page + 1}" ${page >= totalPages ? "disabled" : ""}>Next</button>
          </div>
        `;
        pager.querySelectorAll("[data-yu-pg]").forEach((b) => {
          b.addEventListener("click", () => {
            const np = Number(b.getAttribute("data-yu-pg"));
            if (np >= 1 && np <= totalPages) {
              page = np;
              renderTableView();
            }
          });
        });
      }
    };

    // Event Bindings
    toolbar.querySelector(".yu-dt-search")?.addEventListener("input", (e) => {
      searchTerm = e.target.value || "";
      page = 1;
      renderTableView();
    });

    toolbar.querySelector(".yu-dt-filter")?.addEventListener("change", (e) => {
      filterVal = e.target.value || "";
      page = 1;
      renderTableView();
    });

    toolbar.querySelector(".yu-dt-pagesize")?.addEventListener("change", (e) => {
      pageSize = Number(e.target.value) || 15;
      page = 1;
      renderTableView();
    });

    emptyRow.querySelector(".yu-dt-clear-btn")?.addEventListener("click", () => {
      searchTerm = "";
      filterVal = "";
      const si = toolbar.querySelector(".yu-dt-search");
      const fi = toolbar.querySelector(".yu-dt-filter");
      if (si) si.value = "";
      if (fi) fi.value = "";
      page = 1;
      renderTableView();
    });

    toolbar.querySelector(".yu-dt-csv-btn")?.addEventListener("click", () => {
      const filtered = getFilteredSortedRows();
      const visHdrs = headers
        .map((h, i) => ({ h, i }))
        .filter(({ i }) => !hiddenCols.has(i) && !headers[i].classList.contains("yu-dt-check-col") && !lockedCols.has(i));
      exportRowsToCsv(
        `${tableId}-${new Date().toISOString().slice(0, 10)}.csv`,
        visHdrs.map(({ h }) => h.textContent.replace(/[⇅▲▼]/g, "").trim()),
        filtered.map((tr) => visHdrs.map(({ i }) => tr.children[i]?.textContent || ""))
      );
      Toast.success(`Exported ${filtered.length} rows to CSV.`);
    });

    // Columns popover
    const colsBtn = toolbar.querySelector(".yu-dt-cols-btn");
    const colsPop = toolbar.querySelector(".yu-dt-cols-pop");
    if (colsBtn && colsPop) {
      colsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        colsPop.classList.toggle("hidden");
      });
      document.addEventListener("click", (e) => {
        if (!colsPop.contains(e.target) && !colsBtn.contains(e.target)) {
          colsPop.classList.add("hidden");
        }
      });
      colsPop.querySelectorAll("[data-yu-col-idx]").forEach((cb) => {
        cb.addEventListener("change", () => {
          const ci = Number(cb.getAttribute("data-yu-col-idx"));
          if (cb.checked) hiddenCols.delete(ci);
          else hiddenCols.add(ci);
          applyColVisibility();
        });
      });
      colsPop.querySelector(".yu-dt-cols-reset")?.addEventListener("click", () => {
        hiddenCols.clear();
        colsPop.querySelectorAll("[data-yu-col-idx]").forEach((cb) => {
          cb.checked = true;
        });
        applyColVisibility();
      });
    }

    // Checkboxes for bulk select
    if (injectBulk) {
      const checkAll = headerRow.querySelector(".yu-dt-check-all");
      checkAll?.addEventListener("change", () => {
        const filtered = getFilteredSortedRows();
        const startIdx = noPaginate ? 0 : (page - 1) * pageSize;
        const pageRows = noPaginate ? filtered : filtered.slice(startIdx, startIdx + pageSize);
        pageRows.forEach((tr) => {
          const cb = tr.querySelector(".yu-dt-row-check");
          if (checkAll.checked) {
            selectedSet.add(tr);
            if (cb) cb.checked = true;
            tr.classList.add("is-selected");
          } else {
            selectedSet.delete(tr);
            if (cb) cb.checked = false;
            tr.classList.remove("is-selected");
          }
        });
        updateBulkBar(pageRows);
      });

      rawRows.forEach((tr) => {
        const cb = tr.querySelector(".yu-dt-row-check");
        cb?.addEventListener("change", (e) => {
          e.stopPropagation();
          if (cb.checked) {
            selectedSet.add(tr);
            tr.classList.add("is-selected");
          } else {
            selectedSet.delete(tr);
            tr.classList.remove("is-selected");
          }
          renderTableView();
        });
      });
    }

    // Full Row Clickable Support
    rawRows.forEach((tr) => {
      if (tr.hasAttribute("data-row-view-uid") || tr.hasAttribute("data-row-click")) {
        tr.classList.add("yu-row-clickable");
        tr.addEventListener("click", (e) => {
          if (
            e.target.closest(
              "button, a, input, select, textarea, label, .yu-manage-wrap, .yu-dt-check-col, [data-no-row-click]"
            )
          ) {
            return;
          }
          if (typeof opts.onRowClick === "function") {
            opts.onRowClick(tr, e);
          }
        });
      }
    });

    renderTableView();
  }

  function enhanceTables(container, opts = {}) {
    if (!container) return;
    container.querySelectorAll("table.portal-table").forEach((tbl) => enhanceSingleTable(tbl, opts));
  }

  function filterAccordions(container, query) {
    if (!container) return;
    const q = String(query || "").trim().toLowerCase();
    container.querySelectorAll(".portal-accordion").forEach((acc) => {
      const txt = acc.textContent.toLowerCase();
      const matched = !q || txt.includes(q);
      acc.style.display = matched ? "" : "none";
      if (q && matched && acc.tagName === "DETAILS") {
        acc.open = true;
      }
    });
  }

  if (!document.querySelector('link[href*="v31-theme.css"]')) {
    const lnk = document.createElement("link");
    lnk.rel = "stylesheet";
    lnk.href = "/assets/v31-theme.css?v=310";
    document.head.appendChild(lnk);
  }

  window.YuitorUI = {
    Toast,
    renderBreadcrumbs,
    bindBreadcrumbs,
    openManageMenu,
    closeManageMenu,
    enhanceTables,
    exportRowsToCsv,
    filterAccordions,
  };
})();
