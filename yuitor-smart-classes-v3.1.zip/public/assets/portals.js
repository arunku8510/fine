(() => {
  "use strict";
  const root = document.getElementById("root");
  if (!root) return;

  const BRAND_PENDING_MSG =
    "Your mobile number has been successfully verified. Your account verification is currently pending from the Yuitor Team. We will try to contact you soon. Thank you for your patience.";
  const TEACHER_MISSING_RESUME_MSG =
    "Please upload your resume to complete teacher registration. Without submitting your resume, you cannot access the Teacher Dashboard.";
  const TEACHER_REJECTED_RESUME_MSG =
    "Your previous resume requires an update before Teacher Dashboard access can be restored. Please upload a revised PDF, DOC, or DOCX resume below.";
  const STUDENT_PENDING_MSG =
    "Congratulations on beginning your learning journey with Yuitor! Your mobile number is verified and your student application is with our academic admissions team for quick activation.";
  const TEACHER_PENDING_MSG =
    "Welcome to the Yuitor Teaching Community! Your mobile number and resume have been received. Our academic review team will verify your credentials and reach out to you soon.";

  const escapeHtml = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const escAttr = (v) => escapeHtml(v);

  const ADMIN_GATE =
    window.__YU_ADMIN_GATE__ && typeof window.__YU_ADMIN_GATE__ === "object" ? window.__YU_ADMIN_GATE__ : null;
  const GATE_BASE = ADMIN_GATE?.basePath ? String(ADMIN_GATE.basePath).replace(/\/+$/, "") : "";
  const ADMIN_API_BASE = ADMIN_GATE?.apiBase ? String(ADMIN_GATE.apiBase).replace(/\/+$/, "") : "";
  const adminApiUrl = (suffix) => `${ADMIN_API_BASE}${String(suffix || "").startsWith("/") ? suffix : "/" + suffix}`;

  const safeHref = (url, fallback = "") => {
    const raw = String(url ?? "").trim();
    if (!raw) return fallback;
    if (raw.startsWith("/") && !raw.startsWith("//")) return raw;
    try {
      const u = new URL(raw);
      return ["http:", "https:", "mailto:", "tel:"].includes(u.protocol) ? raw : fallback;
    } catch {
      return fallback;
    }
  };

  const ICONS = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    book: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
    wallet: '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
    megaphone: '<path d="m3 11 18-5v12L3 13v-2z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    bot: '<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
    mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
    user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    arrowUp: '<path d="m18 15-6-6-6 6"/>',
    arrowDown: '<path d="m6 9 6 6 6-6"/>',
    award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    messageSquare: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    graduationCap: '<path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z"/><path d="M22 10v6"/><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>',
    clipboardCheck: '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
    library: '<path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/>',
    barChart: '<line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
  };

  function icon(name, cls = "portal-icon-svg") {
    return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.dashboard}</svg>`;
  }

  function readCsrfCookie() {
    const m = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function api(url, options = {}) {
    const headers = { Accept: "application/json", ...(options.headers || {}) };
    const method = String(options.method || "GET").toUpperCase();
    if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
      const csrf = readCsrfCookie();
      if (csrf && !headers["X-CSRF-Token"]) {
        headers["X-CSRF-Token"] = csrf;
      }
    }
    const opts = { credentials: "same-origin", cache: "no-store", ...options, headers };
    if (options.body && !(options.body instanceof FormData) && typeof options.body !== "string") {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(options.body);
    }
    const res = await fetch(url, opts);
    let data = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function uploadFile(file) {
    const fd = new FormData();
    fd.append("file", file);
    return api("/api/uploads", { method: "POST", body: fd });
  }

  function getMain() {
    return root.querySelector("main");
  }

  function applyThemePreference(main) {
    const dark = localStorage.getItem("yuitor_portal_dark") === "1";
    main.classList.toggle("portal-dark", dark);
    return dark;
  }

  function getPortalHost(main) {
    if (!main) return null;
    let host = main.querySelector("[data-yu-portal-host]");
    if (!host) {
      host = document.createElement("div");
      host.setAttribute("data-yu-portal-host", "true");
      host.className = "min-h-[70vh]";
      main.appendChild(host);
    }
    return host;
  }

  function mountShell(html) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    applyThemePreference(main);
    main.dataset.yuPortalMounted = "true";
    const host = getPortalHost(main);
    host.innerHTML = `<div class="portal-shell">${html}</div>`;
    return main;
  }

  function statusBadge(st) {
    const s = String(st || "").toLowerCase();
    let mod = "pending";
    if (["approved", "active", "verified", "paid", "completed", "resolved", "present", "graded", "available", "sent"].includes(s)) {
      mod = "paid";
    } else if (["rejected", "suspended", "inactive", "failed", "absent", "refunded", "cancelled", "closed"].includes(s)) {
      mod = "overdue";
    }
    return `<span class="portal-status portal-status--${mod}">${escapeHtml(s.replace(/_/g, " "))}</span>`;
  }

  function impersonationBanner(session) {
    if (!session?.impersonation?.active) return "";
    return `
      <div class="portal-alert">
        <div>
          <strong>Admin viewing as user: ${escapeHtml(session.user.full_name)} (${escapeHtml(session.user.role)})</strong>
          · Reason: ${escapeHtml(session.impersonation.reason)}
        </div>
        <button type="button" class="portal-button portal-button--small" data-exit-impersonation>Exit Impersonation</button>
      </div>`;
  }

  function bindGlobalImpersonationExit(container) {
    const btn = container.querySelector("[data-exit-impersonation]");
    if (!btn) return;
    btn.addEventListener("click", async () => {
      try {
        const res = await api("/api/auth/exit-impersonation", { method: "POST" });
        window.location.assign(res.redirectTo || (GATE_BASE ? `${GATE_BASE}/` : "/"));
      } catch (err) {
        btn.textContent = err.message || "Exit failed";
      }
    });
  }

  function openPromptModal({ title, label, placeholder = "", defaultValue = "", minLength = 1 }) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.className = "yu-festival-popup-overlay";
      overlay.style.cssText =
        "position:fixed;inset:0;z-index:10050;background:rgba(15,23,42,.56);display:flex;align-items:center;justify-content:center;padding:16px;";
      overlay.innerHTML = `
        <div class="portal-card portal-profile" role="dialog" aria-modal="true" style="max-width:440px;width:100%;margin:0;">
          <h3 class="portal-section-title" style="margin-bottom:8px;">${escapeHtml(title)}</h3>
          <form class="portal-form" data-modal-prompt-form>
            <div class="portal-field">
              <label>${escapeHtml(label)}</label>
              <input name="value" value="${escAttr(defaultValue)}" placeholder="${escAttr(placeholder)}" minlength="${minLength}" required>
            </div>
            <div class="portal-actions" style="justify-content:flex-end;margin-top:12px;">
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-modal-cancel>Cancel</button>
              <button type="submit" class="portal-button portal-button--small">Confirm</button>
            </div>
          </form>
        </div>`;
      const cleanup = (val) => {
        overlay.remove();
        resolve(val);
      };
      overlay.querySelector("[data-modal-cancel]")?.addEventListener("click", () => cleanup(""));
      overlay.addEventListener("click", (ev) => {
        if (ev.target === overlay) cleanup("");
      });
      overlay.querySelector("[data-modal-prompt-form]")?.addEventListener("submit", (ev) => {
        ev.preventDefault();
        const val = String(new FormData(ev.currentTarget).get("value") || "").trim();
        if (val.length < minLength) return;
        cleanup(val);
      });
      document.body.appendChild(overlay);
      overlay.querySelector('input[name="value"]')?.focus();
    });
  }

  function formatINR(n) {
    return `₹${Number(n || 0).toLocaleString("en-IN")}`;
  }

  function passwordFieldHtml(name, attrs = "") {
    return `<div class="portal-pw-wrap"><input name="${escAttr(name)}" type="password" ${attrs}><button type="button" class="portal-pw-toggle" data-toggle-pw="${escAttr(name)}" aria-label="Show password">Show</button></div>`;
  }

  function bindPasswordToggles(container) {
    if (!container) return;
    container.querySelectorAll("[data-toggle-pw]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const fieldName = btn.getAttribute("data-toggle-pw");
        const input = btn.closest(".portal-pw-wrap")?.querySelector(`input[name="${CSS.escape(fieldName || "")}"]`);
        if (!input) return;
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        btn.textContent = show ? "Hide" : "Show";
        btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
      });
    });
  }

  let rzpScriptPromise = null;
  function loadRazorpayCheckout() {
    if (window.Razorpay) return Promise.resolve(window.Razorpay);
    if (!rzpScriptPromise) {
      rzpScriptPromise = new Promise((resolve, reject) => {
        const sc = document.createElement("script");
        sc.src = "https://checkout.razorpay.com/v1/checkout.js";
        sc.async = true;
        sc.onload = () => (window.Razorpay ? resolve(window.Razorpay) : reject(new Error("Razorpay Checkout unavailable.")));
        sc.onerror = () => reject(new Error("Could not load Razorpay Checkout script. Check internet connection or pay via UPI/Desk."));
        document.head.appendChild(sc);
      });
    }
    return rzpScriptPromise;
  }

  const V3_CLASS_FEE_PLANS = [
    { classNumber: 6, label: "Class 6th", monthlyFee: 600, yearlyFee: 6480, yearlySavings: 720 },
    { classNumber: 7, label: "Class 7th", monthlyFee: 650, yearlyFee: 7020, yearlySavings: 780 },
    { classNumber: 8, label: "Class 8th", monthlyFee: 700, yearlyFee: 7560, yearlySavings: 840 },
    { classNumber: 9, label: "Class 9th", monthlyFee: 750, yearlyFee: 8100, yearlySavings: 900 },
    { classNumber: 10, label: "Class 10th", monthlyFee: 800, yearlyFee: 8640, yearlySavings: 960 },
    { classNumber: 11, label: "Class 11th", monthlyFee: 850, yearlyFee: 9180, yearlySavings: 1020 },
    { classNumber: 12, label: "Class 12th", monthlyFee: 900, yearlyFee: 9720, yearlySavings: 1080 },
  ];

  const V3_BILLING_CYCLES = [
    { id: "1m", label: "1 Month", months: 1, discountPercent: 0 },
    { id: "3m", label: "3 Months", months: 3, discountPercent: 0 },
    { id: "6m", label: "6 Months", months: 6, discountPercent: 0 },
    { id: "9m", label: "9 Months", months: 9, discountPercent: 0 },
    { id: "yearly", label: "Yearly (10% OFF)", months: 12, discountPercent: 10 },
  ];

  function buildWhatsAppHref(phone, fullName) {
    const digits = String(phone || "").replace(/\D+/g, "");
    if (!digits || digits.length < 10) return "";
    const intl = digits.length === 10 ? `91${digits}` : digits;
    const msg = `Hello ${String(fullName || "there").trim()}, greetings from Yuitor Smart Classes.`;
    return `https://wa.me/${intl}?text=${encodeURIComponent(msg)}`;
  }

  function openInAppModal({ title, bodyHtml, onMount }) {
    document.querySelectorAll("[data-yu-v3-modal]").forEach((el) => el.remove());
    const backdrop = document.createElement("div");
    backdrop.className = "portal-modal-backdrop";
    backdrop.setAttribute("data-yu-v3-modal", "true");
    backdrop.setAttribute("role", "dialog");
    backdrop.setAttribute("aria-modal", "true");
    backdrop.innerHTML = `
      <div class="portal-modal-card">
        <div class="portal-modal-head">
          <h3>${escapeHtml(title || "Dialog")}</h3>
          <button type="button" class="portal-icon-btn" data-v3-modal-close aria-label="Close">&times;</button>
        </div>
        <div data-v3-modal-body>${bodyHtml}</div>
      </div>`;
    const close = () => backdrop.remove();
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) close();
    });
    backdrop.querySelector("[data-v3-modal-close]")?.addEventListener("click", close);
    document.body.appendChild(backdrop);
    if (typeof onMount === "function") onMount(backdrop, close);
    return { backdrop, close };
  }

  function openProfilePhotoModal(session, onUpdated) {
    const currentAvatar = safeHref(session?.user?.profile_photo || session?.user?.avatar_url, "/yuitor-icon-192.png");
    openInAppModal({
      title: "Upload / Change Profile Photo",
      bodyHtml: `
        <div class="portal-photo-preview-wrap">
          <img src="${escAttr(currentAvatar)}" alt="Current profile preview" data-photo-preview>
          <div>
            <strong style="display:block;font-size:13px;">${escapeHtml(session?.user?.full_name || "User")}</strong>
            <span class="portal-hint">Accepted formats: JPG, PNG, WEBP · Max size: 2 MB</span>
          </div>
        </div>
        <form class="portal-form" data-v3-photo-form>
          <div class="portal-field">
            <label>Choose Profile Photo *</label>
            <input type="file" name="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" required data-photo-file-input>
          </div>
          <div class="portal-message portal-message--error" data-photo-err hidden></div>
          <div class="portal-message portal-message--success" data-photo-ok hidden></div>
          <div class="portal-actions" style="justify-content:flex-end;">
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-photo-cancel>Cancel</button>
            <button type="submit" class="portal-button portal-button--small" data-photo-submit>${icon("upload")} Save Profile Photo</button>
          </div>
        </form>`,
      onMount: (backdrop, close) => {
        const input = backdrop.querySelector("[data-photo-file-input]");
        const preview = backdrop.querySelector("[data-photo-preview]");
        const errBox = backdrop.querySelector("[data-photo-err]");
        const okBox = backdrop.querySelector("[data-photo-ok]");
        const submitBtn = backdrop.querySelector("[data-photo-submit]");
        let previewObjUrl = "";

        const showErr = (msg) => {
          if (okBox) okBox.hidden = true;
          if (errBox) {
            errBox.textContent = msg;
            errBox.hidden = false;
          }
        };
        const clearMsgs = () => {
          if (errBox) errBox.hidden = true;
          if (okBox) okBox.hidden = true;
        };

        const validateFile = (file) => {
          if (!file) return "Please select an image file first.";
          const ext = String(file.name || "").split(".").pop().toLowerCase();
          const okExt = ["jpg", "jpeg", "png", "webp"].includes(ext);
          const okMime = ["image/jpeg", "image/png", "image/webp"].includes(String(file.type || "").toLowerCase());
          if (!okExt && !okMime) {
            return "Invalid file type. Only JPG, PNG, and WEBP images are allowed.";
          }
          if (file.size > 2 * 1024 * 1024) {
            return `Image is too large (${(file.size / (1024 * 1024)).toFixed(2)} MB). Maximum allowed size is 2 MB.`;
          }
          return "";
        };

        input?.addEventListener("change", () => {
          clearMsgs();
          const file = input.files && input.files[0];
          if (!file) return;
          const vErr = validateFile(file);
          if (vErr) {
            showErr(vErr);
            return;
          }
          if (previewObjUrl) URL.revokeObjectURL(previewObjUrl);
          previewObjUrl = URL.createObjectURL(file);
          if (preview) preview.src = previewObjUrl;
        });

        backdrop.querySelector("[data-photo-cancel]")?.addEventListener("click", () => {
          if (previewObjUrl) URL.revokeObjectURL(previewObjUrl);
          close();
        });

        backdrop.querySelector("[data-v3-photo-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          clearMsgs();
          const file = input?.files && input.files[0];
          const vErr = validateFile(file);
          if (vErr) {
            showErr(vErr);
            return;
          }
          if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = "Uploading...";
          }
          try {
            const fd = new FormData();
            fd.append("photo", file);
            const res = await fetch("/api/auth/profile-photo", {
              method: "POST",
              credentials: "same-origin",
              body: fd,
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
              throw new Error(data.error || "Unable to upload profile photo.");
            }
            const nextUrl = data.avatarUrl || data.profilePhoto || "";
            if (session?.user && nextUrl) {
              session.user.avatar_url = nextUrl;
              session.user.profile_photo = nextUrl;
            }
            const busted = nextUrl ? `${nextUrl}${nextUrl.includes("?") ? "&" : "?"}t=${Date.now()}` : "";
            if (busted) {
              document.querySelectorAll("[data-topbar-avatar]").forEach((img) => {
                img.src = busted;
              });
            }
            if (okBox) {
              okBox.textContent = "Profile photo updated successfully!";
              okBox.hidden = false;
            }
            if (typeof onUpdated === "function") onUpdated(nextUrl);
            setTimeout(() => {
              if (previewObjUrl) URL.revokeObjectURL(previewObjUrl);
              close();
            }, 650);
          } catch (err) {
            showErr(err?.message || "Failed to upload profile photo.");
          } finally {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = `${icon("upload")} Save Profile Photo`;
            }
          }
        });
      },
    });
  }

  function renderWorkspace({
    session,
    portalTitle,
    navItems = [],
    navGroups = null,
    activeNavKey = "",
    openGroups = null,
    onNavSelect = null,
    activeTab,
    onTabChange,
    notifications = [],
    onReadNotifs,
    breadcrumbs = [],
    onBreadcrumbSelect = null,
    pageTitle = "",
    pageSubtitle = "",
    onBack = null,
    onMailShortcut = null,
    bodyHtml,
  }) {
    const main = getMain();
    if (!main) return null;
    main.classList.add("portal-main");
    const isDark = applyThemePreference(main);
    main.dataset.yuPortalMounted = "true";

    const portalBadgeLabel =
      portalTitle === "Admin Console" || portalTitle === "Admin Portal"
        ? "Admin Portal"
        : portalTitle || "Yuitor Portal";
    const isAdminPortal = portalBadgeLabel === "Admin Portal";
    const useGroupedNav = Array.isArray(navGroups) && navGroups.length > 0;
    const unreadCount = notifications.filter((n) => !n.is_read).length;
    const avatarSrc = safeHref(session.user.profile_photo || session.user.avatar_url, "/yuitor-icon-192.png");
    const roleLabel =
      session.user.role === "super_admin"
        ? "Super Admin"
        : session.user.role === "admin"
          ? "Admin"
          : String(session.user.role || "User");

    let activeGroupObj = null;
    if (useGroupedNav) {
      for (const grp of navGroups) {
        const hit =
          (grp.items || []).find((it) => it.key === activeNavKey) ||
          (!activeNavKey && (grp.items || []).find((it) => it.tab === activeTab));
        if (hit) {
          activeGroupObj = grp;
          break;
        }
      }
      if (!activeGroupObj) activeGroupObj = navGroups[0] || null;
    }

    const centerNavHtml = useGroupedNav
      ? `<nav class="portal-unav-center portal-unav-navrow" aria-label="Portal Navigation" data-testid="unified-top-nav">
          ${navGroups
            .map((grp) => {
              const items = grp.items || [];
              const hasActiveChild = activeGroupObj && activeGroupObj.id === grp.id;
              if (items.length === 1) {
                const only = items[0];
                return `
                  <div class="portal-unav-group">
                    <button
                      type="button"
                      class="portal-unav-link ${hasActiveChild ? "is-active" : ""}"
                      aria-current="${hasActiveChild ? "page" : "false"}"
                      data-ws-nav-key="${escAttr(only.key)}"
                      data-nav-group-id="${escAttr(grp.id)}"
                    >
                      <span>${escapeHtml(grp.label)}</span>
                      ${grp.badge ? `<span class="portal-nav-badge">${escapeHtml(grp.badge)}</span>` : ""}
                    </button>
                  </div>`;
              }
              return `
                <div class="portal-unav-group" data-unav-group="${escAttr(grp.id)}">
                  <button
                    type="button"
                    class="portal-unav-link ${hasActiveChild ? "is-active" : ""}"
                    aria-haspopup="menu"
                    aria-expanded="false"
                    data-unav-group-toggle="${escAttr(grp.id)}"
                    data-nav-group-id="${escAttr(grp.id)}"
                  >
                    <span>${escapeHtml(grp.label)}</span>
                    ${grp.badge ? `<span class="portal-nav-badge">${escapeHtml(grp.badge)}</span>` : ""}
                    ${icon("chevronDown", "portal-icon-svg portal-unav-caret")}
                  </button>
                  <div class="portal-unav-dropdown" data-unav-dropdown="${escAttr(grp.id)}" role="menu" hidden>
                    ${items
                      .map((it) => {
                        const isItemActive = activeNavKey ? it.key === activeNavKey : it.tab === activeTab;
                        return `
                          <button
                            type="button"
                            class="portal-unav-dropitem"
                            role="menuitem"
                            aria-current="${isItemActive ? "page" : "false"}"
                            data-ws-nav-key="${escAttr(it.key)}"
                          >
                            <span>${escapeHtml(it.label)}</span>
                            ${it.badge ? `<span class="portal-nav-badge">${escapeHtml(it.badge)}</span>` : ""}
                          </button>`;
                      })
                      .join("")}
                  </div>
                </div>`;
            })
            .join("")}
        </nav>`
      : `<nav class="portal-unav-center portal-unav-navrow" aria-label="Portal Navigation" data-testid="unified-top-nav">
          ${navItems
            .map(
              ([id, label]) => `
                <button
                  type="button"
                  class="portal-unav-link ${activeTab === id ? "is-active" : ""}"
                  aria-current="${activeTab === id ? "page" : "false"}"
                  data-ws-tab="${escAttr(id)}"
                >
                  <span>${escapeHtml(label)}</span>
                </button>`
            )
            .join("")}
        </nav>`;

    const activeSubbarHtml =
      useGroupedNav && activeGroupObj && (activeGroupObj.items || []).length > 1
        ? `<div class="portal-unav-subbar" aria-label="${escAttr(activeGroupObj.label)} sub-navigation">
            <span class="portal-unav-subbar-label">${escapeHtml(activeGroupObj.label)}:</span>
            ${activeGroupObj.items
              .map((it) => {
                const isItemActive = activeNavKey ? it.key === activeNavKey : it.tab === activeTab;
                return `
                  <button
                    type="button"
                    class="portal-unav-subpill"
                    aria-current="${isItemActive ? "page" : "false"}"
                    data-ws-nav-key="${escAttr(it.key)}"
                  >
                    ${escapeHtml(it.label)}
                    ${it.badge ? `<span class="portal-nav-badge">${escapeHtml(it.badge)}</span>` : ""}
                  </button>`;
              })
              .join("")}
          </div>`
        : "";

    const mobileDrawerHtml = useGroupedNav
      ? `<div class="portal-unav-drawer" data-unav-drawer>
          ${navGroups
            .map(
              (grp) => `
                <div class="portal-unav-drawer-group">
                  <div class="portal-unav-drawer-title">${escapeHtml(grp.label)}</div>
                  <div class="portal-unav-drawer-links">
                    ${(grp.items || [])
                      .map((it) => {
                        const isItemActive = activeNavKey ? it.key === activeNavKey : it.tab === activeTab;
                        return `<button type="button" class="portal-unav-subpill" aria-current="${isItemActive ? "page" : "false"}" data-ws-nav-key="${escAttr(it.key)}">${escapeHtml(it.label)}</button>`;
                      })
                      .join("")}
                  </div>
                </div>`
            )
            .join("")}
        </div>`
      : `<div class="portal-unav-drawer" data-unav-drawer>
          <div class="portal-unav-drawer-links">
            ${navItems
              .map(
                ([id, label]) =>
                  `<button type="button" class="portal-unav-subpill" aria-current="${activeTab === id ? "page" : "false"}" data-ws-tab="${escAttr(id)}">${escapeHtml(label)}</button>`
              )
              .join("")}
          </div>
        </div>`;

    const breadcrumbsHtml =
      breadcrumbs.length && window.YuitorUI?.renderBreadcrumbs ? window.YuitorUI.renderBreadcrumbs(breadcrumbs) : "";

    const resolvedPageTitle = (() => {
      if (pageTitle) return pageTitle;
      if (breadcrumbs.length) return breadcrumbs[breadcrumbs.length - 1]?.label || portalBadgeLabel;
      if (useGroupedNav && activeGroupObj) {
        const hit = (activeGroupObj.items || []).find((it) => (activeNavKey ? it.key === activeNavKey : it.tab === activeTab));
        return hit?.label || activeGroupObj.label || portalBadgeLabel;
      }
      const flatHit = (navItems || []).find(([id]) => id === activeTab);
      return flatHit ? flatHit[1] : portalBadgeLabel;
    })();

    const v31PageHeaderHtml = window.YuitorV31?.renderPageHeader
      ? window.YuitorV31.renderPageHeader({
          title: resolvedPageTitle,
          subtitle: pageSubtitle || "",
          backLabel: "Back",
          breadcrumbsHtml,
        })
      : breadcrumbsHtml;

    const v31QuickSearchBtn = window.YuitorV31
      ? `<button type="button" class="v31-quicksearch-btn" data-v31-quicksearch-btn title="Quick Search (Ctrl+K)" aria-label="Quick Search">
           ${window.YuitorV31.lucideIcon("search")}
           <span>Search</span>
           <kbd>Ctrl+K</kbd>
         </button>`
      : "";

    const v31MailBtn =
      typeof onMailShortcut === "function"
        ? `<button type="button" class="portal-icon-btn" data-v31-mail-shortcut title="Mail Center" aria-label="Mail Center">
             ${icon("mail")}
           </button>`
        : "";

    document.documentElement.setAttribute("data-yu-portal-workspace", "1");
    const host = getPortalHost(main);
    host.innerHTML = `
      <div class="portal-workspace" data-portal-ws>
        <div class="portal-main-area">
          ${impersonationBanner(session)}
          <div class="portal-unav-wrap" data-testid="portal-unified-header">
            <div class="portal-unav-bar">
              <div class="portal-unav-toprow">
                <div class="portal-unav-left">
                  <button type="button" class="portal-icon-btn portal-unav-mobile-toggle" title="Toggle navigation menu" aria-label="Toggle navigation menu" aria-expanded="false" data-unav-mobile-toggle>
                    ${icon("menu")}
                  </button>
                  <div class="portal-unav-brand">
                    <img src="/yuitor-icon-192.png" alt="Yuitor Smart Classes logo">
                    <div class="portal-unav-brand-text">
                      <strong>Yuitor Smart Classes <span class="portal-unav-ver">v3.1</span></strong>
                      <div class="portal-unav-brand-sub">
                        <span style="font-size:11px;color:rgba(226,232,240,.85);font-weight:700;">Yuitor Portal</span>
                        <span class="portal-unav-portal-badge" data-testid="active-portal-badge">${escapeHtml(portalBadgeLabel)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="portal-unav-right portal-topbar-right">
                  ${v31QuickSearchBtn}
                  ${v31MailBtn}
                  <button type="button" class="portal-icon-btn" title="Toggle Light/Dark theme" aria-label="Toggle Light/Dark theme" data-theme-toggle>
                    ${icon(isDark ? "sun" : "moon")}
                  </button>
                  <div class="portal-notif-wrap">
                    <button type="button" class="portal-icon-btn" title="Notifications" aria-label="Notifications" data-notif-toggle>
                      ${icon("bell")}
                      ${unreadCount > 0 ? `<span class="portal-notif-dot">${unreadCount}</span>` : ""}
                    </button>
                    <div class="portal-notif-dropdown" data-notif-menu hidden>
                      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                        <strong style="font-size:12px;">Notifications (${notifications.length})</strong>
                        ${onReadNotifs ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-ws-read-notifs>Mark Read</button>` : ""}
                      </div>
                      ${
                        notifications.slice(0, 6).map((n) => `
                        <div class="portal-detail" style="margin-bottom:6px;padding:8px 10px;">
                          <span>${escapeHtml(n.created_at)} · ${n.is_read ? "Read" : "New"}</span>
                          <strong>${escapeHtml(n.title)}</strong>
                          <div style="font-size:12px;color:var(--pt-muted);">${escapeHtml(n.message)}</div>
                        </div>`).join("") || `<p class="portal-hint">No notifications right now.</p>`
                      }
                    </div>
                  </div>
                  <div class="portal-profile-wrap">
                    <button type="button" class="portal-profile-trigger" data-profile-toggle data-testid="profile-dropdown-trigger" aria-haspopup="menu" aria-expanded="false" title="Account menu">
                      <img src="${escAttr(avatarSrc)}" alt="${escAttr(session.user.full_name)}" class="portal-avatar" data-topbar-avatar style="width:32px;height:32px;border-radius:8px;">
                      <div class="portal-profile-labels">
                        <strong>${escapeHtml(session.user.full_name)}</strong>
                        <span>${escapeHtml(roleLabel)}</span>
                      </div>
                      ${icon("arrowDown", "portal-icon-svg portal-profile-caret")}
                    </button>
                    <div class="portal-profile-dropdown" data-profile-menu role="menu" hidden>
                      <div class="portal-profile-menu-meta">
                        <strong>${escapeHtml(session.user.full_name)}</strong>
                        <span>${escapeHtml(session.user.email || roleLabel)}</span>
                      </div>
                      <button type="button" class="portal-profile-menu-item" role="menuitem" data-open-photo-modal data-testid="menu-upload-photo">
                        ${icon("upload")}
                        <span>Upload / Change Profile Photo</span>
                      </button>
                      <button type="button" class="portal-profile-menu-item portal-profile-menu-item--danger" role="menuitem" data-portal-logout data-testid="menu-logout">
                        ${icon("logout")}
                        <span>Logout / Sign Out</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              ${centerNavHtml}
            </div>
            ${activeSubbarHtml}
            ${mobileDrawerHtml}
          </div>

          <div class="v31-content-shell">
            ${v31PageHeaderHtml}
            <div data-ws-body>${bodyHtml}</div>
          </div>
        </div>
      </div>`;

    bindGlobalImpersonationExit(main);
    if (breadcrumbs.length && window.YuitorUI?.bindBreadcrumbs && typeof onBreadcrumbSelect === "function") {
      window.YuitorUI.bindBreadcrumbs(main, async (bc) => {
        if (window.YuitorV31 && !(await window.YuitorV31.confirmDiscardIfDirty())) return;
        onBreadcrumbSelect(bc);
      });
    }

    if (window.YuitorV31) {
      window.YuitorV31.setFormDirty(false);
      window.YuitorV31.bindDirtyFormTracking(main);
      window.YuitorV31.pushNavState({ tab: activeTab, key: activeNavKey || "" });
      window.YuitorV31.bindBackButton(main, (prev) => {
        if (typeof onBack === "function") {
          onBack(prev);
        } else if (prev && prev.key && typeof onNavSelect === "function") {
          onNavSelect(prev.key);
        } else if (prev && prev.tab && prev.tab !== activeTab && typeof onTabChange === "function") {
          onTabChange(prev.tab);
        } else if (activeTab !== "overview" && activeTab !== "dashboard" && typeof onTabChange === "function") {
          onTabChange(useGroupedNav ? "dashboard" : "overview");
        } else if (window.history.length > 1) {
          window.history.back();
        }
      });

      const navRow = main.querySelector(".portal-unav-navrow");
      if (navRow) {
        requestAnimationFrame(() => window.YuitorV31.initOverflowNavbar(navRow));
        if (window.__yuV31ResizeHandler) window.removeEventListener("resize", window.__yuV31ResizeHandler);
        window.__yuV31ResizeHandler = () => {
          const nr = document.querySelector(".portal-unav-navrow");
          if (nr) window.YuitorV31.initOverflowNavbar(nr);
        };
        window.addEventListener("resize", window.__yuV31ResizeHandler);
      }

      const qsItems = useGroupedNav
        ? navGroups.flatMap((g) => (g.items || []).map((it) => ({ key: it.key, tab: it.tab, label: it.label, group: g.label })))
        : (navItems || []).map(([id, label]) => ({ tab: id, label, group: portalBadgeLabel }));
      window.YuitorV31.registerQuickSearch(qsItems, async (item) => {
        if (!(await window.YuitorV31.confirmDiscardIfDirty())) return;
        if (item.key && typeof onNavSelect === "function") onNavSelect(item.key);
        else if (item.tab && typeof onTabChange === "function") onTabChange(item.tab);
      });
      main.querySelector("[data-v31-quicksearch-btn]")?.addEventListener("click", () => {
        window.YuitorV31.openQuickSearchModal();
      });
    }

    main.querySelector("[data-v31-mail-shortcut]")?.addEventListener("click", async () => {
      if (window.YuitorV31 && !(await window.YuitorV31.confirmDiscardIfDirty())) return;
      if (typeof onMailShortcut === "function") onMailShortcut();
    });

    const mobileToggle = main.querySelector("[data-unav-mobile-toggle]");
    const mobileDrawer = main.querySelector("[data-unav-drawer]");
    mobileToggle?.addEventListener("click", (e) => {
      e.stopPropagation();
      const nextOpen = !mobileDrawer?.classList.contains("is-open");
      mobileDrawer?.classList.toggle("is-open", nextOpen);
      mobileToggle.setAttribute("aria-expanded", nextOpen ? "true" : "false");
    });

    main.querySelector("[data-theme-toggle]")?.addEventListener("click", () => {
      const next = !main.classList.contains("portal-dark");
      localStorage.setItem("yuitor_portal_dark", next ? "1" : "0");
      main.classList.toggle("portal-dark", next);
      onTabChange(activeTab);
    });

    const notifMenu = main.querySelector("[data-notif-menu]");
    const profileWrap = main.querySelector(".portal-profile-wrap");
    const profileBtn = main.querySelector("[data-profile-toggle]");
    const profileMenu = main.querySelector("[data-profile-menu]");
    const setProfileMenuOpen = (open) => {
      if (!profileMenu || !profileBtn) return;
      profileMenu.hidden = !open;
      profileBtn.setAttribute("aria-expanded", open ? "true" : "false");
      profileWrap?.classList.toggle("is-open", open);
    };

    const closeAllNavDropdowns = (exceptGroupId = "") => {
      main.querySelectorAll("[data-unav-group]").forEach((grpEl) => {
        const gid = grpEl.getAttribute("data-unav-group");
        if (gid && gid === exceptGroupId) return;
        grpEl.classList.remove("is-open");
        grpEl.querySelector("[data-unav-group-toggle]")?.setAttribute("aria-expanded", "false");
        const dd = grpEl.querySelector("[data-unav-dropdown]");
        if (dd) dd.hidden = true;
      });
    };

    main.querySelector("[data-notif-toggle]")?.addEventListener("click", (e) => {
      e.stopPropagation();
      setProfileMenuOpen(false);
      closeAllNavDropdowns();
      if (notifMenu) notifMenu.hidden = !notifMenu.hidden;
    });

    profileBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (notifMenu) notifMenu.hidden = true;
      closeAllNavDropdowns();
      setProfileMenuOpen(Boolean(profileMenu?.hidden));
    });

    main.querySelector("[data-open-photo-modal]")?.addEventListener("click", (e) => {
      e.stopPropagation();
      setProfileMenuOpen(false);
      openProfilePhotoModal(session);
    });

    if (useGroupedNav) {
      main.querySelectorAll("[data-unav-group-toggle]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          if (notifMenu) notifMenu.hidden = true;
          setProfileMenuOpen(false);
          const gid = btn.getAttribute("data-unav-group-toggle") || "";
          const grpEl = btn.closest("[data-unav-group]");
          const dd = grpEl?.querySelector("[data-unav-dropdown]");
          if (!grpEl || !dd) return;
          const willOpen = dd.hidden;
          closeAllNavDropdowns(willOpen ? gid : "");
          grpEl.classList.toggle("is-open", willOpen);
          btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
          dd.hidden = !willOpen;
        });
      });

      main.querySelectorAll("[data-ws-nav-key]").forEach((subBtn) => {
        subBtn.addEventListener("click", async () => {
          if (window.YuitorV31 && !(await window.YuitorV31.confirmDiscardIfDirty())) return;
          const key = subBtn.getAttribute("data-ws-nav-key");
          closeAllNavDropdowns();
          mobileDrawer?.classList.remove("is-open");
          mobileToggle?.setAttribute("aria-expanded", "false");
          if (typeof onNavSelect === "function" && key) {
            onNavSelect(key);
          }
        });
      });
    }

    main.querySelectorAll("[data-ws-tab]").forEach((b) => {
      b.addEventListener("click", async () => {
        if (window.YuitorV31 && !(await window.YuitorV31.confirmDiscardIfDirty())) return;
        mobileDrawer?.classList.remove("is-open");
        mobileToggle?.setAttribute("aria-expanded", "false");
        onTabChange(b.getAttribute("data-ws-tab"));
      });
    });

    if (window.__yuUnavOutsideHandler) {
      document.removeEventListener("click", window.__yuUnavOutsideHandler);
    }
    window.__yuUnavOutsideHandler = (e) => {
      if (!document.contains(main)) {
        document.removeEventListener("click", window.__yuUnavOutsideHandler);
        return;
      }
      if (notifMenu && !notifMenu.hidden && !e.target.closest(".portal-notif-wrap")) {
        notifMenu.hidden = true;
      }
      if (profileMenu && !profileMenu.hidden && !e.target.closest(".portal-profile-wrap")) {
        setProfileMenuOpen(false);
      }
      if (!e.target.closest("[data-unav-group]")) {
        closeAllNavDropdowns();
      }
    };
    document.addEventListener("click", window.__yuUnavOutsideHandler);

    main.querySelector("[data-ws-read-notifs]")?.addEventListener("click", async () => {
      if (onReadNotifs) await onReadNotifs();
    });

    main.querySelectorAll("[data-portal-logout]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await api("/api/auth/logout", { method: "POST" });
        } catch {
        }
        const logoutDest = isAdminPortal && GATE_BASE ? `${GATE_BASE}/` : "/login";
        window.location.assign(logoutDest);
      });
    });

    return main;
  }

  // ==================== PUBLIC COMPLEMENTARY PAGES ====================
  async function renderPublicExtension(path) {
    if (path.startsWith("/unsubscribe/")) {
      const token = path.split("/unsubscribe/")[1].split("/")[0];
      mountShell(`<div class="portal-card portal-login-card"><p class="portal-kicker">Email Preferences</p><div class="portal-heading"><h1>Loading preferences…</h1></div></div>`);
      try {
        const info = await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`);
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Yuitor Email Preferences</p>
            <div class="portal-heading"><h1>Manage Email Subscription</h1></div>
            <p class="portal-subtitle">Email: <strong>${escapeHtml(info.email)}</strong> · Current status: <strong>${escapeHtml(info.reason)}</strong></p>
            <div class="portal-actions" style="margin-top:20px;">
              <button type="button" class="portal-button" data-unsub-opt="false">Unsubscribe from Marketing Emails</button>
              <button type="button" class="portal-button portal-button--quiet" data-unsub-opt="true">Re-subscribe</button>
            </div>
            <div class="portal-message" data-unsub-fb hidden style="margin-top:16px;"></div>
          </div>`);
        main.querySelectorAll("[data-unsub-opt]").forEach((b) => {
          b.addEventListener("click", async () => {
            const opt = b.getAttribute("data-unsub-opt") === "true";
            const fb = main.querySelector("[data-unsub-fb]");
            try {
              await api(`/api/public/unsubscribe/${encodeURIComponent(token)}`, {
                method: "POST",
                body: { marketingOptIn: opt },
              });
              fb.className = "portal-message portal-message--success";
              fb.textContent = opt ? "Subscribed to Yuitor updates." : "You have been unsubscribed from Yuitor marketing emails.";
              fb.hidden = false;
            } catch (err) {
              fb.className = "portal-message portal-message--error";
              fb.textContent = err.message;
              fb.hidden = false;
            }
          });
        });
      } catch (err) {
        mountShell(`<div class="portal-card portal-login-card"><div class="portal-message portal-message--error">${escapeHtml(err.message)}</div></div>`);
      }
      return;
    }

    const boot = await api("/api/public/bootstrap");
    const courses = boot.courses || [];
    const subjects = boot.subjects || [];
    const teachers = boot.teachers || [];
    const faqs = boot.faqs || [];
    const testimonials = boot.testimonials || [];

    if (path === "/admission") {
      const admEmail = boot.departmentEmails?.admission || "admission@yuitor.com";
      const branchesList = boot.branches || [];
      const batchesList = boot.batches || [];
      const main = mountShell(`
        <p class="portal-kicker">Admissions Open · Muradnagar</p>
        <div class="portal-heading">
          <div>
            <h1>Apply for Admission &amp; Book Demo Class</h1>
            <p class="portal-subtitle">Yuitor Smart Classes · Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · Call/WhatsApp +91 78-2728-9292 · <a class="portal-text-link" href="mailto:${escAttr(admEmail)}">${escapeHtml(admEmail)}</a></p>
          </div>
          <a href="/register/student" class="portal-button portal-button--quiet">Student Portal Registration</a>
        </div>
        <div class="portal-card portal-profile">
          <form class="portal-form" data-adm-form>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Student Full Name *</label><input name="name" required placeholder="Full Name"></div>
              <div class="portal-field"><label>Mobile / WhatsApp Number *</label><input name="phone" required placeholder="10-digit number"></div>
              <div class="portal-field"><label>Email Address</label><input name="email" type="email" placeholder="student@example.com"></div>
              <div class="portal-field"><label>Class / Course *</label>
                <select name="class_or_course" required>
                  <option value="">Select Class or Course</option>
                  ${courses.map((c) => `<option value="${escAttr(c.title)}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}
                </select>
              </div>
              ${
                branchesList.length
                  ? `<div class="portal-field"><label>Preferred Centre / Branch</label>
                      <select name="branchId">
                        ${branchesList.map((br) => `<option value="${br.id}">${escapeHtml(br.name)} (${escapeHtml(br.city)})</option>`).join("")}
                      </select>
                    </div>`
                  : ""
              }
              ${
                batchesList.length
                  ? `<div class="portal-field"><label>Preferred Batch (Live Seat Availability)</label>
                      <select name="preferredBatch">
                        <option value="">Any Available Batch</option>
                        ${batchesList.map((b) => `<option value="${escAttr(`${b.name} (${b.start_time}-${b.end_time})`)}">${escapeHtml(b.name)} · ${escapeHtml(b.schedule_days)} ${escapeHtml(b.start_time)}–${escapeHtml(b.end_time)} (${Number(b.seats_remaining || 0)}/${Number(b.seat_limit || 0)} seats left)</option>`).join("")}
                      </select>
                    </div>`
                  : ""
              }
              <div class="portal-field"><label>Preferred Demo Class Date</label><input name="demoDate" type="date"></div>
              <div class="portal-field"><label>Preferred Demo Time Slot</label>
                <select name="demoTimeSlot">
                  <option value="">Select Demo Slot (Optional)</option>
                  <option value="Morning (7:30 AM - 9:30 AM)">Morning (7:30 AM – 9:30 AM)</option>
                  <option value="Afternoon (3:30 PM - 5:00 PM)">Afternoon (3:30 PM – 5:00 PM)</option>
                  <option value="Evening (5:00 PM - 7:30 PM)">Evening (5:00 PM – 7:30 PM)</option>
                </select>
              </div>
            </div>
            <div class="portal-field"><label>Notes / Questions</label><textarea name="message" placeholder="Preferred subjects, school name, or demo class questions..."></textarea></div>
            <div class="portal-message" data-adm-fb hidden></div>
            <div class="portal-actions"><button type="submit" class="portal-button">Submit Admission &amp; Demo Inquiry</button></div>
          </form>
        </div>`);
      const form = main.querySelector("[data-adm-form]");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        const fd = new FormData(form);
        const fb = main.querySelector("[data-adm-fb]");
        btn.disabled = true;
        const prefBatch = String(fd.get("preferredBatch") || "").trim();
        const rawNotes = String(fd.get("message") || "").trim();
        const combinedMessage = prefBatch ? `Preferred Batch: ${prefBatch}${rawNotes ? ` · ${rawNotes}` : ""}` : rawNotes;
        try {
          const res = await api("/api/public/inquiries", {
            method: "POST",
            body: {
              name: fd.get("name"),
              phone: fd.get("phone"),
              email: fd.get("email"),
              class_or_course: fd.get("class_or_course"),
              branchId: fd.get("branchId") ? Number(fd.get("branchId")) : undefined,
              demoDate: fd.get("demoDate") || "",
              demoTimeSlot: fd.get("demoTimeSlot") || "",
              message: combinedMessage,
              source: fd.get("demoDate") ? "demo_booking" : "admission_form",
            },
          });
          fb.className = "portal-message portal-message--success";
          fb.textContent = res.message;
          fb.hidden = false;
          form.reset();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
        } finally {
          btn.disabled = false;
        }
      });
      return;
    }

    if (path === "/subjects") {
      mountShell(`
        <p class="portal-kicker">Academic Directory</p>
        <div class="portal-heading"><h1>Subjects Offered (Classes 6th–12th &amp; Skills)</h1><a href="/admission" class="portal-button">Book Demo Class</a></div>
        <div class="portal-student-grid">
          ${subjects.map((s) => `<div class="portal-card portal-profile"><strong>${escapeHtml(s.name)}</strong><p class="portal-hint" style="margin-top:4px;">${escapeHtml(s.code)} · ${escapeHtml(s.class_level)}</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(s.description)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/ai-learning" || path === "/computer-courses" || path === "/english-speaking" || path === "/courses") {
      const initialCat =
        path === "/ai-learning"
          ? "AI Learning"
          : path === "/computer-courses"
            ? "Computer"
            : path === "/english-speaking"
              ? "English Speaking"
              : "All";
      let activeCat = initialCat;

      const drawCourses = () => {
        const list = activeCat === "All" ? courses : courses.filter((c) => c.category === activeCat);
        const heading = activeCat === "All" ? "All Courses & Fee Directory" : `${activeCat} Programmes`;
        const cats = ["All", "Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"];
        const main = mountShell(`
          <p class="portal-kicker">Yuitor Smart Classes Programmes</p>
          <div class="portal-heading"><h1>${escapeHtml(heading)}</h1><a href="/admission" class="portal-button">Apply for Admission</a></div>
          ${
            path === "/courses"
              ? `<div class="portal-actions" style="margin-bottom:18px;">
                  ${cats.map((c) => `<button type="button" class="portal-button portal-button--small ${activeCat === c ? "" : "portal-button--quiet"}" data-cat-pick="${escAttr(c)}">${escapeHtml(c)}</button>`).join("")}
                </div>`
              : ""
          }
          <div class="portal-form-grid">
            ${list
              .map(
                (c) => `
              <div class="portal-card portal-profile" style="overflow:hidden;">
                ${c.thumbnail_url ? `<img src="${escAttr(c.thumbnail_url)}" alt="${escAttr(c.title)} classroom at Yuitor Smart Classes" loading="lazy" style="width:100%;height:170px;object-fit:cover;border-radius:10px;margin-bottom:12px;">` : ""}
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
                  <span class="portal-status">${escapeHtml(c.category)}</span>
                  <span class="portal-hint">${c.duration_months} months · ${escapeHtml(c.board)}</span>
                </div>
                <h2 style="margin:0 0 8px;font-size:19px;">${escapeHtml(c.title)}</h2>
                <p class="portal-subtitle" style="font-size:13px;margin:0 0 12px;">${escapeHtml(c.description)}</p>
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;border-top:1px solid var(--pt-border);padding-top:12px;">
                  <div><strong>${formatINR(c.monthly_fee)}/mo</strong> <span class="portal-hint">or ${formatINR(c.yearly_fee)}/yr</span></div>
                  <div style="display:flex;gap:6px;flex-wrap:wrap;">
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-yu-add-cart="${c.id}">Add to Cart</button>
                    <a href="/admission" class="portal-button portal-button--small">Enroll</a>
                  </div>
                </div>
              </div>`
              )
              .join("")}
          </div>`);
        main?.querySelectorAll("[data-cat-pick]").forEach((b) => {
          b.addEventListener("click", () => {
            activeCat = b.getAttribute("data-cat-pick");
            drawCourses();
          });
        });
        main?.querySelectorAll("[data-yu-add-cart]").forEach((b) => {
          b.addEventListener("click", async () => {
            b.disabled = true;
            try {
              await window.YuitorAddons?.addToCartAndOpen(b.getAttribute("data-yu-add-cart"), "monthly");
            } finally {
              b.disabled = false;
            }
          });
        });
      };
      drawCourses();
      return;
    }

    if (path === "/teachers") {
      const careerEmail = boot.departmentEmails?.career || "career@yuitor.com";
      mountShell(`
        <p class="portal-kicker">Faculty &amp; Mentors</p>
        <div class="portal-heading"><div><h1>Approved Faculty &amp; Teachers</h1><p class="portal-subtitle">Experienced educators teaching at Yuitor Smart Classes, Muradnagar. Hiring queries: <a class="portal-text-link" href="mailto:${escAttr(careerEmail)}">${escapeHtml(careerEmail)}</a></p></div><a href="/register/teacher" class="portal-button portal-button--quiet">Join as Teacher</a></div>
        <div class="portal-card portal-profile yu-teachers-showcase">
          <div>
            <h2 style="margin:0 0 8px;font-size:20px;">Mentorship-Driven Teaching in Muradnagar</h2>
            <p class="portal-subtitle" style="font-size:14px;margin:0 0 12px;">Every faculty application at Yuitor undergoes resume screening and academic verification before teaching Classes 5th–12th, JEE, NEET, CUET, Computer, and Spoken English batches.</p>
            <div class="portal-actions">
              <a href="/admission" class="portal-button portal-button--small">Book a Demo Class</a>
              <a href="/register/teacher" class="portal-button portal-button--small portal-button--quiet">Apply with Resume</a>
            </div>
          </div>
          <img src="/assets/images/teacher-classroom-guidance.webp" alt="Faculty mentoring students at Yuitor Smart Classes Muradnagar" loading="lazy">
        </div>
        ${
          teachers.length === 0
            ? `<div class="portal-card portal-empty">Verified faculty cards appear here automatically once teacher resumes and profiles are approved by the Yuitor Academic Team.</div>`
            : `<div class="portal-student-grid">
            ${teachers.map((t) => `<div class="portal-card portal-profile"><img src="${escAttr(t.avatar_url || "/assets/images/teacher-led-class.webp")}" alt="${escAttr(t.full_name)}" class="portal-avatar" style="margin-bottom:10px;object-fit:cover;"><h3 style="margin:0 0 4px;">${escapeHtml(t.full_name)}</h3><p class="portal-hint">${escapeHtml(t.qualification || "Faculty Member")} · ${Number(t.experience_years || 0)} yrs exp</p><p class="portal-subtitle" style="font-size:13px;margin-top:8px;">${escapeHtml(t.bio || "")}</p></div>`).join("")}
          </div>`
        }`);
      return;
    }

    if (path === "/faqs") {
      mountShell(`
        <p class="portal-kicker">Questions &amp; Answers</p>
        <div class="portal-heading"><h1>Frequently Asked Questions</h1></div>
        <div class="portal-form">
          ${faqs.map((f) => `<div class="portal-card portal-profile"><h3 style="margin:0 0 6px;">${escapeHtml(f.question)}</h3><p class="portal-subtitle" style="font-size:14px;margin:0;">${escapeHtml(f.answer)}</p></div>`).join("")}
        </div>`);
      return;
    }

    if (path === "/testimonials") {
      mountShell(`
        <p class="portal-kicker">Student &amp; Parent Stories</p>
        <div class="portal-heading"><h1>Verified Reviews &amp; Testimonials</h1></div>
        <div class="portal-student-grid">
          ${testimonials.map((t) => `<div class="portal-card portal-profile"><p style="margin:0 0 12px;line-height:1.6;">“${escapeHtml(t.quote)}”</p><strong>${escapeHtml(t.author_name)}</strong><div class="portal-hint">${escapeHtml(t.author_role)}${t.outcome_metric ? " · " + escapeHtml(t.outcome_metric) : ""}</div></div>`).join("")}
        </div>`);
    }
  }

  // ==================== AUTHENTICATION, HARDENED INSTALLER & SECRET GATE ====================
  async function renderAdminSetup() {
    if (!GATE_BASE || !ADMIN_API_BASE) {
      return;
    }
    let formState = {
      fullName: "",
      email: "",
      phone: "+91 ",
      setupKey: "",
      otp: "",
      otpEmail: "",
      writeEnv: false,
      smtpHost: "mail.yuitor.com",
      smtpPort: "465",
      smtpSecure: "true",
      smtpUser: "no-reply@yuitor.com",
      smtpFrom: "no-reply@yuitor.com",
    };
    let transientSmtpPass = "";
    let showSmtpEditor = false;
    let otpSentMsg = "";
    let needsDbConfirm = false;
    let needsEnvConfirm = false;
    let setupStructuredErr = null;
    let setupSuccess = null;

    const renderStructuredErrorBox = (errObj) => {
      if (!errObj) return "";
      return `
        <div class="portal-error-box" data-testid="installer-structured-error">
          <h4>Step Failed: ${escapeHtml(errObj.step || "Installation")}</h4>
          <div><strong>What failed:</strong> ${escapeHtml(errObj.whatFailed || "Unexpected error")}</div>
          <div><strong>Why:</strong> ${escapeHtml(errObj.why || "")}</div>
          <div><strong>How to fix:</strong> ${escapeHtml(errObj.howToFix || "Check logs/install.log and retry.")}</div>
          <div style="margin-top:6px;font-size:11.5px;opacity:0.85;">Full technical trace (secrets redacted) recorded in <code>logs/install.log</code>.</div>
        </div>`;
    };

    async function loadPreflightAndDraw() {
      let pre = null;
      let preErr = null;
      try {
        pre = await api(adminApiUrl("/installer/preflight"));
      } catch (err) {
        preErr = err?.data?.error || {
          step: "Preflight Check",
          whatFailed: err?.message || "Unable to inspect server prerequisites",
          why: "Server preflight endpoint returned an error.",
          howToFix: "Ensure Node.js 22+ is active and data/ and logs/ directories have 755 permissions.",
        };
      }

      if (setupSuccess) {
        const main = mountShell(`
          <div class="portal-card portal-login-card" style="width:min(620px,100%);">
            <p class="portal-kicker">Installation Complete · Installer Locked</p>
            <div class="portal-heading"><h1>Super Admin Initialized</h1></div>
            <p class="portal-subtitle">The installer is now permanently locked. Bookmark your Secret Admin Gate URL below — it is shown once for your records.</p>
            <div class="portal-gate-reveal" data-testid="installer-gate-reveal">
              <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#1d4ed8;margin-bottom:4px;">Your Secret Admin Gate URL</div>
              <strong style="font-size:15px;display:block;margin-bottom:8px;" data-gate-url-text>${escapeHtml(setupSuccess.fullAdminGateUrl || setupSuccess.adminGateUrl)}</strong>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-copy-gate-url>Copy URL</button>
                <a href="${escAttr(setupSuccess.adminGateUrl)}" class="portal-button portal-button--small" data-testid="link-enter-admin-gate">Enter Admin Console</a>
              </div>
            </div>
          </div>`);
        main?.querySelector("[data-copy-gate-url]")?.addEventListener("click", async () => {
          const text = setupSuccess.fullAdminGateUrl || setupSuccess.adminGateUrl;
          try {
            await navigator.clipboard.writeText(text);
            const btn = main.querySelector("[data-copy-gate-url]");
            if (btn) btn.textContent = "Copied!";
          } catch {}
        });
        return;
      }

      if (pre?.existingState && pre.existingState.adminCount > 0) {
        mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Installer Locked</p>
            <div class="portal-heading"><h1>Setup Already Completed</h1></div>
            <div class="portal-message portal-message--success">An administrator account already exists (${pre.existingState.adminCount} admin account${pre.existingState.adminCount === 1 ? "" : "s"}). This installer is automatically locked to prevent unauthorized overwrites.</div>
            <div class="portal-actions">
              <a href="${escAttr(GATE_BASE)}/" class="portal-button">Proceed to Admin Gate Login</a>
            </div>
          </div>`);
        return;
      }

      const maskedOtpEmail = formState.otpEmail.trim()
        ? formState.otpEmail.trim()
        : pre?.existingState?.otpRecipientMasked || "configured admin email";
      const smtpConfigured = Boolean(pre?.existingState?.smtpConfigured);
      const smtpEditorOpen = !smtpConfigured || showSmtpEditor;

      const checksHtml = (pre?.checks || [])
        .map((c) => {
          const cls = c.ok ? "is-ok" : c.required ? "is-fail" : "is-warn";
          return `
            <div class="portal-preflight-item ${cls}">
              <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
                <strong>${c.ok ? "✓" : c.required ? "✕" : "!"} ${escapeHtml(c.label)}</strong>
                <span>${c.ok ? "Ready" : c.required ? "Required" : "Action Needed"}</span>
              </div>
              <div style="margin-top:3px;opacity:0.9;">${escapeHtml(c.detail)}</div>
              ${!c.ok && c.howToFix ? `<div style="margin-top:4px;"><strong>Fix:</strong> ${escapeHtml(c.howToFix)}</div>` : ""}
            </div>`;
        })
        .join("");

      const smtpSetupBox = smtpEditorOpen
        ? `
          <div class="portal-card portal-profile" style="margin-top:14px;padding:14px 16px;" data-installer-smtp-box>
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px;">
              <h3 class="portal-section-title" style="margin-bottom:0;">Step 1A · Configure Mail Server (cPanel SSL/TLS Recommended)</h3>
              ${smtpConfigured ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-smtp-editor>Hide SMTP Editor</button>` : ""}
            </div>
            <p class="portal-hint" style="margin-bottom:10px;">Default cPanel settings: Outgoing Host <code>mail.yuitor.com</code>, Port <code>465</code> (Direct SSL/TLS), Username <code>no-reply@yuitor.com</code>, and your mailbox password.</p>
            <div class="portal-form-grid">
              <div class="portal-field"><label>SMTP Host *</label><input name="smtpHost" value="${escAttr(formState.smtpHost)}" placeholder="mail.yuitor.com"></div>
              <div class="portal-field"><label>SMTP Port *</label><input name="smtpPort" type="number" value="${escAttr(formState.smtpPort)}" placeholder="465"></div>
              <div class="portal-field"><label>SSL/TLS Mode</label><select name="smtpSecure"><option value="true" ${formState.smtpSecure === "true" ? "selected" : ""}>Direct SSL/TLS (Port 465)</option><option value="false" ${formState.smtpSecure === "false" ? "selected" : ""}>STARTTLS (Port 587)</option></select></div>
              <div class="portal-field"><label>SMTP Username (Full Email) *</label><input name="smtpUser" value="${escAttr(formState.smtpUser)}" placeholder="no-reply@yuitor.com"></div>
              <div class="portal-field"><label>Mailbox Password *</label>${passwordFieldHtml("smtpPass", 'autocomplete="new-password"')}</div>
              <div class="portal-field"><label>Sender From Email</label><input name="smtpFrom" type="email" value="${escAttr(formState.smtpFrom)}" placeholder="no-reply@yuitor.com"></div>
              <div class="portal-field" style="grid-column:1 / -1;"><label>OTP Recipient Email (Where to receive 6-digit OTP)</label><input name="otpEmail" type="email" value="${escAttr(formState.otpEmail)}" placeholder="admin@yuitor.com (optional — defaults to server setting)"></div>
            </div>
          </div>`
        : `
          <div style="margin-top:12px;display:flex;justify-content:flex-end;">
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-smtp-editor>Change / Edit SMTP Settings</button>
          </div>`;

      const main = mountShell(`
        <div class="portal-card portal-login-card" style="width:min(700px,100%);">
          <p class="portal-kicker">Hardened Setup Wizard · OTP Protected Gate</p>
          <div class="portal-heading">
            <div>
              <h1>Yuitor Platform Installer</h1>
              <p class="portal-subtitle">Protected by mandatory 6-digit Email OTP to <strong>${escapeHtml(maskedOtpEmail)}</strong> so only the owner can install.</p>
            </div>
            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-retry-preflight>Retry Checks</button>
          </div>
          ${renderStructuredErrorBox(preErr || pre?.error || setupStructuredErr)}
          <div class="portal-preflight-list" data-testid="installer-preflight-list">${checksHtml}</div>
          ${
            pre?.existingState?.userCount > 0
              ? `<div class="portal-message">Existing database records detected (${pre.existingState.userCount} user accounts, ${pre.existingState.courseCount} courses). Existing data will be preserved automatically.</div>`
              : ""
          }
          <form class="portal-form" data-setup-form style="margin-top:16px;">
            ${
              pre?.existingState?.requiresSetupKey
                ? `<div class="portal-field"><label>Server Setup Key (YU_ADMIN_SETUP_KEY) *</label><input name="setupKey" type="password" required value="${escAttr(formState.setupKey)}" placeholder="Enter server setup key"></div>`
                : ""
            }
            ${smtpSetupBox}
            <div class="portal-card portal-profile" style="margin-top:14px;padding:14px 16px;">
              <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
                <div>
                  <strong style="font-size:13.5px;">${smtpEditorOpen ? "Step 1B" : "Step 1"} · Request Installer OTP</strong>
                  <div class="portal-hint">OTP will be emailed to <strong>${escapeHtml(maskedOtpEmail)}</strong> (valid 10 minutes).</div>
                </div>
                <button type="button" class="portal-button portal-button--small" data-send-setup-otp data-testid="button-send-setup-otp">Send OTP to ${escapeHtml(maskedOtpEmail)}</button>
              </div>
              ${otpSentMsg ? `<div class="portal-message portal-message--success" style="margin-top:10px;" data-setup-otp-fb>${escapeHtml(otpSentMsg)}</div>` : `<div class="portal-message" style="margin-top:10px;" data-setup-otp-fb hidden></div>`}
            </div>
            <div class="portal-form-grid" style="margin-top:14px;">
              <div class="portal-field"><label>Full Name *</label><input name="fullName" required value="${escAttr(formState.fullName)}" placeholder="Administrator Name"></div>
              <div class="portal-field"><label>Admin Login Email *</label><input name="email" type="email" required value="${escAttr(formState.email)}" placeholder="admin@yuitor.com"></div>
              <div class="portal-field"><label>Mobile Number *</label><input name="phone" required value="${escAttr(formState.phone)}" placeholder="+91 78-2728-9292"></div>
              <div class="portal-field"><label>Admin Password (min 8 chars) *</label>${passwordFieldHtml("password", 'minlength="8" required')}</div>
              <div class="portal-field"><label>6-Digit Email OTP (from ${escapeHtml(maskedOtpEmail)}) *</label><input name="otp" required maxlength="6" inputmode="numeric" pattern="\\d{6}" value="${escAttr(formState.otp)}" placeholder="Enter 6-digit Email OTP" data-testid="input-setup-otp"></div>
            </div>
            ${
              pre?.existingState?.hasEnvFile
                ? `<label class="portal-clear-check"><input type="checkbox" name="writeEnv" value="1" ${formState.writeEnv ? "checked" : ""}> Also sync ADMIN_PATH slug to server <code>.env</code> file</label>`
                : ""
            }
            ${
              pre?.existingState?.userCount > 0 || needsDbConfirm
                ? `<label class="portal-clear-check"><input type="checkbox" name="confirmExistingDb" value="1" required> Confirm adding Super Admin into the existing database without overwriting existing records</label>`
                : ""
            }
            ${
              needsEnvConfirm
                ? `<label class="portal-clear-check"><input type="checkbox" name="confirmOverwriteEnv" value="1" required> Confirm updating existing <code>.env</code> file with ADMIN_PATH</label>`
                : ""
            }
            <div class="portal-message" data-setup-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button" ${pre && !pre.ok ? "disabled" : ""} data-testid="button-run-installer">Verify OTP &amp; Complete Setup</button>
            </div>
          </form>
        </div>`);

      bindPasswordToggles(main);
      const form = main?.querySelector("[data-setup-form]");
      const smtpPassInput = form?.querySelector('input[name="smtpPass"]');
      if (smtpPassInput && transientSmtpPass) {
        smtpPassInput.value = transientSmtpPass;
      }

      const captureFormFields = () => {
        if (!form) return;
        const fd = new FormData(form);
        if (smtpPassInput) {
          transientSmtpPass = String(smtpPassInput.value || "");
        }
        formState = {
          fullName: String(fd.get("fullName") || ""),
          email: String(fd.get("email") || ""),
          phone: String(fd.get("phone") || ""),
          setupKey: String(fd.get("setupKey") || ""),
          otp: String(fd.get("otp") || ""),
          otpEmail: String(fd.get("otpEmail") ?? formState.otpEmail),
          writeEnv: fd.get("writeEnv") === "1",
          smtpHost: String(fd.get("smtpHost") ?? formState.smtpHost),
          smtpPort: String(fd.get("smtpPort") ?? formState.smtpPort),
          smtpSecure: String(fd.get("smtpSecure") ?? formState.smtpSecure),
          smtpUser: String(fd.get("smtpUser") ?? formState.smtpUser),
          smtpFrom: String(fd.get("smtpFrom") ?? formState.smtpFrom),
        };
      };

      const secureSelect = form?.querySelector('select[name="smtpSecure"]');
      const portInput = form?.querySelector('input[name="smtpPort"]');
      secureSelect?.addEventListener("change", () => {
        if (portInput) {
          portInput.value = secureSelect.value === "true" ? "465" : "587";
        }
      });

      main?.querySelector("[data-toggle-smtp-editor]")?.addEventListener("click", () => {
        captureFormFields();
        showSmtpEditor = !showSmtpEditor;
        loadPreflightAndDraw();
      });

      main?.querySelector("[data-retry-preflight]")?.addEventListener("click", () => {
        captureFormFields();
        setupStructuredErr = null;
        loadPreflightAndDraw();
      });

      main?.querySelector("[data-send-setup-otp]")?.addEventListener("click", async () => {
        captureFormFields();
        const sendBtn = main.querySelector("[data-send-setup-otp]");
        const otpFb = main.querySelector("[data-setup-otp-fb]");
        if (sendBtn) sendBtn.disabled = true;
        setupStructuredErr = null;
        try {
          const bodyPayload = {
            setupKey: formState.setupKey,
          };
          if (formState.otpEmail.trim()) {
            bodyPayload.otpEmail = formState.otpEmail.trim();
          }
          if (smtpEditorOpen && form) {
            const fd = new FormData(form);
            const host = String(fd.get("smtpHost") || "").trim();
            const user = String(fd.get("smtpUser") || "").trim();
            const pass = String(fd.get("smtpPass") || "");
            if (host || user || pass.trim()) {
              bodyPayload.smtp = {
                host,
                port: Number(fd.get("smtpPort") || 465),
                secure: String(fd.get("smtpSecure") || "true"),
                user,
                pass,
                fromEmail: String(fd.get("smtpFrom") || "").trim(),
              };
            }
          }
          const res = await api(adminApiUrl("/installer/send-otp"), {
            method: "POST",
            body: bodyPayload,
          });
          otpSentMsg = res.message || `6-digit OTP sent to ${res.recipientMasked || maskedOtpEmail}.`;
          showSmtpEditor = false;
          await loadPreflightAndDraw();
        } catch (err) {
          if (err?.data?.structuredError) {
            setupStructuredErr = err.data.structuredError;
            await loadPreflightAndDraw();
            return;
          }
          if (otpFb) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Failed to send Installer OTP.";
            otpFb.hidden = false;
          }
        } finally {
          if (sendBtn) sendBtn.disabled = false;
        }
      });

      form?.addEventListener("submit", async (e) => {
        e.preventDefault();
        captureFormFields();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-setup-fb]");
        const btn = form.querySelector("[data-testid='button-run-installer']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/installer/run"), {
            method: "POST",
            body: {
              fullName: formState.fullName,
              email: formState.email,
              phone: formState.phone,
              password: String(fd.get("password") || ""),
              otp: formState.otp,
              otpEmail: formState.otpEmail.trim() || undefined,
              setupKey: formState.setupKey,
              writeEnv: formState.writeEnv,
              confirmExistingDb: fd.get("confirmExistingDb") === "1",
              confirmOverwriteEnv: fd.get("confirmOverwriteEnv") === "1",
            },
          });
          transientSmtpPass = "";
          setupSuccess = res;
          await loadPreflightAndDraw();
        } catch (err) {
          if (err?.data?.requiresConfirmation) {
            if (err.data.confirmationType === "existing_db") needsDbConfirm = true;
            if (err.data.confirmationType === "overwrite_env") needsEnvConfirm = true;
            setupStructuredErr = {
              step: "Confirmation Required",
              whatFailed: err.message,
              why: "Installer requires explicit confirmation before continuing.",
              howToFix: "Tick the confirmation checkbox below and click Verify OTP & Complete Setup again.",
            };
            await loadPreflightAndDraw();
            return;
          }
          if (err?.data?.structuredError) {
            setupStructuredErr = err.data.structuredError;
            await loadPreflightAndDraw();
            return;
          }
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
    }

    await loadPreflightAndDraw();
  }

  function renderAdminGateLogin(initialError = "") {
    let challengeToken = "";
    let recipientMasked = "";
    let stepMsg = "";

    function drawLogin() {
      if (challengeToken) {
        const main = mountShell(`
          <div class="portal-card portal-login-card">
            <p class="portal-kicker">Step 2 · Mandatory Email Verification</p>
            <div class="portal-heading"><h1>Enter Admin Sign-In OTP</h1></div>
            <p class="portal-subtitle">Enter the 6-digit verification code emailed to <strong>${escapeHtml(recipientMasked || "configured admin email")}</strong> (valid for 10 minutes).</p>
            ${stepMsg ? `<div class="portal-message portal-message--success" style="margin-top:10px;">${escapeHtml(stepMsg)}</div>` : ""}
            <form class="portal-form" data-admin-gate-otp-form style="margin-top:14px;">
              <div class="portal-field"><label>6-Digit Email OTP *</label><input name="otp" required maxlength="6" inputmode="numeric" pattern="\\d{6}" autocomplete="one-time-code" placeholder="Enter 6-digit OTP" data-testid="input-admin-otp"></div>
              <div class="portal-message" data-gate-otp-fb hidden></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button" data-testid="button-admin-verify-otp">Verify OTP &amp; Enter Console</button>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-resend-admin-otp data-testid="button-admin-resend-otp">Resend OTP</button>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-admin-pw data-testid="button-admin-back-pw">Back</button>
              </div>
            </form>
          </div>`);

        const otpForm = main?.querySelector("[data-admin-gate-otp-form]");
        const otpFb = main?.querySelector("[data-gate-otp-fb]");
        otpForm?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(otpForm);
          const btn = otpForm.querySelector("[data-testid='button-admin-verify-otp']");
          if (btn) btn.disabled = true;
          try {
            await api(adminApiUrl("/auth/verify-otp"), {
              method: "POST",
              body: {
                challengeToken,
                otp: String(fd.get("otp") || ""),
              },
            });
            window.location.assign(`${GATE_BASE}/`);
          } catch (err) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Invalid or expired OTP.";
            otpFb.hidden = false;
            if (btn) btn.disabled = false;
          }
        });

        main?.querySelector("[data-resend-admin-otp]")?.addEventListener("click", async () => {
          const btn = main.querySelector("[data-resend-admin-otp]");
          if (btn) btn.disabled = true;
          try {
            const res = await api(adminApiUrl("/auth/resend-otp"), {
              method: "POST",
              body: { challengeToken },
            });
            otpFb.className = "portal-message portal-message--success";
            otpFb.textContent = res.message || `Fresh OTP sent to ${recipientMasked}.`;
            otpFb.hidden = false;
          } catch (err) {
            otpFb.className = "portal-message portal-message--error";
            otpFb.textContent = err.message || "Failed to resend OTP.";
            otpFb.hidden = false;
          } finally {
            if (btn) btn.disabled = false;
          }
        });

        main?.querySelector("[data-back-admin-pw]")?.addEventListener("click", () => {
          challengeToken = "";
          stepMsg = "";
          drawLogin();
        });
        return;
      }

      const main = mountShell(`
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Restricted Console · 2FA Secret Gate</p>
          <div class="portal-heading"><h1>Administrator Sign In</h1></div>
          <p class="portal-subtitle">Authorized administrators only. Every sign-in verifies both your password and a 6-digit Email OTP.</p>
          ${initialError ? `<div class="portal-message portal-message--error">${escapeHtml(initialError)}</div>` : ""}
          <form class="portal-form" data-admin-gate-login-form style="margin-top:14px;">
            <div class="portal-field"><label>Administrator Email or Mobile</label><input name="identifier" required autocomplete="username" placeholder="admin@yuitor.com"></div>
            <div class="portal-field"><label>Password</label>${passwordFieldHtml("password", 'required autocomplete="current-password"')}</div>
            <div class="portal-message" data-gate-login-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button" data-testid="button-admin-signin">Continue &amp; Send Email OTP</button>
            </div>
          </form>
        </div>`);
      bindPasswordToggles(main);
      const form = main?.querySelector("[data-admin-gate-login-form]");
      form?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const fb = main.querySelector("[data-gate-login-fb]");
        const btn = form.querySelector("[data-testid='button-admin-signin']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/auth/login"), {
            method: "POST",
            body: {
              identifier: String(fd.get("identifier") || ""),
              password: String(fd.get("password") || ""),
            },
          });
          if (res?.otpRequired && res?.challengeToken) {
            challengeToken = res.challengeToken;
            recipientMasked = res.recipientMasked || "configured admin email";
            stepMsg = res.message || `6-digit OTP sent to ${recipientMasked}.`;
            drawLogin();
            return;
          }
          window.location.assign(`${GATE_BASE}/`);
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message || "Administrator login failed.";
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
    }

    drawLogin();
  }

  function buildSplitAuthVisual(portalKind) {
    const isTeacher = portalKind === "teacher";
    const imgSrc = isTeacher ? "/assets/portal-teacher-auth.jpg" : "/assets/portal-student-auth.jpg";
    const imgAlt = isTeacher
      ? "Yuitor Smart Classes Teacher mentoring students at interactive smart board"
      : "Yuitor Smart Classes Students studying in smart classroom";
    const kicker = isTeacher ? "Teacher & Faculty Portal" : "Student & Parent Portal";
    const heading = isTeacher
      ? "Dedicated Faculty Workspace for Yuitor Mentors"
      : "Smart Learning & Parent Tracking in One Place";
    const desc = isTeacher
      ? "Manage batch attendance, upload chapter notes, publish Sunday test marks, resolve student doubts, and track teacher referral payouts."
      : "Access Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking & Skill Courses — plus Parent attendance & fee tracking.";
    const points = isTeacher
      ? [
          "Instant Email or Mobile OTP Login & Registration",
          "Upload Resume (PDF/DOC/DOCX) for Fast Verification",
          "Batch Timetables, Test Grading & Wallet Withdrawals",
        ]
      : [
          "Both Student & Parent / Guardian Access Here",
          "Instant 6-Digit OTP on Email (Mail) or Mobile Number",
          "Live Attendance, Sunday Ranks, Fee Receipts & Referral Wallet",
        ];

    return `
      <div class="yu-auth-visual">
        <img class="yu-auth-photo" src="${imgSrc}" alt="${escAttr(imgAlt)}" onerror="this.style.display='none'">
        <div class="yu-auth-visual-scrim" aria-hidden="true"></div>
        <div class="yu-auth-visual-top">
          <a href="/" class="yu-auth-brand-lockup">
            <img src="/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png" alt="Yuitor Smart Classes Logo">
            <span>
              <span class="yu-auth-brand-title">Yuitor Smart Classes</span>
              <span class="yu-auth-brand-tag">Ek Kadam Safalta Ki Our</span>
            </span>
          </a>
        </div>
        <div class="yu-auth-visual-bottom">
          <p class="yu-auth-visual-kicker">${kicker}</p>
          <h2>${heading}</h2>
          <p class="yu-auth-visual-desc">${desc}</p>
          <ul class="yu-auth-visual-points">
            ${points.map((pt) => `<li>${escapeHtml(pt)}</li>`).join("")}
          </ul>
        </div>
      </div>`;
  }

  function renderSplitAuth(portalKind = "student", initialMode = "login", defaultSubRole = "student", initialError = "") {
    const isTeacherPortal = portalKind === "teacher";
    const isStaffPortal = portalKind === "staff";
    let authMode = initialMode === "register" && !isStaffPortal ? "register" : "login"; // 'login' | 'register' | 'forgot' | 'reset' | 'otp' | 'pending'
    let loginTab = "password"; // 'password' | 'otp'
    let studentSubRole = isTeacherPortal ? "teacher" : defaultSubRole === "parent" ? "parent" : "student";
    let otpLoginChannel = "email";
    let otpLoginIdentifier = "";
    let otpLoginSent = false;
    let otpLoginNote = "";
    let otpLoginIsError = false;
    let otpLoginMasked = "";
    let resetIdentifier = "";
    let resetNote = "";

    // Registration / Pending OTP state
    let registeredPhone = "";
    let registeredEmail = "";
    let registeredOtpChannel = "email";
    let registeredName = "";
    let registeredRole = isTeacherPortal ? "teacher" : studentSubRole;
    let limitationMsg = "";
    let otpSuccessMsg = "";
    let pendingCustomMsg = "";
    let selectedResumeFile = null;
    let otpCooldownSec = 0;
    let otpTimerId = null;
    let publicBranches = [];

    api("/api/public/bootstrap")
      .then((b) => {
        if (Array.isArray(b?.branches) && b.branches.length) {
          publicBranches = b.branches;
          const sel = root.querySelector('[data-reg-form] select[name="branchId"]');
          if (sel) {
            sel.innerHTML = publicBranches
              .map((br) => `<option value="${br.id}">${escapeHtml(br.name)} (${escapeHtml(br.city)})</option>`)
              .join("");
          }
        }
      })
      .catch(() => {});

    function stopOtpTimer() {
      if (otpTimerId) {
        window.clearInterval(otpTimerId);
        otpTimerId = null;
      }
    }

    function startOtpCooldown(seconds = 30) {
      stopOtpTimer();
      otpCooldownSec = Math.max(0, Number(seconds) || 0);
      const syncBtn = () => {
        const btn = root.querySelector("[data-resend-otp]");
        if (!btn) {
          stopOtpTimer();
          return;
        }
        if (otpCooldownSec > 0) {
          btn.disabled = true;
          btn.textContent = `Resend OTP (${otpCooldownSec}s)`;
        } else {
          btn.disabled = false;
          btn.textContent = registeredOtpChannel === "email" ? "Resend on Email" : "Resend on Mobile";
          stopOtpTimer();
        }
      };
      syncBtn();
      if (otpCooldownSec > 0) {
        otpTimerId = window.setInterval(() => {
          otpCooldownSec = Math.max(0, otpCooldownSec - 1);
          syncBtn();
        }, 1000);
      }
    }

    function formatBytes(bytes) {
      const n = Number(bytes || 0);
      if (n < 1024) return `${n} B`;
      if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
      return `${(n / (1024 * 1024)).toFixed(2)} MB`;
    }

    function isValidResumeExtension(name) {
      return /\.(pdf|doc|docx)$/i.test(String(name || ""));
    }

    function wrapSplit(rightHtml) {
      return mountShell(`
        <div class="yu-auth-split">
          ${buildSplitAuthVisual(isTeacherPortal ? "teacher" : "student")}
          <div class="yu-auth-panel">
            ${rightHtml}
          </div>
        </div>`);
    }

    function switchBarHtml() {
      if (isTeacherPortal) {
        return `
          <div class="yu-auth-switch-bar">
            <span>Looking for Student or Parent account?</span>
            <a href="/student/login">Go to Student &amp; Parent Portal &rarr;</a>
          </div>`;
      }
      return `
        <div class="yu-auth-switch-bar">
          <span>Are you a Teacher / Faculty?</span>
          <a href="/teacher/login">Go to Teacher Portal &rarr;</a>
        </div>`;
    }

    function topModeTabsHtml() {
      if (isStaffPortal) return "";
      const loginLabel = isTeacherPortal ? "Teacher Sign In" : "Student / Parent Sign In";
      const regLabel = isTeacherPortal ? "Teacher Registration" : "New Registration";
      return `
        <div class="yu-auth-mode-tabs" role="tablist" aria-label="Authentication mode">
          <button type="button" role="tab" aria-selected="${authMode === "login"}" class="yu-auth-mode-tab ${authMode === "login" ? "is-active" : ""}" data-auth-mode="login">${loginLabel}</button>
          <button type="button" role="tab" aria-selected="${authMode === "register"}" class="yu-auth-mode-tab ${authMode === "register" ? "is-active" : ""}" data-auth-mode="register">${regLabel}</button>
        </div>`;
    }

    function draw() {
      if (authMode === "pending") {
        stopOtpTimer();
        const isTeacher = registeredRole === "teacher";
        const isParent = registeredRole === "parent";
        const headingText = isTeacher
          ? "Teacher Application Verified & Submitted!"
          : isParent
            ? "Parent Account Verified & Submitted!"
            : "Student Registration Verified & Submitted!";
        const roleMessage =
          pendingCustomMsg ||
          (isTeacher
            ? TEACHER_PENDING_MSG
            : isParent
              ? "Your Parent account OTP is verified. Once approved by our desk, sign in on the Student & Parent Portal to view your child's attendance, marks, and fees."
              : STUDENT_PENDING_MSG);
        const loginHref = isTeacher ? "/teacher/login" : "/student/login";
        wrapSplit(`
          <p class="portal-kicker">${isTeacher ? "Teacher Application Confirmed" : isParent ? "Parent Registration Confirmed" : "Student Registration Confirmed"}</p>
          <div class="portal-heading"><h1>${headingText}</h1></div>
          <p class="portal-subtitle">${registeredName ? `Thank you, ${escapeHtml(registeredName)}. ` : ""}Your OTP verification is complete.</p>
          <div class="portal-message portal-message--success" style="margin-top:14px;" data-testid="registration-success-message">${escapeHtml(roleMessage)}</div>
          <p class="portal-hint" style="margin-top:10px;">${escapeHtml(BRAND_PENDING_MSG)}</p>
          <div class="portal-actions" style="margin-top:18px;flex-wrap:wrap;gap:10px;">
            <a href="${escAttr(loginHref)}" class="portal-button">Go to ${isTeacher ? "Teacher" : "Student / Parent"} Sign In</a>
            <a href="/courses" class="portal-button portal-button--quiet">Explore Courses</a>
          </div>
          ${switchBarHtml()}`);
        return;
      }

      if (authMode === "otp") {
        const isTeacher = registeredRole === "teacher";
        const isParent = registeredRole === "parent";
        const isEmailCh = registeredOtpChannel === "email";
        const destLabel = isEmailCh ? (registeredEmail || registeredPhone) : (registeredPhone || registeredEmail);
        const altChannel = isEmailCh ? "sms" : "email";
        const main = wrapSplit(`
          <p class="portal-kicker">Step 2 of 2 · ${isEmailCh ? "Email (Mail) OTP Verification" : "Mobile (SMS) OTP Verification"}</p>
          <div class="portal-heading"><h1>Verify Your ${isEmailCh ? "Email Address" : "Mobile Number"}</h1></div>
          <p class="portal-subtitle">
            ${isTeacher ? "Verify your 6-digit OTP to activate your Teacher account and enter the Teacher Panel immediately." : isParent ? "Verify your 6-digit OTP to activate your Parent Portal account." : "Verify your 6-digit OTP to activate your Student account and enter the Student Panel immediately."}
            Enter the 6-digit OTP sent via <strong>${isEmailCh ? "Email (Mail)" : "Mobile SMS"}</strong> to <strong>${escapeHtml(destLabel)}</strong>.
          </p>
          ${otpSuccessMsg ? `<div class="portal-message portal-message--success" style="margin-top:12px;">${escapeHtml(otpSuccessMsg)}</div>` : ""}
          ${limitationMsg ? `<div class="portal-message portal-message--error" style="margin-top:12px;">${escapeHtml(limitationMsg)}</div>` : ""}
          <form class="portal-form" data-otp-form style="margin-top:16px;">
            <div class="portal-field"><label>6-Digit Verification OTP *</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP" inputmode="numeric"></div>
            <div class="portal-message" data-otp-fb hidden></div>
            <div class="portal-actions" style="flex-wrap:wrap;gap:8px;">
              <button type="submit" class="portal-button">Verify OTP &amp; Enter Panel</button>
              <button type="button" class="portal-button portal-button--quiet" data-resend-otp ${otpCooldownSec > 0 ? "disabled" : ""}>${otpCooldownSec > 0 ? `Resend OTP (${otpCooldownSec}s)` : `Resend on ${isEmailCh ? "Email" : "Mobile"}`}</button>
              <button type="button" class="portal-button portal-button--quiet portal-button--small" data-switch-otp-ch="${altChannel}">Send OTP to ${altChannel === "email" ? "Email (Mail)" : "Mobile Number"} instead</button>
            </div>
          </form>
          <div class="portal-inline-links" style="margin-top:14px;">
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-login>Back to Sign In</button>
          </div>
          ${switchBarHtml()}`);
        startOtpCooldown(otpCooldownSec || 30);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          stopOtpTimer();
          authMode = "login";
          draw();
        });
        main.querySelector("[data-otp-form]").addEventListener("submit", async (e) => {
          e.preventDefault();
          const btn = e.target.querySelector('button[type="submit"]');
          const otp = new FormData(e.target).get("otp");
          const fb = main.querySelector("[data-otp-fb]");
          btn.disabled = true;
          try {
            const verifyRes = await api("/api/auth/verify-otp", {
              method: "POST",
              body: { phone: registeredPhone, email: registeredEmail, otp },
            });
            stopOtpTimer();
            if (verifyRes && verifyRes.authenticated) {
              fb.className = "portal-message portal-message--success";
              fb.textContent = verifyRes.message || "OTP verified! Entering your panel now...";
              fb.hidden = false;
              const dest =
                verifyRes.redirectTo ||
                (registeredRole === "teacher" ? "/teacher/" : registeredRole === "parent" ? "/parent/" : "/student/");
              window.location.assign(dest);
              return;
            }
            pendingCustomMsg = verifyRes?.message || "";
            authMode = "pending";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
            btn.disabled = false;
          }
        });
        const doResend = async (channelToUse) => {
          if (otpCooldownSec > 0) return;
          const fb = main.querySelector("[data-otp-fb]");
          try {
            const res = await api("/api/auth/resend-otp", {
              method: "POST",
              body: { phone: registeredPhone, email: registeredEmail, otpChannel: channelToUse },
            });
            registeredOtpChannel = res.otpChannel || channelToUse;
            const delivered = Boolean(res.emailSent || res.smsSent);
            limitationMsg = delivered ? "" : (res.limitationNote || res.message || "");
            otpSuccessMsg = delivered ? (res.message || "Fresh 6-digit OTP dispatched.") : "";
            startOtpCooldown(Number(res.cooldownSeconds || 30));
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        };
        main.querySelector("[data-resend-otp]").addEventListener("click", () => doResend(registeredOtpChannel));
        main.querySelector("[data-switch-otp-ch]")?.addEventListener("click", (ev) => {
          const nextCh = ev.currentTarget.getAttribute("data-switch-otp-ch") === "sms" ? "sms" : "email";
          doResend(nextCh);
        });
        return;
      }

      if (authMode === "forgot") {
        const main = wrapSplit(`
          <p class="portal-kicker">${isTeacherPortal ? "Teacher Account Recovery" : "Student & Parent Account Recovery"}</p>
          <div class="portal-heading"><h1>Reset Password</h1></div>
          <p class="portal-subtitle">Enter your registered email or mobile number to receive a 6-digit password reset OTP.</p>
          <form class="portal-form" data-forgot-form style="margin-top:14px;">
            <div class="portal-field"><label>Registered Email or Mobile *</label><input name="identifier" required placeholder="email@example.com or 10-digit mobile"></div>
            <div class="portal-message" data-forgot-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button">Send Reset OTP</button>
              <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
            </div>
          </form>
          ${switchBarHtml()}`);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          authMode = "login";
          draw();
        });
        main.querySelector("[data-forgot-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const identifier = String(new FormData(e.target).get("identifier") || "").trim();
          const fb = main.querySelector("[data-forgot-fb]");
          const btn = e.target.querySelector('button[type="submit"]');
          if (btn) btn.disabled = true;
          try {
            const res = await api("/api/auth/forgot-password", { method: "POST", body: { identifier } });
            resetIdentifier = identifier;
            resetNote = res.limitationNote || res.message || "";
            authMode = "reset";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
            if (btn) btn.disabled = false;
          }
        });
        return;
      }

      if (authMode === "reset") {
        const main = wrapSplit(`
          <p class="portal-kicker">Step 2 · Verify Reset OTP</p>
          <div class="portal-heading"><h1>Choose New Password</h1></div>
          <p class="portal-subtitle">Account: <strong>${escapeHtml(resetIdentifier)}</strong></p>
          ${resetNote ? `<div class="portal-message" style="margin-top:12px;">${escapeHtml(resetNote)}</div>` : ""}
          <form class="portal-form" data-reset-form style="margin-top:14px;">
            <div class="portal-field"><label>6-Digit Reset OTP *</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP" inputmode="numeric"></div>
            <div class="portal-field"><label>New Password (min 8 chars) *</label>${passwordFieldHtml("newPassword", 'minlength="8" required')}</div>
            <div class="portal-message" data-reset-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button">Update Password</button>
              <button type="button" class="portal-button portal-button--quiet" data-back-login>Back to Sign In</button>
            </div>
          </form>
          ${switchBarHtml()}`);
        bindPasswordToggles(main);
        main.querySelector("[data-back-login]")?.addEventListener("click", () => {
          authMode = "login";
          draw();
        });
        main.querySelector("[data-reset-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const fb = main.querySelector("[data-reset-fb]");
          try {
            const res = await api("/api/auth/reset-password", {
              method: "POST",
              body: { identifier: resetIdentifier, otp: fd.get("otp"), newPassword: fd.get("newPassword") },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = res.message;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        return;
      }

      if (authMode === "register") {
        const isTeacher = isTeacherPortal;
        const isParent = !isTeacher && studentSubRole === "parent";
        const isStudent = !isTeacher && !isParent;
        const main = wrapSplit(`
          ${topModeTabsHtml()}
          <p class="portal-kicker">${isTeacher ? "Yuitor Faculty Recruitment · Muradnagar" : "Yuitor Student & Parent Portal · Muradnagar"}</p>
          <div class="portal-heading"><h1>${isTeacher ? "Teacher Registration" : isParent ? "Parent / Guardian Registration" : "Student Registration"}</h1></div>
          ${
            !isTeacher
              ? `
          <div class="yu-auth-subtabs" role="tablist" aria-label="Choose Student or Parent Registration" style="margin-top:10px;">
            <button type="button" role="tab" aria-selected="${isStudent}" class="yu-auth-subtab ${isStudent ? "is-active" : ""}" data-sub-role="student">Student Account</button>
            <button type="button" role="tab" aria-selected="${isParent}" class="yu-auth-subtab ${isParent ? "is-active" : ""}" data-sub-role="parent">Parent / Guardian</button>
          </div>`
              : `<p class="portal-subtitle" style="margin-top:4px;">Submit your qualification and updated resume (PDF, DOC, or DOCX) to apply as Yuitor Faculty.</p>`
          }
          <form class="portal-form" data-reg-form novalidate style="margin-top:12px;">
            <div class="portal-form-grid">
              <div class="portal-field"><label>Full Name *</label><input name="fullName" required placeholder="Enter full name"></div>
              <div class="portal-field"><label>Email Address *</label><input name="email" type="email" required placeholder="you@example.com"></div>
              <div class="portal-field"><label>Mobile Number *</label><input name="phone" required placeholder="10-digit mobile number" inputmode="tel"></div>
              <div class="portal-field"><label>Password (min 8 chars) *</label>${passwordFieldHtml("password", 'minlength="8" required placeholder="Minimum 8 characters"')}</div>
              ${
                isStudent
                  ? `
                <div class="portal-field"><label>Class / Course *</label>
                  <select name="classLevel">${["Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12", "NEET / JEE / CUET", "NDA / SSC / Banking", "Computer / Coding / Spoken English"].map((c) => `<option>${c}</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Board / Track *</label>
                  <select name="board"><option>UP Board</option><option>ICSE</option><option>State Board</option><option>Competitive / Skill</option></select>
                </div>
                <div class="portal-field"><label>Preferred Branch / Centre</label>
                  <select name="branchId">
                    ${
                      publicBranches.length
                        ? publicBranches.map((br) => `<option value="${br.id}">${escapeHtml(br.name)} (${escapeHtml(br.city)})</option>`).join("")
                        : `<option value="1">Muradnagar Main Centre (Muradnagar)</option>`
                    }
                  </select>
                </div>
                <div class="portal-field"><label>Parent Mobile (Optional)</label><input name="parentPhone" placeholder="10-digit parent mobile" inputmode="tel"></div>
                <div class="portal-field"><label>Subjects (comma separated)</label><input name="subjects" value="Mathematics, Science" placeholder="Mathematics, Science"></div>
                <div class="portal-field"><label>Referral Code (Optional)</label><input name="referralCode" value="${escAttr(window.YuitorAddons?.getStoredReferralCode() || "")}" placeholder="e.g. YTR-ARJ0001" style="text-transform:uppercase;"></div>
              `
                  : isParent
                    ? `
                <div class="portal-field"><label>Child's Roll Number</label><input name="studentRoll" placeholder="e.g. YTR-STU-0002"></div>
                <div class="portal-field"><label>Child's Registered Mobile</label><input name="studentPhone" placeholder="10-digit student mobile" inputmode="tel"></div>
                <div class="portal-field"><label>Relationship *</label>
                  <select name="relation">
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Guardian">Guardian</option>
                  </select>
                </div>
              `
                    : `
                <div class="portal-field"><label>Highest Qualification *</label><input name="qualification" required placeholder="e.g. M.Sc Physics, B.Ed"></div>
                <div class="portal-field"><label>Experience (Years)</label><input name="experienceYears" type="number" min="0" max="50" value="2"></div>
                <div class="portal-field"><label>Teaching Subjects</label><input name="subjects" placeholder="Physics, Mathematics"></div>
                <div class="portal-field"><label>Preferred Classes</label><input name="assignedClasses" placeholder="Class 9, Class 10, Class 12"></div>
              `
              }
            </div>
            ${
              isTeacher
                ? `
              <div class="portal-field">
                <label>Upload Updated Resume / CV (Mandatory — Auto-Verified) *</label>
                <div class="yu-resume-dropzone">
                  <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required data-reg-resume>
                  <p class="portal-hint">Only genuine <strong>Resume / CV</strong> files in <strong>PDF, DOC, or DOCX</strong> (max <strong>5 MB</strong>) containing your qualification, experience/skills, and contact details are accepted.</p>
                  <div data-resume-preview>
                    ${selectedResumeFile ? `<span class="yu-resume-file-pill">Selected: ${escapeHtml(selectedResumeFile.name)} (${escapeHtml(formatBytes(selectedResumeFile.size))})</span>` : ""}
                  </div>
                  <div class="portal-message" data-resume-verify-fb hidden style="margin-top:8px;"></div>
                </div>
              </div>`
                : ""
            }
            <div class="portal-field">
              <label>Receive 6-Digit Verification OTP via *</label>
              <div class="yu-auth-otp-grid" data-reg-otp-group>
                <label class="yu-auth-otp-option is-active" data-reg-otp-card="email">
                  <input type="radio" name="otpChannel" value="email" checked>
                  <span>Email (Mail OTP)</span>
                </label>
                <label class="yu-auth-otp-option" data-reg-otp-card="sms">
                  <input type="radio" name="otpChannel" value="sms">
                  <span>Mobile Number (SMS)</span>
                </label>
              </div>
            </div>
            <div class="portal-message" data-reg-fb hidden></div>
            <div class="portal-actions">
              <button type="submit" class="portal-button" style="width:100%;">${
                isTeacher
                  ? "Submit Teacher Application &amp; Send OTP"
                  : isParent
                    ? "Register Parent Account &amp; Send OTP"
                    : "Register Student Account &amp; Send OTP"
              }</button>
            </div>
          </form>
          ${switchBarHtml()}`);

        bindPasswordToggles(main);
        main.querySelectorAll("[data-auth-mode]").forEach((btn) => {
          btn.addEventListener("click", () => {
            authMode = btn.getAttribute("data-auth-mode") === "register" ? "register" : "login";
            draw();
          });
        });
        main.querySelectorAll("[data-sub-role]").forEach((btn) => {
          btn.addEventListener("click", () => {
            studentSubRole = btn.getAttribute("data-sub-role") === "parent" ? "parent" : "student";
            draw();
          });
        });
        main.querySelectorAll('[data-reg-otp-group] input[name="otpChannel"]').forEach((radio) => {
          radio.addEventListener("change", () => {
            const picked = radio.value === "sms" ? "sms" : "email";
            main.querySelectorAll("[data-reg-otp-card]").forEach((card) => {
              card.classList.toggle("is-active", card.getAttribute("data-reg-otp-card") === picked);
            });
          });
        });
        const resumeInput = main.querySelector("[data-reg-resume]");
        let resumeVerifiedOk = false;
        let resumeVerifyErr = "";
        if (resumeInput) {
          resumeInput.addEventListener("change", async () => {
            const file = resumeInput.files && resumeInput.files[0];
            const preview = main.querySelector("[data-resume-preview]");
            const vfb = main.querySelector("[data-resume-verify-fb]");
            selectedResumeFile = file || null;
            resumeVerifiedOk = false;
            resumeVerifyErr = "";
            if (preview) {
              preview.innerHTML = file
                ? `<span class="yu-resume-file-pill">Selected: ${escapeHtml(file.name)} (${escapeHtml(formatBytes(file.size))})</span>`
                : "";
            }
            if (!file) {
              if (vfb) vfb.hidden = true;
              return;
            }
            if (!isValidResumeExtension(file.name)) {
              resumeVerifyErr = "Unsupported file type. Please upload your actual Resume/CV in PDF, DOC, or DOCX format.";
              if (vfb) {
                vfb.className = "portal-message portal-message--error";
                vfb.textContent = resumeVerifyErr;
                vfb.hidden = false;
              }
              return;
            }
            if (file.size > 5 * 1024 * 1024) {
              resumeVerifyErr = "Resume file is too large. Maximum allowed size is 5 MB.";
              if (vfb) {
                vfb.className = "portal-message portal-message--error";
                vfb.textContent = resumeVerifyErr;
                vfb.hidden = false;
              }
              return;
            }
            if (vfb) {
              vfb.className = "portal-message";
              vfb.textContent = "Verifying resume document content...";
              vfb.hidden = false;
            }
            try {
              const checkFd = new FormData();
              checkFd.append("resume", file);
              const checkRes = await api("/api/auth/verify-resume", { method: "POST", body: checkFd });
              resumeVerifiedOk = Boolean(checkRes && checkRes.valid);
              resumeVerifyErr = "";
              if (vfb) {
                vfb.className = "portal-message portal-message--success";
                vfb.textContent = checkRes.summary || "Resume verified successfully!";
                vfb.hidden = false;
              }
            } catch (err) {
              resumeVerifiedOk = false;
              resumeVerifyErr = err.message || "Uploaded file could not be verified as a genuine Resume / CV.";
              if (vfb) {
                vfb.className = "portal-message portal-message--error";
                vfb.textContent = resumeVerifyErr;
                vfb.hidden = false;
              }
            }
          });
        }

        main.querySelector("[data-reg-form]").addEventListener("submit", async (e) => {
          e.preventDefault();
          const form = e.target;
          const btn = form.querySelector('button[type="submit"]');
          const fd = new FormData(form);
          const fb = main.querySelector("[data-reg-fb]");
          const showError = (msg) => {
            fb.className = "portal-message portal-message--error";
            fb.textContent = msg;
            fb.hidden = false;
          };
          const role = isTeacher ? "teacher" : studentSubRole;
          const fullName = String(fd.get("fullName") || "").trim();
          const email = String(fd.get("email") || "").trim();
          const phone = String(fd.get("phone") || "").trim();
          const password = String(fd.get("password") || "");
          if (!fullName || !email || !phone || password.length < 8) {
            showError("Please fill in your full name, valid email, 10-digit mobile number, and a password of at least 8 characters.");
            return;
          }
          if (role === "teacher") {
            const qualification = String(fd.get("qualification") || "").trim();
            if (!qualification) {
              showError("Please enter your highest teaching qualification.");
              return;
            }
            const resumeFile = fd.get("resume") instanceof File && fd.get("resume").size > 0 ? fd.get("resume") : selectedResumeFile;
            if (!resumeFile || resumeFile.size === 0) {
              showError(TEACHER_MISSING_RESUME_MSG);
              return;
            }
            if (!isValidResumeExtension(resumeFile.name)) {
              showError("Unsupported resume file type. Please upload a PDF, DOC, or DOCX resume.");
              return;
            }
            if (resumeFile.size > 5 * 1024 * 1024) {
              showError("Resume file is too large. Maximum allowed size is 5 MB.");
              return;
            }
            if (resumeVerifyErr && !resumeVerifiedOk) {
              showError(resumeVerifyErr);
              return;
            }
          }

          btn.disabled = true;
          fb.hidden = true;
          try {
            const splitCsv = (v) => String(v || "").split(",").map((x) => x.trim()).filter(Boolean);
            const otpChannel = String(fd.get("otpChannel") || "email") === "sms" ? "sms" : "email";
            let res;
            if (role === "teacher") {
              const bodyFd = new FormData();
              bodyFd.append("role", "teacher");
              bodyFd.append("fullName", fullName);
              bodyFd.append("email", email);
              bodyFd.append("phone", phone);
              bodyFd.append("password", password);
              bodyFd.append("otpChannel", otpChannel);
              bodyFd.append("qualification", String(fd.get("qualification") || "").trim());
              bodyFd.append("experienceYears", String(Number(fd.get("experienceYears") || 0)));
              bodyFd.append("subjects", JSON.stringify(splitCsv(fd.get("subjects"))));
              bodyFd.append("assignedClasses", JSON.stringify(splitCsv(fd.get("assignedClasses"))));
              const resumeFile = fd.get("resume") instanceof File && fd.get("resume").size > 0 ? fd.get("resume") : selectedResumeFile;
              bodyFd.append("resume", resumeFile);
              res = await api("/api/auth/register", { method: "POST", body: bodyFd });
            } else if (role === "parent") {
              res = await api("/api/auth/register", {
                method: "POST",
                body: {
                  role: "parent",
                  fullName,
                  email,
                  phone,
                  password,
                  otpChannel,
                  studentRoll: String(fd.get("studentRoll") || "").trim(),
                  studentPhone: String(fd.get("studentPhone") || "").trim(),
                  relation: String(fd.get("relation") || "Parent / Guardian").trim(),
                },
              });
            } else {
              res = await api("/api/auth/register", {
                method: "POST",
                body: {
                  role: "student",
                  fullName,
                  email,
                  phone,
                  password,
                  otpChannel,
                  classLevel: fd.get("classLevel"),
                  board: fd.get("board"),
                  branchId: fd.get("branchId") ? Number(fd.get("branchId")) : undefined,
                  parentPhone: String(fd.get("parentPhone") || "").trim(),
                  courseDurationMonths: 12,
                  subjects: splitCsv(fd.get("subjects")),
                  referralCode: String(fd.get("referralCode") || "").trim().toUpperCase(),
                },
              });
            }
            registeredPhone = res.phone || phone;
            registeredEmail = res.email || email;
            registeredOtpChannel = res.otpChannel || otpChannel;
            registeredName = fullName;
            registeredRole = role;
            const delivered = Boolean(res.emailSent || res.smsSent);
            otpSuccessMsg = delivered
              ? (res.message || `6-digit OTP sent to ${res.otpTargetMasked || (otpChannel === "email" ? registeredEmail : registeredPhone)}.`)
              : "";
            limitationMsg = delivered ? "" : (res.limitationNote || "");
            pendingCustomMsg = "";
            authMode = "otp";
            draw();
          } catch (err) {
            showError(err.message);
            btn.disabled = false;
          }
        });
        return;
      }

      // LOGIN VIEW (Dedicated Teacher OR Dedicated Student & Parent)
      const portalHeading = isTeacherPortal
        ? "Teacher & Faculty Sign In"
        : isStaffPortal
          ? "Staff & Coordinator Sign In"
          : studentSubRole === "parent"
            ? "Parent / Guardian Sign In"
            : "Student & Parent Sign In";
      const portalScope = isTeacherPortal ? "teacher" : isStaffPortal ? "" : "student_parent";

      const main = wrapSplit(`
        ${topModeTabsHtml()}
        <p class="portal-kicker">${isTeacherPortal ? "Yuitor Faculty Access" : isStaffPortal ? "Yuitor Staff Access" : "Yuitor Student & Parent Access"}</p>
        <div class="portal-heading"><h1>${portalHeading}</h1></div>
        ${initialError ? `<div class="portal-message portal-message--error" style="margin-top:8px;">${escapeHtml(initialError)}</div>` : ""}
        <div class="yu-auth-subtabs" role="tablist" aria-label="Sign in method" style="margin-top:12px;">
          <button type="button" role="tab" aria-selected="${loginTab === "password"}" class="yu-auth-subtab ${loginTab === "password" ? "is-active" : ""}" data-login-tab="password">Password Login</button>
          <button type="button" role="tab" aria-selected="${loginTab === "otp"}" class="yu-auth-subtab ${loginTab === "otp" ? "is-active" : ""}" data-login-tab="otp">OTP Login (Mail / Mobile)</button>
        </div>
        ${
          loginTab === "password"
            ? `
        <form class="portal-form" data-login-form>
          <div class="portal-field"><label>Registered Email or Mobile *</label><input name="identifier" required placeholder="email@example.com or 10-digit mobile"></div>
          <div class="portal-field"><label>Password *</label>${passwordFieldHtml("password", "required")}</div>
          <div class="portal-message" data-login-fb hidden></div>
          <div class="portal-actions" style="justify-content:space-between;flex-wrap:wrap;gap:8px;">
            <button type="submit" class="portal-button" style="flex:1;min-width:150px;">Sign In</button>
            <button type="button" class="portal-button portal-button--quiet portal-button--small" data-go-forgot>Forgot Password?</button>
          </div>
        </form>`
            : `
        <form class="portal-form" data-login-otp-send-form>
          <div class="portal-field">
            <label>Send 6-Digit Login OTP on *</label>
            <div class="yu-auth-otp-grid">
              <label class="yu-auth-otp-option ${otpLoginChannel === "email" ? "is-active" : ""}">
                <input type="radio" name="otpChannel" value="email" ${otpLoginChannel === "email" ? "checked" : ""} data-login-otp-ch>
                <span>Email (Mail)</span>
              </label>
              <label class="yu-auth-otp-option ${otpLoginChannel === "sms" ? "is-active" : ""}">
                <input type="radio" name="otpChannel" value="sms" ${otpLoginChannel === "sms" ? "checked" : ""} data-login-otp-ch>
                <span>Mobile Number (SMS)</span>
              </label>
            </div>
          </div>
          <div class="portal-field">
            <label>${otpLoginChannel === "email" ? "Registered Email Address *" : "Registered Mobile Number *"}</label>
            <input name="identifier" required value="${escAttr(otpLoginIdentifier)}" placeholder="${otpLoginChannel === "email" ? "you@example.com" : "10-digit mobile number"}" inputmode="${otpLoginChannel === "email" ? "email" : "tel"}">
          </div>
          <div class="portal-message ${otpLoginIsError ? "portal-message--error" : "portal-message--success"}" data-login-otp-fb ${otpLoginNote ? "" : "hidden"}>${escapeHtml(otpLoginNote)}</div>
          <div class="portal-actions">
            <button type="submit" class="portal-button" style="width:100%;">${otpLoginSent ? "Resend 6-Digit OTP" : "Send 6-Digit Login OTP"}</button>
          </div>
        </form>
        ${
          otpLoginSent
            ? `
        <form class="portal-form" data-login-otp-verify-form style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
          <p class="portal-hint" style="margin-bottom:8px;">Enter the 6-digit OTP sent via <strong>${otpLoginChannel === "email" ? "Email (Mail)" : "Mobile SMS"}</strong>${otpLoginMasked ? ` to <strong>${escapeHtml(otpLoginMasked)}</strong>` : ""}.</p>
          <div class="portal-field"><label>6-Digit Login OTP *</label><input name="otp" maxlength="6" required placeholder="Enter 6-digit OTP" inputmode="numeric"></div>
          <div class="portal-message" data-login-otp-vfb hidden></div>
          <div class="portal-actions">
            <button type="submit" class="portal-button" style="width:100%;">Verify OTP &amp; Sign In</button>
          </div>
        </form>`
            : ""
        }`
        }
        ${
          isTeacherPortal
            ? `
        <div data-pending-resume-box hidden style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
          <h3 class="portal-section-title" style="margin-bottom:6px;">Upload / Update Teacher Resume</h3>
          <p class="portal-hint" style="margin-bottom:10px;">Attach a valid PDF, DOC, or DOCX resume (max 5 MB) so the Yuitor Academic Team can verify your teacher account.</p>
          <form class="portal-form" data-login-resume-form>
            <div class="yu-resume-dropzone">
              <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
            </div>
            <div class="portal-message" data-login-resume-fb hidden></div>
            <button type="submit" class="portal-button portal-button--small">Upload Resume for Verification</button>
          </form>
        </div>`
            : ""
        }
        ${switchBarHtml()}`);

      bindPasswordToggles(main);
      main.querySelectorAll("[data-auth-mode]").forEach((btn) => {
        btn.addEventListener("click", () => {
          authMode = btn.getAttribute("data-auth-mode") === "register" ? "register" : "login";
          draw();
        });
      });
      main.querySelectorAll("[data-login-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          loginTab = btn.getAttribute("data-login-tab") === "otp" ? "otp" : "password";
          draw();
        });
      });
      main.querySelectorAll("[data-login-otp-ch]").forEach((inp) => {
        inp.addEventListener("change", () => {
          otpLoginChannel = inp.value === "sms" ? "sms" : "email";
          const idEl = main.querySelector('[data-login-otp-send-form] [name="identifier"]');
          if (idEl) otpLoginIdentifier = String(idEl.value || "").trim();
          otpLoginSent = false;
          otpLoginNote = "";
          otpLoginIsError = false;
          draw();
        });
      });
      main.querySelector("[data-go-forgot]")?.addEventListener("click", () => {
        authMode = "forgot";
        draw();
      });

      const handlePostAuthRedirect = (res, fb, pendingResumeBoxEl) => {
        if (res.verificationStatus === "pending_otp") {
          registeredPhone = res.phone || "";
          registeredEmail = res.email || "";
          registeredRole = res.role || (isTeacherPortal ? "teacher" : "student");
          registeredOtpChannel = registeredEmail ? "email" : "sms";
          otpSuccessMsg = "";
          limitationMsg = "Your account needs OTP verification before login. Enter your 6-digit OTP or click Resend below.";
          otpCooldownSec = 0;
          authMode = "otp";
          draw();
          return;
        }
        if (res.verificationStatus === "resume_required" || (res.role === "teacher" && res.resumeRequired && !res.authenticated)) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = res.pendingMessage || TEACHER_MISSING_RESUME_MSG;
          fb.hidden = false;
          if (pendingResumeBoxEl) {
            pendingResumeBoxEl.hidden = false;
          }
          return;
        }
        if (res.verificationStatus === "pending_approval" || res.verificationStatus === "otp_verified") {
          const missingTeacherResume = res.role === "teacher" && res.teacherResume && !res.teacherResume.hasResume;
          fb.className = missingTeacherResume ? "portal-message portal-message--error" : "portal-message portal-message--success";
          fb.textContent = missingTeacherResume
            ? (res.teacherResume.resumeStatus === "rejected"
                ? TEACHER_REJECTED_RESUME_MSG
                : (res.teacherResume.missingResumeMessage || TEACHER_MISSING_RESUME_MSG))
            : (res.pendingMessage || BRAND_PENDING_MSG);
          fb.hidden = false;
          if (missingTeacherResume && pendingResumeBoxEl) {
            pendingResumeBoxEl.hidden = false;
          }
          return;
        }
        if (res.role === "super_admin" || res.role === "admin") {
          fb.className = "portal-message portal-message--error";
          fb.textContent = "Administrator login is not permitted on the public Student/Parent/Teacher portal.";
          fb.hidden = false;
          return;
        }
        const dest =
          res.role === "teacher"
            ? "/teacher/"
            : res.role === "parent"
              ? "/parent/"
              : res.role === "staff"
                ? "/staff/"
                : "/student/";
        window.location.assign(dest);
      };

      let lastCredentials = { identifier: "", password: "" };
      const form = main.querySelector("[data-login-form]");
      const pendingResumeBox = main.querySelector("[data-pending-resume-box]");
      if (form) {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const fb = main.querySelector("[data-login-fb]");
          const identifier = String(fd.get("identifier") || "");
          const password = String(fd.get("password") || "");
          lastCredentials = { identifier, password };
          if (pendingResumeBox) pendingResumeBox.hidden = true;
          try {
            const res = await api("/api/auth/login", {
              method: "POST",
              body: { identifier, password },
            });
            handlePostAuthRedirect(res, fb, pendingResumeBox);
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
      }

      const otpSendForm = main.querySelector("[data-login-otp-send-form]");
      if (otpSendForm) {
        otpSendForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(otpSendForm);
          const identifier = String(fd.get("identifier") || "").trim();
          const channel = String(fd.get("otpChannel") || otpLoginChannel) === "sms" ? "sms" : "email";
          const fb = main.querySelector("[data-login-otp-fb]");
          const btn = otpSendForm.querySelector('button[type="submit"]');
          if (btn) btn.disabled = true;
          try {
            const res = await api("/api/auth/login-otp/send", {
              method: "POST",
              body: { identifier, otpChannel: channel, portalScope },
            });
            otpLoginIdentifier = identifier;
            otpLoginChannel = res.otpChannel || channel;
            otpLoginMasked = res.otpTargetMasked || "";
            otpLoginSent = true;
            const delivered = Boolean(res.emailSent || res.smsSent);
            otpLoginIsError = !delivered;
            otpLoginNote = res.message || res.limitationNote || "6-digit OTP issued.";
            draw();
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
            if (btn) btn.disabled = false;
          }
        });
      }

      const otpVerifyForm = main.querySelector("[data-login-otp-verify-form]");
      if (otpVerifyForm) {
        otpVerifyForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(otpVerifyForm);
          const otp = String(fd.get("otp") || "").trim();
          const fb = main.querySelector("[data-login-otp-vfb]");
          const btn = otpVerifyForm.querySelector('button[type="submit"]');
          if (btn) btn.disabled = true;
          try {
            const res = await api("/api/auth/login-otp/verify", {
              method: "POST",
              body: { identifier: otpLoginIdentifier, otp },
            });
            handlePostAuthRedirect(res, fb, pendingResumeBox);
            if (btn) btn.disabled = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
            if (btn) btn.disabled = false;
          }
        });
      }

      main.querySelector("[data-login-resume-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const rForm = e.target;
        const rFd = new FormData(rForm);
        const rFb = main.querySelector("[data-login-resume-fb]");
        const file = rFd.get("resume");
        if (!(file instanceof File) || file.size === 0) {
          rFb.className = "portal-message portal-message--error";
          rFb.textContent = TEACHER_MISSING_RESUME_MSG;
          rFb.hidden = false;
          return;
        }
        rFd.append("identifier", lastCredentials.identifier || String(form?.querySelector('[name="identifier"]')?.value || ""));
        rFd.append("password", lastCredentials.password || String(form?.querySelector('[name="password"]')?.value || ""));
        const btn = rForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        try {
          const upRes = await api("/api/auth/teacher-resume", { method: "POST", body: rFd });
          rFb.className = "portal-message portal-message--success";
          rFb.textContent = `Resume (${upRes.resumeFilename || "uploaded"}) submitted! Our academic team will review your profile shortly.`;
          rFb.hidden = false;
        } catch (err) {
          rFb.className = "portal-message portal-message--error";
          rFb.textContent = err.message || "Could not upload resume.";
          rFb.hidden = false;
        } finally {
          if (btn) btn.disabled = false;
        }
      });
    }

    draw();
  }

  function renderLogin(defaultRole = "student", initialError = "") {
    document.documentElement.removeAttribute("data-yu-portal-workspace");
    const portalKind = defaultRole === "teacher" ? "teacher" : defaultRole === "staff" ? "staff" : "student";
    renderSplitAuth(portalKind, "login", defaultRole === "parent" ? "parent" : "student", initialError);
  }

  function renderRegister(defaultRole = "student") {
    document.documentElement.removeAttribute("data-yu-portal-workspace");
    const portalKind = defaultRole === "teacher" ? "teacher" : "student";
    renderSplitAuth(portalKind, "register", defaultRole === "parent" ? "parent" : "student", "");
  }

  // ==================== ADMIN PANEL ====================
  async function renderAdminPanel(session) {
    const VALID_ADMIN_TABS = new Set([
      "dashboard",
      "admissions",
      "users",
      "courses",
      "academics",
      "online_hub",
      "tests",
      "payments",
      "finance",
      "library",
      "mail",
      "alerts",
      "marketing",
      "celebrations",
      "cms",
      "chatbot",
      "referrals",
      "wallets",
      "withdrawals",
      "referral_reports",
      "reports",
      "bulk_export",
      "backups",
      "upgrade",
      "security_logs",
      "settings",
    ]);
    const LEGACY_TAB_MAP = {
      crm_overview: { tab: "settings", settingsTab: "automation" },
      crm_fee_desk: { tab: "payments", subView: "fee_desk", navKey: "finance-fee-desk" },
      crm_leads: { tab: "admissions", subView: "leads", navKey: "adm-leads" },
      crm_hub: { tab: "online_hub", navKey: "academics-hub" },
      crm_student_exits: { tab: "users", role: "student", usersSubView: "exits", navKey: "users-students" },
      crm_teacher_ops: { tab: "users", role: "teacher", usersSubView: "leaves", navKey: "users-teachers" },
      crm_staff_exits: { tab: "users", role: "staff", usersSubView: "exits", navKey: "users-staff" },
      crm_celebrations: { tab: "celebrations", navKey: "comm-celebrations" },
      crm_bulk: { tab: "bulk_export", navKey: "rep-bulk" },
      crm_automation: { tab: "settings", settingsTab: "automation", navKey: "sys-settings" },
    };
    const normalizeSettingsSubTab = (raw) => {
      const s = String(raw || "").trim().toLowerCase();
      if (["security", "gate", "login_attempts"].includes(s)) return "security";
      if (["integrations", "api", "cfg_general", "cfg_ai", "cfg_email", "cfg_sms", "cfg_payments"].includes(s)) return "integrations";
      if (["email_bimi", "bimi"].includes(s)) return "email_bimi";
      if (["mail_templates", "templates", "mail-templates"].includes(s)) return "mail_templates";
      if (["automation", "crm_automation", "crm_overview"].includes(s)) return "automation";
      if (["platform_status", "readiness"].includes(s)) return "platform_status";
      if (["backup_upgrade", "backups", "upgrade"].includes(s)) return "backup_upgrade";
      return "security";
    };
    const parseAdminHashState = () => {
      const rawHash = String(window.location.hash || "").replace(/^#/, "");
      if (!rawHash) return null;
      const [pathPart, queryPart] = rawHash.split("?");
      const [rawTabPart, rawSubPart] = String(pathPart || "").split("/");
      const sp = new URLSearchParams(queryPart || "");
      if (LEGACY_TAB_MAP[rawTabPart]) {
        return { ...LEGACY_TAB_MAP[rawTabPart], role: sp.get("role") || LEGACY_TAB_MAP[rawTabPart].role, status: sp.get("status") };
      }
      if (rawTabPart === "settings") {
        return {
          tab: "settings",
          settingsTab: normalizeSettingsSubTab(rawSubPart || sp.get("tab") || "security"),
          role: sp.get("role"),
          status: sp.get("status"),
        };
      }
      return {
        tab: VALID_ADMIN_TABS.has(rawTabPart) ? rawTabPart : "dashboard",
        subPart: rawSubPart || sp.get("sub") || "",
        role: sp.get("role"),
        status: sp.get("status"),
      };
    };
    const initialHash = parseAdminHashState();
    let tab = initialHash?.tab || "dashboard";
    let settingsSubTab = normalizeSettingsSubTab(initialHash?.settingsTab || "security");
    let admissionsSubView = initialHash?.tab === "admissions" ? initialHash?.subView || initialHash?.subPart || "leads" : "leads";
    let usersSubView = initialHash?.usersSubView || "directory";
    let dashboardSubView = initialHash?.tab === "dashboard" ? initialHash?.subPart || "overview" : "overview";
    let paymentsSubView = initialHash?.tab === "payments" ? initialHash?.subView || initialHash?.subPart || "all" : "all";
    let settingsSearchQuery = "";
    let userFilterStatus = initialHash?.status || "all";
    let userStatusTab = "active";
    let userFilterRole = initialHash?.role || "all";
    let userSearch = "";
    let userPage = 1;
    let showCreateUser = false;
    let selectedUserDetail = null;
    let editingCourse = null;
    let selectedOfflineTest = null;
    let attFilterCourse = "";
    let attFilterFrom = "";
    let attFilterTo = "";
    let lastFeeReminderWaLinks = [];
    let lastAlertWaLinks = [];
    let chatFilterStatus = "all";
    let chatSearch = "";
    let chatMinRating = 0;
    let selectedChatDetail = null;
    let selectedCampaignDeliveries = null;
    let alertsChannelPref = "whatsapp";
    let activeAdminNavKey = initialHash?.navKey || "";
    let pendingScrollSelector = null;
    const openAdminGroups = new Set();
    let auditVisible = true;
    let auditPage = 1;
    let settingsDiagByCat = {};
    let settingsSuccessByCat = {};
    let bimiNotice = null;
    let bimiDnsResult = null;
    let mailSubView = "inbox";
    let mailAccountId = "all";
    let mailSearch = "";
    let mailPage = 1;
    let selectedMailMsg = null;
    let editingMailbox = null;
    let composeDraft = { accountId: "", to: "", cc: "", subject: "", text: "", inReplyTo: "" };
    let mailTestNotice = null;
    let feedbackMsg = "";
    let feedbackError = "";

    const ALL_STAFF_PERMS = [
      ["inquiries", "Inquiries & Follow-up"],
      ["admissions", "Admissions & Parent Links"],
      ["batches", "Batches & Branches"],
      ["timetable", "Timetable"],
      ["attendance", "Attendance Reports"],
      ["tests", "Offline Tests & Ranks"],
      ["fees", "Fees & Installments"],
      ["library", "Library Issue / Return"],
      ["reports", "Center Reports"],
      ["alerts", "Bulk Alerts"],
      ["expenses", "Expenses"],
      ["payouts", "Leave & Payouts"],
      ["cms", "Website CMS"],
      ["branches", "Manage Branches"],
    ];

    async function loadAndDraw() {
      const attQuery = `/reports/attendance?courseId=${encodeURIComponent(attFilterCourse)}&from=${encodeURIComponent(attFilterFrom)}&to=${encodeURIComponent(attFilterTo)}`;
      const [
        dash,
        usersRes,
        coursesRes,
        paymentsRes,
        inquiriesRes,
        cmsRes,
        chatsRes,
        knowledgeRes,
        mktRes,
        notifsRes,
        backupsRes,
        settingsRes,
        adminUrlRes,
        loginAttemptsRes,
        sysUpdateRes,
        branchesRes,
        batchesRes,
        timetableRes,
        attRepRes,
        testsRes,
        instRes,
        leavesRes,
        payoutsRes,
        expensesRes,
        reportsRes,
        libraryRes,
        toppersRes,
        alertsRes,
        parentsRes,
        allStudentsRes,
        mailAccountsRes,
        mailMessagesRes,
        bimiRes,
        waitlistRes,
      ] = await Promise.all([
        api(adminApiUrl("/dashboard")),
        api(adminApiUrl(`/users?role=${encodeURIComponent(userFilterRole)}&status=${encodeURIComponent(userFilterStatus)}&statusTab=${encodeURIComponent(userStatusTab)}&search=${encodeURIComponent(userSearch)}&page=${userPage}&pageSize=12`)),
        api(adminApiUrl("/courses")),
        api(adminApiUrl("/payments")),
        api(adminApiUrl("/inquiries")),
        api(adminApiUrl("/cms")),
        api(adminApiUrl(`/chatbot?status=${encodeURIComponent(chatFilterStatus)}&search=${encodeURIComponent(chatSearch)}&minRating=${chatMinRating}`)),
        api(adminApiUrl("/knowledge-docs")).catch(() => ({ docs: [] })),
        api(adminApiUrl("/marketing/overview")),
        api(adminApiUrl("/notifications")),
        api(adminApiUrl("/backups")),
        api(adminApiUrl("/settings")),
        api(adminApiUrl("/admin-url")).catch(() => ({})),
        api(adminApiUrl("/login-attempts")).catch(() => ({ attempts: [] })),
        api(adminApiUrl("/system-update")).catch(() => ({ currentVersion: "3.0.0", upgradeHistory: [], protectedPaths: [] })),
        api(adminApiUrl("/branches")).catch(() => ({ branches: [] })),
        api(adminApiUrl("/batches")).catch(() => ({ batches: [] })),
        api(adminApiUrl("/timetable")).catch(() => ({ slots: [] })),
        api(adminApiUrl(attQuery)).catch(() => ({ records: [], summary: [] })),
        api(adminApiUrl("/offline-tests")).catch(() => ({ tests: [] })),
        api(adminApiUrl("/fee-installments")).catch(() => ({ feeRecords: [], installments: [] })),
        api(adminApiUrl("/leave-requests")).catch(() => ({ requests: [] })),
        api(adminApiUrl("/teacher-payouts")).catch(() => ({ payouts: [], teachers: [] })),
        api(adminApiUrl("/expenses")).catch(() => ({ expenses: [], financeSummary: {} })),
        api(adminApiUrl("/reports/overview")).catch(() => ({ dropouts: [], batchPerformance: [], monthlyCollection: [] })),
        api(adminApiUrl("/library")).catch(() => ({ books: [], issues: [] })),
        api(adminApiUrl("/cms/toppers")).catch(() => ({ toppers: [] })),
        api(adminApiUrl("/alerts")).catch(() => ({ logs: [] })),
        api(adminApiUrl("/parents")).catch(() => ({ parents: [] })),
        api(adminApiUrl("/users?role=student&status=all&page=1&pageSize=100")).catch(() => ({ users: [] })),
        api(adminApiUrl("/mail/accounts")).catch(() => ({ accounts: [], counts: {} })),
        tab === "mail" && ["inbox", "sent", "trash"].includes(mailSubView)
          ? api(
              adminApiUrl(
                `/mail/messages?folder=${encodeURIComponent(mailSubView)}&accountId=${encodeURIComponent(mailAccountId)}&search=${encodeURIComponent(mailSearch)}&page=${mailPage}&pageSize=25`
              )
            ).catch(() => ({ messages: [], total: 0, counts: {} }))
          : Promise.resolve({ messages: [], total: 0, counts: {} }),
        tab === "settings" && settingsSubTab === "email_bimi"
          ? api(adminApiUrl("/settings/bimi")).catch(() => null)
          : Promise.resolve(null),
        tab === "admissions"
          ? api(adminApiUrl("/crm/waitlist")).catch(() => ({ waitlist: [] }))
          : Promise.resolve({ waitlist: [] }),
      ]);

      const branchesList = branchesRes.branches || [];
      const batchesList = batchesRes.batches || [];
      const slotsList = timetableRes.slots || [];
      const teachersList = coursesRes.teachers || [];
      const coursesList = coursesRes.courses || [];
      const studentsList = allStudentsRes.users || [];
      const parentsList = parentsRes.parents || [];
      const mailAccountsList = mailAccountsRes.accounts || [];
      const mailUnreadTotal = Number(mailAccountsRes?.counts?.inboxUnread || 0);

      const waitlistRows = waitlistRes?.waitlist || [];
      const adminNavGroups = [
        {
          id: "dashboard",
          label: "Dashboard",
          icon: "dashboard",
          items: [
            { key: "dashboard-overview", tab: "dashboard", subView: "overview", label: "Overview" },
            { key: "dashboard-today", tab: "dashboard", subView: "todays_desk", label: "Today's Desk" },
            { key: "dashboard-kpi", tab: "dashboard", subView: "kpi_alerts", label: "KPI alerts" },
            { key: "dashboard-audit", tab: "dashboard", subView: "audit", label: "Audit", scrollMatch: "Recent Audit Activity" },
          ],
        },
        {
          id: "admissions",
          label: "Admissions",
          icon: "clipboardCheck",
          items: [
            { key: "adm-inquiries", tab: "admissions", subView: "inquiries", label: "Inquiries" },
            { key: "adm-leads", tab: "admissions", subView: "leads", label: "Leads CRM" },
            { key: "adm-demo", tab: "admissions", subView: "demo", label: "Demo" },
            { key: "adm-convert", tab: "admissions", subView: "convert", label: "Convert to Student" },
            { key: "adm-waitlist", tab: "admissions", subView: "waitlist", label: "Waitlist" },
          ],
        },
        {
          id: "users",
          label: "Users",
          icon: "users",
          items: [
            { key: "users-students", tab: "users", role: "student", label: "Students" },
            { key: "users-teachers", tab: "users", role: "teacher", label: "Teachers" },
            { key: "users-parents", tab: "users", role: "parent", label: "Parents" },
            { key: "users-staff", tab: "users", role: "staff", label: "Staff" },
          ],
        },
        {
          id: "academics",
          label: "Academics",
          icon: "graduationCap",
          items: [
            { key: "academics-courses", tab: "courses", label: "Courses" },
            { key: "academics-subjects", tab: "courses", label: "Subjects", scrollMatch: "Manage Subjects" },
            { key: "academics-branches", tab: "academics", label: "Branches", scrollMatch: "Multi-Branch Centers" },
            { key: "academics-batches", tab: "academics", label: "Batches", scrollMatch: "Batches, Classrooms" },
            { key: "academics-timetable", tab: "academics", label: "Timetable", scrollMatch: "Master Weekly Timetable" },
            { key: "academics-hub", tab: "online_hub", label: "Online Hub (Live, CBT, DPP, Doubts)" },
            { key: "academics-tests", tab: "tests", label: "Tests", scrollMatch: "Offline Tests" },
            { key: "academics-attendance", tab: "tests", label: "Attendance", scrollMatch: "Student Attendance Reports" },
          ],
        },
        {
          id: "finance",
          label: "Finance",
          icon: "wallet",
          items: [
            { key: "finance-fee-desk", tab: "payments", subView: "fee_desk", label: "Fee Desk" },
            { key: "finance-plans", tab: "payments", subView: "all", label: "Fee Plans", scrollMatch: "Official Fee Plans" },
            { key: "finance-emi", tab: "payments", subView: "all", label: "EMI", scrollMatch: "Fee Installments" },
            { key: "finance-coupons", tab: "payments", subView: "all", label: "Coupons", scrollMatch: "Discount Coupons" },
            { key: "finance-payments", tab: "payments", subView: "all", label: "Payments", scrollMatch: "Recent Fee Transactions" },
            { key: "finance-payouts", tab: "finance", label: "Payouts", scrollMatch: "Teacher Salary Payouts" },
            { key: "finance-expenses", tab: "finance", label: "Expenses", scrollMatch: "Center Operational Expenses" },
          ],
        },
        {
          id: "library",
          label: "Library",
          icon: "library",
          items: [
            { key: "library-books", tab: "library", label: "Books", scrollMatch: "Inventory" },
            { key: "library-issue", tab: "library", label: "Issue/Return", scrollMatch: "Issue / Return Register" },
          ],
        },
        {
          id: "communication",
          label: "Communication",
          icon: "messageSquare",
          badge: mailUnreadTotal > 0 ? String(mailUnreadTotal) : "",
          items: [
            { key: "comm-mail", tab: "mail", label: "Mail", badge: mailUnreadTotal > 0 ? String(mailUnreadTotal) : "" },
            { key: "comm-alerts", tab: "alerts", label: "Bulk Alerts" },
            { key: "comm-marketing", tab: "marketing", label: "Email Marketing" },
          ],
        },
        {
          id: "marketing_web",
          label: "Marketing & Website",
          icon: "megaphone",
          items: [
            { key: "mkt-cms", tab: "cms", label: "CMS" },
            { key: "mkt-chatbot", tab: "chatbot", label: "Chatbot (Shreya AI)" },
          ],
        },
        {
          id: "referrals",
          label: "Referrals",
          icon: "award",
          items: [
            { key: "ref-rules", tab: "referrals", label: "Rules" },
            { key: "ref-milestones", tab: "referrals", label: "Milestones", scrollMatch: "Milestone" },
            { key: "ref-campaigns", tab: "referrals", label: "Campaigns", scrollMatch: "Campaign" },
            { key: "ref-wallets", tab: "wallets", label: "Wallets" },
            { key: "ref-withdrawals", tab: "withdrawals", label: "Withdrawals" },
            { key: "ref-reports", tab: "referral_reports", label: "Reports" },
          ],
        },
        {
          id: "reports",
          label: "Reports",
          icon: "barChart",
          items: [
            { key: "rep-center", tab: "reports", label: "Center Reports" },
            { key: "rep-bulk", tab: "bulk_export", label: "Bulk Export" },
          ],
        },
        {
          id: "system",
          label: "System",
          icon: "settings",
          items: [
            { key: "sys-backup", tab: "backups", label: "Backup" },
            { key: "sys-upgrade", tab: "upgrade", label: "Upgrade" },
            { key: "sys-security", tab: "security_logs", label: "Security Logs" },
            { key: "sys-settings", tab: "settings", label: "Settings", settingsTab: settingsSubTab },
          ],
        },
      ];

      const resolveAdminNavSelection = () => {
        if (activeAdminNavKey) {
          for (const g of adminNavGroups) {
            const found = g.items.find((it) => it.key === activeAdminNavKey);
            if (found && found.tab === tab) {
              return { groupId: g.id, item: found };
            }
          }
        }
        if (tab === "admissions") {
          const kMap = { inquiries: "adm-inquiries", leads: "adm-leads", demo: "adm-demo", convert: "adm-convert", waitlist: "adm-waitlist" };
          const grp = adminNavGroups.find((g) => g.id === "admissions");
          const item = grp?.items.find((it) => it.key === kMap[admissionsSubView]) || grp?.items[0] || null;
          return { groupId: "admissions", item };
        }
        if (tab === "users") {
          const roleKey =
            userFilterRole === "teacher"
              ? "users-teachers"
              : userFilterRole === "parent"
                ? "users-parents"
                : userFilterRole === "staff"
                  ? "users-staff"
                  : "users-students";
          const grp = adminNavGroups.find((g) => g.id === "users");
          return { groupId: "users", item: grp?.items.find((it) => it.key === roleKey) || grp?.items[0] || null };
        }
        if (tab === "payments") {
          const grp = adminNavGroups.find((g) => g.id === "finance");
          const k = paymentsSubView === "fee_desk" ? "finance-fee-desk" : "finance-payments";
          return { groupId: "finance", item: grp?.items.find((it) => it.key === k) || grp?.items[0] || null };
        }
        for (const g of adminNavGroups) {
          const found = g.items.find((it) => it.tab === tab);
          if (found) return { groupId: g.id, item: found };
        }
        return { groupId: "dashboard", item: adminNavGroups[0].items[0] };
      };
      const resolvedAdminNav = resolveAdminNavSelection();
      if (resolvedAdminNav.item) {
        activeAdminNavKey = resolvedAdminNav.item.key;
      } else {
        activeAdminNavKey = "";
      }
      if (resolvedAdminNav.groupId) {
        openAdminGroups.add(resolvedAdminNav.groupId);
      }

      const breadcrumbsList = [
        { label: "Dashboard", tab: "dashboard" },
        ...(resolvedAdminNav.groupId !== "dashboard"
          ? [{ label: adminNavGroups.find((g) => g.id === resolvedAdminNav.groupId)?.label || tab, tab }]
          : []),
        ...(resolvedAdminNav.item ? [{ label: resolvedAdminNav.item.label }] : []),
      ];

      let bodyHtml = "";
      if (feedbackError) {
        bodyHtml += `<div class="portal-message portal-message--error">${escapeHtml(feedbackError)}</div>`;
        feedbackError = "";
      }
      if (feedbackMsg) {
        bodyHtml += `<div class="portal-message portal-message--success">${escapeHtml(feedbackMsg)}</div>`;
        feedbackMsg = "";
      }

      if (tab === "dashboard") {
        const c = dash.counts;
        const f = dash.feeSummary;
        const fs = expensesRes.financeSummary || {};
        bodyHtml += `
          <div class="portal-subtabs" role="tablist" aria-label="Dashboard sections" style="margin-bottom:12px;">
            ${[
              ["overview", "Overview"],
              ["todays_desk", "Today's Desk"],
              ["kpi_alerts", "KPI Alerts"],
              ["audit", "Audit"],
            ]
              .map(([dk, dl]) => `<button type="button" class="portal-subtab ${dashboardSubView === dk ? "is-active" : ""}" data-dash-subview="${dk}">${dl}</button>`)
              .join("")}
          </div>`;
        if (dashboardSubView === "overview" || dashboardSubView === "todays_desk") {
          bodyHtml += `<div data-yu-crm-dashboard-header></div>`;
        }
        if (dashboardSubView === "overview" || dashboardSubView === "kpi_alerts") {
          bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <a href="#users?role=student" class="portal-stat portal-stat--link" data-dash-tab="users" data-dash-role="student" data-dash-status="all"><div><strong>${c.totalStudents}</strong><span>Total Students</span></div><div class="portal-stat-icon">${icon("users")}</div></a>
            <a href="#users?role=teacher" class="portal-stat portal-stat--link" data-dash-tab="users" data-dash-role="teacher" data-dash-status="all"><div><strong>${c.totalTeachers}</strong><span>Total Teachers</span></div><div class="portal-stat-icon">${icon("user")}</div></a>
            <a href="#users?status=pending_approval" class="portal-stat portal-stat--link" data-dash-tab="users" data-dash-role="all" data-dash-status="pending_approval"><div><strong>${c.pendingApprovals}</strong><span>Pending Approvals</span></div><div class="portal-stat-icon">${icon("dashboard")}</div></a>
            <a href="#academics" class="portal-stat portal-stat--link" data-dash-tab="academics"><div><strong>${batchesList.length} / ${branchesList.length}</strong><span>Batches / Branches</span></div><div class="portal-stat-icon">${icon("calendar")}</div></a>
            <a href="#reports" class="portal-stat portal-stat--link" data-dash-tab="reports"><div><strong>${c.totalAdmissions}</strong><span>Confirmed Admissions</span></div><div class="portal-stat-icon">${icon("award")}</div></a>
            <a href="#admissions" class="portal-stat portal-stat--link" data-dash-tab="admissions"><div><strong>${c.newInquiries}</strong><span>New Website Inquiries</span></div><div class="portal-stat-icon">${icon("megaphone")}</div></a>
            <a href="#payments" class="portal-stat portal-stat--link" data-dash-tab="payments"><div><strong>${formatINR(f.totalCollected)}</strong><span>Verified Fees (${formatINR(f.totalPending)} pending)</span></div><div class="portal-stat-icon">${icon("wallet")}</div></a>
            <a href="#finance" class="portal-stat portal-stat--link" data-dash-tab="finance"><div><strong>${formatINR(fs.netSurplus || 0)}</strong><span>Net Center Surplus</span></div><div class="portal-stat-icon">${icon("award")}</div></a>
          </div>`;
        }
        const allActivities = dash.recentActivities || [];
        const auditPageSize = 10;
        const auditTotalPages = Math.max(1, Math.ceil(allActivities.length / auditPageSize));
        if (auditPage > auditTotalPages) auditPage = auditTotalPages;
        if (auditPage < 1) auditPage = 1;
        const auditStart = (auditPage - 1) * auditPageSize;
        const pagedActivities = dashboardSubView === "audit" ? allActivities : allActivities.slice(auditStart, auditStart + auditPageSize);
        if (dashboardSubView === "overview" || dashboardSubView === "audit") {
          const showAuditBody = dashboardSubView === "audit" || auditVisible;
          bodyHtml += `
          <div class="portal-card portal-table-card" data-testid="recent-audit-card">
            <div style="padding:12px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);display:flex;align-items:center;justify-content:space-between;gap:12px;">
              <span>Recent Audit Activity (${allActivities.length})</span>
              ${dashboardSubView !== "audit" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-audit-activity data-testid="toggle-audit-activity">${auditVisible ? "Hide" : "Show"}</button>` : ""}
            </div>
            ${
              showAuditBody
                ? `<div class="portal-table-scroll">
                    <table class="portal-table" data-testid="recent-audit-table" data-yu-table="admin_recent_audit" ${dashboardSubView === "audit" ? "" : 'data-yu-no-paginate="1"'}>
                      <thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>Details</th><th>Timestamp</th></tr></thead>
                      <tbody>
                        ${pagedActivities.map((a) => `<tr><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.actor_name || "-")}</td><td>${escapeHtml(a.target_name || "-")}</td><td>${escapeHtml(a.details || "")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No activity logs yet.</td></tr>`}
                      </tbody>
                    </table>
                  </div>
                  ${
                    dashboardSubView !== "audit"
                      ? `<div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;padding:10px 16px;border-top:1px solid var(--pt-border);font-size:12px;">
                           <span>Showing ${allActivities.length ? auditStart + 1 : 0}–${Math.min(auditStart + auditPageSize, allActivities.length)} of ${allActivities.length} · Page ${auditPage} of ${auditTotalPages} (max 10/page)</span>
                           <div class="portal-actions">
                             <button type="button" class="portal-button portal-button--small portal-button--quiet" data-audit-page="${auditPage - 1}" data-testid="audit-prev-btn" ${auditPage <= 1 ? "disabled" : ""}>Previous</button>
                             <button type="button" class="portal-button portal-button--small portal-button--quiet" data-audit-page="${auditPage + 1}" data-testid="audit-next-btn" ${auditPage >= auditTotalPages ? "disabled" : ""}>Next</button>
                           </div>
                         </div>`
                      : ""
                  }`
                : `<div style="padding:12px 16px;font-size:12px;color:var(--pt-muted);">Recent Audit Activity is hidden. Click <strong>Show</strong> to view logs.</div>`
            }
          </div>`;
        }
      } else if (tab === "admissions") {
        const allInquiries = inquiriesRes.inquiries || [];
        const demoInquiries = allInquiries.filter((q) => Boolean(q.demo_date));
        const convertibleInquiries = allInquiries.filter((q) => q.status !== "admitted");
        bodyHtml += `
          <div class="portal-subtabs" role="tablist" aria-label="Admissions views" style="margin-bottom:12px;">
            ${[
              ["inquiries", `Inquiries (${allInquiries.length})`],
              ["leads", "Leads CRM"],
              ["demo", `Demo Classes (${demoInquiries.length})`],
              ["convert", `Convert to Student (${convertibleInquiries.length})`],
              ["waitlist", `Waitlist (${waitlistRows.length})`],
            ]
              .map(([ak, al]) => `<button type="button" class="portal-subtab ${admissionsSubView === ak ? "is-active" : ""}" data-adm-subview="${ak}">${escapeHtml(al)}</button>`)
              .join("")}
          </div>`;
        if (admissionsSubView === "leads") {
          bodyHtml += `<div data-yu-admin-crm="crm_leads"></div>`;
        } else if (admissionsSubView === "waitlist") {
          bodyHtml += `
            <div class="portal-card portal-table-card">
              <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);display:flex;justify-content:space-between;align-items:center;gap:10px;">
                <span>Batch &amp; Admission Waitlist (${waitlistRows.length})</span>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-adm-subview="leads">+ Add / Convert Lead</button>
              </div>
              <div class="portal-table-scroll"><table class="portal-table" data-yu-table="admissions_waitlist">
                <thead><tr><th>Student</th><th>Contact</th><th>Course / Batch</th><th>Position</th><th>Status</th><th data-yu-locked="1" data-yu-no-sort="1">Actions</th></tr></thead>
                <tbody>
                  ${waitlistRows.map((w) => `<tr>
                    <td><span class="portal-cell-title">${escapeHtml(w.student_name || w.full_name || "Waitlisted Student")}</span><span class="portal-cell-sub">${escapeHtml(w.roll_number || w.notes || "")}</span></td>
                    <td>${escapeHtml(w.phone || "-")}<span class="portal-cell-sub">${escapeHtml(w.email || "")}</span></td>
                    <td>${escapeHtml(w.course_title || "-")} <span class="portal-cell-sub">${escapeHtml(w.batch_name || "Any Batch")} (${Number(w.seats_used || 0)}/${Number(w.seat_limit || 0)} seats)</span></td>
                    <td><strong>#${Number(w.priority_order || w.id)}</strong></td>
                    <td>${statusBadge(w.status || "waiting")}</td>
                    <td><div class="portal-actions">
                      ${w.status !== "promoted" ? `<button type="button" class="portal-button portal-button--small" data-wl-promote="${w.id}">Promote to Batch</button>` : ""}
                      <button type="button" class="portal-button portal-button--small portal-button--danger" data-wl-del="${w.id}">Remove</button>
                    </div></td>
                  </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No students on the waitlist right now.</td></tr>`}
                </tbody>
              </table></div>
            </div>`;
        } else {
          const rowsToShow =
            admissionsSubView === "demo"
              ? demoInquiries
              : admissionsSubView === "convert"
                ? convertibleInquiries
                : allInquiries;
          const sectionTitle =
            admissionsSubView === "demo"
              ? `Demo Class Bookings (${rowsToShow.length})`
              : admissionsSubView === "convert"
                ? `Ready to Convert to Student (${rowsToShow.length})`
                : `Website & Walk-in Inquiries (${rowsToShow.length})`;
          bodyHtml += `
            <div class="portal-card portal-table-card" style="margin-bottom:16px;">
              <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);display:flex;justify-content:space-between;align-items:center;gap:10px;">
                <span>${sectionTitle}</span>
                <button type="button" class="portal-button portal-button--small" data-adm-subview="leads">Open Leads CRM Pipeline</button>
              </div>
              <div class="portal-table-scroll"><table class="portal-table" data-yu-table="admissions_${escAttr(admissionsSubView)}">
                <thead><tr><th>Lead &amp; Course</th><th>Demo / Branch</th><th>Follow-Up</th><th>Status</th><th data-yu-locked="1" data-yu-no-sort="1">Actions</th></tr></thead>
                <tbody>
                  ${rowsToShow.map((q) => `<tr>
                    <td><span class="portal-cell-title">${escapeHtml(q.name)} (${escapeHtml(q.phone)})</span><span class="portal-cell-sub">${escapeHtml(q.class_or_course)} · ${escapeHtml(q.message || "")}</span></td>
                    <td>${q.demo_date ? `<strong>${escapeHtml(q.demo_date)}</strong> ${escapeHtml(q.demo_time_slot || "")}` : "General Lead"}<span class="portal-cell-sub">${escapeHtml(q.branch_name || "")}</span></td>
                    <td>
                      <input type="date" data-inq-fdate value="${escAttr(q.follow_up_date || "")}" style="min-height:30px;border:1px solid var(--pt-border);border-radius:6px;padding:2px 6px;margin-bottom:4px;display:block;">
                      <input type="text" data-inq-fnotes value="${escAttr(q.follow_up_notes || "")}" placeholder="Follow-up note" style="min-height:30px;border:1px solid var(--pt-border);border-radius:6px;padding:2px 6px;width:150px;">
                    </td>
                    <td><select data-inq-status="${q.id}" style="min-height:32px;border:1px solid var(--pt-border);border-radius:8px;padding:2px 6px;">${["new", "contacted", "admitted", "closed"].map((st) => `<option value="${st}"${q.status === st ? " selected" : ""}>${st}</option>`).join("")}</select></td>
                    <td><div class="portal-actions">
                      <button type="button" class="portal-button portal-button--small" data-inq-save="${q.id}">Save</button>
                      ${q.status !== "admitted" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-inq-convert="${q.id}">Convert</button>` : ""}
                      <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-inq="${q.id}">Delete</button>
                    </div></td>
                  </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No records match this Admissions view.</td></tr>`}
                </tbody>
              </table></div>
            </div>`;
        }
      } else if (tab === "mail") {
        const counts = mailMessagesRes.counts && Object.keys(mailMessagesRes.counts).length
          ? mailMessagesRes.counts
          : mailAccountsRes.counts || { inboxUnread: 0, inboxTotal: 0, sentTotal: 0, trashTotal: 0 };
        const missingPwdAccounts = mailAccountsList.filter((a) => !a.hasPassword);
        const readyAccountsCount = mailAccountsList.length - missingPwdAccounts.length;
        const activeAccountObj =
          mailAccountId !== "all"
            ? mailAccountsList.find((a) => String(a.id) === String(mailAccountId))
            : null;
        const messagesList = mailMessagesRes.messages || [];
        const totalMsgs = Number(mailMessagesRes.total || 0);
        const totalMailPages = Math.max(1, Math.ceil(totalMsgs / 25));

        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:14px;">
            <div class="portal-stat"><div><strong>${readyAccountsCount} / ${mailAccountsList.length}</strong><span>Active Mailboxes Ready</span></div><div class="portal-stat-icon">${icon("mail")}</div></div>
            <div class="portal-stat"><div><strong>${Number(counts.inboxUnread || 0)}</strong><span>Unread Inbox Emails</span></div><div class="portal-stat-icon">${icon("bell")}</div></div>
            <div class="portal-stat"><div><strong>${Number(counts.inboxTotal || 0)}</strong><span>Total Received Emails</span></div><div class="portal-stat-icon">${icon("download")}</div></div>
            <div class="portal-stat"><div><strong>${Number(counts.sentTotal || 0)}</strong><span>Sent Emails</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
          </div>
          ${
            missingPwdAccounts.length > 0
              ? `<div class="portal-message" style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;">
                  <div><strong>Security Vault Notice:</strong> ${missingPwdAccounts.length} mailbox(es) (${missingPwdAccounts.map((a) => escapeHtml(a.email)).join(", ")}) need your runtime password before sending/receiving emails. Passwords are AES-256 encrypted on your server and never hardcoded in files or ZIPs.</div>
                  <button type="button" class="portal-button portal-button--small" data-mail-view="accounts">Enter Passwords Now</button>
                </div>`
              : ""
          }
          ${
            mailTestNotice
              ? `<div class="portal-message ${mailTestNotice.ok ? "portal-message--success" : "portal-message--error"}" style="margin-bottom:14px;">${escapeHtml(mailTestNotice.text)}</div>`
              : ""
          }
          <div class="portal-subtabs" role="tablist" aria-label="Mail folder sections">
            <button type="button" class="portal-subtab ${mailSubView === "inbox" ? "is-active" : ""}" data-mail-view="inbox">Inbox (${Number(counts.inboxTotal || 0)})</button>
            <button type="button" class="portal-subtab ${mailSubView === "sent" ? "is-active" : ""}" data-mail-view="sent">Sent (${Number(counts.sentTotal || 0)})</button>
            <button type="button" class="portal-subtab ${mailSubView === "trash" ? "is-active" : ""}" data-mail-view="trash">Trash (${Number(counts.trashTotal || 0)})</button>
            <button type="button" class="portal-subtab ${mailSubView === "compose" ? "is-active" : ""}" data-mail-view="compose">+ Compose Email</button>
            <button type="button" class="portal-subtab ${mailSubView === "accounts" ? "is-active" : ""}" data-mail-view="accounts">Mailboxes &amp; Passwords (${readyAccountsCount}/${mailAccountsList.length})</button>
          </div>`;

        if (["inbox", "sent", "trash"].includes(mailSubView)) {
          bodyHtml += `
            <div class="portal-card portal-profile" style="margin-bottom:14px;">
              <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
                  <button type="button" class="portal-button portal-button--small ${mailAccountId === "all" ? "" : "portal-button--quiet"}" data-mail-acct="all">All Mailboxes</button>
                  ${mailAccountsList
                    .map(
                      (a) =>
                        `<button type="button" class="portal-button portal-button--small ${String(mailAccountId) === String(a.id) ? "" : "portal-button--quiet"}" data-mail-acct="${a.id}">${escapeHtml(a.email)}${a.unreadCount > 0 ? ` (${a.unreadCount})` : ""}</button>`
                    )
                    .join("")}
                </div>
                <div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-sync-all>${icon("download")} Sync All Inboxes</button>
                  <button type="button" class="portal-button portal-button--small" data-mail-new-compose>${icon("mail")} Compose</button>
                </div>
              </div>
              <form class="portal-actions" data-mail-search-form style="gap:8px;">
                <input name="search" type="search" value="${escAttr(mailSearch)}" placeholder="Search subject, sender, recipient..." style="flex:1 1 200px;min-width:0;max-width:100%;min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 12px;">
                <button type="submit" class="portal-button portal-button--small portal-button--quiet">Search</button>
                ${mailSearch ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-clear-search>Clear</button>` : ""}
              </form>
              ${
                activeAccountObj && activeAccountObj.lastSyncAt
                  ? `<p class="portal-hint" style="margin:8px 0 0;">Last IMAP Sync for ${escapeHtml(activeAccountObj.email)}: ${escapeHtml(activeAccountObj.lastSyncAt.replace("T", " ").slice(0, 19))}${activeAccountObj.lastError ? ` · Note: ${escapeHtml(activeAccountObj.lastError)}` : ""}</p>`
                  : ""
              }
            </div>`;

          if (selectedMailMsg) {
            const safeDoc =
              selectedMailMsg.html_body ||
              `<div style="font-family:system-ui,sans-serif;padding:12px;white-space:pre-wrap;">${escapeHtml(selectedMailMsg.text_body || selectedMailMsg.snippet || "")}</div>`;
            bodyHtml += `
              <div class="portal-card portal-profile" style="margin-bottom:14px;">
                <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--pt-border);">
                  <div>
                    <div style="font-size:17px;font-weight:750;margin-bottom:4px;">${escapeHtml(selectedMailMsg.subject || "(No Subject)")}</div>
                    <div class="portal-hint" style="margin:0;">
                      <strong>From:</strong> ${escapeHtml(selectedMailMsg.from_name ? `${selectedMailMsg.from_name} <${selectedMailMsg.from_email}>` : selectedMailMsg.from_email)}<br>
                      <strong>To:</strong> ${escapeHtml(selectedMailMsg.to_emails)} ${selectedMailMsg.cc_emails ? ` · <strong>Cc:</strong> ${escapeHtml(selectedMailMsg.cc_emails)}` : ""}<br>
                      <strong>Mailbox:</strong> ${escapeHtml(selectedMailMsg.account_email)} · <strong>Date:</strong> ${escapeHtml(String(selectedMailMsg.mail_date || "").replace("T", " ").slice(0, 19))}
                    </div>
                  </div>
                  <div class="portal-actions">
                    <button type="button" class="portal-button portal-button--small" data-mail-reply="${selectedMailMsg.id}">Reply</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-forward="${selectedMailMsg.id}">Forward</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-star="${selectedMailMsg.id}" data-star="${selectedMailMsg.is_starred ? "0" : "1"}">${selectedMailMsg.is_starred ? "Unstar" : "Star"}</button>
                    ${
                      selectedMailMsg.folder === "trash"
                        ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-restore="${selectedMailMsg.id}">Restore to Inbox</button>
                           <button type="button" class="portal-button portal-button--small portal-button--danger" data-mail-delete="${selectedMailMsg.id}" data-perm="1">Delete Forever</button>`
                        : `<button type="button" class="portal-button portal-button--small portal-button--danger" data-mail-delete="${selectedMailMsg.id}" data-perm="0">Trash</button>`
                    }
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-close-reader>Close</button>
                  </div>
                </div>
                ${
                  Array.isArray(selectedMailMsg.attachments) && selectedMailMsg.attachments.length > 0
                    ? `<div style="margin-bottom:10px;font-size:13px;"><strong>Attachments:</strong> ${selectedMailMsg.attachments.map((at) => `<span class="portal-status portal-status--pending">${escapeHtml(at.filename)} (${Math.max(1, Math.round((at.size || 0) / 1024))} KB)</span>`).join(" ")}</div>`
                    : ""
                }
                <iframe sandbox="" referrerpolicy="no-referrer" style="width:100%;min-height:340px;border:1px solid var(--pt-border);border-radius:10px;background:#ffffff;" srcdoc="${escAttr(safeDoc)}"></iframe>
              </div>`;
          }

          bodyHtml += `
            <div class="portal-card portal-table-card">
              <div style="padding:12px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);display:flex;justify-content:space-between;align-items:center;">
                <span>${mailSubView.toUpperCase()} Folder (${totalMsgs})</span>
                <span class="portal-hint" style="margin:0;">Page ${mailPage} of ${totalMailPages}</span>
              </div>
              <div class="portal-table-scroll"><table class="portal-table">
                <thead><tr><th>Sender / Recipient</th><th>Subject &amp; Preview</th><th>Mailbox</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                  ${
                    messagesList
                      .map((m) => {
                        const isUnread = Number(m.is_read) === 0;
                        const peer = mailSubView === "sent" ? `To: ${m.to_emails}` : m.from_name ? `${m.from_name} (${m.from_email})` : m.from_email;
                        return `<tr style="${isUnread ? "background:rgba(22,119,255,0.05);" : ""}">
                          <td><span class="portal-cell-title">${m.is_starred ? "★ " : ""}${isUnread ? "<strong>" : ""}${escapeHtml(peer)}${isUnread ? "</strong>" : ""}</span></td>
                          <td>
                            <button type="button" class="portal-link-btn" data-mail-open="${m.id}" style="background:none;border:0;padding:0;text-align:left;cursor:pointer;color:inherit;font:inherit;">
                              <span class="portal-cell-title" style="${isUnread ? "font-weight:800;color:var(--pt-primary,#1677ff);" : ""}">${escapeHtml(m.subject || "(No Subject)")}${m.has_attachments ? " [Attachment]" : ""}</span>
                              <span class="portal-cell-sub">${escapeHtml(m.snippet || "")}</span>
                            </button>
                          </td>
                          <td><span class="portal-status portal-status--approved">${escapeHtml(m.account_email)}</span></td>
                          <td style="white-space:nowrap;">${escapeHtml(String(m.mail_date || "").replace("T", " ").slice(0, 16))}</td>
                          <td><div class="portal-actions">
                            <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-open="${m.id}">Read</button>
                            <button type="button" class="portal-button portal-button--small portal-button--danger" data-mail-delete="${m.id}" data-perm="${mailSubView === "trash" ? "1" : "0"}">${mailSubView === "trash" ? "Delete" : "Trash"}</button>
                          </div></td>
                        </tr>`;
                      })
                      .join("") ||
                    `<tr><td colspan="5" class="portal-empty">No emails in this folder yet. Set your mailbox password under <strong>Mailboxes &amp; Passwords</strong> and click <strong>Sync All Inboxes</strong>.</td></tr>`
                  }
                </tbody>
              </table></div>
              ${
                totalMailPages > 1
                  ? `<div style="padding:12px 16px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--pt-border);">
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-page="${mailPage - 1}" ${mailPage <= 1 ? "disabled" : ""}>Previous</button>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mail-page="${mailPage + 1}" ${mailPage >= totalMailPages ? "disabled" : ""}>Next</button>
                    </div>`
                  : ""
              }
            </div>`;
        } else if (mailSubView === "compose") {
          const defaultAcc = mailAccountsList.find((a) => a.isDefault) || mailAccountsList[0];
          const chosenAccId = composeDraft.accountId || (defaultAcc ? String(defaultAcc.id) : "");
          bodyHtml += `
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Compose &amp; Send Email</h3>
              <p class="portal-hint" style="margin-bottom:12px;">Select any configured mailbox (<strong>no-reply@yuitor.com</strong>, <strong>admission@yuitor.com</strong>, <strong>info@yuitor.com</strong>, <strong>support@yuitor.com</strong>, or custom) to send directly.</p>
              <form class="portal-form" data-mail-compose-form>
                <input type="hidden" name="inReplyTo" value="${escAttr(composeDraft.inReplyTo || "")}">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>From Mailbox *</label>
                    <select name="accountId" required>
                      ${
                        mailAccountsList
                          .filter((a) => a.isActive)
                          .map(
                            (a) =>
                              `<option value="${a.id}" ${String(a.id) === String(chosenAccId) ? "selected" : ""}>${escapeHtml(a.email)} — ${escapeHtml(a.displayName)} (${a.hasPassword ? "Ready" : "Password Needed"})</option>`
                          )
                          .join("") || `<option value="">No mailboxes configured</option>`
                      }
                    </select>
                  </div>
                  <div class="portal-field"><label>To Recipient Email *</label><input name="to" type="text" required placeholder="student@example.com, parent@example.com" value="${escAttr(composeDraft.to || "")}"></div>
                  <div class="portal-field"><label>Cc (Optional)</label><input name="cc" type="text" placeholder="Optional Cc address" value="${escAttr(composeDraft.cc || "")}"></div>
                  <div class="portal-field"><label>Subject *</label><input name="subject" type="text" required placeholder="Email subject line" value="${escAttr(composeDraft.subject || "")}"></div>
                </div>
                <div class="portal-field"><label>Message Body *</label><textarea name="text" rows="9" required placeholder="Write your message here...">${escapeHtml(composeDraft.text || "")}</textarea></div>
                <div class="portal-field"><label>Attachments (Optional · up to 3 files, max 5 MB each)</label><input name="attachments" type="file" multiple></div>
                <div class="portal-actions">
                  <button type="submit" class="portal-button" data-mail-send-btn>${icon("mail")} Send Email Now</button>
                  <button type="button" class="portal-button portal-button--quiet" data-mail-view="inbox">Cancel</button>
                </div>
              </form>
            </div>`;
        } else if (mailSubView === "accounts") {
          const editTarget = editingMailbox || {};
          bodyHtml += `
            <div class="portal-card portal-profile" style="margin-bottom:16px;">
              <h3 class="portal-section-title">Quick Vault Password Setup (Apply to Multiple Mailboxes)</h3>
              <p class="portal-hint" style="margin-bottom:10px;">Agar aapke multiple email IDs (jaise <strong>no-reply@yuitor.com</strong>, <strong>admission@yuitor.com</strong>, <strong>info@yuitor.com</strong>, <strong>support@yuitor.com</strong>) ka same password hai, toh yahan ek baar password daal kar sabko ek click me activate karein. Password server vault me encrypted save hota hai aur kabhi leak nahi hota.</p>
              <form class="portal-form" data-mail-bulk-pwd-form>
                <div class="portal-form-grid">
                  <div class="portal-field">
                    <label>Mailbox Password *</label>
                    <div class="portal-setting-input-row">
                      <input name="password" type="password" required autocomplete="new-password" placeholder="Enter shared mailbox password" data-bulk-pwd-input>
                      <button type="button" class="portal-button portal-button--small portal-button--quiet" data-toggle-bulk-pwd>Show</button>
                    </div>
                  </div>
                </div>
                <div class="portal-field">
                  <label>Select Mailboxes to Apply Password</label>
                  <div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:6px;">
                    ${mailAccountsList
                      .map(
                        (a) =>
                          `<label style="display:inline-flex;align-items:center;gap:6px;font-size:13px;"><input type="checkbox" name="accountIds" value="${a.id}" ${!a.hasPassword ? "checked" : ""}> <span><strong>${escapeHtml(a.email)}</strong> (${a.hasPassword ? "Saved" : "Needs Password"})</span></label>`
                      )
                      .join("")}
                  </div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Save Encrypted Password for Selected Mailboxes</button>
              </form>
            </div>
            <div class="portal-card portal-table-card" style="margin-bottom:16px;">
              <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Configured Mailboxes (${mailAccountsList.length})</div>
              <div class="portal-table-scroll"><table class="portal-table">
                <thead><tr><th>Email &amp; Name</th><th>SMTP Server</th><th>IMAP Server</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  ${mailAccountsList
                    .map(
                      (a) => `<tr>
                        <td><span class="portal-cell-title">${escapeHtml(a.email)} ${a.isDefault ? '<span class="portal-status portal-status--approved">Default</span>' : ""}</span><span class="portal-cell-sub">${escapeHtml(a.displayName)}</span></td>
                        <td>${escapeHtml(a.smtpHost)}:${a.smtpPort} (${a.smtpSecure ? "SSL" : "TLS"})<br><span class="portal-hint" style="margin:0;">User: ${escapeHtml(a.smtpUser)}</span></td>
                        <td>${escapeHtml(a.imapHost)}:${a.imapPort} (${a.imapSecure ? "SSL" : "PLAIN"})<br><span class="portal-hint" style="margin:0;">User: ${escapeHtml(a.imapUser)}</span></td>
                        <td>${a.hasPassword ? statusBadge("approved") : statusBadge("pending")}<div class="portal-hint" style="margin:4px 0 0;">${a.hasPassword ? "Encrypted Ready" : "Password Needed"}${a.lastError ? `<br><span style="color:#dc2626;">${escapeHtml(a.lastError)}</span>` : ""}</div></td>
                        <td><div class="portal-actions">
                          <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mb-test="${a.id}">Test SMTP+IMAP</button>
                          <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mb-sync="${a.id}">Sync Inbox</button>
                          ${!a.isDefault ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-mb-default="${a.id}">Set Default</button>` : ""}
                          <button type="button" class="portal-button portal-button--small portal-button--quiet" data-mb-edit="${a.id}">Edit</button>
                          <button type="button" class="portal-button portal-button--small portal-button--danger" data-mb-del="${a.id}">Delete</button>
                        </div></td>
                      </tr>`
                    )
                    .join("")}
                </tbody>
              </table></div>
            </div>
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">${editingMailbox ? `Edit Mailbox: ${escapeHtml(editingMailbox.email)}` : "Add Any Other Email ID (Send & Receive)"}</h3>
              <p class="portal-hint" style="margin-bottom:12px;">Default server host is <strong>mail.yuitor.com</strong> (SMTP Port 465 SSL &amp; IMAP Port 993 SSL). Username usually matches your Email ID (or enter custom SMTP/IMAP username if your hosting requires a specific login user).</p>
              <form class="portal-form" data-mail-account-form="${editingMailbox ? escAttr(editingMailbox.id) : ""}">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Email ID *</label><input name="email" type="email" required placeholder="e.g. accounts@yuitor.com" value="${escAttr(editTarget.email || "")}"></div>
                  <div class="portal-field"><label>Sender Display Name *</label><input name="displayName" required placeholder="e.g. Yuitor Admissions Desk" value="${escAttr(editTarget.displayName || "Yuitor Smart Classes")}"></div>
                  <div class="portal-field"><label>${editingMailbox ? "New Password (leave blank to keep existing)" : "Email Password *"}</label><input name="password" type="password" ${editingMailbox ? "" : "required"} autocomplete="new-password" placeholder="${editingMailbox && editingMailbox.hasPassword ? "Saved in encrypted vault — leave blank to keep" : "Enter mailbox password"}"></div>
                  <div class="portal-field"><label>SMTP Host *</label><input name="smtpHost" required value="${escAttr(editTarget.smtpHost || "mail.yuitor.com")}"></div>
                  <div class="portal-field"><label>SMTP Port *</label><input name="smtpPort" type="number" required value="${escAttr(String(editTarget.smtpPort || 465))}"></div>
                  <div class="portal-field"><label>SMTP Security</label><select name="smtpSecure"><option value="true" ${editTarget.smtpSecure !== false ? "selected" : ""}>SSL/TLS (Port 465)</option><option value="false" ${editTarget.smtpSecure === false ? "selected" : ""}>STARTTLS (Port 587)</option></select></div>
                  <div class="portal-field"><label>SMTP Username (blank = Email ID)</label><input name="smtpUser" placeholder="Usually same as Email ID" value="${escAttr(editTarget.smtpUser || "")}"></div>
                  <div class="portal-field"><label>IMAP Host (for Receiving) *</label><input name="imapHost" required value="${escAttr(editTarget.imapHost || "mail.yuitor.com")}"></div>
                  <div class="portal-field"><label>IMAP Port *</label><input name="imapPort" type="number" required value="${escAttr(String(editTarget.imapPort || 993))}"></div>
                  <div class="portal-field"><label>IMAP Security</label><select name="imapSecure"><option value="true" ${editTarget.imapSecure !== false ? "selected" : ""}>SSL/TLS (Port 993)</option><option value="false" ${editTarget.imapSecure === false ? "selected" : ""}>STARTTLS / Plain (Port 143)</option></select></div>
                  <div class="portal-field"><label>IMAP Username (blank = Email ID)</label><input name="imapUser" placeholder="Usually same as Email ID" value="${escAttr(editTarget.imapUser || "")}"></div>
                </div>
                <div class="portal-field">
                  <label style="display:inline-flex;align-items:center;gap:8px;"><input type="checkbox" name="isDefault" value="1" ${editTarget.isDefault ? "checked" : ""}> Set as Default System Sender (for Student OTPs, Notices &amp; Fee Receipts)</label>
                </div>
                <div class="portal-actions">
                  <button type="submit" class="portal-button portal-button--small">${editingMailbox ? "Save Mailbox Changes" : "Add Mailbox"}</button>
                  ${editingMailbox ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-mb-cancel-edit>Cancel Edit</button>` : ""}
                </div>
              </form>
            </div>`;
        }
      } else if (tab === "users") {
        if (selectedUserDetail) {
          const u = selectedUserDetail.user;
          const sp = selectedUserDetail.studentProfile || {};
          const tp = selectedUserDetail.teacherProfile || {};
          let currentPerms = [];
          try {
            currentPerms = JSON.parse(u.staff_permissions_json || "[]");
          } catch {}
          const cleanPhone = String(u.phone || "").replace(/\D+/g, "");
          const waPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
          const waHref = waPhone ? `https://wa.me/${waPhone}?text=${encodeURIComponent(`Hello ${u.full_name}, update from Yuitor Smart Classes.`)}` : "";
          const isDeletedUser = Boolean(u.deleted_at) || String(u.verification_status || "").toLowerCase() === "deleted";
          const isSuperAdminAcc = String(u.role || "").toLowerCase() === "super_admin";
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>${escapeHtml(u.full_name)}</h2><p>${escapeHtml(u.role)} · ${escapeHtml(u.email)} · ${escapeHtml(u.phone)}</p></div>
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-users>← Back to Users</button>
              </div>
              <div class="portal-personal-grid" style="margin-bottom:16px;">
                <div class="portal-detail"><span>Verification Status</span><strong>${statusBadge(u.verification_status)}</strong></div>
                <div class="portal-detail"><span>Mobile OTP Verified</span><strong>${u.mobile_verified ? "Yes" : "No"}</strong></div>
                <div class="portal-detail"><span>Account Active</span><strong>${u.is_active && !isDeletedUser ? "Yes" : "Disabled"}</strong></div>
                ${u.status_reason ? `<div class="portal-detail"><span>Status Reason</span><strong>${escapeHtml(u.status_reason)}</strong></div>` : ""}
                ${sp.roll_number ? `<div class="portal-detail"><span>Student Roll No.</span><strong>${escapeHtml(sp.roll_number)}</strong></div>` : ""}
              </div>
              <div class="portal-actions" style="margin-bottom:20px;gap:8px;flex-wrap:wrap;" data-testid="manage-user-actions">
                ${isDeletedUser
                  ? `<button type="button" class="portal-button portal-button--small v31-btn-success" data-v31-restore-uid="${u.id}" data-u-name="${escAttr(u.full_name)}">Restore Account</button>`
                  : `
                    <button type="button" class="portal-button portal-button--small" data-user-act="approve" data-uid="${u.id}">Approve</button>
                    <button type="button" class="portal-button portal-button--small v31-btn-success" data-user-act="reactivate" data-uid="${u.id}">Activate / Reactivate</button>
                    <button type="button" class="portal-button portal-button--small v31-btn-warning" data-user-act="suspend" data-uid="${u.id}" data-u-name="${escAttr(u.full_name)}">Suspend</button>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-user-act="terminate" data-uid="${u.id}" data-u-name="${escAttr(u.full_name)}">Terminate</button>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-user-act="reject" data-uid="${u.id}" data-u-name="${escAttr(u.full_name)}">Reject</button>
                  `}
                ${["student", "teacher", "parent", "staff"].includes(u.role) && !isDeletedUser ? `<button type="button" class="portal-button portal-button--small" data-impersonate-uid="${u.id}">Impersonate Panel</button>` : ""}
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-u-compose-mail="${u.id}" data-u-email="${escAttr(u.email)}" data-u-name="${escAttr(u.full_name)}">Mail</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-u-quick-mail="${u.id}">One-Click Mail</button>
                ${waHref ? `<a href="${escAttr(waHref)}" target="_blank" rel="noopener noreferrer" class="portal-button portal-button--small portal-button--quiet">WhatsApp</a>` : ""}
                ${u.role === "student" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-u-quick-invoice="${u.id}">One-Click Invoice</button>` : ""}
                ${!isSuperAdminAcc && u.id !== session.user.id && !isDeletedUser ? `<button type="button" class="portal-button portal-button--small portal-button--danger" data-u-delete="${u.id}" data-u-name="${escAttr(u.full_name)}" data-u-role="${escAttr(u.role)}">Soft Delete</button>` : ""}
              </div>
              ${u.role === "student" ? `<div data-v31-student-manage="${u.id}" style="margin-bottom:20px;"></div>` : ""}
              ${u.role === "teacher" ? `<div data-v31-teacher-manage="${u.id}" style="margin-bottom:20px;"></div>` : ""}
              ${
                u.role === "staff"
                  ? `<form class="portal-form" data-staff-perm-form="${u.id}" style="margin-bottom:20px;padding:14px;border:1px solid var(--pt-border);border-radius:12px;">
                      <h3 class="portal-section-title">Staff Role &amp; Module Permissions</h3>
                      <div class="portal-form-grid">
                        <div class="portal-field"><label>Staff Designation</label><select name="staffRole">${["coordinator", "counselor", "accountant", "librarian", "receptionist", "manager"].map((sr) => `<option value="${sr}"${u.staff_role === sr ? " selected" : ""}>${sr}</option>`).join("")}</select></div>
                        <div class="portal-field"><label>Assigned Branch</label><select name="branchId"><option value="">All Branches</option>${branchesList.map((br) => `<option value="${br.id}"${Number(u.branch_id) === Number(br.id) ? " selected" : ""}>${escapeHtml(br.name)}</option>`).join("")}</select></div>
                      </div>
                      <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
                        ${ALL_STAFF_PERMS.map(([pk, pl]) => `<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;"><input type="checkbox" name="permissions" value="${pk}"${currentPerms.includes(pk) || currentPerms.includes("all") ? " checked" : ""}> ${escapeHtml(pl)}</label>`).join("")}
                      </div>
                      <button type="submit" class="portal-button portal-button--small">Save Staff Permissions</button>
                    </form>`
                  : ""
              }
              ${
                u.role === "teacher"
                  ? `<div class="portal-detail" style="margin-bottom:20px;padding:14px 16px;">
                      <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
                        <div>
                          <span>Teacher Resume / CV Status</span>
                          <div style="display:flex;align-items:center;gap:8px;margin-top:4px;">
                            ${statusBadge(tp.resume_status || "missing")}
                            <strong>${escapeHtml(tp.resume_filename || "No resume uploaded yet")}</strong>
                          </div>
                        </div>
                        ${tp.resume_url ? `<a href="${escAttr(adminApiUrl(`/users/${u.id}/resume`))}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${icon("download")} View / Download Resume</a>` : ""}
                      </div>
                      ${tp.resume_uploaded_at ? `<p class="portal-hint" style="margin-bottom:8px;">Uploaded: ${escapeHtml(tp.resume_uploaded_at)}${tp.resume_notes ? ` · Notes: ${escapeHtml(tp.resume_notes)}` : ""}</p>` : ""}
                      ${
                        tp.resume_url
                          ? `<div class="portal-actions">
                              <input type="text" placeholder="Optional review note" value="${escAttr(tp.resume_notes || "")}" data-resume-note-input style="min-height:34px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;flex:1 1 180px;min-width:0;max-width:100%;">
                              <button type="button" class="portal-button portal-button--small" data-resume-review="verified" data-uid="${u.id}">Verify Resume</button>
                              <button type="button" class="portal-button portal-button--small portal-button--danger" data-resume-review="rejected" data-uid="${u.id}">Request Re-upload</button>
                            </div>`
                          : `<p class="portal-hint" style="color:#b91c1c;">This teacher has not uploaded a valid resume yet and cannot be approved for dashboard access.</p>`
                      }
                    </div>`
                  : ""
              }
              <h3 class="portal-section-title">Edit Account &amp; Profile</h3>
              <form class="portal-form" data-edit-user-form="${u.id}" style="margin-bottom:20px;">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(u.full_name)}" required></div>
                  <div class="portal-field"><label>Email</label><input name="email" type="email" value="${escAttr(u.email)}" required></div>
                  <div class="portal-field"><label>Phone</label><input name="phone" value="${escAttr(u.phone)}" required></div>
                  ${
                    u.role === "student"
                      ? `<div class="portal-field"><label>Class / Level</label><input name="classLevel" value="${escAttr(sp.class_level || "")}"></div>
                         <div class="portal-field"><label>Board</label><input name="board" value="${escAttr(sp.board || "UP Board")}"></div>
                         <div class="portal-field"><label>Duration (months)</label><input name="courseDurationMonths" type="number" value="${Number(sp.course_duration_months || 12)}"></div>`
                      : u.role === "teacher"
                        ? `<div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                           <div class="portal-field"><label>Experience (years)</label><input name="experienceYears" type="number" value="${Number(tp.experience_years || 0)}"></div>`
                        : ""
                  }
                </div>
                <div><button type="submit" class="portal-button portal-button--small">Save Profile Changes</button></div>
              </form>
              <div class="portal-accordion" data-accordion="otp-summary">
                <div class="portal-accordion-head">
                  <h3>OTP Summary (${(selectedUserDetail.otpSummary || []).length})</h3>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-accordion-toggle data-testid="toggle-otp-summary">Show</button>
                </div>
                <div class="portal-accordion-body" hidden>
                  <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Purpose</th><th>Attempts</th><th>Consumed</th><th>Created</th></tr></thead><tbody>
                    ${(selectedUserDetail.otpSummary || []).map((o) => `<tr><td>${escapeHtml(o.purpose)}</td><td>${o.attempts}</td><td>${o.consumed_at ? "Yes" : "Pending"}</td><td>${new Date(Number(o.created_at) * 1000).toLocaleString()}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No OTP logs.</td></tr>`}
                  </tbody></table></div>
                </div>
              </div>
              <div class="portal-accordion" data-accordion="audit-history">
                <div class="portal-accordion-head">
                  <h3>Account Audit History (${(selectedUserDetail.history || []).length})</h3>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-accordion-toggle data-testid="toggle-account-audit">Show</button>
                </div>
                <div class="portal-accordion-body" hidden>
                  <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Action</th><th>Details</th><th>IP</th><th>Date</th></tr></thead><tbody>
                    ${(selectedUserDetail.history || []).map((h) => `<tr><td>${escapeHtml(h.action)}</td><td>${escapeHtml(h.details)}</td><td>${escapeHtml(h.ip_address)}</td><td>${escapeHtml(h.created_at)}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No audit history yet.</td></tr>`}
                  </tbody></table></div>
                </div>
              </div>
            </div>`;
        } else {
          const totalPages = Math.max(1, Math.ceil((usersRes.total || 0) / (usersRes.pageSize || 12)));
          const roleSubTabs =
            userFilterRole === "student"
              ? [["directory", "Student Directory"], ["exits", "Exits & Alumni"]]
              : userFilterRole === "teacher"
                ? [["directory", "Teacher Directory"], ["leaves", "Leaves & Substitutes"], ["ratings", "Ratings & Feedback"], ["exits", "Exits"]]
                : userFilterRole === "staff"
                  ? [["directory", "Staff Directory"], ["exits", "Exits & Rejoin"]]
                  : [];
          if (!roleSubTabs.some(([k]) => k === usersSubView)) {
            usersSubView = "directory";
          }
          bodyHtml += `
            <div class="portal-subtabs" role="tablist" aria-label="User role tabs" style="margin-bottom:10px;">
              ${[
                ["student", "Students"],
                ["teacher", "Teachers"],
                ["parent", "Parents"],
                ["staff", "Staff"],
                ["all", "All Users"],
              ]
                .map(
                  ([rk, rl]) =>
                    `<button type="button" class="portal-subtab ${userFilterRole === rk ? "is-active" : ""}" data-user-role-tab="${rk}" data-testid="users-tab-${rk}">${rl}</button>`
                )
                .join("")}
            </div>
            ${
              roleSubTabs.length
                ? `<div class="portal-subtabs" role="tablist" aria-label="Role sub-views" style="margin-bottom:12px;">
                    ${roleSubTabs
                      .map(
                        ([sk, sl]) =>
                          `<button type="button" class="portal-subtab ${usersSubView === sk ? "is-active" : ""}" data-users-subview="${sk}" data-testid="users-sub-${sk}">${escapeHtml(sl)}</button>`
                      )
                      .join("")}
                  </div>`
                : ""
            }`;

          if (usersSubView === "exits" && userFilterRole === "student") {
            bodyHtml += `<div data-yu-admin-crm="crm_student_exits"></div>`;
          } else if (["leaves", "ratings", "exits"].includes(usersSubView) && userFilterRole === "teacher") {
            if (usersSubView === "leaves") {
              const leaves = leavesRes.requests || [];
              bodyHtml += `
                <div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Teacher Leave Requests (${leaves.length})</h3>
                  <div class="portal-table-scroll"><table class="portal-table" data-yu-table="teacher_leave_requests">
                    <thead><tr><th>Teacher</th><th>Dates</th><th>Reason</th><th>Status</th><th>Review</th></tr></thead>
                    <tbody>
                      ${leaves.map((l) => `<tr><td><strong>${escapeHtml(l.teacher_name)}</strong><span class="portal-cell-sub">${escapeHtml(l.branch_name || "")}</span></td><td>${escapeHtml(l.from_date)} to ${escapeHtml(l.to_date)}</td><td>${escapeHtml(l.reason)}</td><td>${statusBadge(l.status)}</td><td>${l.status === "pending" ? `<div class="portal-actions"><input type="text" placeholder="Admin note" data-leave-note="${l.id}" style="min-height:32px;border:1px solid var(--pt-border);border-radius:8px;padding:0 8px;"><button type="button" class="portal-button portal-button--small" data-leave-review="${l.id}" data-st="approved">Approve</button><button type="button" class="portal-button portal-button--small portal-button--danger" data-leave-review="${l.id}" data-st="rejected">Reject</button></div>` : escapeHtml(l.admin_note || l.reviewed_at || "-")}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No teacher leave requests yet.</td></tr>`}
                    </tbody>
                  </table></div>
                </div>`;
            }
            bodyHtml += `<div data-yu-admin-crm="crm_teacher_ops"></div>`;
          } else if (usersSubView === "exits" && userFilterRole === "staff") {
            bodyHtml += `<div data-yu-admin-crm="crm_staff_exits"></div>`;
          } else {
            bodyHtml += `
              ${window.YuitorV31?.renderStatusTabs ? window.YuitorV31.renderStatusTabs(userStatusTab, usersRes.tabCounts || {}) : ""}
              <div class="portal-toolbar">
                <input type="search" data-admin-usearch value="${escAttr(userSearch)}" placeholder="Search name, email, phone...">
                <div class="portal-toolbar-actions">
                  <select data-admin-urole style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                    ${[["all", "All Roles"], ["student", "Students"], ["teacher", "Teachers"], ["parent", "Parents"], ["staff", "Staff"], ["admin", "Admins"], ["super_admin", "Super Admins"]].map(([k, l]) => `<option value="${k}"${userFilterRole === k ? " selected" : ""}>${l}</option>`).join("")}
                  </select>
                  <select data-admin-ustatus style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                    ${[["all", "All Statuses"], ["pending_approval", "Pending Approval"], ["pending_otp", "Pending OTP"], ["approved", "Approved"], ["suspended", "Suspended"], ["terminated", "Terminated"], ["rejected", "Rejected"], ["deleted", "Soft Deleted"]].map(([k, l]) => `<option value="${k}"${userFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                  </select>
                  <button type="button" class="portal-button portal-button--small" data-toggle-new-user>${showCreateUser ? "Close Form" : "+ Create User"}</button>
                </div>
              </div>
              ${
                showCreateUser
                  ? `<div class="portal-card portal-profile" style="margin-bottom:16px;" data-create-user-panel>
                      <h3 class="portal-section-title">Create Approved Account (Student / Parent / Teacher / Staff)</h3>
                      <form class="portal-form" data-admin-create-user>
                        <div class="portal-form-grid">
                          <div class="portal-field"><label>Role</label><select name="role" data-admin-create-role><option value="student">Student</option><option value="parent">Parent</option><option value="teacher">Teacher</option><option value="staff">Staff</option>${session.user.role === "super_admin" ? `<option value="admin">Admin</option>` : ""}</select></div>
                          <div class="portal-field"><label>Full Name *</label><input name="fullName" required></div>
                          <div class="portal-field"><label>Email *</label><input name="email" type="email" required></div>
                          <div class="portal-field"><label>Phone *</label><input name="phone" required></div>
                          <div class="portal-field"><label>Password (min 8 chars) *</label><input name="password" type="password" minlength="8" required></div>
                          <div class="portal-field"><label>Branch</label><select name="branchId"><option value="">Main / All Branches</option>${branchesList.map((br) => `<option value="${br.id}">${escapeHtml(br.name)}</option>`).join("")}</select></div>
                          <div class="portal-field" data-cu-only="student,teacher"><label>Class / Qualification</label><input name="extra" placeholder="Class 10 or M.Sc"></div>
                          <div class="portal-field" data-cu-only="student"><label>Parent WhatsApp / Phone</label><input name="parentPhone" placeholder="Parent mobile"></div>
                          <div class="portal-field" data-cu-only="parent"><label>Link Student</label><select name="studentId"><option value="">Select later</option>${studentsList.map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.roll_number || "#" + s.id)})</option>`).join("")}</select></div>
                          <div class="portal-field" data-cu-only="parent"><label>Relation</label><input name="relation" value="Parent / Guardian"></div>
                          <div class="portal-field" data-cu-only="staff"><label>Staff Role</label><select name="staffRole"><option value="coordinator">Coordinator</option><option value="counselor">Counselor</option><option value="accountant">Accountant</option><option value="librarian">Librarian</option><option value="receptionist">Receptionist</option></select></div>
                        </div>
                        <div class="portal-field" data-cu-only="staff">
                          <label>Staff Permissions</label>
                          <div style="display:flex;flex-wrap:wrap;gap:10px;">
                            ${ALL_STAFF_PERMS.map(([pk, pl]) => `<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;"><input type="checkbox" name="permissions" value="${pk}"> ${escapeHtml(pl)}</label>`).join("")}
                          </div>
                        </div>
                        <p class="portal-hint" style="margin-bottom:10px;">Note: Admin-created teachers without a resume on file will be prompted to upload their PDF/DOC/DOCX resume on first sign-in before entering the Teacher Dashboard.</p>
                        <button type="submit" class="portal-button portal-button--small">Create Approved User</button>
                      </form>
                    </div>`
                  : ""
              }
              <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table" data-yu-table="users_${escAttr(userFilterRole)}_${escAttr(userStatusTab)}" data-yu-server-paged="1" data-yu-bulk="users">
                <thead><tr><th>Name</th><th>Contact</th><th>Role</th><th>OTP</th><th>Resume / Roll</th><th>Status</th><th data-yu-locked="1" data-yu-no-sort="1">Manage</th></tr></thead>
                <tbody>
                  ${(usersRes.users || []).map((u) => {
                    return `<tr data-row-view-uid="${u.id}" data-uid="${u.id}" data-role="${escAttr(u.role || "")}" data-email="${escAttr(u.email || "")}" data-phone="${escAttr(u.phone || "")}" data-name="${escAttr(u.full_name || "")}">
                    <td><span class="portal-cell-title">${escapeHtml(u.full_name)}</span><span class="portal-cell-sub">${escapeHtml(u.class_level || u.qualification || u.staff_role || "")}</span></td>
                    <td>${escapeHtml(u.email)}<span class="portal-cell-sub">${escapeHtml(u.phone)}</span></td>
                    <td>${escapeHtml(u.role)}</td>
                    <td>${u.mobile_verified ? "Verified" : "Unverified"}</td>
                    <td>${u.role === "teacher" ? (u.has_resume ? `${statusBadge(u.resume_status || "submitted")} <span class="portal-cell-sub">${escapeHtml(u.resume_filename || "")}</span>` : statusBadge("missing")) : u.roll_number ? `<strong>${escapeHtml(u.roll_number)}</strong>` : `<span class="portal-hint">—</span>`}</td>
                    <td>${statusBadge(u.deleted_at ? "deleted" : u.verification_status)}</td>
                    <td data-no-row-click="1">
                      <div class="yu-manage-wrap">
                        <button type="button" class="yu-manage-btn" data-user-manage="${u.id}" data-testid="user-manage-${u.id}">Manage</button>
                      </div>
                    </td>
                  </tr>`;
                  }).join("") || `<tr><td colspan="7" class="portal-empty">No users match the filter.</td></tr>`}
                </tbody>
              </table></div>
              <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-top:1px solid var(--pt-border);font-size:12px;">
                <span>Showing page ${userPage} of ${totalPages} (${usersRes.total || 0} total)</span>
                <div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage - 1}" ${userPage <= 1 ? "disabled" : ""}>Prev</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-upage="${userPage + 1}" ${userPage >= totalPages ? "disabled" : ""}>Next</button>
                </div>
              </div></div>
              ${
                userFilterRole === "parent" || userFilterRole === "all"
                  ? `<div class="portal-card portal-profile">
                      <h3 class="portal-section-title">Parent–Student Linking (${parentsList.length} parents)</h3>
                      <form class="portal-form" data-parent-link-form style="margin-bottom:14px;">
                        <div class="portal-form-grid">
                          <div class="portal-field"><label>Parent Account *</label><select name="parentId" required><option value="">Select parent</option>${parentsList.map((p) => `<option value="${p.id}">${escapeHtml(p.full_name)} (${escapeHtml(p.phone)})</option>`).join("")}</select></div>
                          <div class="portal-field"><label>Student Account *</label><select name="studentId" required><option value="">Select student</option>${studentsList.map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.roll_number || "#" + s.id)})</option>`).join("")}</select></div>
                          <div class="portal-field"><label>Relation</label><input name="relation" value="Parent / Guardian"></div>
                        </div>
                        <button type="submit" class="portal-button portal-button--small">Link Parent to Student</button>
                      </form>
                      <div class="portal-table-scroll"><table class="portal-table" data-yu-table="parent_links"><thead><tr><th>Parent</th><th>Contact</th><th>Linked Children</th><th>Status</th></tr></thead><tbody>
                        ${parentsList.map((p) => `<tr><td>${escapeHtml(p.full_name)}</td><td>${escapeHtml(p.phone)} · ${escapeHtml(p.email)}</td><td>${escapeHtml(p.linked_children || "None linked yet")}</td><td>${statusBadge(p.verification_status)}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No parent accounts yet.</td></tr>`}
                      </tbody></table></div>
                    </div>`
                  : ""
              }`;
          }
        }
      } else if (tab === "courses") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">${editingCourse ? `Edit Course: ${escapeHtml(editingCourse.title)}` : "Create Course"}</h3>
            <form class="portal-form" ${editingCourse ? `data-edit-course-form="${editingCourse.id}"` : "data-new-course-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Title *</label><input name="title" required value="${escAttr(editingCourse?.title || "")}"></div>
                <div class="portal-field"><label>Category</label><select name="category">${["Classes 6-12", "Competitive", "Computer", "AI Learning", "English Speaking"].map((cat) => `<option${editingCourse?.category === cat ? " selected" : ""}>${cat}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Class / Level</label><input name="classRange" value="${escAttr(editingCourse?.class_range || "Classes 9–10")}"></div>
                <div class="portal-field"><label>Board / Track</label><input name="board" value="${escAttr(editingCourse?.board || "UP Board / ICSE")}"></div>
                <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="60" value="${editingCourse?.duration_months ?? 12}"></div>
                <div class="portal-field"><label>Monthly Fee (₹)</label><input name="monthlyFee" type="number" value="${editingCourse?.monthly_fee ?? 1400}" required></div>
                <div class="portal-field"><label>Yearly Fee (₹)</label><input name="yearlyFee" type="number" value="${editingCourse?.yearly_fee ?? 14300}" required></div>
                <div class="portal-field"><label>Assign Teacher</label><select name="teacherId"><option value="">Unassigned</option>${teachersList.map((t) => `<option value="${t.id}"${Number(editingCourse?.teacher_id) === Number(t.id) ? " selected" : ""}>${escapeHtml(t.full_name)}</option>`).join("")}</select></div>
              </div>
              <div class="portal-field"><label>Description</label><textarea name="description" rows="2">${escapeHtml(editingCourse?.description || "")}</textarea></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editingCourse ? "Update Course" : "Create Course"}</button>
                ${editingCourse ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-course>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Course</th><th>Category</th><th>Teacher</th><th>Monthly / Yearly</th><th>Students</th><th>Actions</th></tr></thead>
            <tbody>
              ${coursesList.map((c) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(c.title)}</span><span class="portal-cell-sub">${escapeHtml(c.class_range)}</span></td>
                <td>${escapeHtml(c.category)}</td>
                <td>${escapeHtml(c.teacher_name || "Unassigned")}</td>
                <td>${formatINR(c.monthly_fee)} / ${formatINR(c.yearly_fee)}</td>
                <td>${c.active_students}</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-course="${c.id}">Edit</button>
                  <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-course="${c.id}">Delete</button>
                </div></td>
              </tr>`).join("")}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Manage Subjects (${(coursesRes.subjects || []).length})</h3>
            <form class="portal-form" data-new-subject-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Subject Name *</label><input name="name" required placeholder="e.g. Organic Chemistry"></div>
                <div class="portal-field"><label>Subject Code *</label><input name="code" required placeholder="CHEM-12"></div>
                <div class="portal-field"><label>Class Level</label><input name="classLevel" value="Classes 11–12"></div>
                <div class="portal-field"><label>Description</label><input name="description" placeholder="Short syllabus overview"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Subject</button></div>
            </form>
            <div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Subject</th><th>Code</th><th>Class</th><th>Action</th></tr></thead><tbody>
              ${(coursesRes.subjects || []).map((s) => `<tr><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.code)}</td><td>${escapeHtml(s.class_level)}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-subject="${s.id}">Delete</button></td></tr>`).join("")}
            </tbody></table></div>
          </div>`;
      } else if (tab === "academics") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Multi-Branch Centers (${branchesList.length})</h3>
            <form class="portal-form" data-branch-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Branch Name *</label><input name="name" required placeholder="e.g. Yuitor Main Campus"></div>
                <div class="portal-field"><label>Branch Code *</label><input name="code" required placeholder="MRD-01"></div>
                <div class="portal-field"><label>City</label><input name="city" value="Muradnagar"></div>
                <div class="portal-field"><label>Phone</label><input name="phone" value="+91 78-2728-9292"></div>
                <div class="portal-field"><label>Timing Note</label><input name="timingNote" value="Mon–Sat · 7:00 AM – 8:00 PM"></div>
                <div class="portal-field"><label>Google Map URL</label><input name="mapUrl" placeholder="https://maps.google.com/..."></div>
              </div>
              <div class="portal-field"><label>Address</label><input name="address" placeholder="Full branch street address"></div>
              <button type="submit" class="portal-button portal-button--small">Add Branch</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Branch</th><th>Code</th><th>City &amp; Address</th><th>Batches / Students</th><th>Action</th></tr></thead>
              <tbody>
                ${branchesList.map((br) => `<tr><td><strong>${escapeHtml(br.name)}</strong><span class="portal-cell-sub">${escapeHtml(br.timing_note || "")}</span></td><td>${escapeHtml(br.code)}</td><td>${escapeHtml(br.city)} · ${escapeHtml(br.address || "-")}</td><td>${br.batch_count || 0} batches · ${br.student_count || 0} students</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-branch="${br.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No branches added yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Batches, Classrooms &amp; Seat Capacity (${batchesList.length})</h3>
            <form class="portal-form" data-batch-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course *</label><select name="courseId" required>${coursesList.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Branch</label><select name="branchId"><option value="">Default Branch</option>${branchesList.map((br) => `<option value="${br.id}">${escapeHtml(br.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Teacher</label><select name="teacherId"><option value="">Unassigned</option>${teachersList.map((t) => `<option value="${t.id}">${escapeHtml(t.full_name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch Name *</label><input name="name" required placeholder="e.g. Evening Sankalp Batch A"></div>
                <div class="portal-field"><label>Batch Code</label><input name="code" placeholder="BAT-10A"></div>
                <div class="portal-field"><label>Classroom / Room</label><input name="roomName" value="Room 101"></div>
                <div class="portal-field"><label>Seat Limit</label><input name="seatLimit" type="number" min="1" max="500" value="40"></div>
                <div class="portal-field"><label>Days</label><input name="scheduleDays" value="Mon–Sat"></div>
                <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00"></div>
                <div class="portal-field"><label>End Time</label><input name="endTime" value="17:30"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Create Batch</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Batch</th><th>Course / Branch</th><th>Room &amp; Timing</th><th>Teacher</th><th>Seats (Used / Limit)</th><th>Action</th></tr></thead>
              <tbody>
                ${batchesList.map((b) => `<tr><td><strong>${escapeHtml(b.name)}</strong><span class="portal-cell-sub">${escapeHtml(b.code)}</span></td><td>${escapeHtml(b.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(b.branch_name || "Main")}</span></td><td>${escapeHtml(b.room_name)} · ${escapeHtml(b.schedule_days)} ${escapeHtml(b.start_time)}-${escapeHtml(b.end_time)}</td><td>${escapeHtml(b.teacher_name || "Unassigned")}</td><td><strong>${b.seats_used} / ${b.seat_limit}</strong> (${b.seats_remaining} left)</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-batch="${b.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No batches created yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Master Weekly Timetable (${slotsList.length} slots)</h3>
            <form class="portal-form" data-timetable-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Day</label><select name="dayOfWeek">${["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((d) => `<option>${d}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00"></div>
                <div class="portal-field"><label>End Time</label><input name="endTime" value="17:00"></div>
                <div class="portal-field"><label>Subject *</label><input name="subjectName" required placeholder="e.g. Physics"></div>
                <div class="portal-field"><label>Course</label><select name="courseId"><option value="">Any</option>${coursesList.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch</label><select name="batchId"><option value="">All Batches</option>${batchesList.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Teacher</label><select name="teacherId"><option value="">Unassigned</option>${teachersList.map((t) => `<option value="${t.id}">${escapeHtml(t.full_name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Room</label><input name="roomName" value="Room 101"></div>
                <div class="portal-field"><label>Mode</label><select name="mode"><option value="offline">Offline Classroom</option><option value="online">Online Live</option></select></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Add Timetable Slot</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Day &amp; Time</th><th>Subject</th><th>Course / Batch</th><th>Teacher</th><th>Room / Mode</th><th>Action</th></tr></thead>
              <tbody>
                ${slotsList.map((s) => `<tr><td><strong>${escapeHtml(s.day_of_week)}</strong><span class="portal-cell-sub">${escapeHtml(s.start_time)} – ${escapeHtml(s.end_time)}</span></td><td>${escapeHtml(s.subject_name)}</td><td>${escapeHtml(s.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(s.batch_name || "All")}</span></td><td>${escapeHtml(s.teacher_name || "-")}</td><td>${escapeHtml(s.room_name)} (${escapeHtml(s.mode)})</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-slot="${s.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No timetable slots configured.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "tests") {
        const testsList = testsRes.tests || [];
        const attSum = attRepRes.summary || [];
        const csvUrl = adminApiUrl(`/reports/attendance?courseId=${encodeURIComponent(attFilterCourse)}&from=${encodeURIComponent(attFilterFrom)}&to=${encodeURIComponent(attFilterTo)}&format=csv`);
        bodyHtml += `
          ${
            selectedOfflineTest
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <div class="portal-profile-head">
                    <div><h3>Marks &amp; Automatic Rank Sheet: ${escapeHtml(selectedOfflineTest.test.title)}</h3><p>Max Marks: ${selectedOfflineTest.test.max_marks} · Passing: ${selectedOfflineTest.test.passing_marks} · ${escapeHtml(selectedOfflineTest.test.course_title || "")}</p></div>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-close-test-marks>Close Sheet</button>
                  </div>
                  <form class="portal-form" data-save-test-marks-form="${selectedOfflineTest.test.id}">
                    <div class="portal-table-scroll" style="margin-bottom:12px;"><table class="portal-table" data-yu-no-paginate="1" data-yu-no-bulk="1">
                      <thead><tr><th>Rank</th><th>Student (Roll No)</th><th>Marks Obtained</th><th>Absent?</th><th>Remarks</th></tr></thead>
                      <tbody>
                        ${(selectedOfflineTest.students || []).map((st) => `<tr data-mark-row="${st.student_id}">
                          <td>${st.rank_position ? `<strong>#${st.rank_position}</strong>` : "—"}</td>
                          <td>${escapeHtml(st.full_name)} <span class="portal-cell-sub">${escapeHtml(st.roll_number || "")}</span></td>
                          <td><input name="marks" type="number" step="0.5" min="0" max="${Number(selectedOfflineTest.test.max_marks || 100)}" value="${escAttr(st.marks_obtained ?? 0)}" style="width:90px;"></td>
                          <td><input name="absent" type="checkbox"${st.is_absent ? " checked" : ""}></td>
                          <td><input name="remarks" value="${escAttr(st.remarks || "")}" placeholder="Remarks"></td>
                        </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No enrolled students in this course/batch.</td></tr>`}
                      </tbody>
                    </table></div>
                    <button type="submit" class="portal-button portal-button--small">Save Marks &amp; Recalculate Ranks</button>
                  </form>
                </div>`
              : ""
          }
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Offline Tests &amp; Rank Lists (${testsList.length})</h3>
            <form class="portal-form" data-offline-test-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course *</label><select name="courseId" required>${coursesList.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch (Optional)</label><select name="batchId"><option value="">All Batches</option>${batchesList.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Test Title *</label><input name="title" required placeholder="e.g. Monthly Unit Test 1"></div>
                <div class="portal-field"><label>Subject</label><input name="subjectName" value="All Subjects"></div>
                <div class="portal-field"><label>Test Date</label><input name="testDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
                <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="100"></div>
                <div class="portal-field"><label>Passing Marks</label><input name="passingMarks" type="number" value="33"></div>
                <div class="portal-field"><label>Exam Room</label><input name="roomName" value="Exam Hall 1"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Schedule Offline Test</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Test</th><th>Course / Batch</th><th>Date &amp; Room</th><th>Marks Graded</th><th>Class Avg</th><th>Action</th></tr></thead>
              <tbody>
                ${testsList.map((t) => `<tr><td><strong>${escapeHtml(t.title)}</strong><span class="portal-cell-sub">${escapeHtml(t.subject_name)} · Max ${t.max_marks}</span></td><td>${escapeHtml(t.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(t.batch_name || "All Batches")}</span></td><td>${escapeHtml(t.test_date)} · ${escapeHtml(t.room_name || "")}</td><td>${t.marks_entered || 0}</td><td>${t.avg_marks ?? "—"}</td><td><button type="button" class="portal-button portal-button--small" data-open-test-marks="${t.id}">Marks &amp; Ranks</button></td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No offline tests created yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <h3 class="portal-section-title" style="margin:0;">Student Attendance Reports</h3>
              <a href="${escAttr(csvUrl)}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Attendance CSV</a>
            </div>
            <form class="portal-form" data-att-filter-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId"><option value="">All Courses</option>${coursesList.map((c) => `<option value="${c.id}"${String(attFilterCourse) === String(c.id) ? " selected" : ""}>${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>From Date</label><input name="from" type="date" value="${escAttr(attFilterFrom)}"></div>
                <div class="portal-field"><label>To Date</label><input name="to" type="date" value="${escAttr(attFilterTo)}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Filter Report</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Student</th><th>Roll No</th><th>Course</th><th>Present / Late / Absent</th><th>Attendance %</th></tr></thead>
              <tbody>
                ${attSum.map((s) => `<tr><td>${escapeHtml(s.full_name)}</td><td>${escapeHtml(s.roll_number || "-")}</td><td>${escapeHtml(s.course_title)}</td><td>${s.present_days} P · ${s.late_days} L · ${s.absent_days} A (${s.total_days} total)</td><td><strong>${s.percentage}%</strong></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No attendance logs match the selected filters.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "online_hub") {
        bodyHtml += `<div data-yu-admin-crm="crm_hub"></div>`;
      } else if (tab === "payments") {
        const feeRecords = instRes.feeRecords || [];
        const installments = instRes.installments || [];
        if (paymentsSubView === "fee_desk") {
          bodyHtml += `
            <div class="portal-subtabs" style="margin-bottom:12px;">
              <button type="button" class="portal-subtab is-active" data-pay-subview="fee_desk">Quick Fee Desk</button>
              <button type="button" class="portal-subtab" data-pay-subview="all">Fee Plans, EMI, Coupons &amp; History</button>
            </div>
            <div data-yu-admin-crm="crm_fee_desk"></div>`;
        } else {
        bodyHtml += `
          <div class="portal-subtabs" style="margin-bottom:12px;">
            <button type="button" class="portal-subtab" data-pay-subview="fee_desk">Quick Fee Desk</button>
            <button type="button" class="portal-subtab is-active" data-pay-subview="all">Fee Plans, EMI, Coupons &amp; History</button>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">Class 6th – Class 12th Official Fee Plans &amp; Billing Cycles</h3>
                <p class="portal-hint">Supports 1 Month, 3 Months, 6 Months, 9 Months &amp; Yearly (10% OFF). Generate instant invoices for any student.</p>
              </div>
            </div>
            <div class="portal-table-scroll" style="margin-bottom:14px;">
              <table class="portal-table">
                <thead><tr><th>Class</th><th>Monthly (1M)</th><th>3 Months</th><th>6 Months</th><th>9 Months</th><th>Yearly (10% OFF)</th><th>Yearly Savings</th></tr></thead>
                <tbody>
                  ${V3_CLASS_FEE_PLANS.map((p) => `<tr><td><strong>${escapeHtml(p.label)}</strong></td><td>${formatINR(p.monthlyFee)}</td><td>${formatINR(p.monthlyFee * 3)}</td><td>${formatINR(p.monthlyFee * 6)}</td><td>${formatINR(p.monthlyFee * 9)}</td><td><strong>${formatINR(p.yearlyFee)}</strong></td><td><span class="portal-status portal-status--paid">Save ${formatINR(p.yearlySavings)}</span></td></tr>`).join("")}
                </tbody>
              </table>
            </div>
            <form class="portal-form" data-class-invoice-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Student *</label><select name="studentId" required><option value="">Select student</option>${studentsList.map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.class_level || "Class 10")})</option>`).join("")}</select></div>
                <div class="portal-field"><label>Class Plan *</label><select name="classNumber">${V3_CLASS_FEE_PLANS.map((p) => `<option value="${p.classNumber}">${escapeHtml(p.label)} (${formatINR(p.monthlyFee)}/mo · ${formatINR(p.yearlyFee)}/yr)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Billing Cycle *</label><select name="billingCycle">${V3_BILLING_CYCLES.map((c) => `<option value="${c.id}">${escapeHtml(c.label)}</option>`).join("")}</select></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Generate Class-Wise Invoice</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;">
              <h3 class="portal-section-title" style="margin:0;">Fee Installments / EMI Plans (${installments.length})</h3>
              <div class="portal-actions">
                <label style="font-size:12px;display:inline-flex;align-items:center;gap:4px;"><input type="checkbox" name="remSendSms"> SMS</label>
                <label style="font-size:12px;display:inline-flex;align-items:center;gap:4px;"><input type="checkbox" name="remSendWa" checked> WhatsApp</label>
                <button type="button" class="portal-button portal-button--small" data-send-fee-reminders>${icon("bell")} Send Fee Due Reminders</button>
              </div>
            </div>
            ${
              lastFeeReminderWaLinks.length
                ? `<div class="portal-message portal-message--success" style="margin-bottom:12px;">
                    <strong>Direct WhatsApp Reminder Links (${lastFeeReminderWaLinks.length}):</strong>
                    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">
                      ${lastFeeReminderWaLinks.slice(0, 12).map((w) => `<a href="${escAttr(safeHref(w.waLink, "#"))}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${escapeHtml(w.studentName)} (₹${w.dueAmount})</a>`).join("")}
                    </div>
                  </div>`
                : ""
            }
            <form class="portal-form" data-gen-inst-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Pending Fee Record *</label><select name="feeRecordId" required><option value="">Select fee record</option>${feeRecords.filter((fr) => Number(fr.total_amount || 0) - Number(fr.discount_amount || 0) - Number(fr.paid_amount || 0) > 0).map((fr) => `<option value="${fr.id}">${escapeHtml(fr.student_name)} — ${escapeHtml(fr.course_title)} (Due: ₹${Math.max(0, Number(fr.total_amount) - Number(fr.discount_amount || 0) - Number(fr.paid_amount || 0))})</option>`).join("")}</select></div>
                <div class="portal-field"><label>No. of Installments</label><input name="installmentsCount" type="number" min="1" max="12" value="3"></div>
                <div class="portal-field"><label>First Due Date</label><input name="firstDueDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Generate EMI Schedule</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Student (Roll)</th><th>Installment</th><th>Due Date</th><th>Amount / Paid</th><th>Status</th><th>Collect Fee</th></tr></thead>
              <tbody>
                ${installments.map((fi) => `<tr><td><strong>${escapeHtml(fi.student_name)}</strong><span class="portal-cell-sub">${escapeHtml(fi.roll_number || fi.student_phone || "")}</span></td><td>${escapeHtml(fi.title)}</td><td>${escapeHtml(fi.due_date)}</td><td>${formatINR(fi.amount)} (${formatINR(fi.paid_amount || 0)} paid)</td><td>${statusBadge(fi.status)}</td><td>${fi.status !== "paid" ? `<div class="portal-actions"><button type="button" class="portal-button portal-button--small" data-pay-inst="${fi.id}" data-method="cash">Cash Paid</button><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-inst="${fi.id}" data-method="upi">UPI Paid</button></div>` : `<span class="portal-hint">Settled</span>`}</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No installments generated yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Discount Coupons (${(paymentsRes.coupons || []).length})</h3>
            <form class="portal-form" data-coupon-form style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Code *</label><input name="code" required placeholder="YUITOR15"></div>
                <div class="portal-field"><label>Type</label><select name="discountType"><option value="percent">Percentage (%)</option><option value="flat">Flat (₹)</option></select></div>
                <div class="portal-field"><label>Value *</label><input name="discountValue" type="number" required value="10"></div>
                <div class="portal-field"><label>Max Uses</label><input name="maxUses" type="number" value="100"></div>
              </div>
              <div><button type="submit" class="portal-button portal-button--small">Add Coupon</button></div>
            </form>
            ${(paymentsRes.coupons || []).map((cp) => `<span class="portal-status" style="margin-right:6px;">${escapeHtml(cp.code)} (${cp.discount_type === "percent" ? cp.discount_value + "%" : formatINR(cp.discount_value)} · ${cp.used_count}/${cp.max_uses})</span>`).join("")}
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Amount</th><th>Method / Ref</th><th>Status</th><th>Receipt</th><th>Actions</th></tr></thead>
            <tbody>
                ${(paymentsRes.payments || []).map((p) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(p.student_name)}</span><span class="portal-cell-sub">${escapeHtml(p.student_phone)}</span></td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)} ${p.gateway_payment_id ? "· " + escapeHtml(p.gateway_payment_id) : ""}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td>${escapeHtml(p.receipt_number || "-")}</td>
                <td><div class="portal-actions">
                  ${p.verification_status === "pending_verification" ? `<button type="button" class="portal-button portal-button--small" data-pay-verify="${p.id}" data-dec="verify">Verify</button><button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-verify="${p.id}" data-dec="fail">Reject</button>` : ""}
                  ${p.verification_status === "verified" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-pay-refund="${p.id}">Refund</button>` : ""}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="7" class="portal-empty">No payments submitted yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
        }
      } else if (tab === "finance") {
        const fs = expensesRes.financeSummary || {};
        const payouts = payoutsRes.payouts || [];
        const payoutTeachers = payoutsRes.teachers || [];
        const expenses = expensesRes.expenses || [];
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${formatINR(fs.feeIncome || 0)}</strong><span>Fee Income</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(fs.salaryPaid || 0)}</strong><span>Salaries Paid</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(fs.opsExpenses || 0)}</strong><span>Operational Expenses</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(fs.netSurplus || 0)}</strong><span>Net Profit / Surplus</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Teacher Salary Payouts (${payouts.length})</h3>
            <form class="portal-form" data-payout-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Teacher *</label><select name="teacherId" required>${payoutTeachers.map((t) => `<option value="${t.id}">${escapeHtml(t.full_name)} (Rate: ${formatINR(t.monthly_payout_rate || 0)})</option>`).join("")}</select></div>
                <div class="portal-field"><label>Month (YYYY-MM)</label><input name="salaryMonth" value="${new Date().toISOString().slice(0, 7)}"></div>
                <div class="portal-field"><label>Base Salary (₹)</label><input name="baseAmount" type="number" value="18000" required></div>
                <div class="portal-field"><label>Bonus (₹)</label><input name="bonusAmount" type="number" value="0"></div>
                <div class="portal-field"><label>Deductions (₹)</label><input name="deductionAmount" type="number" value="0"></div>
                <div class="portal-field"><label>Method</label><select name="paymentMethod"><option value="upi">UPI</option><option value="bank">Bank Transfer</option><option value="cash">Cash</option></select></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Create Salary Payout</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Teacher</th><th>Month</th><th>Net Payout</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${payouts.map((p) => `<tr><td>${escapeHtml(p.teacher_name)}</td><td>${escapeHtml(p.salary_month)}</td><td><strong>${formatINR(p.net_amount)}</strong><span class="portal-cell-sub">Base ${formatINR(p.base_amount)} + ${formatINR(p.bonus_amount)}</span></td><td>${statusBadge(p.status)}</td><td>${p.status !== "paid" ? `<button type="button" class="portal-button portal-button--small" data-payout-paid="${p.id}">Mark Paid</button>` : escapeHtml(p.reference_no || "Paid")}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No salary payouts logged yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Center Operational Expenses (${expenses.length})</h3>
            <form class="portal-form" data-expense-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Expense Title *</label><input name="title" required placeholder="e.g. Classroom Rent"></div>
                <div class="portal-field"><label>Category</label><select name="category"><option>Rent</option><option>Electricity &amp; WiFi</option><option>Printing &amp; Notes</option><option>Marketing</option><option>Operations</option></select></div>
                <div class="portal-field"><label>Amount (₹) *</label><input name="amount" type="number" required></div>
                <div class="portal-field"><label>Date</label><input name="expenseDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
                <div class="portal-field"><label>Branch</label><select name="branchId"><option value="">All Branches</option>${branchesList.map((br) => `<option value="${br.id}">${escapeHtml(br.name)}</option>`).join("")}</select></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Log Expense</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Title</th><th>Category</th><th>Date</th><th>Amount</th><th>Action</th></tr></thead>
              <tbody>
                ${expenses.map((ex) => `<tr><td>${escapeHtml(ex.title)}</td><td>${escapeHtml(ex.category)}</td><td>${escapeHtml(ex.expense_date)}</td><td><strong>${formatINR(ex.amount)}</strong></td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-expense="${ex.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No expenses logged yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "library") {
        const books = libraryRes.books || [];
        const issues = libraryRes.issues || [];
        bodyHtml += `
          <div class="portal-form-grid" style="margin-bottom:16px;">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Add Study Material / Library Book</h3>
              <form class="portal-form" data-lib-book-form>
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Book / Module Title *</label><input name="title" required placeholder="e.g. Class 12 Physics Booklet"></div>
                  <div class="portal-field"><label>Code</label><input name="code" placeholder="PHY-12-MOD"></div>
                  <div class="portal-field"><label>Category</label><input name="category" value="Study Module"></div>
                  <div class="portal-field"><label>Total Copies</label><input name="totalCopies" type="number" min="1" value="25"></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Add to Inventory</button>
              </form>
            </div>
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Issue Material to Student</h3>
              <form class="portal-form" data-lib-issue-form>
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Book / Module *</label><select name="bookId" required>${books.map((bk) => `<option value="${bk.id}">${escapeHtml(bk.title)} (${bk.available_copies}/${bk.total_copies} avail)</option>`).join("")}</select></div>
                  <div class="portal-field"><label>Student *</label><select name="studentId" required>${studentsList.map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.roll_number || "#" + s.id)})</option>`).join("")}</select></div>
                  <div class="portal-field"><label>Due Return Date</label><input name="dueReturnDate" type="date" value="${new Date(Date.now() + 14 * 86400 * 1000).toISOString().slice(0, 10)}"></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Issue Book</button>
              </form>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Inventory (${books.length})</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Title</th><th>Code</th><th>Category</th><th>Available / Total</th></tr></thead>
            <tbody>${books.map((b) => `<tr><td>${escapeHtml(b.title)}</td><td>${escapeHtml(b.code)}</td><td>${escapeHtml(b.category)}</td><td><strong>${b.available_copies} / ${b.total_copies}</strong></td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No books added yet.</td></tr>`}</tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Issue / Return Register (${issues.length})</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Material</th><th>Issued / Due</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>${issues.map((i) => `<tr><td>${escapeHtml(i.student_name)} <span class="portal-cell-sub">${escapeHtml(i.roll_number || "")}</span></td><td>${escapeHtml(i.book_title)}</td><td>${escapeHtml(String(i.issued_at || "").slice(0, 10))} · Due ${escapeHtml(i.due_return_date || "-")}</td><td>${statusBadge(i.status)}</td><td>${i.status === "issued" ? `<button type="button" class="portal-button portal-button--small" data-lib-return="${i.id}">Mark Returned</button>` : escapeHtml(String(i.returned_at || "").slice(0, 10))}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No books issued yet.</td></tr>`}</tbody>
          </table></div></div>`;
      } else if (tab === "reports") {
        const bp = reportsRes.batchPerformance || [];
        const mc = reportsRes.monthlyCollection || [];
        const dr = reportsRes.dropouts || [];
        bodyHtml += `
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Batch Performance &amp; Seat Utilization</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Batch</th><th>Course / Branch</th><th>Seats</th><th>Avg Attendance</th><th>Avg Test Score</th></tr></thead>
            <tbody>${bp.map((b) => `<tr><td><strong>${escapeHtml(b.name)}</strong></td><td>${escapeHtml(b.course_title || "-")} (${escapeHtml(b.branch_name || "Main")})</td><td>${b.enrolled_count || 0} / ${b.seat_limit}</td><td>${b.attendance_pct != null ? b.attendance_pct + "%" : "—"}</td><td>${b.test_avg_pct != null ? b.test_avg_pct + "%" : "—"}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No batch metrics yet.</td></tr>`}</tbody>
          </table></div></div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Monthly Fee Collection Summary</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Month</th><th>Verified Receipts</th><th>Total Collected</th></tr></thead>
            <tbody>${mc.map((m) => `<tr><td><strong>${escapeHtml(m.month)}</strong></td><td>${m.receipt_count}</td><td><strong>${formatINR(m.total_collected)}</strong></td></tr>`).join("") || `<tr><td colspan="3" class="portal-empty">No fee receipts recorded yet.</td></tr>`}</tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Dropouts / Expired / Suspended Enrollments (${dr.length})</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course / Batch</th><th>Contact</th><th>Status / Expiry</th></tr></thead>
            <tbody>${dr.map((d) => `<tr><td>${escapeHtml(d.full_name)}</td><td>${escapeHtml(d.course_title)} (${escapeHtml(d.batch_name || "-")})</td><td>${escapeHtml(d.phone)}</td><td>${statusBadge(d.status)} · ${escapeHtml(d.expires_at || "-")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">Zero dropouts / expired enrollments!</td></tr>`}</tbody>
          </table></div></div>`;
      } else if (tab === "alerts") {
        const alertLogs = alertsRes.logs || [];
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Bulk SMS, WhatsApp &amp; Parent/Student Alert Dispatcher</h3>
            <form class="portal-form" data-bulk-alert-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Channel</label><select name="channel"><option value="whatsapp">WhatsApp (API / Direct Link)</option><option value="sms">SMS (Fast2SMS)</option><option value="in_app">In-App Notification Only</option></select></div>
                <div class="portal-field"><label>Target Audience</label><select name="audience"><option value="all_students">All Approved Students</option><option value="all_parents">All Parents</option><option value="fee_due">Students/Parents With Pending Fees</option><option value="batch">Specific Batch</option><option value="course">Specific Course</option></select></div>
                <div class="portal-field"><label>Batch (if Batch selected)</label><select name="batchId"><option value="">Optional Batch</option>${batchesList.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Course (if Course selected)</label><select name="courseId"><option value="">Optional Course</option>${coursesList.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
              </div>
              <div class="portal-field"><label>Alert Message *</label><textarea name="message" rows="3" required placeholder="e.g. Tomorrow's Science test is scheduled at 4:00 PM in Exam Hall 1."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">${icon("megaphone")} Dispatch Bulk Alert</button>
            </form>
            ${
              lastAlertWaLinks.length
                ? `<div class="portal-message portal-message--success" style="margin-top:12px;"><strong>WhatsApp Dispatch Links (${lastAlertWaLinks.length}):</strong><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">${lastAlertWaLinks.slice(0, 15).map((w) => `<a href="${escAttr(safeHref(w.waLink, "#"))}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${escapeHtml(w.name)} (${escapeHtml(w.phone)})</a>`).join("")}</div></div>`
                : ""
            }
          </div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Alert Dispatch Logs (${alertLogs.length})</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Recipient</th><th>Channel</th><th>Message</th><th>Status</th><th>Time</th></tr></thead>
            <tbody>${alertLogs.map((l) => `<tr><td>${escapeHtml(l.recipient_name)} <span class="portal-cell-sub">${escapeHtml(l.recipient_contact)}</span></td><td>${escapeHtml(l.channel)}</td><td><span class="portal-cell-message">${escapeHtml(l.message)}</span></td><td>${statusBadge(l.status)}</td><td>${escapeHtml(l.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No bulk alerts sent yet.</td></tr>`}</tbody>
          </table></div></div>`;
      } else if (tab === "cms") {
        const toppersList = toppersRes.toppers || [];
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Website Toppers &amp; Results Showcase (${toppersList.length})</h3>
            <form class="portal-form" data-topper-form style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Student Name *</label><input name="studentName" required></div>
                <div class="portal-field"><label>Exam / Board *</label><input name="examName" required placeholder="UP Board Class 12 / JEE"></div>
                <div class="portal-field"><label>Rank Label</label><input name="rankLabel" value="District Topper"></div>
                <div class="portal-field"><label>Score / Percentile</label><input name="scoreLabel" value="98.4%"></div>
                <div class="portal-field"><label>Batch Label</label><input name="batchLabel" value="Sankalp Batch"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Add Topper Card</button>
            </form>
            <div style="display:grid;gap:6px;">
              ${toppersList.map((tp) => `<div class="portal-detail" style="display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(tp.student_name)} · ${escapeHtml(tp.score_label)}</strong><span>${escapeHtml(tp.exam_name)} · ${escapeHtml(tp.rank_label)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-topper="${tp.id}">Delete</button></div>`).join("")}
            </div>
          </div>

          <div class="portal-form-grid" style="margin-bottom:16px;">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Publish Notice / Announcement</h3>
              <form class="portal-form" data-ann-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Audience</label><select name="audience"><option value="all">All Users</option><option value="students">Students</option><option value="parents">Parents</option><option value="teachers">Teachers</option><option value="public">Public</option></select></div>
                <div class="portal-field"><label>Message</label><textarea name="body" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Publish Notice</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.announcements || []).map((a) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)}</strong><span>${escapeHtml(a.audience)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-ann="${a.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Homepage / Promo Banners</h3>
              <form class="portal-form" data-banner-form>
                <div class="portal-field"><label>Headline</label><input name="title" required></div>
                <div class="portal-field"><label>Subtitle</label><input name="subtitle"></div>
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Button Label</label><input name="ctaLabel" value="Apply for Admission"></div>
                  <div class="portal-field"><label>Link</label><input name="ctaHref" value="/admission"></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">Add Banner</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.banners || []).map((b) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(b.title)}</strong><span>${escapeHtml(b.cta_href)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-banner="${b.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>

          <div class="portal-form-grid">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Blog Posts (${(cmsRes.blogPosts || []).length})</h3>
              <form class="portal-form" data-blog-form>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Category</label><input name="category" value="Study Tips"></div>
                <div class="portal-field"><label>Excerpt</label><input name="excerpt"></div>
                <div class="portal-field"><label>Article Content</label><textarea name="content" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Publish Article</button>
              </form>
              <div style="margin-top:12px;">
                ${(cmsRes.blogPosts || []).map((p) => `<div class="portal-detail" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(p.title)}</strong><span>${escapeHtml(p.category)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-blog="${p.id}">Delete</button></div>`).join("")}
              </div>
            </div>

            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">FAQs &amp; Testimonials</h3>
              <form class="portal-form" data-faq-form style="margin-bottom:14px;">
                <div class="portal-field"><label>FAQ Question</label><input name="question" required></div>
                <div class="portal-field"><label>Answer</label><textarea name="answer" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add FAQ</button>
              </form>
              ${(cmsRes.faqs || []).map((f) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(f.question)}</strong></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-faq="${f.id}">Delete</button></div>`).join("")}
              <form class="portal-form" data-test-form style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Author Name</label><input name="authorName" required></div>
                  <div class="portal-field"><label>Role / Batch</label><input name="authorRole" required placeholder="Class 12 Student"></div>
                </div>
                <div class="portal-field"><label>Outcome Metric</label><input name="outcomeMetric" placeholder="95% in Boards"></div>
                <div class="portal-field"><label>Quote</label><textarea name="quote" required></textarea></div>
                <button type="submit" class="portal-button portal-button--small">Add Testimonial</button>
              </form>
              <div style="margin-top:10px;">
                ${(cmsRes.testimonials || []).map((t) => `<div class="portal-detail" style="margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(t.author_name)}</strong><span>${escapeHtml(t.outcome_metric)}</span></div><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-test="${t.id}">Delete</button></div>`).join("")}
              </div>
            </div>
          </div>`;
      } else if (tab === "chatbot") {
        if (selectedChatDetail) {
          bodyHtml += `
            <div class="portal-card portal-profile">
              <div class="portal-profile-head">
                <div><h2>Shreya Transcript</h2><p>${escapeHtml(selectedChatDetail.conversation.visitor_name || "Visitor")} · ${statusBadge(selectedChatDetail.conversation.status)}</p></div>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-back>← All Conversations</button>
              </div>
              <div style="display:grid;gap:10px;margin-bottom:16px;">
                ${(selectedChatDetail.messages || []).map((m) => `<div class="portal-detail"><span>${escapeHtml(m.sender)} · ${escapeHtml(m.created_at)}</span><strong style="font-weight:500;">${escapeHtml(m.message)}</strong></div>`).join("")}
              </div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--small" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="resolved">Mark Resolved</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-chat-status="${escAttr(selectedChatDetail.conversation.id)}" data-st="escalated">Escalate to Team</button>
              </div>
            </div>`;
        } else {
          bodyHtml += `
            <div class="portal-toolbar">
              <input type="search" data-chat-search value="${escAttr(chatSearch)}" placeholder="Search transcripts, visitor name/phone...">
              <div class="portal-toolbar-actions">
                <select data-chat-status-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  ${[["all", "All Statuses"], ["active", "Active"], ["unresolved", "Unresolved"], ["escalated", "Escalated"], ["resolved", "Resolved"]].map(([k, l]) => `<option value="${k}"${chatFilterStatus === k ? " selected" : ""}>${l}</option>`).join("")}
                </select>
                <select data-chat-rating-filter style="min-height:38px;border:1px solid var(--pt-border);border-radius:10px;padding:0 10px;background:var(--pt-surface);color:var(--pt-text);">
                  <option value="0"${chatMinRating === 0 ? " selected" : ""}>Any Rating</option>
                  ${[1, 2, 3, 4, 5].map((r) => `<option value="${r}"${chatMinRating === r ? " selected" : ""}>${r}+ Stars</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Visitor</th><th>Last Message</th><th>Status</th><th>Rating</th><th>View</th></tr></thead>
              <tbody>
                ${(chatsRes.conversations || []).map((c) => `<tr>
                  <td><span class="portal-cell-title">${escapeHtml(c.visitor_name || "Anonymous Visitor")}</span><span class="portal-cell-sub">${escapeHtml(c.visitor_phone || c.visitor_email || c.visitor_id)}</span></td>
                  <td><span class="portal-cell-message">${escapeHtml(c.last_message || "")}</span></td>
                  <td>${statusBadge(c.status)}</td>
                  <td>${c.rating ? `${c.rating}/5` : "-"}</td>
                  <td><button type="button" class="portal-button portal-button--small portal-button--quiet" data-open-chat="${escAttr(c.id)}">Transcript</button></td>
                </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No Shreya chatbot conversations match.</td></tr>`}
              </tbody>
            </table></div></div>
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Shreya AI Knowledge Base Documents (PDF / TXT / MD)</h3>
              <p class="portal-hint" style="margin-bottom:12px;">Upload course brochures, fee sheets, syllabus PDFs, or FAQ notes. Shreya automatically indexes extracted text to ground Gemini &amp; fallback responses.</p>
              <form class="portal-form" data-knowledge-upload-form style="margin-bottom:14px;">
                <div class="portal-form-grid">
                  <div class="portal-field"><label>Document Title *</label><input name="title" required placeholder="e.g. Class 10 Board Syllabus 2026"></div>
                  <div class="portal-field"><label>Document File (.pdf, .txt, .md · max 5 MB) *</label><input name="document" type="file" accept=".pdf,.txt,.md,application/pdf,text/plain,text/markdown" required></div>
                </div>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload &amp; Index Document</button>
              </form>
              <div class="portal-table-scroll"><table class="portal-table">
                <thead><tr><th>Document Title</th><th>Filename</th><th>Indexed Text</th><th>Uploaded</th><th>Action</th></tr></thead>
                <tbody>
                  ${(knowledgeRes.docs || []).map((d) => `<tr><td><strong>${escapeHtml(d.title)}</strong></td><td>${escapeHtml(d.filename)}</td><td>${Number(d.char_count || 0).toLocaleString("en-IN")} chars</td><td>${escapeHtml(d.created_at)}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-del-kdoc="${d.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No knowledge documents indexed yet.</td></tr>`}
                </tbody>
              </table></div>
            </div>`;
        }
      } else if (tab === "marketing") {
        const mktSum = mktRes.summary || { totalCampaigns: 0, totalEligible: 0, totalSent: 0, totalFailed: 0 };
        const recipientsList = [...(mktRes.students || []).map((u) => ({ ...u, role: "Student" })), ...(mktRes.teachers || []).map((u) => ({ ...u, role: "Teacher" }))];
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${mktSum.totalCampaigns}</strong><span>Campaigns</span></div><div class="portal-stat-icon">${icon("mail")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalEligible}</strong><span>Queued Recipients</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalSent}</strong><span>Emails Sent</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${mktSum.totalFailed}</strong><span>Failed / Pending SMTP</span></div><div class="portal-stat-icon">${icon("megaphone")}</div></div>
          </div>
          <div class="portal-message">Sender: <strong>${escapeHtml(mktRes.senderEmail)}</strong> · Reply-To: <strong>${escapeHtml(mktRes.replyToEmail)}</strong> · SMTP Status: <strong>${mktRes.smtpConfigured ? "Configured" : "Not Configured (configure SMTP_* in .env before sending live emails)"}</strong>${mktSum.openClickTrackingNote ? ` · ${escapeHtml(mktSum.openClickTrackingNote)}` : ""}</div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create &amp; Send Email Campaign</h3>
            <form class="portal-form" data-mkt-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Campaign Name *</label><input name="name" required placeholder="e.g. Board Exam Batch Alert"></div>
                <div class="portal-field"><label>Load Reusable Template (${(mktRes.templates || []).length})</label>
                  <select data-mkt-tmpl><option value="">Custom Email</option>${(mktRes.templates || []).map((t) => `<option value="${t.id}">${escapeHtml(t.name)} (${escapeHtml(t.category)})</option>`).join("")}</select>
                </div>
                <div class="portal-field"><label>Segment Audience</label>
                  <select name="audienceGroup">
                    <option value="all_students">All Eligible Students</option>
                    <option value="all_teachers">All Eligible Teachers</option>
                    <option value="all_opted_in">All Students &amp; Teachers</option>
                    <option value="recently_registered">Recently Registered (30 days)</option>
                  </select>
                </div>
                <div class="portal-field"><label>Account Status Filter</label>
                  <select name="accountStatus"><option value="all">Any</option><option value="approved">Approved Only</option><option value="pending_approval">Pending Approval</option></select>
                </div>
                <div class="portal-field"><label>Class Filter (Optional)</label><input name="classLevel" placeholder="e.g. Class 10"></div>
                <div class="portal-field"><label>Subject Keyword (Optional)</label><input name="subjectFilter" placeholder="e.g. Mathematics"></div>
                <div class="portal-field"><label>Course Filter</label><select name="courseId"><option value="">Any Course</option>${(mktRes.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Registered After</label><input name="registeredAfter" type="date"></div>
                <div class="portal-field"><label>Email Subject *</label><input name="subject" required></div>
                <div class="portal-field"><label>Preview Text (Optional)</label><input name="previewText" placeholder="Inbox snippet line..."></div>
                <div class="portal-field"><label>CTA Button Label (Optional)</label><input name="ctaLabel" placeholder="e.g. Apply for Admission"></div>
                <div class="portal-field"><label>CTA Link URL (Optional)</label><input name="ctaUrl" placeholder="https://yuitor.com/admission"></div>
                <div class="portal-field"><label>Send Mode</label><select name="sendMode"><option value="draft">Save Draft</option><option value="immediate">Send Immediately</option><option value="scheduled">Schedule</option></select></div>
                <div class="portal-field"><label>Schedule Date &amp; Time (if Scheduled)</label><input name="scheduledAt" type="datetime-local"></div>
                <div class="portal-field"><label>Optional Attachment (PDF / Image, max 5 MB)</label><input name="attachmentFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field">
                <label>Or Select Specific Recipients (Optional — leave unchecked to use segment filters)</label>
                <div class="portal-email-recipient-list">
                  ${recipientsList.map((u) => `<label class="portal-email-recipient"><input type="checkbox" name="selectedUid" value="${u.id}"><span><strong>${escapeHtml(u.full_name)}</strong> (${u.role})<br><span style="color:var(--pt-muted);">${escapeHtml(u.email)}</span></span></label>`).join("") || `<span class="portal-hint">No contacts found.</span>`}
                </div>
              </div>
              <div class="portal-field"><label>HTML Body (supports {{name}}) *</label><textarea name="htmlBody" rows="5" required><p>Dear {{name}},</p><p>Admissions are open at Yuitor Smart Classes, Muradnagar.</p></textarea></div>
              <div class="portal-message" data-mkt-preview hidden></div>
              <div class="portal-actions">
                <button type="button" class="portal-button portal-button--quiet portal-button--small" data-mkt-check>Preview Eligible Recipients</button>
                <button type="submit" class="portal-button portal-button--small">Create Campaign</button>
              </div>
            </form>
            <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
              <h4 style="margin:0 0 8px;font-size:13px;">Send Test Email</h4>
              <div class="portal-actions">
                <input type="email" data-test-email placeholder="recipient@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-test-send-btn>Send Test</button>
              </div>
              <div class="portal-message" data-test-fb hidden style="margin-top:8px;"></div>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Campaign</th><th>Recipients</th><th>Sent / Failed</th><th>Status</th><th>Controls</th></tr></thead>
            <tbody>
              ${(mktRes.campaigns || []).map((cp) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(cp.name)}</span><span class="portal-cell-sub">${escapeHtml(cp.subject)}</span></td>
                <td>${cp.total_recipients} eligible (${cp.excluded_count} excluded)</td>
                <td>${cp.sent_count} sent / ${cp.failed_count} failed</td>
                <td>${statusBadge(cp.status)}</td>
                <td><div class="portal-actions">
                  ${cp.status !== "cancelled" && cp.status !== "completed" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-act="${cp.id}" data-act="pause">Pause</button><button type="button" class="portal-button portal-button--small" data-camp-act="${cp.id}" data-act="process_now">Process</button>` : ""}
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-camp-deliveries="${cp.id}">Logs</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No campaigns yet.</td></tr>`}
            </tbody>
          </table></div></div>
          ${
            selectedCampaignDeliveries
              ? `<div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:12px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Delivery Logs</div><div class="portal-table-scroll"><table class="portal-table"><thead><tr><th>Recipient</th><th>Status</th><th>Error / ID</th><th>Timestamp</th></tr></thead><tbody>
                ${selectedCampaignDeliveries.map((d) => `<tr><td>${escapeHtml(d.recipient_name)} (${escapeHtml(d.recipient_email)})</td><td>${statusBadge(d.status)}</td><td>${escapeHtml(d.error_message || d.provider_message_id || "-")}</td><td>${escapeHtml(d.sent_at || d.created_at || "")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No deliveries queued.</td></tr>`}
              </tbody></table></div></div>`
              : ""
          }
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Email Suppression List (${(mktRes.suppressions || []).length})</h3>
            <form class="portal-form" data-supp-form style="margin-bottom:10px;">
              <div class="portal-actions">
                <input name="email" type="email" required placeholder="optout@example.com" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 10px;">
                <select name="reason" style="min-height:36px;border:1px solid var(--pt-border);border-radius:8px;padding:0 8px;"><option value="unsubscribed">Unsubscribed</option><option value="bounced">Bounced</option><option value="complaint">Complaint</option></select>
                <button type="submit" class="portal-button portal-button--small portal-button--quiet">Add Suppression</button>
              </div>
            </form>
            <p class="portal-hint">${(mktRes.suppressions || []).map((s) => `${escapeHtml(s.email)} (${escapeHtml(s.reason)})`).join(" · ") || "No suppressed addresses."}</p>
          </div>`;
      } else if (tab === "backups") {
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
            <div>
              <h3 class="portal-section-title" style="margin:0;">SQLite Database Backups</h3>
              <p class="portal-hint">Atomic VACUUM INTO snapshots stored safely inside private /backups (verified via PRAGMA quick_check).</p>
            </div>
            <div class="portal-actions">
              <a href="${escAttr(adminApiUrl("/project-zip"))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Deploy / Upgrade ZIP</a>
              <a href="${escAttr(adminApiUrl("/project-zip?type=source"))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Complete Source Code ZIP</a>
              <button type="button" class="portal-button portal-button--small" data-create-backup>${icon("database")} Create Backup Now</button>
            </div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Filename</th><th>Size</th><th>Integrity</th><th>Created</th><th>Download</th></tr></thead>
            <tbody>
              ${(backupsRes.backups || []).map((b) => `<tr><td><strong>${escapeHtml(b.filename)}</strong></td><td>${(b.sizeBytes / 1024).toFixed(1)} KB</td><td>${statusBadge(b.integrityOk ? "verified" : "failed")}</td><td>${escapeHtml(b.createdAt)}</td><td><a href="${escAttr(adminApiUrl(`/backups/${encodeURIComponent(b.filename)}`))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download .db</a></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No backups recorded yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Backup &amp; Recovery Procedure</h3>
            <div class="portal-personal-grid" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));">
              <div class="portal-detail"><span>1. Database Snapshot</span><strong>Atomic VACUUM INTO snapshots in /backups (non-public). Download verified .db archives off-server daily.</strong></div>
              <div class="portal-detail"><span>2. Uploaded Documents</span><strong>Archive /uploads/resumes and /uploads/knowledge alongside the DB backup (never served via public static root).</strong></div>
              <div class="portal-detail"><span>3. Configuration Backup</span><strong>Keep .env secrets backed up in your hosting secret manager; non-secret &amp; admin keys also persist in system_settings.</strong></div>
              <div class="portal-detail"><span>4. Recovery Steps</span><strong>Stop Node process, replace /data/yuitor.db with verified backup .db, restore /uploads, restart server, verify /api/health.</strong></div>
            </div>
          </div>`;
      } else if (tab === "upgrade") {
        const curVer = sysUpdateRes.currentVersion || "3.0.0";
        const protectedList = sysUpdateRes.protectedPaths || [
          "data/yuitor.db",
          "uploads/",
          "backups/",
          "logs/",
          ".env",
          "Active Stealth Admin URL",
        ];
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;">
              <div>
                <h3 class="portal-section-title" style="margin:0;">1-Click ZIP Version Upgrade</h3>
                <p class="portal-hint" style="margin:4px 0 0;">Sirf naya Yuitor release <strong>.zip</strong> upload karein — system khud naya version apply karega aur automatic pre-upgrade backup banayega.</p>
              </div>
              <span class="portal-status portal-status--approved" data-testid="current-app-version">Active Version: v${escapeHtml(curVer)}</span>
            </div>
            <div class="portal-personal-grid" style="margin-bottom:16px;">
              <div class="portal-detail"><span>Installed Version</span><strong>v${escapeHtml(curVer)} (${escapeHtml(sysUpdateRes.nodeVersion || "Node 22+")})</strong></div>
              <div class="portal-detail"><span>Max Archive Size</span><strong>${escapeHtml(String(sysUpdateRes.maxUploadMb || 80))} MB (.zip only)</strong></div>
              <div class="portal-detail"><span>Auto-Preserved Data</span><strong>${escapeHtml(protectedList.join(", "))}</strong></div>
            </div>
            <form class="portal-form" data-system-upgrade-form>
              <div class="portal-field">
                <label for="yu-upgrade-zip-input">Select Release ZIP Archive (e.g. yuitor-deploy-shared-hosting.zip) *</label>
                <input id="yu-upgrade-zip-input" name="releaseZip" type="file" accept=".zip,application/zip" required data-testid="input-upgrade-zip">
              </div>
              <div class="portal-actions">
                <button type="submit" class="portal-button" data-upgrade-submit-btn data-testid="button-apply-zip-upgrade">${icon("upload")} Upload &amp; Upgrade Version</button>
              </div>
              <div class="portal-message" data-upgrade-feedback hidden></div>
            </form>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Version Upgrade History (${(sysUpdateRes.upgradeHistory || []).length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Version</th><th>Details</th><th>Admin</th><th>IP</th><th>Date</th></tr></thead>
              <tbody>
                ${(sysUpdateRes.upgradeHistory || []).map((u) => `<tr><td>${statusBadge("verified")} <strong>${escapeHtml(u.target_name || "-")}</strong></td><td>${escapeHtml(u.details || "-")}</td><td>${escapeHtml(u.actor_name || "-")}</td><td>${escapeHtml(u.ip_address || "-")}</td><td>${escapeHtml(u.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No ZIP upgrades applied yet. Upload a release ZIP above to upgrade automatically.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "celebrations") {
        bodyHtml += `<div data-yu-admin-crm="crm_celebrations"></div>`;
      } else if (tab === "bulk_export") {
        bodyHtml += `<div data-yu-admin-crm="crm_bulk"></div>`;
      } else if (tab === "security_logs") {
        const attemptsList = loginAttemptsRes.attempts || [];
        const securityAudit = (dash.recentActivities || []).filter((a) =>
          /impersonat|admin|login|slug|delete|role|security/i.test(String(a.action || "") + " " + String(a.details || ""))
        );
        bodyHtml += `
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Admin Gate Login Attempts (${attemptsList.length})</div>
            <div class="portal-table-scroll"><table class="portal-table" data-yu-table="security_login_attempts">
              <thead><tr><th>Identifier</th><th>IP Address</th><th>Outcome</th><th>Reason</th><th>Timestamp</th></tr></thead>
              <tbody>
                ${attemptsList.map((a) => `<tr><td>${escapeHtml(a.identifier || "-")}</td><td>${escapeHtml(a.ip_address)}</td><td>${statusBadge(a.outcome === "success" ? "approved" : "rejected")}</td><td>${escapeHtml(a.reason || "-")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No admin login attempts logged yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Security, Impersonation &amp; Privilege Audit Events (${securityAudit.length})</div>
            <div class="portal-table-scroll"><table class="portal-table" data-yu-table="security_audit_events">
              <thead><tr><th>Event</th><th>Actor</th><th>Target</th><th>Details</th><th>Timestamp</th></tr></thead>
              <tbody>
                ${securityAudit.map((a) => `<tr><td><strong>${escapeHtml(a.action)}</strong></td><td>${escapeHtml(a.actor_name || "-")}</td><td>${escapeHtml(a.target_name || "-")}</td><td>${escapeHtml(a.details || "-")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No privileged audit events recorded yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div data-v31-audit-logs></div>`;
      } else if (tab === "settings") {
        const sList = settingsRes.settings || [];
        const rdy = settingsRes.readiness || {};
        const intStatuses = settingsRes.integrationStatuses || {};
        const attemptsList = loginAttemptsRes.attempts || [];
        const badgeForIntegration = (groupId, configured) => {
          const map = { ai: "gemini", email: "smtp", sms: "fast2sms", payments: "razorpay", general: "general" };
          const key = map[groupId];
          if (groupId === "general") {
            return configured
              ? `<span class="portal-status portal-status--paid" data-group-status="general">Connected</span>`
              : `<span class="portal-status portal-status--pending" data-group-status="general">Not Connected</span>`;
          }
          if (!configured) {
            return `<span class="portal-status portal-status--pending" data-group-status="${escAttr(groupId)}">Not Connected</span>`;
          }
          const st = intStatuses[key];
          if (st?.tested && st.connected) {
            return `<span class="portal-status portal-status--paid" data-group-status="${escAttr(groupId)}">Connected</span>`;
          }
          if (st?.tested && !st.connected) {
            return `<span class="portal-status portal-status--overdue" data-group-status="${escAttr(groupId)}">Not Connected</span>`;
          }
          return `<span class="portal-status portal-status--pending" data-group-status="${escAttr(groupId)}">Not Connected</span>`;
        };
        const groups = [
          {
            id: "ai",
            title: "Shreya AI Assistant (Gemini API)",
            subtitle: "Connect GEMINI_API_KEY & model for live Gemini LLM replies + PDF knowledge base grounding.",
            configured: Boolean(rdy.geminiAi),
          },
          {
            id: "email",
            title: "Email & SMTP Configuration",
            subtitle: "Live SMTP settings for registration/reset emails, fee receipts, campaigns, and admin alerts.",
            configured: Boolean(rdy.smtpMail),
          },
          {
            id: "sms",
            title: "Mobile SMS OTP Gateway (Fast2SMS)",
            subtitle: "Configure FAST2SMS_API_KEY to dispatch live 6-digit registration & password reset OTPs via SMS.",
            configured: Boolean(rdy.fast2sms),
          },
          {
            id: "payments",
            title: `Online Payments (Razorpay${rdy.razorpayMode === "live" ? " · Live Mode" : rdy.razorpayMode === "sandbox" ? " · Sandbox Mode" : ""})`,
            subtitle: "Create Razorpay orders and verify checkout + webhook HMAC-SHA256 signatures automatically.",
            configured: Boolean(rdy.razorpay),
          },
          {
            id: "general",
            title: "Website Domain & Security Keys",
            subtitle: "Configure APP_URL, SESSION_SECRET, IP allow-list, and installer setup key.",
            configured: Boolean(rdy.appUrl && rdy.sessionSecret),
          },
        ];

        const renderSettingField = (item) => {
          const sourceLabel =
            item.source === "admin"
              ? "Saved in Admin"
              : item.source === "env"
                ? "From Server .env"
                : item.source === "default"
                  ? "Default"
                  : "Not Set";
          const sourceTone = item.isConfigured ? "approved" : "pending";
          const inputHtml =
            item.inputType === "boolean"
              ? `<select name="cfg__${escAttr(item.key)}">
                   <option value="false" ${String(item.value || "false") !== "true" ? "selected" : ""}>false (STARTTLS / Port 587)</option>
                   <option value="true" ${String(item.value) === "true" ? "selected" : ""}>true (SSL/TLS / Port 465)</option>
                 </select>`
              : item.key === "FAST2SMS_ROUTE"
                ? `<select name="cfg__FAST2SMS_ROUTE">
                     <option value="q" ${String(item.value || "q") === "q" ? "selected" : ""}>q (Quick SMS Route)</option>
                     <option value="otp" ${String(item.value) === "otp" ? "selected" : ""}>otp (OTP Route)</option>
                     <option value="dlt" ${String(item.value) === "dlt" ? "selected" : ""}>dlt (TRAI DLT Approved Route)</option>
                   </select>`
                : `<input
                     name="cfg__${escAttr(item.key)}"
                     type="${item.isSecret ? "password" : item.inputType === "number" ? "number" : item.inputType === "email" ? "email" : item.inputType === "url" ? "url" : "text"}"
                     value="${item.isSecret ? "" : escAttr(item.value || "")}"
                     ${item.key === "GEMINI_MODEL" ? 'list="gemini-model-presets"' : ""}
                     placeholder="${item.isSecret && item.isConfigured ? `Saved (${item.maskedValue}) — leave blank to keep` : escAttr(item.placeholder || "")}"
                     autocomplete="new-password"
                   >`;
          const secretToggleBtn = item.isSecret
            ? `<button type="button" class="portal-button portal-button--small portal-button--quiet portal-setting-toggle" data-toggle-secret="${escAttr(item.key)}" aria-label="Show ${escAttr(item.key)}">Show</button>`
            : "";
          const extraBtn =
            item.key === "SESSION_SECRET"
              ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-gen-secret>Generate 64-Char Secret</button>`
              : "";
          const clearBox = item.hasDbOverride
            ? `<label class="portal-clear-check"><input type="checkbox" name="clr__${escAttr(item.key)}" value="1"> Clear saved Admin override (revert to .env / unset)</label>`
            : "";
          return `
            <div class="portal-setting-row">
              <div class="portal-setting-head">
                <strong style="font-size:13px;color:var(--pt-text);">${escapeHtml(item.label)}</strong>
                <span class="portal-status portal-status--${sourceTone}">${escapeHtml(sourceLabel)}</span>
              </div>
              <p class="portal-hint" style="margin:0 0 8px;">${escapeHtml(item.description)}</p>
              <div class="portal-field" style="margin:0;">
                <div class="portal-setting-input-row">${inputHtml}${secretToggleBtn}${extraBtn}</div>
              </div>
              ${clearBox}
            </div>`;
        };

        const renderDiagHtml = (diag) => {
          if (!diag) return "";
          const steps = Array.isArray(diag.howToFix) ? diag.howToFix : [String(diag.howToFix || "Verify your configuration and retry.")];
          return `
            <div class="portal-diag-box" data-testid="settings-diag-box">
              <h4>Save Blocked — Validation / Live Connection Test Failed</h4>
              <div class="portal-diag-row"><strong>1. Error:</strong> ${escapeHtml(diag.error || "Connection test failed.")}</div>
              <div class="portal-diag-row"><strong>2. Why it happened (Root Cause):</strong> ${escapeHtml(diag.rootCause || "The submitted settings failed live verification.")}</div>
              <div class="portal-diag-row"><strong>3. How to fix it:</strong>
                <ul>${steps.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>
              </div>
            </div>`;
        };

        settingsSubTab = normalizeSettingsSubTab(settingsSubTab);
        const SETTINGS_TABS = [
          ["security", "Security"],
          ["integrations", "Integrations & API Keys"],
          ["mail_templates", "Mail Templates"],
          ["email_bimi", "Email & BIMI"],
          ["automation", "Automation"],
          ["platform_status", "Platform Status"],
          ["backup_upgrade", "Backup & Upgrade"],
        ];

        bodyHtml += `
          <div class="yu-settings-header portal-card" style="margin-bottom:16px;padding:14px 16px;">
            <div class="yu-settings-top">
              <div class="yu-settings-tabs" role="tablist" aria-label="Settings sections">
                ${SETTINGS_TABS.map(([sid, slabel]) => `<button type="button" class="portal-subtab ${settingsSubTab === sid ? "is-active" : ""}" data-settings-subtab="${sid}" data-testid="settings-tab-${sid}">${escapeHtml(slabel)}</button>`).join("")}
              </div>
              <input type="search" class="yu-settings-search" data-settings-search value="${escAttr(settingsSearchQuery)}" placeholder="Search settings accordions..." aria-label="Search settings">
            </div>
          </div>
          <datalist id="gemini-model-presets">
            <option value="gemini-2.5-flash">
            <option value="gemini-2.5-pro">
            <option value="gemini-3.1-pro-preview">
          </datalist>`;

        if (settingsSubTab === "security") {
          bodyHtml += `
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>Secret Admin Gate URL &amp; Slug Rotation</span><span class="portal-status portal-status--approved">Active Gate</span></summary>
              <div class="yu-accordion-body">
                <p class="portal-hint" style="margin-bottom:12px;">The admin panel is hidden at a secret gate path. Changing the slug immediately disables the old URL and redirects you to the new secret path.</p>
                <div class="portal-personal-grid" style="margin-bottom:16px;">
                  <div class="portal-detail"><span>Current Secret Admin URL</span><strong data-testid="current-admin-gate-url">${escapeHtml(adminUrlRes.fullAdminGateUrl || GATE_BASE + "/")}</strong></div>
                  <div class="portal-detail"><span>Current Slug</span><strong data-testid="current-admin-slug">${escapeHtml(adminUrlRes.adminPath || GATE_BASE.replace(/^\//, ""))}</strong></div>
                  <div class="portal-detail"><span>Admin IP Allow-List</span><strong>${escapeHtml(adminUrlRes.ipAllowlist || "Any IP (Unrestricted)")}</strong></div>
                </div>
                <form class="portal-form" data-change-admin-path-form>
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>New Secret Admin Slug *</label><input name="adminPath" required pattern="[a-z0-9][a-z0-9\\-]{7,62}[a-z0-9]" placeholder="e.g. yt-ctrl-88k4-gate" value="${escAttr(adminUrlRes.adminPath || "")}"></div>
                    <div class="portal-field"><label>Confirm Current Admin Password *</label>${passwordFieldHtml("currentPassword", "required")}</div>
                  </div>
                  <div class="portal-actions">
                    <button type="submit" class="portal-button portal-button--small" data-testid="button-rotate-admin-slug">Update Secret Admin URL</button>
                  </div>
                </form>
              </div>
            </details>
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>Recent Admin Login Attempts (${attemptsList.length})</span><span class="portal-status portal-status--paid">Monitored</span></summary>
              <div class="yu-accordion-body">
                <div class="portal-table-scroll"><table class="portal-table" data-yu-table="settings_login_attempts">
                  <thead><tr><th>Identifier</th><th>IP Address</th><th>Outcome</th><th>Reason</th><th>Timestamp</th></tr></thead>
                  <tbody>
                    ${attemptsList.map((a) => `<tr><td>${escapeHtml(a.identifier || "-")}</td><td>${escapeHtml(a.ip_address)}</td><td>${statusBadge(a.outcome === "success" ? "approved" : "rejected")}</td><td>${escapeHtml(a.reason || "-")}</td><td>${escapeHtml(a.created_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No admin login attempts logged yet.</td></tr>`}
                  </tbody>
                </table></div>
              </div>
            </details>
            <div data-v31-audit-logs style="margin-top:16px;"></div>`;
        } else if (settingsSubTab === "mail_templates") {
          bodyHtml += `<div data-v31-mail-templates></div>`;
        } else if (settingsSubTab === "integrations") {
          bodyHtml += groups
            .map((grp, idx) => {
              const items = sList.filter((it) => it.category === grp.id);
              const diag = settingsDiagByCat[grp.id] || null;
              const okNote = settingsSuccessByCat[grp.id] || "";
              const extraTestInputs =
                grp.id === "email"
                  ? `<div class="portal-field" style="margin-top:10px;"><label>Optional Test Recipient Email (verified during save)</label><input type="email" name="__testRecipient" placeholder="Leave blank to verify SMTP handshake/auth without sending a test message"></div>`
                  : grp.id === "sms"
                    ? `<div class="portal-field" style="margin-top:10px;"><label>Optional 10-Digit Test Phone (blank = live wallet verification)</label><input type="tel" name="__testPhone" placeholder="Optional 10-digit mobile"></div>`
                    : "";
              return `
                <details class="portal-accordion yu-accordion" ${idx === 0 || diag || okNote ? "open" : ""}>
                  <summary class="yu-accordion-summary"><span>${escapeHtml(grp.title)}</span>${badgeForIntegration(grp.id, grp.configured)}</summary>
                  <div class="yu-accordion-body">
                    <p class="portal-hint" style="margin:0 0 12px;">${escapeHtml(grp.subtitle)}</p>
                    <form class="portal-form" data-tested-settings-form="${escAttr(grp.id)}" novalidate>
                      <div class="portal-form-grid">
                        ${items.map(renderSettingField).join("")}
                      </div>
                      ${extraTestInputs}
                      <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;margin-top:16px;padding-top:14px;border-top:1px solid var(--pt-border);">
                        <p class="portal-hint" style="margin:0;"><strong>Strict Test-Before-Save:</strong> Saving runs a live validation/connection check first and saves ONLY if the test succeeds.</p>
                        <button type="submit" class="portal-button" data-save-tested-btn data-testid="btn-test-and-save-${escAttr(grp.id)}">Test &amp; Save Configuration</button>
                      </div>
                      ${okNote ? `<div class="portal-message portal-message--success" style="margin-top:12px;">${escapeHtml(okNote)}</div>` : ""}
                      <div data-tested-diag-slot>${renderDiagHtml(diag)}</div>
                    </form>
                  </div>
                </details>`;
            })
            .join("");
        } else if (settingsSubTab === "email_bimi") {
          const bimi = bimiRes || {};
          const dnsRec = bimi.dnsRecord || {};
          const bimiDomain = bimi.domain || "yuitor.com";
          const bimiSelector = bimi.selector || "default";
          const bimiLogoUrl = bimi.logoUrl || "/bimi-logo.svg";
          const bimiHost = dnsRec.host || `${bimiSelector}._bimi.${bimiDomain}`;
          const bimiTxtValue = dnsRec.value || `v=BIMI1; l=${bimiLogoUrl};`;
          const dnsChecks = bimiDnsResult?.checks || null;
          bodyHtml += `
            ${bimiNotice ? `<div class="portal-message ${bimiNotice.ok ? "portal-message--success" : "portal-message--error"}" style="margin-bottom:12px;">${escapeHtml(bimiNotice.text)}</div>` : ""}
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>BIMI Brand Logo (SVG) &amp; Email Header Preview</span><span class="portal-status portal-status--${bimi.hasCustomSvg ? "paid" : "approved"}">${bimi.hasCustomSvg ? "Custom SVG Active" : "Default Brand SVG"}</span></summary>
              <div class="yu-accordion-body">
                <p class="portal-hint" style="margin-bottom:12px;">The exact SVG logo below is served at <code>/bimi-logo.svg</code> &amp; <code>/.well-known/bimi.svg</code> and automatically embedded inside outgoing Mail headers.</p>
                <div class="yu-bimi-grid">
                  <div class="yu-bimi-preview-card">
                    <span class="portal-hint">Inbox Avatar / BIMI Square Preview</span>
                    <div class="yu-bimi-avatar"><img src="${escAttr(bimiLogoUrl)}?t=${Date.now()}" alt="BIMI Brand Logo"></div>
                    <div class="yu-bimi-email-preview">
                      <div class="yu-bimi-email-head">
                        <img src="${escAttr(bimiLogoUrl)}?t=${Date.now()}" alt="Logo" width="32" height="32">
                        <div><strong>Yuitor Smart Classes</strong><span>Official Email Header</span></div>
                      </div>
                    </div>
                  </div>
                  <div class="yu-bimi-controls">
                    <form class="portal-form" data-bimi-svg-form>
                      <div class="portal-field">
                        <label>Upload BIMI SVG Logo (max 256 KB, SVG Tiny PS recommended)</label>
                        <input type="file" accept=".svg,image/svg+xml" data-bimi-svg-file required>
                      </div>
                      <div class="portal-actions">
                        <button type="submit" class="portal-button portal-button--small" data-bimi-upload-btn>${icon("upload")} Upload &amp; Apply SVG Logo</button>
                        <button type="button" class="portal-button portal-button--small portal-button--quiet" data-bimi-reset>Reset Default Logo</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </details>
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>BIMI DNS TXT Record Generator</span><span class="portal-status portal-status--approved">${escapeHtml(bimiHost)}</span></summary>
              <div class="yu-accordion-body">
                <form class="portal-form" data-bimi-config-form style="margin-bottom:14px;">
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>Sending Domain *</label><input name="domain" required value="${escAttr(bimiDomain)}" placeholder="yuitor.com"></div>
                    <div class="portal-field"><label>BIMI Selector</label><input name="selector" value="${escAttr(bimiSelector)}" placeholder="default"></div>
                    <div class="portal-field"><label>VMC Certificate URL (Optional .pem)</label><input name="vmcUrl" value="${escAttr(bimi.vmcUrl || "")}" placeholder="https://example.com/vmc.pem"></div>
                  </div>
                  <button type="submit" class="portal-button portal-button--small">Save BIMI Domain &amp; Regenerate TXT Record</button>
                </form>
                <div class="yu-bimi-dns-box">
                  <div class="yu-bimi-dns-row">
                    <div><span>TXT Host / Name</span><strong>${escapeHtml(bimiHost)}</strong></div>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-copy-text="${escAttr(bimiHost)}">Copy Host</button>
                  </div>
                  <div class="yu-bimi-dns-row">
                    <div><span>TXT Record Value</span><code style="word-break:break-all;">${escapeHtml(bimiTxtValue)}</code></div>
                    <button type="button" class="portal-button portal-button--small" data-copy-text="${escAttr(bimiTxtValue)}">Copy TXT Value</button>
                  </div>
                </div>
              </div>
            </details>
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>SPF / DKIM / DMARC / BIMI Live DNS Status</span><button type="button" class="portal-button portal-button--small" data-bimi-check-dns>Verify Live DNS Now</button></summary>
              <div class="yu-accordion-body">
                ${
                  dnsChecks
                    ? `<div class="portal-personal-grid">
                        ${["spf", "dkim", "dmarc", "bimi"]
                          .map((k) => {
                            const c = dnsChecks[k] || {};
                            return `<div class="portal-detail"><span>${k.toUpperCase()} Record ${statusBadge(c.ok ? "connected" : "missing")}</span><strong>${escapeHtml(c.detail || c.record || (c.ok ? "Verified" : "Not Found"))}</strong></div>`;
                          })
                          .join("")}
                      </div>`
                    : `<p class="portal-hint">Click <strong>Verify Live DNS Now</strong> to query TXT records for <code>${escapeHtml(bimiDomain)}</code> (SPF, common DKIM selectors, <code>_dmarc.${escapeHtml(bimiDomain)}</code>, and <code>${escapeHtml(bimiHost)}</code>).</p>`
                }
              </div>
            </details>`;
        } else if (settingsSubTab === "automation") {
          bodyHtml += `
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>Cross-Selling Engine (Weekly Progressive Discount &amp; Dry-Run)</span><span class="portal-status portal-status--approved">v3.1 Engine</span></summary>
              <div class="yu-accordion-body">
                <div data-v31-cross-sell-admin></div>
              </div>
            </details>
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>Automation Rules, Safety Controls &amp; Exception Inbox</span><span class="portal-status portal-status--approved">IST Scheduler</span></summary>
              <div class="yu-accordion-body">
                <div data-yu-admin-crm="crm_automation"></div>
              </div>
            </details>`;
        } else if (settingsSubTab === "platform_status") {
          const describeLiveStatus = (key, configured, defaultUnset) => {
            if (!configured) return defaultUnset;
            const st = intStatuses[key];
            if (st?.tested && st.connected) return `Connected (${st.testedAt ? st.testedAt.slice(0, 19).replace("T", " ") : "Verified"})`;
            if (st?.tested && !st.connected) return `Not Connected: ${st.message || "Re-test"}`;
            return "Configured — Untested";
          };
          bodyHtml += `
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>Platform Readiness &amp; Live Integration Status</span><span class="portal-status portal-status--approved">v3.0 Live</span></summary>
              <div class="yu-accordion-body">
                <div class="portal-personal-grid">
                  <div class="portal-detail"><span>Application Version</span><strong>Yuitor Smart Classes v3.0</strong></div>
                  <div class="portal-detail"><span>Public Domain (APP_URL)</span><strong>${rdy.appUrl ? "Configured" : "Using Default"}</strong></div>
                  <div class="portal-detail"><span>Session Signing Secret</span><strong>${rdy.sessionSecret ? "Custom Secret Active" : "Auto-Derived Key"}</strong></div>
                  <div class="portal-detail"><span>Installer Setup Key</span><strong>${rdy.setupKeyProtected ? "Protected by YU_ADMIN_SETUP_KEY" : "Standard (Single-Run Lock)"}</strong></div>
                  <div class="portal-detail"><span>Shreya Gemini AI (${escapeHtml(rdy.geminiModel || "gemini-2.5-flash")})</span><strong>${escapeHtml(describeLiveStatus("gemini", rdy.geminiAi, "Not Connected (Deterministic Fallback Active)"))}</strong></div>
                  <div class="portal-detail"><span>SMTP Mail Server</span><strong>${escapeHtml(describeLiveStatus("smtp", rdy.smtpMail, "Not Connected"))}</strong></div>
                  <div class="portal-detail"><span>Fast2SMS Mobile OTP</span><strong>${escapeHtml(describeLiveStatus("fast2sms", rdy.fast2sms, "Not Connected (SMS Delivery Disabled)"))}</strong></div>
                  <div class="portal-detail"><span>Razorpay Checkout (${rdy.razorpayMode === "live" ? "Live" : rdy.razorpayMode === "sandbox" ? "Sandbox" : "Unconfigured"})</span><strong>${escapeHtml(describeLiveStatus("razorpay", rdy.razorpay, "Not Connected (Manual UPI / Cash Desk Mode)"))}</strong></div>
                  <div class="portal-detail"><span>Razorpay Webhook Secret</span><strong>${rdy.razorpayWebhook ? "Webhook Signature Verified" : "Not Connected (Optional)"}</strong></div>
                </div>
                <div class="portal-actions" style="margin-top:16px;">
                  <button type="button" class="portal-button portal-button--small" data-settings-subtab="integrations">Manage API Keys &amp; Integrations</button>
                  <a href="${escAttr(adminApiUrl("/project-zip"))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download Deploy ZIP</a>
                </div>
              </div>
            </details>`;
        } else if (settingsSubTab === "backup_upgrade") {
          const curVer = sysUpdateRes.currentVersion || "3.0.0";
          bodyHtml += `
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>SQLite Database Backups &amp; Export (${(backupsRes.backups || []).length})</span><span class="portal-status portal-status--approved">Atomic Backups</span></summary>
              <div class="yu-accordion-body">
                <div class="portal-actions" style="margin-bottom:12px;">
                  <button type="button" class="portal-button portal-button--small" data-create-backup>${icon("database")} Create Backup Now</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-dash-tab="backups">Open Full Backup Manager</button>
                </div>
                <div class="portal-table-scroll"><table class="portal-table" data-yu-table="settings_backups">
                  <thead><tr><th>Filename</th><th>Size</th><th>Integrity</th><th>Created</th><th data-yu-locked="1">Download</th></tr></thead>
                  <tbody>
                    ${(backupsRes.backups || []).map((b) => `<tr><td><strong>${escapeHtml(b.filename)}</strong></td><td>${(b.sizeBytes / 1024).toFixed(1)} KB</td><td>${statusBadge(b.integrityOk ? "verified" : "failed")}</td><td>${escapeHtml(b.createdAt)}</td><td><a href="${escAttr(adminApiUrl(`/backups/${encodeURIComponent(b.filename)}`))}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} .db</a></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No backups recorded yet.</td></tr>`}
                  </tbody>
                </table></div>
              </div>
            </details>
            <details class="portal-accordion yu-accordion" open>
              <summary class="yu-accordion-summary"><span>1-Click ZIP Version Upgrade</span><span class="portal-status portal-status--approved">v${escapeHtml(curVer)}</span></summary>
              <div class="yu-accordion-body">
                <p class="portal-hint" style="margin-bottom:12px;">Upload a verified Yuitor release .zip to upgrade cleanly with automatic pre-upgrade SQLite snapshot.</p>
                <form class="portal-form" data-system-upgrade-form>
                  <div class="portal-field"><label>Release ZIP Archive *</label><input name="releaseZip" type="file" accept=".zip,application/zip" required></div>
                  <div class="portal-actions">
                    <button type="submit" class="portal-button portal-button--small" data-upgrade-submit-btn>${icon("upload")} Upload &amp; Upgrade Version</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-dash-tab="upgrade">Open Upgrade History</button>
                  </div>
                  <div class="portal-message" data-upgrade-feedback hidden></div>
                </form>
              </div>
            </details>`;
        }
      } else if (tab === "referrals" || tab === "wallets" || tab === "withdrawals" || tab === "referral_reports") {
        bodyHtml += `<div data-yu-admin-addon="${escAttr(tab)}"></div>`;
      }

      const replaceAdminHash = (nextHash) => {
        try {
          const protoReplace = Object.getPrototypeOf(window.history)?.replaceState;
          if (typeof protoReplace === "function") {
            protoReplace.call(window.history, null, "", nextHash);
          } else {
            window.history.replaceState(null, "", nextHash);
          }
        } catch {
        }
      };

      const main = renderWorkspace({
        session,
        portalTitle: "Admin Portal",
        navGroups: adminNavGroups,
        activeNavKey: activeAdminNavKey,
        openGroups: openAdminGroups,
        activeTab: tab,
        breadcrumbs: breadcrumbsList,
        onBreadcrumbSelect: (bc) => {
          if (!bc || !bc.tab) return;
          tab = VALID_ADMIN_TABS.has(bc.tab) ? bc.tab : "dashboard";
          selectedUserDetail = null;
          selectedChatDetail = null;
          replaceAdminHash(tab === "settings" ? `#settings/${settingsSubTab}` : `#${encodeURIComponent(tab)}`);
          loadAndDraw();
        },
        onNavSelect: (key) => {
          let matchedGroup = null;
          let matchedItem = null;
          for (const g of adminNavGroups) {
            const it = g.items.find((x) => x.key === key);
            if (it) {
              matchedGroup = g;
              matchedItem = it;
              break;
            }
          }
          if (!matchedItem) return;
          tab = matchedItem.tab;
          activeAdminNavKey = matchedItem.key;
          if (matchedGroup) openAdminGroups.add(matchedGroup.id);
          selectedUserDetail = null;
          selectedChatDetail = null;
          editingCourse = null;
          selectedOfflineTest = null;
          pendingScrollSelector = matchedItem.scrollMatch || null;

          let nextHash = `#${encodeURIComponent(tab)}`;
          if (matchedItem.tab === "admissions") {
            admissionsSubView = matchedItem.subView || "leads";
            nextHash = `#admissions/${encodeURIComponent(admissionsSubView)}`;
          } else if (matchedItem.tab === "dashboard") {
            dashboardSubView = matchedItem.subView || "overview";
            nextHash = `#dashboard/${encodeURIComponent(dashboardSubView)}`;
          } else if (matchedItem.tab === "users" && matchedItem.role) {
            userFilterRole = matchedItem.role;
            usersSubView = "directory";
            userFilterStatus = "all";
            userPage = 1;
            nextHash = `#users?role=${encodeURIComponent(matchedItem.role)}`;
          } else if (matchedItem.tab === "payments") {
            paymentsSubView = matchedItem.subView || "all";
            nextHash = paymentsSubView === "fee_desk" ? "#payments/fee_desk" : "#payments";
          } else if (matchedItem.tab === "settings") {
            if (matchedItem.settingsTab) settingsSubTab = normalizeSettingsSubTab(matchedItem.settingsTab);
            nextHash = `#settings/${encodeURIComponent(settingsSubTab)}`;
          } else if (matchedItem.tab === "alerts" && matchedItem.channel) {
            alertsChannelPref = matchedItem.channel;
          }
          replaceAdminHash(nextHash);
          loadAndDraw();
        },
        onTabChange: (next) => {
          tab = next;
          activeAdminNavKey = "";
          selectedUserDetail = null;
          selectedChatDetail = null;
          editingCourse = null;
          selectedOfflineTest = null;
          replaceAdminHash(tab === "settings" ? `#settings/${settingsSubTab}` : `#${encodeURIComponent(tab)}`);
          loadAndDraw();
        },
        notifications: notifsRes.notifications || [],
        onReadNotifs: async () => {
          await api(adminApiUrl("/notifications/read-all"), { method: "POST" });
          loadAndDraw();
        },
        onMailShortcut: () => {
          tab = "mail";
          activeAdminNavKey = "comm-mail";
          selectedUserDetail = null;
          replaceAdminHash("#mail");
          loadAndDraw();
        },
        onBack: (prev) => {
          if (selectedUserDetail) {
            selectedUserDetail = null;
            loadAndDraw();
            return;
          }
          if (selectedChatDetail) {
            selectedChatDetail = null;
            loadAndDraw();
            return;
          }
          if (editingCourse) {
            editingCourse = null;
            loadAndDraw();
            return;
          }
          if (selectedOfflineTest) {
            selectedOfflineTest = null;
            loadAndDraw();
            return;
          }
          if (prev && prev.tab && prev.tab !== tab) {
            tab = VALID_ADMIN_TABS.has(prev.tab) ? prev.tab : "dashboard";
            activeAdminNavKey = prev.key || "";
            replaceAdminHash(tab === "settings" ? `#settings/${settingsSubTab}` : `#${encodeURIComponent(tab)}`);
            loadAndDraw();
            return;
          }
          if (tab !== "dashboard") {
            tab = "dashboard";
            activeAdminNavKey = "dashboard-overview";
            replaceAdminHash("#dashboard");
            loadAndDraw();
          } else if (window.history.length > 1) {
            window.history.back();
          }
        },
        bodyHtml,
      });

      // v3.1 Mounted Modules (Mail Templates, Cross-Sell Settings, IST Audit Viewer, Editable Student/Teacher Details)
      if (window.YuitorV31) {
        const mtEl = main?.querySelector("[data-v31-mail-templates]");
        if (mtEl) window.YuitorV31.renderMailTemplatesTab(mtEl, adminApiUrl);

        const csEl = main?.querySelector("[data-v31-cross-sell-admin]");
        if (csEl) window.YuitorV31.renderCrossSellAdminSection(csEl, adminApiUrl);

        const alEl = main?.querySelector("[data-v31-audit-logs]");
        if (alEl) window.YuitorV31.renderAuditLogViewer(alEl, adminApiUrl);

        const stuMgrEl = main?.querySelector("[data-v31-student-manage]");
        if (stuMgrEl) {
          const sid = stuMgrEl.getAttribute("data-v31-student-manage");
          (async () => {
            try {
              const det = await api(adminApiUrl(`/v31/students/${sid}/details`));
              const sp = det.profile || {};
              const subjectsStr = Array.isArray(det.enrolledSubjects) ? det.enrolledSubjects.join(", ") : String(sp.enrolled_subjects_json || "");
              const addonsStr = Array.isArray(det.subjectAddons) ? det.subjectAddons.join(", ") : String(sp.subject_addons_json || "");
              const totalFee = Number(det.totalFee || sp.total_fee_override || 0);
              const paidFee = Number(det.paidFee || sp.paid_fee_override || 0);
              const remFee = Math.max(0, totalFee - paidFee);
              const curClass = sp.class_level || det.user?.class_level || "";
              stuMgrEl.innerHTML = `
                <div class="portal-card portal-profile" style="margin-bottom:14px;border-left:4px solid #2563EB;">
                  <h3 class="portal-section-title">Change Student Class (Updates Batches, Subjects &amp; Cross-Sell Immediately)</h3>
                  <form class="portal-form" data-v31-class-change-form="${sid}">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Current Class</label><input value="${escAttr(curClass || "Not Set")}" disabled></div>
                      <div class="portal-field"><label>New Class *</label>
                        <select name="newClass" required>
                          <option value="">Select New Class</option>
                          ${["Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10","Class 11","Class 12","Dropper / Foundation"].map((cl) => `<option value="${escAttr(cl)}" ${String(curClass).toLowerCase() === cl.toLowerCase() ? "selected" : ""}>${escapeHtml(cl)}</option>`).join("")}
                        </select>
                      </div>
                      <div class="portal-field"><label>Reason / Audit Note</label><input name="reason" placeholder="e.g. Annual promotion or correction"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Confirm &amp; Change Class</button>
                  </form>
                </div>
                <div class="portal-card portal-profile" style="border-left:4px solid #7C3AED;">
                  <h3 class="portal-section-title">Editable Student Subjects, Duration, Payments &amp; Profile</h3>
                  <form class="portal-form" data-v31-stu-details-form="${sid}">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Enrolled Subjects (comma-separated)</label><input name="enrolledSubjects" value="${escAttr(subjectsStr)}" placeholder="Mathematics, Science, English"></div>
                      <div class="portal-field"><label>Subject Add-ons (comma-separated)</label><input name="subjectAddons" value="${escAttr(addonsStr)}" placeholder="Olympiad Prep, Coding"></div>
                      <div class="portal-field"><label>Course Duration (Months)</label><input name="courseDurationMonths" type="number" min="1" max="60" value="${Number(sp.course_duration_months || 12)}"></div>
                      <div class="portal-field"><label>Total Fee (₹)</label><input name="totalFee" type="number" min="0" value="${totalFee}" data-v31-fee-total></div>
                      <div class="portal-field"><label>Paid Fee (₹)</label><input name="paidFee" type="number" min="0" value="${paidFee}" data-v31-fee-paid></div>
                      <div class="portal-field"><label>Remaining Fee (Auto-calculated)</label><input value="₹${remFee.toLocaleString("en-IN")}" disabled data-v31-fee-rem></div>
                      <div class="portal-field"><label>Date of Birth (IST)</label><input name="dob" type="date" max="${window.YuitorV31.getTodayIstYmd()}" value="${escAttr(det.user?.dob || "")}"></div>
                      <div class="portal-field"><label>School Name</label><input name="schoolName" value="${escAttr(sp.school_name || "")}" placeholder="Student School Name"></div>
                      <div class="portal-field"><label>Residential Address</label><input name="address" value="${escAttr(sp.address || "")}" placeholder="Full Address"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Save Student Details</button>
                  </form>
                </div>`;
              const tIn = stuMgrEl.querySelector("[data-v31-fee-total]");
              const pIn = stuMgrEl.querySelector("[data-v31-fee-paid]");
              const rIn = stuMgrEl.querySelector("[data-v31-fee-rem]");
              const recalc = () => {
                if (rIn) rIn.value = `₹${Math.max(0, Number(tIn?.value || 0) - Number(pIn?.value || 0)).toLocaleString("en-IN")}`;
              };
              tIn?.addEventListener("input", recalc);
              pIn?.addEventListener("input", recalc);

              stuMgrEl.querySelector("[data-v31-class-change-form]")?.addEventListener("submit", async (e) => {
                e.preventDefault();
                const fd = new FormData(e.target);
                const newClass = String(fd.get("newClass") || "").trim();
                const reason = String(fd.get("reason") || "").trim();
                if (!newClass) return;
                const ok = await window.YuitorV31.confirmModal({
                  title: "Confirm Student Class Change",
                  message: `Change class from "${curClass || "Unset"}" to "${newClass}"? Student Panel batches, subjects, and cross-sell offers will update immediately.`,
                  confirmLabel: "Yes, Change Class",
                  variant: "warning",
                });
                if (!ok) return;
                await runAdminAction(async () => {
                  await api(adminApiUrl(`/v31/students/${sid}/change-class`), { method: "POST", body: { newClass, reason } });
                  selectedUserDetail = await api(adminApiUrl(`/users/${sid}`));
                }, `Student class updated to ${newClass}.`);
              });

              stuMgrEl.querySelector("[data-v31-stu-details-form]")?.addEventListener("submit", async (e) => {
                e.preventDefault();
                const fd = new FormData(e.target);
                const ok = await window.YuitorV31.confirmModal({
                  title: "Save Student Academic & Fee Details",
                  message: "Confirm saving updated subjects, duration, payments, and student profile details?",
                  confirmLabel: "Yes, Save Details",
                });
                if (!ok) return;
                await runAdminAction(async () => {
                  await api(adminApiUrl(`/v31/students/${sid}/details`), {
                    method: "PATCH",
                    body: {
                      enrolledSubjects: String(fd.get("enrolledSubjects") || "").split(",").map((s) => s.trim()).filter(Boolean),
                      subjectAddons: String(fd.get("subjectAddons") || "").split(",").map((s) => s.trim()).filter(Boolean),
                      courseDurationMonths: Number(fd.get("courseDurationMonths") || 12),
                      totalFee: Number(fd.get("totalFee") || 0),
                      paidFee: Number(fd.get("paidFee") || 0),
                      dob: String(fd.get("dob") || "").trim() || undefined,
                      schoolName: String(fd.get("schoolName") || "").trim(),
                      address: String(fd.get("address") || "").trim(),
                    },
                  });
                  selectedUserDetail = await api(adminApiUrl(`/users/${sid}`));
                }, "Student academic & fee details saved.");
              });
            } catch (err) {
              stuMgrEl.innerHTML = `<div class="v31-error-state">${escapeHtml(err?.message || "Unable to load student details.")}</div>`;
            }
          })();
        }

        const tchMgrEl = main?.querySelector("[data-v31-teacher-manage]");
        if (tchMgrEl) {
          const tid = tchMgrEl.getAttribute("data-v31-teacher-manage");
          (async () => {
            try {
              const det = await api(adminApiUrl(`/v31/teachers/${tid}/details`));
              const tp = det.profile || {};
              const subjectsStr = Array.isArray(det.subjectsTaught) ? det.subjectsTaught.join(", ") : String(tp.subjects_taught_json || "");
              const totalSeats = Number(det.batchTotalSeats ?? tp.batch_total_seats ?? 30);
              const activeStudents = Number(det.activeStudentCount ?? tp.active_student_count_override ?? 0);
              const vacantSeats = Math.max(0, totalSeats - activeStudents);
              const referralsCount = Number(det.referralsCount ?? tp.referrals_count_override ?? 0);
              tchMgrEl.innerHTML = `
                <div class="portal-card portal-profile" style="border-left:4px solid #0284C7;">
                  <h3 class="portal-section-title">Editable Teacher Details, Batch Seats &amp; Referrals</h3>
                  ${vacantSeats === 0 ? `<div class="portal-message portal-message--error" style="margin-bottom:12px;" data-v31-seat-warn><strong>Seat Capacity Alert:</strong> 0 vacant seats remaining (Total Seats: ${totalSeats}, Active Students: ${activeStudents}).</div>` : `<div class="portal-message portal-message--success" style="margin-bottom:12px;" data-v31-seat-warn>Vacant Seats: <strong>${vacantSeats}</strong> (${activeStudents} active / ${totalSeats} total seats)</div>`}
                  <form class="portal-form" data-v31-tch-details-form="${tid}">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Subjects Taught (comma-separated)</label><input name="subjectsTaught" value="${escAttr(subjectsStr)}" placeholder="Physics, Chemistry, Mathematics"></div>
                      <div class="portal-field"><label>End Date</label><input name="endDate" type="date" value="${escAttr(tp.end_date || "")}"></div>
                      <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="120" value="${Number(tp.duration_months || 12)}"></div>
                      <div class="portal-field"><label>Active Student Count</label><input name="activeStudentCount" type="number" min="0" value="${activeStudents}" data-v31-t-active></div>
                      <div class="portal-field"><label>Batch Total Seats (e.g. 30)</label><input name="batchTotalSeats" type="number" min="0" value="${totalSeats}" data-v31-t-total></div>
                      <div class="portal-field"><label>Vacant Seats (Auto: Total - Active)</label><input value="${vacantSeats}" disabled data-v31-t-vacant></div>
                      <div class="portal-field"><label>Teacher Referrals Count</label><input name="referralsCount" type="number" min="0" value="${referralsCount}"></div>
                      <div class="portal-field"><label>Date of Birth (IST)</label><input name="dob" type="date" max="${window.YuitorV31.getTodayIstYmd()}" value="${escAttr(det.user?.dob || "")}"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Save Teacher Details</button>
                  </form>
                </div>`;
              const actIn = tchMgrEl.querySelector("[data-v31-t-active]");
              const totIn = tchMgrEl.querySelector("[data-v31-t-total]");
              const vacIn = tchMgrEl.querySelector("[data-v31-t-vacant]");
              const warnBox = tchMgrEl.querySelector("[data-v31-seat-warn]");
              const recalcSeats = () => {
                const a = Math.max(0, Number(actIn?.value || 0));
                const t = Math.max(0, Number(totIn?.value || 0));
                const v = Math.max(0, t - a);
                if (vacIn) vacIn.value = String(v);
                if (warnBox) {
                  if (v === 0) {
                    warnBox.className = "portal-message portal-message--error";
                    warnBox.innerHTML = `<strong>Seat Capacity Alert:</strong> 0 vacant seats remaining (Total Seats: ${t}, Active Students: ${a}).`;
                  } else {
                    warnBox.className = "portal-message portal-message--success";
                    warnBox.innerHTML = `Vacant Seats: <strong>${v}</strong> (${a} active / ${t} total seats)`;
                  }
                }
              };
              actIn?.addEventListener("input", recalcSeats);
              totIn?.addEventListener("input", recalcSeats);

              tchMgrEl.querySelector("[data-v31-tch-details-form]")?.addEventListener("submit", async (e) => {
                e.preventDefault();
                const fd = new FormData(e.target);
                const ok = await window.YuitorV31.confirmModal({
                  title: "Save Teacher Details",
                  message: "Confirm saving teacher subjects, duration, batch seat capacity, and referral count?",
                  confirmLabel: "Yes, Save Teacher Details",
                });
                if (!ok) return;
                await runAdminAction(async () => {
                  await api(adminApiUrl(`/v31/teachers/${tid}/details`), {
                    method: "PATCH",
                    body: {
                      subjectsTaught: String(fd.get("subjectsTaught") || "").split(",").map((s) => s.trim()).filter(Boolean),
                      endDate: String(fd.get("endDate") || "").trim(),
                      durationMonths: Number(fd.get("durationMonths") || 12),
                      activeStudentCount: Number(fd.get("activeStudentCount") || 0),
                      batchTotalSeats: Number(fd.get("batchTotalSeats") || 30),
                      referralsCount: Number(fd.get("referralsCount") || 0),
                      dob: String(fd.get("dob") || "").trim() || undefined,
                    },
                  });
                  selectedUserDetail = await api(adminApiUrl(`/users/${tid}`));
                }, "Teacher details updated.");
              });
            } catch (err) {
              tchMgrEl.innerHTML = `<div class="v31-error-state">${escapeHtml(err?.message || "Unable to load teacher details.")}</div>`;
            }
          })();
        }
      }

      const addonAdminMount = main?.querySelector("[data-yu-admin-addon]");
      if (addonAdminMount && window.YuitorAddons) {
        if (tab === "referrals") window.YuitorAddons.renderAdminReferralsPage(addonAdminMount, { adminApiUrl });
        else if (tab === "wallets") window.YuitorAddons.renderAdminWalletsPage(addonAdminMount, { adminApiUrl });
        else if (tab === "withdrawals") window.YuitorAddons.renderAdminWithdrawalsPage(addonAdminMount, { adminApiUrl });
        else if (tab === "referral_reports") window.YuitorAddons.renderAdminReferralReportsPage(addonAdminMount, { adminApiUrl });
      }
      const crmNavigate = (target) => {
        if (!target) return;
        const reqTab = target.tab || "dashboard";
        if (LEGACY_TAB_MAP[reqTab]) {
          const mapped = LEGACY_TAB_MAP[reqTab];
          tab = mapped.tab;
          if (mapped.role) userFilterRole = mapped.role;
          if (mapped.usersSubView) usersSubView = mapped.usersSubView;
          if (mapped.subView) {
            if (tab === "admissions") admissionsSubView = mapped.subView;
            else if (tab === "payments") paymentsSubView = mapped.subView;
          }
          if (mapped.settingsTab) settingsSubTab = normalizeSettingsSubTab(mapped.settingsTab);
          activeAdminNavKey = target.navKey || mapped.navKey || "";
        } else {
          tab = VALID_ADMIN_TABS.has(reqTab) ? reqTab : "dashboard";
          activeAdminNavKey = target.navKey || "";
        }
        if (target.role) userFilterRole = target.role;
        if (target.usersSubView) usersSubView = target.usersSubView;
        if (target.subView) {
          if (tab === "admissions") admissionsSubView = target.subView;
          else if (tab === "payments") paymentsSubView = target.subView;
          else if (tab === "dashboard") dashboardSubView = target.subView;
        }
        if (target.settingsTab) settingsSubTab = normalizeSettingsSubTab(target.settingsTab);
        pendingScrollSelector = target.scrollMatch || null;
        const nextHash =
          tab === "settings"
            ? `#settings/${encodeURIComponent(settingsSubTab)}`
            : tab === "users" && userFilterRole
              ? `#users?role=${encodeURIComponent(userFilterRole)}`
              : `#${encodeURIComponent(tab)}`;
        replaceAdminHash(nextHash);
        loadAndDraw();
      };
      if (window.YuitorCrmV25) {
        window.YuitorCrmV25.mountCtrlKCommandBar({ adminApiUrl, onNavigate: crmNavigate });
        const crmDashHeader = main?.querySelector("[data-yu-crm-dashboard-header]");
        if (crmDashHeader && tab === "dashboard") {
          window.YuitorCrmV25.mountSmartDashboardHeader(crmDashHeader, { adminApiUrl, onNavigate: crmNavigate });
        }
        const crmAdminMount = main?.querySelector("[data-yu-admin-crm]");
        if (crmAdminMount) {
          const crmKey = crmAdminMount.getAttribute("data-yu-admin-crm") || settingsSubTab;
          if (crmKey === "crm_fee_desk") window.YuitorCrmV25.renderQuickFeeDesk(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_leads") window.YuitorCrmV25.renderLeadsCrm(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_hub") window.YuitorCrmV25.renderOnlineAcademicHub(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_student_exits") window.YuitorCrmV25.renderStudentExitsPanel(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_teacher_ops") {
            if (!window.__YU_CRM_SUBTAB__ && ["leaves", "ratings", "exits"].includes(usersSubView)) {
              window.__YU_CRM_SUBTAB__ = usersSubView;
            }
            window.YuitorCrmV25.renderTeacherOpsPanel(crmAdminMount, { adminApiUrl });
          }
          else if (crmKey === "crm_staff_exits") window.YuitorCrmV25.renderStaffExitsPanel(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_celebrations") window.YuitorCrmV25.renderCelebrationsPanel(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_bulk") window.YuitorCrmV25.renderBulkImportExport(crmAdminMount, { adminApiUrl });
          else if (crmKey === "crm_automation") window.YuitorCrmV25.renderAutomationControl(crmAdminMount, { adminApiUrl });
        }
      }
      window.YuitorAddons?.mountAdminGlobalSearch(main?.querySelector(".portal-topbar-right"), {
        adminApiUrl,
        onNavigate: crmNavigate,
      });

      if (tab === "alerts") {
        const channelSel = main.querySelector('[data-bulk-alert-form] select[name="channel"]');
        if (channelSel && alertsChannelPref) {
          channelSel.value = alertsChannelPref;
        }
      }

      if (pendingScrollSelector) {
        const needle = pendingScrollSelector.toLowerCase();
        pendingScrollSelector = null;
        const wsBody = main.querySelector("[data-ws-body]");
        if (wsBody) {
          const headings = wsBody.querySelectorAll("h3.portal-section-title, .portal-table-card > div:first-child");
          for (const h of headings) {
            if (String(h.textContent || "").toLowerCase().includes(needle)) {
              const card = h.closest(".portal-card") || h;
              card.scrollIntoView({ behavior: "smooth", block: "start" });
              break;
            }
          }
        }
      }

      if (tab === "dashboard") {
        // Trigger CRM header sub-tab if Todays Desk / KPI Alerts selected
      }

      main.querySelectorAll("[data-dash-subview]").forEach((b) => {
        b.addEventListener("click", () => {
          dashboardSubView = b.getAttribute("data-dash-subview") || "overview";
          replaceAdminHash(`#dashboard/${encodeURIComponent(dashboardSubView)}`);
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-adm-subview]").forEach((b) => {
        b.addEventListener("click", () => {
          admissionsSubView = b.getAttribute("data-adm-subview") || "leads";
          replaceAdminHash(`#admissions/${encodeURIComponent(admissionsSubView)}`);
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-users-subview]").forEach((b) => {
        b.addEventListener("click", () => {
          usersSubView = b.getAttribute("data-users-subview") || "directory";
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-pay-subview]").forEach((b) => {
        b.addEventListener("click", () => {
          paymentsSubView = b.getAttribute("data-pay-subview") || "all";
          replaceAdminHash(paymentsSubView === "fee_desk" ? "#payments/fee_desk" : "#payments");
          loadAndDraw();
        });
      });

      main.querySelectorAll("[data-dash-tab]").forEach((linkEl) => {
        linkEl.addEventListener("click", (e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
          e.preventDefault();
          const nextTab = linkEl.getAttribute("data-dash-tab") || "dashboard";
          const nextRole = linkEl.getAttribute("data-dash-role");
          const nextStatus = linkEl.getAttribute("data-dash-status");
          tab = VALID_ADMIN_TABS.has(nextTab) ? nextTab : "dashboard";
          activeAdminNavKey = "";
          if (nextRole !== null) userFilterRole = nextRole;
          if (nextStatus !== null) userFilterStatus = nextStatus;
          userPage = 1;
          selectedUserDetail = null;
          selectedChatDetail = null;
          editingCourse = null;
          selectedOfflineTest = null;
          const href = linkEl.getAttribute("href");
          if (href) replaceAdminHash(href);
          loadAndDraw();
        });
      });

      // Users handlers
      main.querySelectorAll("[data-v31-status-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          userStatusTab = btn.getAttribute("data-v31-status-tab") || "active";
          userPage = 1;
          loadAndDraw();
        });
      });
      main.querySelector("[data-admin-usearch]")?.addEventListener("change", (e) => {
        userSearch = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-urole]")?.addEventListener("change", (e) => {
        userFilterRole = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-admin-ustatus]")?.addEventListener("change", (e) => {
        userFilterStatus = e.target.value;
        userPage = 1;
        loadAndDraw();
      });
      main.querySelectorAll("[data-upage]").forEach((b) => {
        b.addEventListener("click", () => {
          userPage = Math.max(1, Number(b.getAttribute("data-upage")));
          loadAndDraw();
        });
      });
      main.querySelector("[data-toggle-new-user]")?.addEventListener("click", () => {
        showCreateUser = !showCreateUser;
        loadAndDraw().then(() => {
          if (showCreateUser) window.YuitorV31?.scrollToAndFocus("[data-create-user-panel]");
        });
      });
      const runAdminAction = async (fn, successMsg = "") => {
        try {
          await fn();
          if (successMsg) feedbackMsg = successMsg;
        } catch (err) {
          feedbackError = err?.message || "Action failed. Please check inputs and try again.";
        }
        loadAndDraw();
      };

      // Mail Folder handlers
      main.querySelectorAll("[data-mail-view]").forEach((b) => {
        b.addEventListener("click", () => {
          mailSubView = b.getAttribute("data-mail-view") || "inbox";
          selectedMailMsg = null;
          mailPage = 1;
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-mail-acct]").forEach((b) => {
        b.addEventListener("click", () => {
          mailAccountId = b.getAttribute("data-mail-acct") || "all";
          selectedMailMsg = null;
          mailPage = 1;
          loadAndDraw();
        });
      });
      main.querySelector("[data-mail-new-compose]")?.addEventListener("click", () => {
        composeDraft = {
          accountId: mailAccountId !== "all" ? String(mailAccountId) : "",
          to: "",
          cc: "",
          subject: "",
          text: "",
          inReplyTo: "",
        };
        mailSubView = "compose";
        loadAndDraw();
      });
      main.querySelector("[data-mail-search-form]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        mailSearch = String(new FormData(e.target).get("search") || "").trim();
        mailPage = 1;
        loadAndDraw();
      });
      main.querySelector("[data-mail-clear-search]")?.addEventListener("click", () => {
        mailSearch = "";
        mailPage = 1;
        loadAndDraw();
      });
      main.querySelectorAll("[data-mail-page]").forEach((b) => {
        b.addEventListener("click", () => {
          mailPage = Math.max(1, Number(b.getAttribute("data-mail-page") || 1));
          loadAndDraw();
        });
      });
      main.querySelector("[data-mail-sync-all]")?.addEventListener("click", async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        btn.textContent = "Syncing IMAP...";
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/mail/sync-all"), { method: "POST" });
          const failed = (res.results || []).filter((r) => !r.ok);
          const imported = Number(res.totalImported || 0);
          mailTestNotice = {
            ok: failed.length === 0,
            text:
              failed.length === 0
                ? `Inbox sync completed across ${(res.results || []).length} mailbox(es). ${imported} new email(s) imported.`
                : `Imported ${imported} email(s). Sync issue on: ${failed.map((f) => `${f.email} (${f.error})`).join("; ")}`,
          };
        });
      });
      main.querySelectorAll("[data-mail-open]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mail-open");
          await runAdminAction(async () => {
            const res = await api(adminApiUrl(`/mail/messages/${id}`));
            selectedMailMsg = res.message || null;
          });
        });
      });
      main.querySelector("[data-mail-close-reader]")?.addEventListener("click", () => {
        selectedMailMsg = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-mail-reply]").forEach((b) => {
        b.addEventListener("click", () => {
          if (!selectedMailMsg) return;
          const origSubj = String(selectedMailMsg.subject || "(No Subject)");
          composeDraft = {
            accountId: String(selectedMailMsg.account_id || ""),
            to: selectedMailMsg.direction === "outbound" ? selectedMailMsg.to_emails : selectedMailMsg.from_email,
            cc: "",
            subject: /^re:/i.test(origSubj) ? origSubj : `Re: ${origSubj}`,
            text: `\n\n--- On ${String(selectedMailMsg.mail_date || "").slice(0, 16)}, ${selectedMailMsg.from_email} wrote ---\n${selectedMailMsg.text_body || selectedMailMsg.snippet || ""}`,
            inReplyTo: selectedMailMsg.message_id || "",
          };
          mailSubView = "compose";
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-mail-forward]").forEach((b) => {
        b.addEventListener("click", () => {
          if (!selectedMailMsg) return;
          const origSubj = String(selectedMailMsg.subject || "(No Subject)");
          composeDraft = {
            accountId: String(selectedMailMsg.account_id || ""),
            to: "",
            cc: "",
            subject: /^fwd?:/i.test(origSubj) ? origSubj : `Fwd: ${origSubj}`,
            text: `\n\n--- Forwarded Message ---\nFrom: ${selectedMailMsg.from_email}\nTo: ${selectedMailMsg.to_emails}\nDate: ${String(selectedMailMsg.mail_date || "").slice(0, 16)}\n\n${selectedMailMsg.text_body || selectedMailMsg.snippet || ""}`,
            inReplyTo: "",
          };
          mailSubView = "compose";
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-mail-star]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mail-star");
          const star = b.getAttribute("data-star") === "1";
          await runAdminAction(async () => {
            await api(adminApiUrl(`/mail/messages/${id}`), { method: "PATCH", body: { isStarred: star } });
            if (selectedMailMsg && String(selectedMailMsg.id) === String(id)) {
              selectedMailMsg.is_starred = star ? 1 : 0;
            }
          });
        });
      });
      main.querySelectorAll("[data-mail-restore]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mail-restore");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/mail/messages/${id}`), { method: "PATCH", body: { folder: "inbox" } });
            selectedMailMsg = null;
          }, "Email restored to Inbox.");
        });
      });
      main.querySelectorAll("[data-mail-delete]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mail-delete");
          const perm = b.getAttribute("data-perm") === "1";
          await runAdminAction(async () => {
            await api(adminApiUrl(`/mail/messages/${id}${perm ? "?permanent=1" : ""}`), { method: "DELETE" });
            if (selectedMailMsg && String(selectedMailMsg.id) === String(id)) {
              selectedMailMsg = null;
            }
          }, perm ? "Email permanently deleted." : "Email moved to Trash.");
        });
      });
      main.querySelector("[data-mail-compose-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const btn = form.querySelector("[data-mail-send-btn]");
        if (btn) {
          btn.disabled = true;
          btn.textContent = "Sending...";
        }
        const fd = new FormData(form);
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/mail/send"), { method: "POST", body: fd });
          composeDraft = { accountId: "", to: "", cc: "", subject: "", text: "", inReplyTo: "" };
          mailSubView = "sent";
          feedbackMsg = `Email sent cleanly from ${res.fromEmail} (Message ID: ${res.messageId}).`;
        });
      });
      main.querySelector("[data-toggle-bulk-pwd]")?.addEventListener("click", (e) => {
        const inp = main.querySelector("[data-bulk-pwd-input]");
        if (!inp) return;
        const show = inp.type === "password";
        inp.type = show ? "text" : "password";
        e.currentTarget.textContent = show ? "Hide" : "Show";
      });
      main.querySelector("[data-mail-bulk-pwd-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const password = String(new FormData(form).get("password") || "");
        const accountIds = Array.from(form.querySelectorAll('input[name="accountIds"]:checked')).map((el) => Number(el.value));
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/mail/accounts/bulk-password"), {
            method: "POST",
            body: { password, accountIds },
          });
          mailTestNotice = {
            ok: true,
            text: `Encrypted password saved for ${res.updatedCount} mailbox(es). Click Test SMTP+IMAP or Sync All Inboxes next.`,
          };
        }, "Encrypted password saved for selected mailboxes.");
      });
      main.querySelectorAll("[data-mb-test]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mb-test");
          b.disabled = true;
          b.textContent = "Testing...";
          try {
            const res = await api(adminApiUrl(`/mail/accounts/${id}/test`), { method: "POST" });
            mailTestNotice = { ok: true, text: `${res.smtp?.detail || "SMTP OK"} · ${res.imap?.detail || "IMAP OK"}` };
          } catch (err) {
            const d = err?.data;
            mailTestNotice = {
              ok: false,
              text: d?.smtp && d?.imap ? `SMTP: ${d.smtp.detail} | IMAP: ${d.imap.detail}` : err?.message || "Connection test failed.",
            };
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-mb-sync]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mb-sync");
          b.disabled = true;
          b.textContent = "Syncing...";
          await runAdminAction(async () => {
            const res = await api(adminApiUrl(`/mail/accounts/${id}/sync`), { method: "POST" });
            mailTestNotice = { ok: true, text: `Synced mailbox INBOX: ${res.imported || 0} new message(s) imported.` };
          });
        });
      });
      main.querySelectorAll("[data-mb-default]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mb-default");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/mail/accounts/${id}`), { method: "PATCH", body: { isDefault: true } });
          }, "Default sender mailbox updated.");
        });
      });
      main.querySelectorAll("[data-mb-edit]").forEach((b) => {
        b.addEventListener("click", () => {
          const id = Number(b.getAttribute("data-mb-edit"));
          editingMailbox = mailAccountsList.find((a) => Number(a.id) === id) || null;
          loadAndDraw();
        });
      });
      main.querySelector("[data-mb-cancel-edit]")?.addEventListener("click", () => {
        editingMailbox = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-mb-del]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = b.getAttribute("data-mb-del");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/mail/accounts/${id}`), { method: "DELETE" });
            if (editingMailbox && String(editingMailbox.id) === String(id)) editingMailbox = null;
          }, "Mailbox deleted.");
        });
      });
      main.querySelector("[data-mail-account-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const editId = form.getAttribute("data-mail-account-form");
        const fd = new FormData(form);
        const payload = {
          email: fd.get("email"),
          displayName: fd.get("displayName"),
          password: fd.get("password") || undefined,
          smtpHost: fd.get("smtpHost"),
          smtpPort: Number(fd.get("smtpPort") || 465),
          smtpSecure: fd.get("smtpSecure") === "true",
          smtpUser: fd.get("smtpUser") || undefined,
          imapHost: fd.get("imapHost"),
          imapPort: Number(fd.get("imapPort") || 993),
          imapSecure: fd.get("imapSecure") === "true",
          imapUser: fd.get("imapUser") || undefined,
          isDefault: Boolean(fd.get("isDefault")),
        };
        await runAdminAction(async () => {
          if (editId) {
            await api(adminApiUrl(`/mail/accounts/${editId}`), { method: "PATCH", body: payload });
            editingMailbox = null;
          } else {
            await api(adminApiUrl("/mail/accounts"), { method: "POST", body: payload });
          }
        }, editId ? "Mailbox updated cleanly." : "New mailbox added cleanly.");
      });

      const createRoleSel = main.querySelector("[data-admin-create-role]");
      if (createRoleSel) {
        const syncRoleFields = () => {
          const r = createRoleSel.value;
          main.querySelectorAll("[data-cu-only]").forEach((el) => {
            el.hidden = !String(el.getAttribute("data-cu-only") || "").split(",").includes(r);
          });
        };
        createRoleSel.addEventListener("change", syncRoleFields);
        syncRoleFields();
      }
      main.querySelector("[data-admin-create-user]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const role = fd.get("role");
        const perms = Array.from(e.target.querySelectorAll('input[name="permissions"]:checked')).map((el) => el.value);
        await runAdminAction(async () => {
          await api(adminApiUrl("/users"), {
            method: "POST",
            body: {
              role,
              fullName: fd.get("fullName"),
              email: fd.get("email"),
              phone: fd.get("phone"),
              password: fd.get("password"),
              branchId: fd.get("branchId") ? Number(fd.get("branchId")) : undefined,
              classLevel: role === "student" ? fd.get("extra") || "Class 10" : undefined,
              parentPhone: role === "student" ? fd.get("parentPhone") || "" : undefined,
              qualification: role === "teacher" ? fd.get("extra") || "" : undefined,
              studentId: role === "parent" && fd.get("studentId") ? Number(fd.get("studentId")) : undefined,
              relation: role === "parent" ? fd.get("relation") || "Parent / Guardian" : undefined,
              staffRole: role === "staff" ? fd.get("staffRole") || "coordinator" : undefined,
              permissions: role === "staff" ? perms : undefined,
            },
          });
          showCreateUser = false;
        }, "User created & approved successfully.");
      });
      main.querySelector("[data-parent-link-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          await api(adminApiUrl("/parents/link"), {
            method: "POST",
            body: {
              parentId: Number(fd.get("parentId")),
              studentId: Number(fd.get("studentId")),
              relation: fd.get("relation") || "Parent / Guardian",
            },
          });
        }, "Parent linked to student.");
      });
      // Dashboard Recent Audit Activity toggle & pagination
      main.querySelector("[data-toggle-audit-activity]")?.addEventListener("click", () => {
        auditVisible = !auditVisible;
        loadAndDraw();
      });
      main.querySelectorAll("[data-audit-page]").forEach((b) => {
        b.addEventListener("click", () => {
          auditPage = Math.max(1, Number(b.getAttribute("data-audit-page") || 1));
          loadAndDraw();
        });
      });

      // Collapsible Accordions (OTP Summary, Account Audit History)
      main.querySelectorAll("[data-accordion-toggle]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const acc = btn.closest("[data-accordion]");
          const body = acc?.querySelector(".portal-accordion-body");
          if (!acc || !body) return;
          const willShow = body.hidden;
          body.hidden = !willShow;
          acc.classList.toggle("is-open", willShow);
          btn.textContent = willShow ? "Hide" : "Show";
        });
      });

      // Users Role Sub-Tabs
      main.querySelectorAll("[data-user-role-tab]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const rk = btn.getAttribute("data-user-role-tab") || "all";
          userFilterRole = rk;
          userPage = 1;
          activeAdminNavKey = rk === "teacher" ? "users-teachers" : rk === "parent" ? "users-parents" : rk === "staff" ? "users-staff" : rk === "student" ? "users-students" : "";
          replaceAdminHash(`#users?role=${encodeURIComponent(rk)}`);
          loadAndDraw();
        });
      });

      // Users Row Real Actions: Mail Composer, One-Click Mail, One-Click Invoice, Safe Delete
      const showInvoiceResultModal = (res) => {
        const viewUrl = res.invoicePath ? adminApiUrl(res.invoicePath) : "";
        openInAppModal({
          title: `Invoice Ready · ${res.invoiceNumber || "Generated"}`,
          bodyHtml: `
            <div class="portal-personal-grid" style="margin-bottom:14px;">
              <div class="portal-detail"><span>Invoice Number</span><strong>${escapeHtml(res.invoiceNumber || "-")}</strong></div>
              <div class="portal-detail"><span>Fee Plan</span><strong>${escapeHtml(res.title || "-")}</strong></div>
              <div class="portal-detail"><span>Subtotal</span><strong>${formatINR(res.subtotal || 0)}</strong></div>
              <div class="portal-detail"><span>Discount</span><strong>${formatINR(res.discountAmount || 0)}</strong></div>
              <div class="portal-detail"><span>Net Payable</span><strong>${formatINR(res.netPayable || 0)}</strong></div>
              <div class="portal-detail"><span>Balance Due</span><strong>${formatINR(res.balanceDue || 0)}</strong></div>
            </div>
            <div class="portal-message portal-message--success">${escapeHtml(res.message || "Invoice generated cleanly.")}</div>
            <div class="portal-actions" style="justify-content:flex-end;">
              ${viewUrl ? `<a href="${escAttr(viewUrl)}" target="_blank" rel="noopener noreferrer" class="portal-button portal-button--small">Open / Print Invoice</a>` : ""}
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-inv-close>Close</button>
            </div>`,
          onMount: (backdrop, close) => {
            backdrop.querySelector("[data-inv-close]")?.addEventListener("click", close);
          },
        });
      };

      const openComposeMailModal = ({ uid, email, name }) => {
        openInAppModal({
          title: `Send Email to ${name}`,
          bodyHtml: `
            <form class="portal-form" data-v3-compose-mail-form>
              <div class="portal-field"><label>Recipient Email</label><input type="email" value="${escAttr(email)}" readonly></div>
              <div class="portal-field"><label>Subject *</label><input name="subject" required value="Important Update from Yuitor Smart Classes"></div>
              <div class="portal-field"><label>Message *</label><textarea name="message" rows="5" required>Dear ${escapeHtml(name)},\n\nGreetings from Yuitor Smart Classes.\n\nRegards,\nYuitor Smart Classes Team</textarea></div>
              <div class="portal-message portal-message--error" data-cm-err hidden></div>
              <div class="portal-message portal-message--success" data-cm-ok hidden></div>
              <div class="portal-actions" style="justify-content:flex-end;">
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-cm-cancel>Cancel</button>
                <button type="submit" class="portal-button portal-button--small" data-cm-send>Send via SMTP</button>
              </div>
            </form>`,
          onMount: (backdrop, close) => {
            backdrop.querySelector("[data-cm-cancel]")?.addEventListener("click", close);
            backdrop.querySelector("[data-v3-compose-mail-form]")?.addEventListener("submit", async (e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              const errEl = backdrop.querySelector("[data-cm-err]");
              const okEl = backdrop.querySelector("[data-cm-ok]");
              const sendBtn = backdrop.querySelector("[data-cm-send]");
              if (errEl) errEl.hidden = true;
              if (okEl) okEl.hidden = true;
              if (sendBtn) {
                sendBtn.disabled = true;
                sendBtn.textContent = "Sending...";
              }
              try {
                const res = await api(adminApiUrl(`/users/${uid}/one-click-mail`), {
                  method: "POST",
                  body: {
                    subject: String(fd.get("subject") || "").trim(),
                    message: String(fd.get("message") || "").trim(),
                  },
                });
                if (okEl) {
                  okEl.textContent = res.message || `Email sent to ${email}.`;
                  okEl.hidden = false;
                }
                window.YuitorUI?.Toast?.success(res.message || `Email sent to ${email}.`);
                setTimeout(close, 900);
              } catch (err) {
                if (errEl) {
                  errEl.textContent = err?.message || "Failed to send email. Verify SMTP settings.";
                  errEl.hidden = false;
                }
              } finally {
                if (sendBtn) {
                  sendBtn.disabled = false;
                  sendBtn.textContent = "Send via SMTP";
                }
              }
            });
          },
        });
      };

      const triggerOneClickMail = async (uid) => {
        await runAdminAction(async () => {
          const res = await api(adminApiUrl(`/users/${uid}/one-click-mail`), { method: "POST", body: {} });
          feedbackMsg = res.message || "Quick email sent via SMTP.";
          window.YuitorUI?.Toast?.success(feedbackMsg);
        });
      };

      const triggerOneClickInvoice = async (uid) => {
        try {
          const res = await api(adminApiUrl(`/users/${uid}/one-click-invoice`), { method: "POST", body: {} });
          showInvoiceResultModal(res);
          window.YuitorUI?.Toast?.success(res.message || "Invoice generated cleanly.");
        } catch (err) {
          feedbackError = err?.message || "Could not generate invoice.";
          window.YuitorUI?.Toast?.error(feedbackError);
          loadAndDraw();
        }
      };

      const confirmV31 = async (opts) => {
        if (window.YuitorV31?.confirmModal) return window.YuitorV31.confirmModal(opts);
        return true;
      };

      const openConfirmDeleteModal = async ({ uid, name, role }) => {
        const ok = await confirmV31({
          title: "Confirm Soft Delete (Recoverable)",
          message: `Soft-delete ${name} (${role})? Their active sessions will be logged out immediately and their record will move to the "Others" tab where you can Restore it anytime.`,
          confirmLabel: "Yes, Soft Delete",
          variant: "danger",
        });
        if (!ok) return;
        await runAdminAction(async () => {
          const res = await api(adminApiUrl(`/users/${uid}`), { method: "DELETE" });
          selectedUserDetail = null;
          feedbackMsg = res.message || `Soft-deleted ${name}.`;
          window.YuitorUI?.Toast?.success(feedbackMsg);
        });
      };

      const triggerImpersonateUser = async (uid) => {
        const reason = await openPromptModal({
          title: "Start Troubleshooting Session",
          label: "Reason for impersonation (min 4 characters)",
          defaultValue: "Support check",
          minLength: 4,
        });
        if (!reason || reason.trim().length < 4) return;
        try {
          const res = await api(adminApiUrl("/impersonate"), { method: "POST", body: { userId: Number(uid), reason } });
          window.location.assign(res.redirectTo || "/student/");
        } catch (err) {
          feedbackError = err?.message || "Unable to start impersonation session.";
          loadAndDraw();
        }
      };

      const openUserProfileById = async (uid) => {
        if (!uid) return;
        await runAdminAction(async () => {
          selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
        });
      };

      // Change [11]: Manage button directly opens Manage -> User Details (no table-row dropdown)
      main.querySelectorAll("[data-user-manage]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          const uid = Number(btn.getAttribute("data-user-manage"));
          if (uid) openUserProfileById(uid);
        });
      });

      main.querySelector("[data-class-invoice-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const sid = fd.get("studentId");
        const classNumber = Number(fd.get("classNumber") || 10);
        const billingCycle = String(fd.get("billingCycle") || "1m");
        if (!sid) return;
        try {
          const res = await api(adminApiUrl(`/users/${sid}/one-click-invoice`), {
            method: "POST",
            body: { classNumber, billingCycle },
          });
          showInvoiceResultModal(res);
        } catch (err) {
          feedbackError = err?.message || "Unable to generate class-wise invoice.";
          loadAndDraw();
        }
      });

      main.querySelectorAll("[data-u-compose-mail]").forEach((btn) => {
        btn.addEventListener("click", () => {
          openComposeMailModal({
            uid: btn.getAttribute("data-u-compose-mail"),
            email: btn.getAttribute("data-u-email") || "",
            name: btn.getAttribute("data-u-name") || "User",
          });
        });
      });
      main.querySelectorAll("[data-u-quick-mail]").forEach((btn) => {
        btn.addEventListener("click", () => triggerOneClickMail(btn.getAttribute("data-u-quick-mail")));
      });
      main.querySelectorAll("[data-u-quick-invoice]").forEach((btn) => {
        btn.addEventListener("click", () => triggerOneClickInvoice(btn.getAttribute("data-u-quick-invoice")));
      });
      main.querySelectorAll("[data-u-delete]").forEach((btn) => {
        btn.addEventListener("click", () => {
          openConfirmDeleteModal({
            uid: btn.getAttribute("data-u-delete"),
            name: btn.getAttribute("data-u-name") || "this user",
            role: btn.getAttribute("data-u-role") || "user",
          });
        });
      });
      main.querySelectorAll("[data-view-uid]").forEach((b) => {
        b.addEventListener("click", () => openUserProfileById(b.getAttribute("data-view-uid")));
      });
      main.querySelector("[data-back-users]")?.addEventListener("click", () => {
        selectedUserDetail = null;
        loadAndDraw();
      });
      main.querySelector("[data-edit-user-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const uid = e.target.getAttribute("data-edit-user-form");
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          await api(adminApiUrl(`/users/${uid}`), {
            method: "PATCH",
            body: {
              fullName: fd.get("fullName"),
              email: fd.get("email"),
              phone: fd.get("phone"),
              studentProfile: fd.has("classLevel")
                ? { classLevel: fd.get("classLevel"), board: fd.get("board"), courseDurationMonths: Number(fd.get("courseDurationMonths") || 12) }
                : undefined,
              teacherProfile: fd.has("qualification")
                ? { qualification: fd.get("qualification"), experienceYears: Number(fd.get("experienceYears") || 0) }
                : undefined,
            },
          });
          selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
        }, "Account changes saved.");
      });
      main.querySelector("[data-staff-perm-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const uid = e.target.getAttribute("data-staff-perm-form");
        const fd = new FormData(e.target);
        const permissions = Array.from(e.target.querySelectorAll('input[name="permissions"]:checked')).map((el) => el.value);
        await runAdminAction(async () => {
          await api(adminApiUrl(`/users/${uid}/staff-permissions`), {
            method: "PATCH",
            body: {
              staffRole: fd.get("staffRole") || "coordinator",
              branchId: fd.get("branchId") ? Number(fd.get("branchId")) : null,
              permissions,
            },
          });
          selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
        }, "Staff role & permissions updated.");
      });
      main.querySelectorAll("[data-v31-restore-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-v31-restore-uid");
          const uname = b.getAttribute("data-u-name") || "this user";
          const ok = await confirmV31({
            title: "Restore Soft-Deleted Account",
            message: `Restore ${uname} back to Active status?`,
            confirmLabel: "Yes, Restore",
            variant: "success",
          });
          if (!ok) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/v31/users/${uid}/restore`), { method: "POST" });
            selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
          }, `${uname} restored successfully.`);
        });
      });
      main.querySelectorAll("[data-user-act]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-uid");
          const action = b.getAttribute("data-user-act");
          const uname = b.getAttribute("data-u-name") || "this user";
          let reason = "";
          let note = "";
          if (action === "suspend" || action === "terminate") {
            const res = await confirmV31({
              title: action === "terminate" ? `Terminate ${uname}` : `Suspend ${uname}`,
              message: `This will immediately log out ${uname}, block login, move them to the ${action === "terminate" ? "Terminated" : "Suspended"} tab, and automatically email them the reason and next steps.`,
              confirmLabel: action === "terminate" ? "Yes, Terminate & Send Mail" : "Yes, Suspend & Send Mail",
              variant: action === "terminate" ? "danger" : "warning",
              requireReason: true,
              requireNote: true,
            });
            if (!res || !res.confirmed) return;
            reason = res.reason || "";
            note = res.note || "";
          } else {
            const ok = await confirmV31({
              title: `Confirm Account ${action.charAt(0).toUpperCase() + action.slice(1)}`,
              message: `Proceed with "${action}" for ${uname}?`,
              confirmLabel: `Yes, ${action.charAt(0).toUpperCase() + action.slice(1)}`,
              variant: action === "reject" ? "danger" : "primary",
            });
            if (!ok) return;
          }
          await runAdminAction(async () => {
            await api(adminApiUrl(`/users/${uid}/status`), { method: "POST", body: { action, reason, note } });
            if (selectedUserDetail) selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
          }, `Account ${action} completed.`);
        });
      });
      main.querySelectorAll("[data-resume-review]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = b.getAttribute("data-uid");
          const status = b.getAttribute("data-resume-review");
          const notes = main.querySelector("[data-resume-note-input]")?.value || "";
          await runAdminAction(async () => {
            await api(adminApiUrl(`/users/${uid}/resume-review`), { method: "POST", body: { status, notes } });
            if (selectedUserDetail) selectedUserDetail = await api(adminApiUrl(`/users/${uid}`));
          }, status === "verified" ? "Teacher resume marked verified." : "Resume re-upload requested.");
        });
      });
      main.querySelectorAll("[data-impersonate-uid]").forEach((b) => {
        b.addEventListener("click", async () => {
          const uid = Number(b.getAttribute("data-impersonate-uid"));
          const reason = await openPromptModal({
            title: "Start Troubleshooting Session",
            label: "Reason for impersonation (min 4 characters)",
            defaultValue: "Support check",
            minLength: 4,
          });
          if (reason.trim().length < 4) return;
          try {
            const res = await api(adminApiUrl("/impersonate"), { method: "POST", body: { userId: uid, reason } });
            window.location.assign(res.redirectTo || "/student/");
          } catch (err) {
            feedbackError = err.message;
            loadAndDraw();
          }
        });
      });

      // Courses & Subjects
      main.querySelector("[data-new-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/courses"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Course created.");
      });
      main.querySelector("[data-edit-course-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        const cid = formEl.getAttribute("data-edit-course-form");
        const ok = await confirmV31({ title: "Save Course Changes", message: "Save updates to this course?", confirmLabel: "Yes, Save" });
        if (!ok) return;
        await runAdminAction(async () => {
          await api(adminApiUrl(`/courses/${cid}`), { method: "PATCH", body: Object.fromEntries(new FormData(formEl).entries()) });
          editingCourse = null;
        }, "Course updated.");
      });
      main.querySelector("[data-cancel-edit-course]")?.addEventListener("click", () => {
        editingCourse = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-course]").forEach((b) => {
        b.addEventListener("click", () => {
          const cid = Number(b.getAttribute("data-edit-course"));
          editingCourse = (coursesRes.courses || []).find((c) => Number(c.id) === cid) || null;
          loadAndDraw().then(() => window.YuitorV31?.scrollToAndFocus("[data-edit-course-form]"));
        });
      });
      main.querySelectorAll("[data-del-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Course", message: "Are you sure you want to delete this course?", confirmLabel: "Yes, Delete", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/courses/${b.getAttribute("data-del-course")}`), { method: "DELETE" });
          }, "Course deleted.");
        });
      });
      main.querySelector("[data-new-subject-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/subjects"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Subject added.");
      });
      main.querySelectorAll("[data-del-subject]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Subject", message: "Are you sure you want to remove this subject?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/subjects/${b.getAttribute("data-del-subject")}`), { method: "DELETE" });
          }, "Subject removed.");
        });
      });

      // Academics: Branches, Batches & Timetable
      main.querySelector("[data-branch-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/branches"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Branch added.");
      });
      main.querySelectorAll("[data-del-branch]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Branch", message: "Are you sure you want to delete this branch?", confirmLabel: "Yes, Delete", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/branches/${b.getAttribute("data-del-branch")}`), { method: "DELETE" });
          }, "Branch deleted.");
        });
      });
      main.querySelector("[data-batch-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/batches"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Batch created.");
      });
      main.querySelectorAll("[data-del-batch]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Batch", message: "Are you sure you want to delete this batch?", confirmLabel: "Yes, Delete", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/batches/${b.getAttribute("data-del-batch")}`), { method: "DELETE" });
          }, "Batch deleted.");
        });
      });
      main.querySelector("[data-timetable-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/timetable"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Timetable slot added.");
      });
      main.querySelectorAll("[data-del-slot]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Timetable Slot", message: "Confirm removing this timetable slot?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/timetable/${b.getAttribute("data-del-slot")}`), { method: "DELETE" });
          }, "Timetable slot removed.");
        });
      });

      // Offline Tests, Rank Lists & Attendance Reports
      main.querySelector("[data-offline-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/offline-tests"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Offline test created.");
      });
      main.querySelectorAll("[data-open-test-marks]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            selectedOfflineTest = await api(adminApiUrl(`/offline-tests/${b.getAttribute("data-open-test-marks")}/marks`));
          });
        });
      });
      main.querySelector("[data-close-test-marks]")?.addEventListener("click", () => {
        selectedOfflineTest = null;
        loadAndDraw();
      });
      main.querySelector("[data-save-test-marks-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const tid = e.target.getAttribute("data-save-test-marks-form");
        const rows = Array.from(e.target.querySelectorAll("[data-mark-row]")).map((tr) => ({
          studentId: Number(tr.getAttribute("data-mark-row")),
          marksObtained: Number(tr.querySelector('input[name="marks"]')?.value || 0),
          isAbsent: Boolean(tr.querySelector('input[name="absent"]')?.checked),
          remarks: tr.querySelector('input[name="remarks"]')?.value || "",
        }));
        await runAdminAction(async () => {
          await api(adminApiUrl(`/offline-tests/${tid}/marks`), { method: "POST", body: { marks: rows } });
          selectedOfflineTest = await api(adminApiUrl(`/offline-tests/${tid}/marks`));
        }, "Marks saved & class rank list recalculated.");
      });
      main.querySelector("[data-att-filter-form]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        attFilterCourse = String(fd.get("courseId") || "");
        attFilterFrom = String(fd.get("from") || "");
        attFilterTo = String(fd.get("to") || "");
        loadAndDraw();
      });

      // Payments & Installments
      main.querySelector("[data-coupon-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/coupons"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Discount coupon created.");
      });
      main.querySelectorAll("[data-pay-verify]").forEach((b) => {
        b.addEventListener("click", async () => {
          const dec = b.getAttribute("data-dec");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/payments/${b.getAttribute("data-pay-verify")}/verify`), { method: "POST", body: { decision: dec } });
          }, dec === "verify" ? "Payment verified & receipt generated." : "Payment marked rejected.");
        });
      });
      main.querySelectorAll("[data-pay-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/payments/${b.getAttribute("data-pay-refund")}/refund`), { method: "POST" });
          }, "Payment refund processed.");
        });
      });
      main.querySelector("[data-gen-inst-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          await api(adminApiUrl("/fee-installments/generate"), {
            method: "POST",
            body: {
              feeRecordId: Number(fd.get("feeRecordId")),
              installmentsCount: Number(fd.get("installmentsCount") || 3),
              firstDueDate: fd.get("firstDueDate"),
            },
          });
        }, "EMI installment plan generated.");
      });
      main.querySelectorAll("[data-pay-inst]").forEach((b) => {
        b.addEventListener("click", async () => {
          const iid = b.getAttribute("data-pay-inst");
          const method = b.getAttribute("data-method") || "cash";
          await runAdminAction(async () => {
            const r = await api(adminApiUrl(`/fee-installments/${iid}/pay`), { method: "POST", body: { paymentMethod: method } });
            feedbackMsg = `Installment recorded (${method.toUpperCase()} · Receipt ${r.receiptNumber}).`;
          });
        });
      });
      main.querySelector("[data-send-fee-reminders]")?.addEventListener("click", async () => {
        const sendSms = Boolean(main.querySelector('input[name="remSendSms"]')?.checked);
        const sendWhatsApp = Boolean(main.querySelector('input[name="remSendWa"]')?.checked);
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/fee-installments/send-reminders"), { method: "POST", body: { sendSms, sendWhatsApp } });
          lastFeeReminderWaLinks = res.waLinks || [];
          feedbackMsg = `Processed ${res.remindersProcessed} due installments (${res.inAppSent} in-app, ${res.smsSent} SMS, ${res.waSent} WhatsApp API).`;
        });
      });

      // Finance: Leave Requests, Payouts & Expenses
      main.querySelectorAll("[data-leave-review]").forEach((b) => {
        b.addEventListener("click", async () => {
          const lid = b.getAttribute("data-leave-review");
          const status = b.getAttribute("data-st");
          const noteInput = main.querySelector(`[data-leave-note="${CSS.escape(lid || "")}"]`);
          await runAdminAction(async () => {
            await api(adminApiUrl(`/leave-requests/${lid}/review`), { method: "POST", body: { status, adminNote: noteInput?.value || "" } });
          }, `Leave request ${status}.`);
        });
      });
      main.querySelector("[data-payout-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/teacher-payouts"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Teacher salary payout queued.");
      });
      main.querySelectorAll("[data-payout-paid]").forEach((b) => {
        b.addEventListener("click", async () => {
          const pid = b.getAttribute("data-payout-paid");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/teacher-payouts/${pid}/mark-paid`), { method: "POST", body: { paymentMethod: "upi" } });
          }, "Salary marked paid & teacher notified.");
        });
      });
      main.querySelector("[data-expense-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/expenses"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Expense recorded.");
      });
      main.querySelectorAll("[data-del-expense]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Expense", message: "Confirm deleting this expense record?", confirmLabel: "Yes, Delete", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/expenses/${b.getAttribute("data-del-expense")}`), { method: "DELETE" });
          }, "Expense removed.");
        });
      });

      // Library
      main.querySelector("[data-lib-book-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/library/books"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Study material / book added to inventory.");
      });
      main.querySelector("[data-lib-issue-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/library/issues"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Study material issued to student.");
      });
      main.querySelectorAll("[data-lib-return]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/library/issues/${b.getAttribute("data-lib-return")}/return`), { method: "POST" });
          }, "Book marked returned.");
        });
      });

      // Bulk Alerts
      main.querySelector("[data-bulk-alert-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        if (!(await confirmV31({ title: "Confirm Bulk Alert Dispatch", message: "Send this bulk alert to all matching recipients now?", confirmLabel: "Yes, Send Alert", variant: "warning" }))) return;
        const formEl = e.target;
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/alerts/send"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
          lastAlertWaLinks = res.waLinks || [];
          feedbackMsg = `Alert dispatched to ${res.totalRecipients} recipient(s) via ${res.channel}.`;
        });
      });

      // Inquiries & CMS
      main.querySelectorAll("[data-inq-status]").forEach((sel) => {
        sel.addEventListener("change", async () => {
          await runAdminAction(async () => {
            await api(adminApiUrl(`/inquiries/${sel.getAttribute("data-inq-status")}`), { method: "PATCH", body: { status: sel.value } });
          }, "Inquiry status updated.");
        });
      });
      main.querySelectorAll("[data-inq-save]").forEach((b) => {
        b.addEventListener("click", async () => {
          const qid = b.getAttribute("data-inq-save");
          const row = b.closest("tr");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/inquiries/${qid}`), {
              method: "PATCH",
              body: {
                status: row?.querySelector("[data-inq-status]")?.value || "contacted",
                followUpDate: row?.querySelector("[data-inq-fdate]")?.value || "",
                followUpNotes: row?.querySelector("[data-inq-fnotes]")?.value || "",
              },
            });
          }, "Inquiry follow-up saved.");
        });
      });
      main.querySelectorAll("[data-inq-convert]").forEach((b) => {
        b.addEventListener("click", async () => {
          const qid = b.getAttribute("data-inq-convert");
          await runAdminAction(async () => {
            const out = await api(adminApiUrl(`/crm/leads/${qid}/convert`), { method: "POST", body: {} });
            feedbackMsg = `Converted inquiry to Student #${out.studentId} (Roll: ${out.rollNumber}${out.waitlisted ? ", Added to Waitlist" : ""}).`;
          });
        });
      });
      main.querySelectorAll("[data-wl-promote]").forEach((b) => {
        b.addEventListener("click", async () => {
          const wid = b.getAttribute("data-wl-promote");
          await runAdminAction(async () => {
            const out = await api(adminApiUrl(`/crm/waitlist/${wid}/promote`), { method: "POST", body: {} });
            feedbackMsg = out.message || "Student promoted from waitlist!";
          });
        });
      });
      main.querySelectorAll("[data-wl-del]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove From Waitlist", message: "Confirm removing this entry from waitlist?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          const wid = b.getAttribute("data-wl-del");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/crm/waitlist/${wid}`), { method: "DELETE" });
          }, "Removed from waitlist.");
        });
      });
      main.querySelectorAll("[data-del-inq]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Delete Inquiry", message: "Confirm deleting this inquiry?", confirmLabel: "Yes, Delete", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/inquiries/${b.getAttribute("data-del-inq")}`), { method: "DELETE" });
          }, "Inquiry deleted.");
        });
      });
      main.querySelector("[data-topper-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/toppers"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Topper added to website CMS.");
      });
      main.querySelectorAll("[data-del-topper]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Topper", message: "Confirm removing this topper from CMS?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/toppers/${b.getAttribute("data-del-topper")}`), { method: "DELETE" });
          }, "Topper removed.");
        });
      });
      main.querySelector("[data-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/announcements"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Notice published.");
      });
      main.querySelectorAll("[data-del-ann]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Notice", message: "Confirm removing this notice?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/announcements/${b.getAttribute("data-del-ann")}`), { method: "DELETE" });
          }, "Notice removed.");
        });
      });
      main.querySelector("[data-banner-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/banners"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Banner added.");
      });
      main.querySelectorAll("[data-del-banner]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Banner", message: "Confirm removing this banner?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/banners/${b.getAttribute("data-del-banner")}`), { method: "DELETE" });
          }, "Banner removed.");
        });
      });
      main.querySelector("[data-blog-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/blog"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Blog article published.");
      });
      main.querySelectorAll("[data-del-blog]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Blog Article", message: "Confirm removing this article?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/blog/${b.getAttribute("data-del-blog")}`), { method: "DELETE" });
          }, "Article removed.");
        });
      });
      main.querySelector("[data-faq-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/faqs"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "FAQ added.");
      });
      main.querySelectorAll("[data-del-faq]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove FAQ", message: "Confirm removing this FAQ?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/faqs/${b.getAttribute("data-del-faq")}`), { method: "DELETE" });
          }, "FAQ removed.");
        });
      });
      main.querySelector("[data-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runAdminAction(async () => {
          await api(adminApiUrl("/cms/testimonials"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Testimonial added.");
      });
      main.querySelectorAll("[data-del-test]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Testimonial", message: "Confirm removing this testimonial?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/cms/testimonials/${b.getAttribute("data-del-test")}`), { method: "DELETE" });
          }, "Testimonial removed.");
        });
      });

      // Chatbot handlers
      main.querySelector("[data-chat-search]")?.addEventListener("change", (e) => {
        chatSearch = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-status-filter]")?.addEventListener("change", (e) => {
        chatFilterStatus = e.target.value;
        loadAndDraw();
      });
      main.querySelector("[data-chat-rating-filter]")?.addEventListener("change", (e) => {
        chatMinRating = Number(e.target.value || 0);
        loadAndDraw();
      });
      main.querySelectorAll("[data-open-chat]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runAdminAction(async () => {
            selectedChatDetail = await api(adminApiUrl(`/chatbot/${encodeURIComponent(b.getAttribute("data-open-chat"))}`));
          });
        });
      });
      main.querySelector("[data-chat-back]")?.addEventListener("click", () => {
        selectedChatDetail = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-chat-status]").forEach((b) => {
        b.addEventListener("click", async () => {
          const cid = b.getAttribute("data-chat-status");
          await runAdminAction(async () => {
            await api(adminApiUrl(`/chatbot/${encodeURIComponent(cid)}`), { method: "PATCH", body: { status: b.getAttribute("data-st") } });
            selectedChatDetail = await api(adminApiUrl(`/chatbot/${encodeURIComponent(cid)}`));
          }, "Conversation status updated.");
        });
      });
      main.querySelector("[data-knowledge-upload-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runAdminAction(async () => {
          const upRes = await api(adminApiUrl("/knowledge-docs"), { method: "POST", body: fd });
          feedbackMsg = `Document "${upRes.doc?.title || "Knowledge Doc"}" indexed (${upRes.doc?.char_count || 0} chars) for Shreya AI.`;
        });
      });
      main.querySelectorAll("[data-del-kdoc]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (!(await confirmV31({ title: "Remove Knowledge Document", message: "Confirm removing this knowledge document?", confirmLabel: "Yes, Remove", variant: "danger" }))) return;
          await runAdminAction(async () => {
            await api(adminApiUrl(`/knowledge-docs/${b.getAttribute("data-del-kdoc")}`), { method: "DELETE" });
          }, "Knowledge document removed.");
        });
      });

      // Marketing handlers
      const mktForm = main.querySelector("[data-mkt-form]");
      const buildMktFilters = () => {
        const fd = new FormData(mktForm);
        const selectedUserIds = Array.from(mktForm.querySelectorAll('input[name="selectedUid"]:checked')).map((el) => Number(el.value));
        return {
          audienceGroup: fd.get("audienceGroup"),
          accountStatus: fd.get("accountStatus"),
          classLevel: String(fd.get("classLevel") || "").trim() || undefined,
          subject: String(fd.get("subjectFilter") || "").trim() || undefined,
          courseId: fd.get("courseId") ? Number(fd.get("courseId")) : undefined,
          registeredAfter: fd.get("registeredAfter") || undefined,
          selectedUserIds: selectedUserIds.length ? selectedUserIds : undefined,
        };
      };
      if (mktForm) {
        main.querySelector("[data-mkt-tmpl]")?.addEventListener("change", (e) => {
          const t = (mktRes.templates || []).find((x) => String(x.id) === e.target.value);
          if (t) {
            mktForm.querySelector('[name="subject"]').value = t.subject;
            mktForm.querySelector('[name="previewText"]').value = t.preview_text || "";
            mktForm.querySelector('[name="htmlBody"]').value = t.html_body;
          }
        });
        main.querySelector("[data-mkt-check]")?.addEventListener("click", async () => {
          const box = main.querySelector("[data-mkt-preview]");
          try {
            const pv = await api(adminApiUrl("/marketing/preview-recipients"), { method: "POST", body: { filters: buildMktFilters() } });
            box.className = "portal-message portal-message--success";
            box.textContent = `Eligible recipients: ${pv.eligibleCount} · Excluded (opted-out/suppressed/unverified): ${pv.excludedCount}`;
            box.hidden = false;
          } catch (err) {
            box.className = "portal-message portal-message--error";
            box.textContent = err.message || "Unable to preview recipients.";
            box.hidden = false;
          }
        });
        mktForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const fd = new FormData(mktForm);
          await runAdminAction(async () => {
            let attachmentUrl = "";
            const attFile = fd.get("attachmentFile");
            if (attFile instanceof File && attFile.size > 0) {
              const up = await uploadFile(attFile);
              attachmentUrl = up.url;
            }
            await api(adminApiUrl("/marketing/campaigns"), {
              method: "POST",
              body: {
                name: fd.get("name"),
                templateId: main.querySelector("[data-mkt-tmpl]")?.value || undefined,
                subject: fd.get("subject"),
                previewText: fd.get("previewText"),
                ctaLabel: fd.get("ctaLabel"),
                ctaUrl: fd.get("ctaUrl"),
                scheduledAt: fd.get("scheduledAt") || undefined,
                attachmentUrl,
                htmlBody: fd.get("htmlBody"),
                sendMode: fd.get("sendMode"),
                filters: buildMktFilters(),
              },
            });
          }, "Campaign created.");
        });
        main.querySelector("[data-test-send-btn]")?.addEventListener("click", async () => {
          const to = main.querySelector("[data-test-email]")?.value || "";
          const fb = main.querySelector("[data-test-fb]");
          try {
            const res = await api(adminApiUrl("/marketing/test-send"), {
              method: "POST",
              body: {
                to,
                subject: mktForm.querySelector('[name="subject"]').value,
                previewText: mktForm.querySelector('[name="previewText"]').value,
                ctaLabel: mktForm.querySelector('[name="ctaLabel"]').value,
                ctaUrl: mktForm.querySelector('[name="ctaUrl"]').value,
                htmlBody: mktForm.querySelector('[name="htmlBody"]').value,
              },
            });
            fb.className = "portal-message portal-message--success";
            fb.textContent = `Test email sent (ID: ${res.messageId || "ok"}).`;
            fb.hidden = false;
          } catch (err) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err.message;
            fb.hidden = false;
          }
        });
        main.querySelectorAll("[data-camp-act]").forEach((b) => {
          b.addEventListener("click", async () => {
            await runAdminAction(async () => {
              await api(adminApiUrl(`/marketing/campaigns/${b.getAttribute("data-camp-act")}/action`), {
                method: "POST",
                body: { action: b.getAttribute("data-act") },
              });
            }, "Campaign updated.");
          });
        });
        main.querySelectorAll("[data-camp-deliveries]").forEach((b) => {
          b.addEventListener("click", async () => {
            await runAdminAction(async () => {
              const res = await api(adminApiUrl(`/marketing/campaigns/${b.getAttribute("data-camp-deliveries")}/deliveries`));
              selectedCampaignDeliveries = res.deliveries || [];
            });
          });
        });
        main.querySelector("[data-supp-form]")?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const formEl = e.target;
          await runAdminAction(async () => {
            await api(adminApiUrl("/marketing/suppressions"), { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
          }, "Email added to suppression list.");
        });
      }

      // Backups
      main.querySelector("[data-create-backup]")?.addEventListener("click", async () => {
        await runAdminAction(async () => {
          const res = await api(adminApiUrl("/backups"), { method: "POST" });
          feedbackMsg = `Backup created: ${res.backup?.filename}`;
        });
      });

      // System Upgrade (ZIP Auto-Updater)
      main.querySelector("[data-system-upgrade-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const btn = form.querySelector("[data-upgrade-submit-btn]");
        const fb = form.querySelector("[data-upgrade-feedback]");
        const fd = new FormData(form);
        const file = fd.get("releaseZip");
        if (!(file instanceof File) || file.size === 0) {
          if (fb) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = "Please choose a valid Yuitor release .zip file first.";
            fb.hidden = false;
          }
          return;
        }
        if (btn) {
          btn.disabled = true;
          btn.textContent = "Backing up & Applying ZIP Update...";
        }
        if (fb) {
          fb.className = "portal-message";
          fb.textContent = "Creating automatic SQLite backup, verifying ZIP integrity & extracting update...";
          fb.hidden = false;
        }
        try {
          const res = await api(adminApiUrl("/system-update"), { method: "POST", body: fd });
          feedbackMsg = res.message || `Upgraded to v${res.newVersion} cleanly.`;
          await loadAndDraw();
        } catch (err) {
          if (fb) {
            fb.className = "portal-message portal-message--error";
            fb.textContent = err?.message || "ZIP upgrade failed. Existing files and database are untouched.";
            fb.hidden = false;
          }
          if (btn) {
            btn.disabled = false;
            btn.innerHTML = `${icon("upload")} Upload &amp; Upgrade Version`;
          }
        }
      });

      // Secret Admin Slug change (password-confirmed)
      bindPasswordToggles(main);
      main.querySelector("[data-change-admin-path-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const form = e.target;
        const fd = new FormData(form);
        const btn = form.querySelector("[data-testid='button-rotate-admin-slug']");
        if (btn) btn.disabled = true;
        try {
          const res = await api(adminApiUrl("/settings/admin-path"), {
            method: "POST",
            body: {
              adminPath: String(fd.get("adminPath") || "").trim(),
              currentPassword: String(fd.get("currentPassword") || ""),
            },
          });
          window.location.assign(res.redirectTo || `/${res.adminPath}/`);
        } catch (err) {
          feedbackError = err?.message || "Unable to update Secret Admin Gate URL.";
          loadAndDraw();
        }
      });

      // Settings, Search, BIMI & Mandatory Test-Before-Save
      main.querySelectorAll("[data-settings-subtab]").forEach((b) => {
        b.addEventListener("click", () => {
          settingsSubTab = normalizeSettingsSubTab(b.getAttribute("data-settings-subtab") || "security");
          replaceAdminHash(`#settings/${encodeURIComponent(settingsSubTab)}`);
          loadAndDraw();
        });
      });
      const settingsSearchInp = main.querySelector("[data-settings-search]");
      if (settingsSearchInp) {
        if (settingsSearchQuery) window.YuitorUI?.filterAccordions?.(main, settingsSearchQuery);
        settingsSearchInp.addEventListener("input", (e) => {
          settingsSearchQuery = e.target.value || "";
          window.YuitorUI?.filterAccordions?.(main, settingsSearchQuery);
        });
      }
      main.querySelectorAll("[data-toggle-secret]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const key = btn.getAttribute("data-toggle-secret");
          const input = main.querySelector(`input[name="cfg__${CSS.escape(key || "")}"]`);
          if (!input) return;
          const reveal = input.type === "password";
          input.type = reveal ? "text" : "password";
          btn.textContent = reveal ? "Hide" : "Show";
          btn.setAttribute("aria-label", `${reveal ? "Hide" : "Show"} ${key}`);
        });
      });
      main.querySelector("[data-gen-secret]")?.addEventListener("click", () => {
        const input = main.querySelector('input[name="cfg__SESSION_SECRET"]');
        if (!input) return;
        const bytes = new Uint8Array(32);
        crypto.getRandomValues(bytes);
        const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
        input.type = "text";
        input.value = hex;
        const toggleBtn = main.querySelector('[data-toggle-secret="SESSION_SECRET"]');
        if (toggleBtn) toggleBtn.textContent = "Hide";
      });
      main.querySelectorAll("[data-tested-settings-form]").forEach((form) => {
        form.addEventListener("submit", async (e) => {
          e.preventDefault();
          const category = form.getAttribute("data-tested-settings-form") || "";
          const btn = form.querySelector("[data-save-tested-btn]");
          const diagSlot = form.querySelector("[data-tested-diag-slot]");
          const values = {};
          const clearKeys = [];
          let testRecipient = "";
          let testPhone = "";
          const fd = new FormData(form);
          for (const [name, val] of fd.entries()) {
            if (name.startsWith("cfg__")) {
              values[name.slice(5)] = String(val);
            } else if (name.startsWith("clr__")) {
              clearKeys.push(name.slice(5));
            } else if (name === "__testRecipient") {
              testRecipient = String(val || "").trim();
            } else if (name === "__testPhone") {
              testPhone = String(val || "").trim();
            }
          }
          if (btn) {
            btn.disabled = true;
            btn.textContent = "Testing & Validating...";
          }
          try {
            const res = await api(adminApiUrl("/settings/save-tested"), {
              method: "POST",
              body: { category, values, clearKeys, testRecipient, testPhone },
            });
            delete settingsDiagByCat[category];
            settingsSuccessByCat[category] = res.testMessage || "Test passed and configuration saved cleanly.";
            feedbackMsg = res.testMessage || "Live validation passed — configuration saved.";
            window.YuitorUI?.Toast?.success(feedbackMsg);
            loadAndDraw();
          } catch (err) {
            delete settingsSuccessByCat[category];
            const diag = {
              error: err?.data?.error || err?.message || "Connection test failed.",
              rootCause: err?.data?.rootCause || "The configuration failed live validation before saving.",
              howToFix: Array.isArray(err?.data?.howToFix)
                ? err.data.howToFix
                : ["Double-check your credentials, URL/host, and API permissions, then retry Test & Save."],
            };
            settingsDiagByCat[category] = diag;
            if (diagSlot) {
              diagSlot.innerHTML = `
                <div class="portal-diag-box" data-testid="settings-diag-box">
                  <h4>Save Blocked — Validation / Live Connection Test Failed</h4>
                  <div class="portal-diag-row"><strong>1. Error:</strong> ${escapeHtml(diag.error)}</div>
                  <div class="portal-diag-row"><strong>2. Why it happened (Root Cause):</strong> ${escapeHtml(diag.rootCause)}</div>
                  <div class="portal-diag-row"><strong>3. How to fix it:</strong>
                    <ul>${diag.howToFix.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>
                  </div>
                </div>`;
            }
          } finally {
            if (btn) {
              btn.disabled = false;
              btn.textContent = "Test & Save Configuration";
            }
          }
        });
      });

      // BIMI Upload, Config, DNS Check & Copy Handlers
      main.querySelector("[data-bimi-svg-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fileInp = main.querySelector("[data-bimi-svg-file]");
        const file = fileInp?.files?.[0];
        if (!file) {
          bimiNotice = { ok: false, text: "Please select an .svg logo file first." };
          loadAndDraw();
          return;
        }
        try {
          const svgMarkup = await file.text();
          const res = await api(adminApiUrl("/settings/bimi/upload-svg"), {
            method: "POST",
            body: { svgMarkup, filename: file.name },
          });
          bimiNotice = { ok: true, text: res.message || "Custom BIMI SVG logo uploaded and synced with email headers!" };
          window.YuitorUI?.Toast?.success(bimiNotice.text);
        } catch (err) {
          bimiNotice = { ok: false, text: err?.message || "Invalid SVG file for BIMI." };
        }
        loadAndDraw();
      });
      main.querySelector("[data-bimi-reset]")?.addEventListener("click", async () => {
        try {
          const res = await api(adminApiUrl("/settings/bimi/reset"), { method: "POST", body: {} });
          bimiNotice = { ok: true, text: res.message || "Restored default Yuitor BIMI SVG logo." };
          window.YuitorUI?.Toast?.success(bimiNotice.text);
        } catch (err) {
          bimiNotice = { ok: false, text: err?.message || "Unable to reset BIMI logo." };
        }
        loadAndDraw();
      });
      main.querySelector("[data-bimi-config-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        try {
          const res = await api(adminApiUrl("/settings/bimi"), {
            method: "POST",
            body: {
              domain: String(fd.get("domain") || "").trim(),
              selector: String(fd.get("selector") || "default").trim(),
              vmcUrl: String(fd.get("vmcUrl") || "").trim(),
            },
          });
          bimiNotice = { ok: true, text: res.message || "BIMI DNS configuration updated!" };
          window.YuitorUI?.Toast?.success(bimiNotice.text);
        } catch (err) {
          bimiNotice = { ok: false, text: err?.message || "Could not update BIMI configuration." };
        }
        loadAndDraw();
      });
      main.querySelector("[data-bimi-check-dns]")?.addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const domainVal = main.querySelector('[data-bimi-config-form] input[name="domain"]')?.value || bimiRes?.domain || "yuitor.com";
        const selVal = main.querySelector('[data-bimi-config-form] input[name="selector"]')?.value || bimiRes?.selector || "default";
        try {
          bimiDnsResult = await api(adminApiUrl("/settings/bimi/check-dns"), {
            method: "POST",
            body: { domain: domainVal, selector: selVal },
          });
          bimiNotice = { ok: true, text: `Live DNS scan completed for ${bimiDnsResult.domain}.` };
        } catch (err) {
          bimiNotice = { ok: false, text: err?.message || "DNS verification check failed." };
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-copy-text]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const val = btn.getAttribute("data-copy-text") || "";
          try {
            await navigator.clipboard.writeText(val);
            window.YuitorUI?.Toast?.success("Copied to clipboard!");
          } catch {
            window.YuitorUI?.Toast?.info(val);
          }
        });
      });

      // Reusable Shared DataTable Enhancement (Columns, Sort, Search, Filter, Pagination, Bulk Mail/WA/CSV, Row Click)
      window.YuitorUI?.enhanceTables?.(main.querySelector("[data-ws-body]"), {
        onRowClick: (tr) => {
          const uid = tr.getAttribute("data-row-view-uid");
          if (uid) openUserProfileById(uid);
        },
        onBulkAction: (action, selectedRows) => {
          if (!selectedRows.length) return;
          if (action === "whatsapp") {
            const withPhone = selectedRows
              .map((r) => {
                const digits = String(r.phone || "").replace(/\D+/g, "");
                const wp = digits.length === 10 ? `91${digits}` : digits;
                return { ...r, wp };
              })
              .filter((r) => r.wp);
            if (!withPhone.length) {
              window.YuitorUI?.Toast?.warn("No phone numbers found in selected rows.");
              return;
            }
            openInAppModal({
              title: `Bulk WhatsApp (${withPhone.length} Recipients)`,
              bodyHtml: `
                <div class="portal-field"><label>Custom Message Template</label><textarea id="yu-bulk-wa-msg" rows="3">Hello {{name}}, greetings from Yuitor Smart Classes!</textarea></div>
                <div style="display:flex;flex-wrap:wrap;gap:6px;max-height:240px;overflow:auto;" id="yu-bulk-wa-links">
                  ${withPhone.map((r) => `<a href="https://wa.me/${r.wp}?text=${encodeURIComponent(`Hello ${r.name || ""}, greetings from Yuitor Smart Classes!`)}" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet" data-wa-name="${escAttr(r.name || "")}" data-wa-num="${r.wp}">${escapeHtml(r.name || r.phone)}</a>`).join("")}
                </div>`,
              onMount: (bd) => {
                bd.querySelector("#yu-bulk-wa-msg")?.addEventListener("input", (ev) => {
                  const tmpl = ev.target.value || "";
                  bd.querySelectorAll("#yu-bulk-wa-links a").forEach((a) => {
                    const nm = a.getAttribute("data-wa-name") || "";
                    const num = a.getAttribute("data-wa-num") || "";
                    a.href = `https://wa.me/${num}?text=${encodeURIComponent(tmpl.replace(/\{\{name\}\}/g, nm))}`;
                  });
                });
              },
            });
          } else if (action === "mail") {
            const withUid = selectedRows.filter((r) => r.uid);
            if (!withUid.length) {
              window.YuitorUI?.Toast?.warn("Bulk Mail requires rows linked to user accounts.");
              return;
            }
            openInAppModal({
              title: `Bulk Mail (${withUid.length} Selected Users)`,
              bodyHtml: `
                <form class="portal-form" data-yu-bulk-mail-form>
                  <div class="portal-field"><label>Subject *</label><input name="subject" required value="Important Update from Yuitor Smart Classes"></div>
                  <div class="portal-field"><label>Message *</label><textarea name="message" rows="4" required>Dear Student/Parent,\n\nGreetings from Yuitor Smart Classes.\n\nRegards,\nYuitor Team</textarea></div>
                  <div class="portal-message portal-message--error" data-bm-err hidden></div>
                  <div class="portal-actions" style="justify-content:flex-end;">
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-bm-cancel>Cancel</button>
                    <button type="submit" class="portal-button portal-button--small" data-bm-send>Send to ${withUid.length} Users</button>
                  </div>
                </form>`,
              onMount: (bd, close) => {
                bd.querySelector("[data-bm-cancel]")?.addEventListener("click", close);
                bd.querySelector("[data-yu-bulk-mail-form]")?.addEventListener("submit", async (ev) => {
                  ev.preventDefault();
                  const fd = new FormData(ev.target);
                  const sendBtn = bd.querySelector("[data-bm-send]");
                  const errEl = bd.querySelector("[data-bm-err]");
                  if (sendBtn) {
                    sendBtn.disabled = true;
                    sendBtn.textContent = "Sending...";
                  }
                  let sentOk = 0;
                  let failCnt = 0;
                  for (const r of withUid) {
                    try {
                      await api(adminApiUrl(`/users/${r.uid}/one-click-mail`), {
                        method: "POST",
                        body: { subject: String(fd.get("subject") || ""), message: String(fd.get("message") || "") },
                      });
                      sentOk++;
                    } catch {
                      failCnt++;
                    }
                  }
                  if (sentOk > 0) {
                    close();
                    window.YuitorUI?.Toast?.success(`Bulk mail sent to ${sentOk} user(s)${failCnt ? ` (${failCnt} failed)` : ""}.`);
                  } else if (errEl) {
                    errEl.textContent = "Bulk mail failed. Verify SMTP settings in Settings > Integrations & API Keys.";
                    errEl.hidden = false;
                    if (sendBtn) {
                      sendBtn.disabled = false;
                      sendBtn.textContent = `Send to ${withUid.length} Users`;
                    }
                  }
                });
              },
            });
          }
        },
      });
    }
    window.addEventListener("hashchange", () => {
      const nextHash = parseAdminHashState();
      if (!nextHash) return;
      tab = nextHash.tab || tab;
      if (nextHash.settingsTab) settingsSubTab = normalizeSettingsSubTab(nextHash.settingsTab);
      if (nextHash.role) userFilterRole = nextHash.role;
      if (nextHash.usersSubView) usersSubView = nextHash.usersSubView;
      if (nextHash.subView) {
        if (tab === "admissions") admissionsSubView = nextHash.subView;
        else if (tab === "payments") paymentsSubView = nextHash.subView;
      }
      if (nextHash.subPart) {
        if (tab === "admissions") admissionsSubView = nextHash.subPart;
        else if (tab === "dashboard") dashboardSubView = nextHash.subPart;
        else if (tab === "payments") paymentsSubView = nextHash.subPart;
      }
      loadAndDraw();
    });
    await loadAndDraw();
  }

  // ==================== STUDENT PANEL ====================
  async function renderStudentPanel(session) {
    if (session.user.verification_status !== "approved" && !session.impersonation?.active) {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Account Status</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    const qrParam = new URLSearchParams(window.location.search).get("qr") || "";
    let tab = qrParam ? "timetable" : "overview";
    let qrInputVal = qrParam;
    let activeLessons = null;
    let studentNotice = "";
    let studentNoticeType = "success";

    async function loadAndDraw() {
      const [dash, boot, payCfg] = await Promise.all([
        api("/api/student/dashboard"),
        api("/api/public/bootstrap"),
        api("/api/payments/config").catch(() => ({ razorpayEnabled: false, keyId: "" })),
      ]);
      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["courses", "Courses", "book"],
        ["timetable", "Timetable", "calendar"],
        ["assignments", "Tests", "award"],
        ["crm_online", "Live & CBT", "award"],
        ["fees", "Fees", "wallet"],
        ["referrals", "Referrals", "award"],
        ["wallet", "Wallet", "wallet"],
        ["idcard", "ID & Library", "award"],
        ["support", "Doubts", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        const p = dash.profile || {};
        const card = dash.idCard || {};
        const totalLearningMins = (dash.enrollments || []).reduce((acc, e) => acc + Number(e.learning_minutes || 0), 0);
        const dueInsts = (dash.installments || []).filter((i) => i.status !== "paid");
        const overdueCount = dueInsts.filter((i) => i.status === "overdue").length;
        const classBatches = dash.classBatches || [];
        const cs = dash.crossSell || null;
        const csCourses = cs?.eligible && cs.discountPercent > 0 ? (cs.availableCourses || []) : [];
        bodyHtml = `
          ${
            dueInsts.length
              ? `<div class="portal-message portal-message--${overdueCount ? "error" : "success"}" style="margin-bottom:14px;">
                  <strong>${overdueCount ? "Overdue Fee Alert" : "Upcoming Fee Installment"}:</strong>
                  ${dueInsts.length} pending installment(s) — next due <strong>${escapeHtml(dueInsts[0].due_date)}</strong> (${formatINR(Math.max(0, Number(dueInsts[0].amount) - Number(dueInsts[0].paid_amount || 0)))}).
                </div>`
              : ""
          }
          ${
            csCourses.length
              ? `<div class="v31-cross-sell-banner" style="margin-bottom:16px;" data-testid="v31-student-cross-sell">
                  <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
                    <div>
                      <span class="v31-offer-badge">Week ${Number(cs.weekNumber || 1)} · ${Number(cs.discountPercent)}% OFF</span>
                      <h3 style="margin:6px 0 4px;font-size:17px;">Exclusive Course Add-On Offer</h3>
                      <p style="margin:0;font-size:14px;opacity:.96;">Yuitor ki taraf se aapko ek offer diya gaya hai. Agar aap ek aur course add karte hain to aapko ${Number(cs.discountPercent)}% off milega.</p>
                    </div>
                  </div>
                  <div class="v31-batch-grid">
                    ${csCourses.map((c) => `
                      <div class="v31-batch-card" style="background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.25);color:#fff;">
                        <strong>${escapeHtml(c.title)}</strong>
                        <div style="font-size:12px;opacity:.9;margin:4px 0;">Class: ${escapeHtml(c.class_level || p.class_level || "-")} · Duration: ${Number(c.duration_months || 12)} months</div>
                        <div style="font-size:14px;margin:6px 0;">
                          <span style="text-decoration:line-through;opacity:.75;margin-right:6px;">${formatINR(c.monthly_fee)}/mo</span>
                          <strong style="font-size:16px;">${formatINR(c.discounted_monthly_fee)}/mo</strong>
                        </div>
                        <button type="button" class="portal-button portal-button--small" style="background:#FFFFFF;color:#101B3D;font-weight:700;" data-v31-cs-enroll="${c.id}">Enroll at ${Number(cs.discountPercent)}% Off</button>
                      </div>`).join("")}
                  </div>
                </div>`
              : ""
          }
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${escapeHtml(p.roll_number || card.rollNumber || "-")}</strong><span>Roll Number</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.enrollments || []).length}</strong><span>Enrolled Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
            <div class="portal-stat"><div><strong>${(dash.attendance || []).filter((a) => a.status === "present" || a.status === "late").length}</strong><span>Present Sessions</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${totalLearningMins} min</strong><span>Learning Time</span></div><div class="portal-stat-icon">${icon("dashboard")}</div></div>
          </div>
          <div data-v31-postreg-profile style="margin-bottom:16px;"></div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;" data-testid="v31-student-batch-details">
            <h3 class="portal-section-title">Your Class Batch Details (${escapeHtml(p.class_level || "Current Class")})</h3>
            ${
              classBatches.length
                ? `<div class="v31-batch-grid">
                    ${classBatches.map((b) => `
                      <div class="v31-batch-card">
                        <strong>${escapeHtml(b.name)}</strong>
                        <div class="v31-batch-meta">
                          <span><strong>Course / Subject:</strong> ${escapeHtml(b.course_title || b.subject || "-")}</span>
                          <span><strong>Start Date:</strong> ${escapeHtml(b.start_date || "Rolling Admission")}</span>
                          <span><strong>Duration:</strong> ${Number(b.duration_months || p.course_duration_months || 12)} months</span>
                          <span><strong>Teacher:</strong> ${escapeHtml(b.teacher_name || "Assigned Yuitor Faculty")}</span>
                          <span><strong>Timing:</strong> ${escapeHtml(b.schedule_days || "Mon–Sat")} · ${escapeHtml(b.start_time || "TBA")}${b.end_time ? " – " + escapeHtml(b.end_time) : ""}</span>
                        </div>
                      </div>`).join("")}
                  </div>`
                : `<p class="portal-hint">No active batches found for ${escapeHtml(p.class_level || "your current class")} yet. Please check back or contact Yuitor Support.</p>`
            }
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Student Profile</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Roll Number</span><strong>${escapeHtml(p.roll_number || card.rollNumber || "-")}</strong></div>
              <div class="portal-detail"><span>Batch &amp; Branch</span><strong>${escapeHtml(card.batchName || "Regular Batch")} · ${escapeHtml(card.branchName || "Main Campus")}</strong></div>
              <div class="portal-detail"><span>Class &amp; Board</span><strong>${escapeHtml(p.class_level || "Student")} · ${escapeHtml(p.board || "UP Board")}</strong></div>
              <div class="portal-detail"><span>Admission Date</span><strong>${escapeHtml(p.admission_date || "Pending assignment")}</strong></div>
              <div class="portal-detail"><span>Course Duration</span><strong>${Number(p.course_duration_months || 12)} months</strong></div>
              <div class="portal-detail"><span>Enrollment Status</span><strong>${statusBadge(p.enrollment_status || "active")}</strong></div>
            </div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Upcoming Classes</h3>
            ${(dash.upcomingClasses || []).map((c) => { const mUrl = safeHref(c.meeting_link); return `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(c.scheduled_date)} · ${escapeHtml(c.start_time)}–${escapeHtml(c.end_time)} (${escapeHtml(c.mode)})</span><strong>${escapeHtml(c.title)} · ${escapeHtml(c.course_title)}</strong>${mUrl ? `<div><a href="${escAttr(mUrl)}" target="_blank" rel="noopener noreferrer">Join Online Class</a></div>` : ""}</div>`; }).join("") || `<p class="portal-hint">No upcoming classes scheduled right now.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Announcements</h3>
            ${(dash.announcements || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(a.created_at)}</span><strong>${escapeHtml(a.title)}</strong><div>${escapeHtml(a.body)}</div></div>`).join("") || `<p class="portal-hint">No recent announcements.</p>`}
          </div>`;
      } else if (tab === "courses") {
        const batches = boot.batches || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">My Enrolled Courses &amp; Batches</h3>
            ${(dash.enrollments || []).map((e) => `
              <div class="portal-detail" style="margin-bottom:10px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;">
                <div>
                  <strong>${escapeHtml(e.title)} (${e.progress_percent || 0}% complete)</strong>
                  <span>${e.batch_name ? `Batch: ${escapeHtml(e.batch_name)} (${escapeHtml(e.room_name || "Room")}) · ` : ""}Status: ${escapeHtml(e.is_expired ? "expired" : e.status)}${e.expires_at ? " · Valid until " + escapeHtml(e.expires_at) : ""}${e.certificate_code ? " · Certificate: " + escapeHtml(e.certificate_code) : ""}</span>
                </div>
                <div class="portal-actions">
                  ${["active", "completed"].includes(e.status) && !e.is_expired ? `<button type="button" class="portal-button portal-button--small" data-open-course="${e.course_id}">Open Lessons</button>` : statusBadge(e.is_expired ? "expired" : e.status)}
                  ${e.certificate_code ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-cert="${escAttr(JSON.stringify({ code: e.certificate_code, student: session.user.full_name, course: e.title }))}">Certificate</button>` : ""}
                </div>
              </div>`).join("") || `<p class="portal-hint">No enrolled courses yet. Enroll below.</p>`}
          </div>
          ${
            activeLessons
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
              <h3 class="portal-section-title">Course Lessons</h3>
              ${(activeLessons.lessons || []).map((l) => { const matUrl = safeHref(l.material_url); return `
                <div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.duration_minutes} mins · ${escapeHtml(l.content)}</span>${matUrl ? `<div><a href="${escAttr(matUrl)}" target="_blank" rel="noopener noreferrer">Open Study Material</a></div>` : ""}</div>
                  ${l.completed ? statusBadge("completed") : `<button type="button" class="portal-button portal-button--small" data-complete-lesson="${l.id}">Mark Complete</button>`}
                </div>`; }).join("")}
            </div>`
              : ""
          }
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Enroll in a Course &amp; Batch</h3>
            <form class="portal-form" data-enroll-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)} (${formatINR(c.monthly_fee)}/mo)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch &amp; Seat Capacity</label><select name="batchId"><option value="">Auto-assign / Flexible</option>${batches.map((b) => `<option value="${b.id}"${Number(b.seats_remaining || 0) <= 0 ? " disabled" : ""}>${escapeHtml(b.name)} (${escapeHtml(b.schedule_days || "")} ${escapeHtml(b.start_time || "")} · ${b.seats_remaining} seats left)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Plan</label><select name="plan"><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div>
                <div class="portal-field"><label>Payment Method</label><select name="paymentMethod"><option value="upi">UPI / Desk Transfer</option><option value="cash">Centre Cash Desk</option><option value="gateway">${payCfg.razorpayEnabled ? "Online Gateway (Razorpay Instant)" : "Online Gateway (Desk Fallback)"}</option></select></div>
                <div class="portal-field"><label>UTR / Reference No.</label><input name="utrReference" placeholder="UTR or desk receipt ref"></div>
                <div class="portal-field"><label>Coupon Code (Optional)</label><input name="couponCode" placeholder="e.g. YUITOR10"></div>
              </div>
              <p class="portal-hint" data-enroll-mode-hint style="margin-bottom:8px;">${payCfg.razorpayEnabled ? "Razorpay Online Gateway is active for instant receipt generation, or choose UPI/Cash Desk." : "Gateway keys are not set yet — enrollments save cleanly as Pending Verification for desk confirmation."}</p>
              <div class="portal-message" data-enroll-fb hidden></div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="submit" class="portal-button portal-button--small">Submit Enrollment</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-stu-add-cart>Add Selected Course to Cart</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Rate an Enrolled Course</h3>
            <form class="portal-form" data-review-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(boot.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Rating</label><select name="rating"><option value="5">5 - Excellent</option><option value="4">4 - Good</option><option value="3">3 - Average</option><option value="2">2 - Fair</option><option value="1">1 - Needs Improvement</option></select></div>
              </div>
              <div class="portal-field"><label>Review</label><textarea name="comment" required placeholder="Share your learning experience..."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Submit Review</button>
            </form>
          </div>`;
      } else if (tab === "timetable") {
        const present = (dash.attendance || []).filter((a) => a.status === "present" || a.status === "late").length;
        const absent = (dash.attendance || []).filter((a) => a.status === "absent").length;
        const slots = dash.timetable || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">QR Classroom Self Check-In</h3>
            <p class="portal-hint" style="margin-bottom:10px;">Scan your classroom QR displayed by your teacher or enter the session QR code below to mark today's attendance instantly.</p>
            <form class="portal-form" data-stu-qr-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Classroom QR Code *</label><input name="qrCode" value="${escAttr(qrInputVal)}" required placeholder="e.g. YTR-QR-..."></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">${icon("check")} Mark QR Attendance</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Weekly Batch Timetable (${slots.length} classes)</h3>
            ${
              slots.length
                ? `<div class="yu-timetable-grid">${slots.map((s) => `<div class="portal-detail"><span>${escapeHtml(s.day_of_week)} · ${escapeHtml(s.start_time)}–${escapeHtml(s.end_time)}</span><strong>${escapeHtml(s.subject_name)}</strong><span>${escapeHtml(s.course_title || "")}${s.batch_name ? " · " + escapeHtml(s.batch_name) : ""} · ${escapeHtml(s.room_name || "Room")} (${escapeHtml(s.teacher_name || "Faculty")})</span></div>`).join("")}</div>`
                : `<p class="portal-hint">No weekly timetable slots assigned to your courses/batch yet.</p>`
            }
          </div>
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${present}</strong><span>Present / Late Sessions</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${absent}</strong><span>Absent Sessions</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          <div class="portal-card portal-table-card"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Date</th><th>Course</th><th>Status</th><th>Mode</th><th>Remarks</th></tr></thead>
            <tbody>
              ${(dash.attendance || []).map((a) => `<tr><td>${escapeHtml(a.att_date)}</td><td>${escapeHtml(a.course_title)}</td><td>${statusBadge(a.status)}</td><td>${escapeHtml(a.marked_via || "manual")}</td><td>${escapeHtml(a.remarks || "-")}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No attendance marked yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "assignments") {
        const offTests = dash.offlineTests || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Offline Test Schedule, Marks &amp; Class Ranks (${offTests.length})</h3>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Date</th><th>Test &amp; Subject</th><th>Course / Room</th><th>Score</th><th>Class Rank</th></tr></thead>
              <tbody>
                ${offTests.map((t) => `<tr>
                  <td>${escapeHtml(t.test_date)}</td>
                  <td><strong>${escapeHtml(t.title)}</strong><span class="portal-cell-sub">${escapeHtml(t.subject_name)}</span></td>
                  <td>${escapeHtml(t.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(t.room_name || "")}</span></td>
                  <td>${t.is_absent ? statusBadge("absent") : t.marks_obtained !== null && t.marks_obtained !== undefined ? `<strong>${t.marks_obtained} / ${t.max_marks}</strong>` : `<span class="portal-hint">Scheduled</span>`}</td>
                  <td>${t.rank_position ? `<strong>#${t.rank_position}</strong>` : "—"}</td>
                </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No offline tests published yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Assignments &amp; Homework</h3>
            ${(dash.assignments || []).map((a) => `
              <div class="portal-detail" style="margin-bottom:10px;">
                <strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong>
                <span>Due: ${escapeHtml(a.due_date)} · Status: ${escapeHtml(a.submission_status || "Pending")} ${a.marks_obtained !== null ? "· Score: " + a.marks_obtained + "/" + a.max_marks : ""}</span>
                <form class="portal-form" data-sub-assign="${a.id}" style="margin-top:8px;">
                  <div class="portal-form-grid">
                    <div class="portal-field"><label>Answer Text</label><input name="submissionText" placeholder="Write answer or notes..."></div>
                    <div class="portal-field"><label>Upload File (PDF / Image, max 5 MB)</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
                  </div>
                  <button type="submit" class="portal-button portal-button--small">Submit Assignment</button>
                </form>
              </div>`).join("") || `<p class="portal-hint">No pending assignments.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Online Quizzes &amp; Practice Tests</h3>
            ${(dash.quizzes || []).map((q) => {
              let qs = [];
              try { qs = JSON.parse(q.questions_json || "[]"); } catch { qs = []; }
              return `<div class="portal-detail" style="margin-bottom:12px;">
                <strong>${escapeHtml(q.title)} (${escapeHtml(q.course_title)})</strong>
                <span>${q.duration_minutes} mins · Max ${q.max_marks} marks ${q.score !== null && q.score !== undefined ? "· Last Score: " + q.score + "/" + q.max_marks : ""}</span>
                ${qs.length ? `<form class="portal-form" data-quiz-form="${q.id}" style="margin-top:10px;">
                  ${qs.map((item, idx) => `<div style="margin-bottom:8px;"><div><strong>Q${idx + 1}:</strong> ${escapeHtml(item.question)}</div><select name="q_${idx}">${(item.options || []).map((opt, oi) => `<option value="${oi}">${escapeHtml(opt)}</option>`).join("")}</select></div>`).join("")}
                  <button type="submit" class="portal-button portal-button--small">Submit Quiz</button>
                </form>` : ""}
              </div>`;
            }).join("") || `<p class="portal-hint">No quizzes published for your enrolled courses yet.</p>`}
          </div>`;
      } else if (tab === "fees") {
        const totalNetFee = (dash.feeRecords || []).reduce((acc, f) => acc + Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0)), 0);
        const totalPaidFee = (dash.feeRecords || []).reduce((acc, f) => acc + Number(f.paid_amount || 0), 0);
        const pendingFee = Math.max(0, totalNetFee - totalPaidFee);
        const installments = dash.installments || [];
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${formatINR(totalNetFee)}</strong><span>Total Net Fee</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(totalPaidFee)}</strong><span>Paid Amount</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(pendingFee)}</strong><span>Pending Balance</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
          </div>
          ${
            installments.length
              ? `<div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Fee Installments / EMI Schedule (${installments.length})</div><div class="portal-table-scroll"><table class="portal-table">
                  <thead><tr><th>Installment</th><th>Due Date</th><th>Amount</th><th>Paid</th><th>Status</th></tr></thead>
                  <tbody>${installments.map((fi) => `<tr><td>${escapeHtml(fi.title)}</td><td>${escapeHtml(fi.due_date)}</td><td>${formatINR(fi.amount)}</td><td>${formatINR(fi.paid_amount || 0)}</td><td>${statusBadge(fi.status)}</td></tr>`).join("")}</tbody>
                </table></div></div>`
              : ""
          }
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Invoice</th><th>Course</th><th>Total</th><th>Paid</th><th>Due Date</th><th>Status</th></tr></thead>
            <tbody>
              ${(dash.feeRecords || []).map((f) => `<tr><td>${escapeHtml(f.invoice_number)}</td><td>${escapeHtml(f.course_title)}</td><td>${formatINR(f.total_amount - f.discount_amount)}</td><td>${formatINR(f.paid_amount)}</td><td>${escapeHtml(f.due_date || "-")}</td><td>${statusBadge(f.status)}</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No fee records yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Payment Receipts &amp; Refunds</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Receipt #</th><th>Course</th><th>Amount</th><th>Method</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              ${(dash.payments || []).map((p) => `<tr>
                <td>${escapeHtml(p.receipt_number || "Pending")}</td>
                <td>${escapeHtml(p.course_title)}</td>
                <td>${formatINR(p.amount)}</td>
                <td>${escapeHtml(p.payment_method)}</td>
                <td>${statusBadge(p.verification_status)}</td>
                <td><div class="portal-actions">
                  ${p.receipt_number ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-print-receipt="${escAttr(JSON.stringify({ receipt: p.receipt_number, student: session.user.full_name, course: p.course_title, amount: p.amount, date: p.paid_at || p.created_at, invoice: p.invoice_number }))}">Print Receipt</button>` : ""}
                  ${p.verification_status === "verified" && p.refund_status === "none" ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-req-refund="${p.id}">Request Refund</button>` : escapeHtml(p.refund_status !== "none" ? `Refund: ${p.refund_status}` : "")}
                </div></td>
              </tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No payment transactions yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-dept-strip" style="margin-top:14px;">
            <span>Fee Billing &amp; Receipts: <a href="mailto:${escAttr(boot.departmentEmails?.fee || "fee@yuitor.com")}">${escapeHtml(boot.departmentEmails?.fee || "fee@yuitor.com")}</a></span>
            <span>Fee Refunds: <a href="mailto:${escAttr(boot.departmentEmails?.refund || "refund@yuitor.com")}">${escapeHtml(boot.departmentEmails?.refund || "refund@yuitor.com")}</a></span>
          </div>`;
      } else if (tab === "idcard") {
        const card = dash.idCard || {};
        const libIssues = dash.libraryIssues || [];
        const instituteLogoSrc = safeHref(card.instituteLogoUrl, "/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png");
        const studentName = String(card.fullName || session.user.full_name || "Student").trim();
        const initials = studentName
          .split(/\s+/)
          .filter(Boolean)
          .slice(0, 2)
          .map((part) => part[0].toUpperCase())
          .join("") || "YS";
        const fallbackPortraitSvg = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(
          `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="190" viewBox="0 0 160 190"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#e0edff"/><stop offset="100%" stop-color="#ccfbf1"/></linearGradient></defs><rect width="160" height="190" rx="16" fill="url(#g)"/><circle cx="80" cy="64" r="28" fill="#1e429f" opacity="0.2"/><path d="M32 162c6-31 28-46 48-46s42 15 48 46" fill="#1e429f" opacity="0.16"/><text x="80" y="96" text-anchor="middle" font-family="system-ui,-apple-system,sans-serif" font-size="38" font-weight="800" fill="#0f172a">${initials}</text></svg>`
        )}`;
        const studentPhotoSrc = safeHref(card.avatarUrl || session.user.avatar_url, "") || fallbackPortraitSvg;
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px;">
              <h3 class="portal-section-title" style="margin:0;">Digital Student ID Card</h3>
              <button type="button" class="portal-button portal-button--small" onclick="window.print()">Print ID Card</button>
            </div>
            <div class="yu-id-card">
              <div class="yu-id-card-head">
                <div class="yu-id-card-brand">
                  <div class="yu-id-logo-badge">
                    <img src="${escAttr(instituteLogoSrc)}" alt="Yuitor Smart Classes Logo" class="yu-id-institute-logo">
                  </div>
                  <div>
                    <strong>YUITOR SMART CLASSES</strong>
                    <span>${escapeHtml(card.branchName || "Muradnagar Main Centre")}</span>
                  </div>
                </div>
                <span class="yu-id-roll-pill">${escapeHtml(card.rollNumber || "")}</span>
              </div>
              <div class="yu-id-card-body">
                <div class="yu-id-photo-frame">
                  <img src="${escAttr(studentPhotoSrc)}" alt="${escapeHtml(studentName)} Photo" class="yu-id-student-photo" onerror="this.onerror=null;this.src='${escAttr(fallbackPortraitSvg)}';">
                </div>
                <div class="yu-id-card-meta">
                  <h4>${escapeHtml(studentName)}</h4>
                  <p>${escapeHtml(card.classLevel || "Student")} · ${escapeHtml(card.board || "UP Board")}</p>
                  <p>Batch: <strong>${escapeHtml(card.batchName || "Regular Batch")}</strong></p>
                  <p>Emergency / Parent: ${escapeHtml(card.parentPhone || session.user.phone || "-")}</p>
                </div>
                <div class="yu-qr-box">${card.qrSvg || ""}</div>
              </div>
              <div class="yu-id-card-foot">
                <span>Admitted: ${escapeHtml(card.admissionDate || "-")}</span>
                <span>Helpline: ${escapeHtml(card.branchPhone || "+91 78-2728-9292")}</span>
              </div>
            </div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Library &amp; Issued Study Materials (${libIssues.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Book / Module</th><th>Code</th><th>Issued On</th><th>Due Return</th><th>Status</th></tr></thead>
              <tbody>
                ${libIssues.map((li) => `<tr><td><strong>${escapeHtml(li.book_title)}</strong><span class="portal-cell-sub">${escapeHtml(li.category || "")}</span></td><td>${escapeHtml(li.book_code)}</td><td>${escapeHtml(String(li.issued_at || "").slice(0, 10))}</td><td>${escapeHtml(li.due_return_date || "-")}</td><td>${statusBadge(li.status)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No library books or printed modules issued yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else {
        const teachers = dash.teachers || [];
        const courses = dash.enrollments || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Profile Photo</h3>
            <form class="portal-form" data-stu-avatar-form>
              <div class="portal-actions">
                <img src="${escAttr(safeHref(session.user.avatar_url, "/yuitor-icon-192.png"))}" alt="Avatar" class="portal-avatar">
                <input type="file" name="file" accept=".png,.jpg,.jpeg,.webp" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload Photo</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Ask a Subject Doubt or Contact Support</h3>
            <form class="portal-form" data-support-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course (Optional)</label><select name="courseId"><option value="">General Support</option>${courses.map((c) => `<option value="${c.course_id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Route to Faculty (Optional)</label><select name="teacherId"><option value="">Yuitor Support / Auto Faculty</option>${teachers.map((t) => `<option value="${t.id}">${escapeHtml(t.full_name)} (${escapeHtml(t.course_title)})</option>`).join("")}</select></div>
              </div>
              <div class="portal-field"><label>Doubt / Subject *</label><input name="subject" required placeholder="e.g. Doubt in Trigonometry Ex 8.4"></div>
              <div class="portal-field"><label>Message / Question *</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Send Doubt / Message</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">My Doubts &amp; Support Thread</h3>
            ${(dash.supportMessages || []).map((m) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(m.created_at)}${m.course_title ? " · " + escapeHtml(m.course_title) : ""}${m.teacher_name ? " · To " + escapeHtml(m.teacher_name) : ""} · ${statusBadge(m.status || "open")}</span><strong>${escapeHtml(m.subject)}</strong><div>${escapeHtml(m.body)}</div>${m.admin_reply ? `<div style="margin-top:6px;padding:8px 10px;border-radius:8px;background:rgba(16,185,129,.12);"><strong>Reply:</strong> ${escapeHtml(m.admin_reply)}</div>` : ""}</div>`).join("") || `<p class="portal-hint">No support messages sent yet.</p>`}
          </div>
          <div class="portal-dept-strip">
            <span>Student Support: <a href="mailto:${escAttr(boot.departmentEmails?.support || "support@yuitor.com")}">${escapeHtml(boot.departmentEmails?.support || "support@yuitor.com")}</a></span>
            <span>Grievance Officer: <a href="mailto:${escAttr(boot.departmentEmails?.grievance || "grievance@yuitor.com")}">${escapeHtml(boot.departmentEmails?.grievance || "grievance@yuitor.com")}</a></span>
            <span>Complaints: <a href="mailto:${escAttr(boot.departmentEmails?.complain || "complain@yuitor.com")}">${escapeHtml(boot.departmentEmails?.complain || "complain@yuitor.com")}</a></span>
          </div>`;
      }
      if (tab === "referrals" || tab === "wallet") {
        bodyHtml = `<div data-yu-user-addon="${escAttr(tab)}"></div>`;
      } else if (tab === "crm_online") {
        bodyHtml = `<div data-yu-student-crm></div>`;
      }

      const studentNoticeHtml = studentNotice
        ? `<div class="portal-message portal-message--${studentNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(studentNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: "Student Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          studentNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        onReadNotifs: async () => {
          await api("/api/student/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        bodyHtml: studentNoticeHtml + bodyHtml,
      });

      window.YuitorUI?.enhanceTables?.(main?.querySelector("[data-ws-body]"));

      const stuProfEl = main?.querySelector("[data-v31-postreg-profile]");
      if (stuProfEl && window.YuitorV31) {
        window.YuitorV31.renderPostRegProfileCard(stuProfEl, "student", () => loadAndDraw());
      }
      main?.querySelectorAll("[data-v31-cs-enroll]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const cid = btn.getAttribute("data-v31-cs-enroll");
          tab = "courses";
          loadAndDraw().then(() => {
            const sel = document.querySelector('[data-enroll-form] select[name="courseId"]');
            if (sel && cid) sel.value = cid;
            window.YuitorV31?.scrollToAndFocus("[data-enroll-form]");
          });
        });
      });

      const stuAddonEl = main?.querySelector("[data-yu-user-addon]");
      if (stuAddonEl && window.YuitorAddons) {
        if (tab === "referrals") window.YuitorAddons.renderUserReferralsTab(stuAddonEl, "student");
        else if (tab === "wallet") window.YuitorAddons.renderUserWalletTab(stuAddonEl, "student");
      }
      const stuCrmEl = main?.querySelector("[data-yu-student-crm]");
      if (stuCrmEl && window.YuitorCrmV25) {
        window.YuitorCrmV25.renderStudentCrmTab(stuCrmEl);
      }
      main?.querySelector("[data-stu-add-cart]")?.addEventListener("click", async () => {
        const f = main.querySelector("[data-enroll-form]");
        if (!f) return;
        const fd = new FormData(f);
        await window.YuitorAddons?.addToCartAndOpen(fd.get("courseId"), fd.get("plan") || "monthly", fd.get("batchId") || null);
      });

      main.querySelector("[data-stu-qr-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const code = String(new FormData(e.target).get("qrCode") || "").trim();
        try {
          const res = await api("/api/student/attendance/qr", { method: "POST", body: { qrCode: code } });
          qrInputVal = "";
          studentNoticeType = "success";
          studentNotice = `Attendance marked PRESENT for ${res.sessionDate || "today"} via QR check-in!`;
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message || "Invalid or expired QR session code.";
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-open-course]").forEach((b) => {
        b.addEventListener("click", async () => {
          studentNotice = "";
          try {
            activeLessons = await api(`/api/student/courses/${b.getAttribute("data-open-course")}/lessons`);
          } catch (err) {
            activeLessons = null;
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-complete-lesson]").forEach((b) => {
        b.addEventListener("click", async () => {
          try {
            await api(`/api/student/lessons/${b.getAttribute("data-complete-lesson")}/complete`, { method: "POST", body: { timeSpentMinutes: 20 } });
            if (activeLessons?.enrollment?.course_id) {
              activeLessons = await api(`/api/student/courses/${activeLessons.enrollment.course_id}/lessons`);
            }
            studentNoticeType = "success";
            studentNotice = "Lesson marked complete.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelector("[data-enroll-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        const btn = formEl.querySelector('button[type="submit"]');
        const fb = main.querySelector("[data-enroll-fb]");
        const payload = Object.fromEntries(new FormData(formEl).entries());
        if (payload.batchId) payload.batchId = Number(payload.batchId);
        else delete payload.batchId;
        if (btn) btn.disabled = true;
        try {
          if (payload.paymentMethod === "gateway" && payCfg.razorpayEnabled) {
            const order = await api("/api/payments/create-order", {
              method: "POST",
              body: {
                courseId: Number(payload.courseId),
                batchId: payload.batchId || undefined,
                plan: payload.plan,
                couponCode: payload.couponCode || "",
              },
            });
            let failedReported = false;
            const reportOrderFailed = (reason) => {
              if (failedReported || !order?.orderId) return;
              failedReported = true;
              api("/api/payments/order-failed", {
                method: "POST",
                body: { orderId: order.orderId, reason: String(reason || "cancelled").slice(0, 200) },
              }).catch(() => {});
            };
            const RazorpayCtor = await loadRazorpayCheckout();
            const gwResponse = await new Promise((resolve, reject) => {
              const rzp = new RazorpayCtor({
                key: order.keyId || payCfg.keyId,
                amount: order.amount,
                currency: order.currency || "INR",
                name: "Yuitor Smart Classes",
                description: "Course Enrollment Fee",
                order_id: order.orderId,
                prefill: {
                  name: session.user.full_name || "",
                  email: session.user.email || "",
                  contact: session.user.phone || "",
                },
                handler: (resp) => resolve(resp),
                modal: {
                  ondismiss: () => {
                    reportOrderFailed("Payment popup dismissed by student");
                    reject(new Error("Razorpay payment window closed before completion. You can retry anytime."));
                  },
                },
              });
              rzp.on("payment.failed", (resp) => {
                const desc = resp?.error?.description || "Online payment failed.";
                reportOrderFailed(desc);
                reject(new Error(desc));
              });
              rzp.open();
            });
            const verifiedRes = await api("/api/payments/enroll", {
              method: "POST",
              body: {
                ...payload,
                gatewayOrderId: gwResponse.razorpay_order_id,
                gatewayPaymentId: gwResponse.razorpay_payment_id,
                gatewaySignature: gwResponse.razorpay_signature,
              },
            });
            studentNoticeType = "success";
            studentNotice = verifiedRes.message;
            loadAndDraw();
            return;
          }
          const res = await api("/api/payments/enroll", { method: "POST", body: payload });
          studentNoticeType = "success";
          studentNotice = res.message || "Enrollment request submitted successfully.";
          loadAndDraw();
        } catch (err) {
          fb.className = "portal-message portal-message--error";
          fb.textContent = err.message;
          fb.hidden = false;
          if (btn) btn.disabled = false;
        }
      });
      main.querySelector("[data-review-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await api("/api/student/reviews", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          studentNoticeType = "success";
          studentNotice = "Thank you! Your course review has been submitted.";
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message;
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-print-receipt]").forEach((b) => {
        b.addEventListener("click", () => {
          const info = JSON.parse(b.getAttribute("data-print-receipt"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:640px;margin:0 auto;">
              <p class="portal-kicker">Official Fee Receipt · Yuitor Smart Classes</p>
              <div class="portal-heading"><h1>Receipt ${escapeHtml(info.receipt)}</h1><button type="button" class="portal-button portal-button--small" onclick="window.print()">Print</button></div>
              <p class="portal-subtitle">Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · +91 78-2728-9292 · fee@yuitor.com</p>
              <div class="portal-personal-grid" style="margin-top:16px;">
                <div class="portal-detail"><span>Student</span><strong>${escapeHtml(info.student)}</strong></div>
                <div class="portal-detail"><span>Invoice</span><strong>${escapeHtml(info.invoice)}</strong></div>
                <div class="portal-detail"><span>Course</span><strong>${escapeHtml(info.course)}</strong></div>
                <div class="portal-detail"><span>Amount Paid</span><strong>${formatINR(info.amount)}</strong></div>
                <div class="portal-detail"><span>Date</span><strong>${escapeHtml(info.date)}</strong></div>
              </div>
              <div style="margin-top:18px;"><button type="button" class="portal-button portal-button--quiet portal-button--small" data-back-fees>← Back to Fees</button></div>
            </div>`);
          getMain().querySelector("[data-back-fees]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-print-cert]").forEach((b) => {
        b.addEventListener("click", () => {
          const cert = JSON.parse(b.getAttribute("data-print-cert"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:680px;margin:0 auto;text-align:center;padding:36px;">
              <p class="portal-kicker" style="justify-content:center;">Certificate of Completion · Yuitor Smart Classes</p>
              <h1 style="margin:8px 0;">${escapeHtml(cert.student)}</h1>
              <p class="portal-subtitle" style="margin:0 auto 14px;">has successfully completed all lessons for <strong>${escapeHtml(cert.course)}</strong> at Yuitor Smart Classes, Muradnagar.</p>
              <p class="portal-hint">Certificate ID: <strong>${escapeHtml(cert.code)}</strong></p>
              <div class="portal-actions" style="justify-content:center;margin-top:20px;">
                <button type="button" class="portal-button portal-button--small" onclick="window.print()">Print Certificate</button>
                <button type="button" class="portal-button portal-button--small portal-button--quiet" data-back-courses>← Back to Courses</button>
              </div>
            </div>`);
          getMain().querySelector("[data-back-courses]")?.addEventListener("click", loadAndDraw);
        });
      });
      main.querySelectorAll("[data-req-refund]").forEach((b) => {
        b.addEventListener("click", async () => {
          const reason = await openPromptModal({
            title: "Request Fee Refund",
            label: "Reason for refund request (min 5 characters)",
            defaultValue: "Batch change request",
            minLength: 5,
          });
          if (reason.trim().length < 5) return;
          try {
            await api("/api/payments/refund-request", {
              method: "POST",
              body: { paymentId: Number(b.getAttribute("data-req-refund")), reason },
            });
            studentNoticeType = "success";
            studentNotice = "Refund request submitted to Yuitor Admin.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-sub-assign]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const fd = new FormData(f);
            let fileUrl = "";
            const file = fd.get("file");
            if (file instanceof File && file.size > 0) {
              const up = await uploadFile(file);
              fileUrl = up.url;
            }
            await api(`/api/student/assignments/${f.getAttribute("data-sub-assign")}/submit`, {
              method: "POST",
              body: { submissionText: fd.get("submissionText"), fileUrl },
            });
            studentNoticeType = "success";
            studentNotice = "Assignment submitted.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-quiz-form]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          try {
            const answers = Array.from(new FormData(f).values()).map(Number);
            const res = await api(`/api/student/quizzes/${f.getAttribute("data-quiz-form")}/attempt`, { method: "POST", body: { answers } });
            studentNoticeType = "success";
            studentNotice = res?.score !== undefined ? `Quiz submitted! Score: ${res.score}/${res.maxMarks || ""}` : "Quiz submitted.";
          } catch (err) {
            studentNoticeType = "error";
            studentNotice = err.message;
          }
          loadAndDraw();
        });
      });
      main.querySelector("[data-stu-avatar-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const file = new FormData(e.target).get("file");
          if (file instanceof File && file.size > 0) {
            const up = await uploadFile(file);
            await api("/api/auth/avatar", { method: "PATCH", body: { avatarUrl: up.url } });
            session.user.avatar_url = up.url;
            studentNoticeType = "success";
            studentNotice = "Profile photo updated.";
            loadAndDraw();
          }
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message;
          loadAndDraw();
        }
      });
      main.querySelector("[data-support-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const payload = Object.fromEntries(new FormData(e.target).entries());
          if (!payload.courseId) delete payload.courseId;
          if (!payload.teacherId) delete payload.teacherId;
          await api("/api/student/support", { method: "POST", body: payload });
          studentNoticeType = "success";
          studentNotice = "Doubt / support message sent.";
        } catch (err) {
          studentNoticeType = "error";
          studentNotice = err.message;
        }
        loadAndDraw();
      });
    }
    await loadAndDraw();
  }

  // ==================== TEACHER PANEL ====================
  function renderTeacherResumeGate(session, customMessage = "") {
    const resumeInfo = session?.teacherResume || {};
    const isRejected = resumeInfo.resumeStatus === "rejected";
    const main = mountShell(`
      ${impersonationBanner(session)}
      <div class="portal-card portal-profile yu-reg-card">
        <div class="yu-reg-hero">
          <p class="yu-reg-hero-kicker">Teacher Dashboard Access Restricted</p>
          <h1>Resume Submission Required</h1>
          <p>${escapeHtml(customMessage || TEACHER_MISSING_RESUME_MSG)}</p>
        </div>
        ${
          isRejected && resumeInfo.resumeNotes
            ? `<div class="portal-message portal-message--error">Admin Review Note: ${escapeHtml(resumeInfo.resumeNotes)}</div>`
            : ""
        }
        <form class="portal-form" data-teacher-gate-resume>
          <div class="portal-field">
            <label>Upload Updated Resume / CV (PDF, DOC, or DOCX · Max 5 MB) *</label>
            <div class="yu-resume-dropzone">
              <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
            </div>
          </div>
          <div class="portal-message" data-t-gate-fb hidden></div>
          <div class="portal-actions">
            <button type="submit" class="portal-button">Upload Resume &amp; Unlock Review</button>
            <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
          </div>
        </form>
      </div>`);

    main?.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
      await api("/api/auth/logout", { method: "POST" });
      window.location.assign("/login");
    });

    main?.querySelector("[data-teacher-gate-resume]")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const form = e.target;
      const fd = new FormData(form);
      const fb = main.querySelector("[data-t-gate-fb]");
      const btn = form.querySelector('button[type="submit"]');
      const file = fd.get("resume");
      if (!(file instanceof File) || file.size === 0) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = TEACHER_MISSING_RESUME_MSG;
        fb.hidden = false;
        return;
      }
      btn.disabled = true;
      try {
        await api("/api/auth/teacher-resume", { method: "POST", body: fd });
        const refreshed = await api("/api/auth/me");
        renderTeacherPanel(refreshed);
      } catch (err) {
        fb.className = "portal-message portal-message--error";
        fb.textContent = err.message;
        fb.hidden = false;
        btn.disabled = false;
      }
    });
  }

  async function renderTeacherPanel(session) {
    const resumeState = session?.teacherResume || {};
    if (!session.impersonation?.active && (!resumeState.hasResume || resumeState.resumeStatus === "missing" || resumeState.resumeStatus === "rejected")) {
      renderTeacherResumeGate(
        session,
        resumeState.resumeStatus === "rejected" ? TEACHER_REJECTED_RESUME_MSG : TEACHER_MISSING_RESUME_MSG
      );
      return;
    }

    if (session.user.verification_status !== "approved" && !session.impersonation?.active) {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Teacher Verification Pending</p>
          <div class="portal-heading"><h1>Application Under Review</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || TEACHER_PENDING_MSG)}</div>
          <p class="portal-hint" style="margin-bottom:14px;">Submitted resume: <strong>${escapeHtml(resumeState.resumeFilename || "On file")}</strong> (${escapeHtml(resumeState.resumeStatus || "submitted")})</p>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let selectedCourseId = null;
    let editingLessonId = null;
    let activeSubmissions = null;
    let selectedTeacherTest = null;
    let teacherNotice = "";
    let teacherNoticeType = "success";

    async function loadAndDraw() {
      let dash;
      try {
        dash = await api("/api/teacher/dashboard");
      } catch (err) {
        if (err?.data?.code === "RESUME_REQUIRED" || err?.status === 403) {
          renderTeacherResumeGate(session, err?.message || TEACHER_MISSING_RESUME_MSG);
          return;
        }
        throw err;
      }
      if (!selectedCourseId && dash.courses?.length) selectedCourseId = dash.courses[0].id;
      const [lessonsData, perfRes] = await Promise.all([
        selectedCourseId ? api(`/api/teacher/courses/${selectedCourseId}/lessons`) : Promise.resolve({ lessons: [] }),
        tab === "students" ? api("/api/teacher/performance-report").catch(() => ({ report: [] })) : Promise.resolve({ report: [] }),
      ]);
      const selectedCourse = (dash.courses || []).find((c) => Number(c.id) === Number(selectedCourseId));

      const navItems = [
        ["overview", "Dashboard", "dashboard"],
        ["lessons", "Courses", "book"],
        ["students", "Attendance", "users"],
        ["schedules", "Tests & Grading", "calendar"],
        ["crm_doubts", "Doubts & Roster", "mail"],
        ["messages", "Parent Chat", "mail"],
        ["referrals", "Referrals", "award"],
        ["wallet", "Wallet", "wallet"],
        ["profile", "Profile", "user"],
      ];

      let bodyHtml = "";
      if (tab === "overview") {
        const batches = dash.batches || [];
        const slots = dash.timetableSlots || [];
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <a href="#lessons" class="portal-stat portal-stat--link" data-t-stat-nav="lessons"><div><strong>${(dash.courses || []).length}</strong><span>Assigned Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></a>
            <a href="#teacher-assigned-batches" class="portal-stat portal-stat--link" data-t-stat-nav="batches"><div><strong>${batches.length}</strong><span>Assigned Batches</span></div><div class="portal-stat-icon">${icon("calendar")}</div></a>
            <a href="#students" class="portal-stat portal-stat--link" data-t-stat-nav="students"><div><strong>${(dash.students || []).length}</strong><span>Students</span></div><div class="portal-stat-icon">${icon("users")}</div></a>
            <a href="#schedules" class="portal-stat portal-stat--link" data-t-stat-nav="schedules"><div><strong>${(dash.offlineTests || []).length}</strong><span>Offline Tests</span></div><div class="portal-stat-icon">${icon("award")}</div></a>
          </div>
          <div data-v31-postreg-profile style="margin-bottom:16px;"></div>
          <div class="portal-card portal-profile" id="teacher-assigned-batches" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Assigned Batches &amp; Classrooms (${batches.length})</h3>
            ${
              batches.length
                ? `<div class="yu-timetable-grid">${batches.map((b) => `<div class="portal-detail"><span>${escapeHtml(b.course_title || "")} · ${escapeHtml(b.branch_name || "Main Campus")}</span><strong>${escapeHtml(b.name)} (${b.seats_used || 0}/${b.seat_limit} seats)</strong><span>${escapeHtml(b.room_name || "Room")} · ${escapeHtml(b.schedule_days || "")} ${escapeHtml(b.start_time || "")}-${escapeHtml(b.end_time || "")}</span></div>`).join("")}</div>`
                : `<p class="portal-hint">No specific batches assigned yet.</p>`
            }
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">My Weekly Teaching Timetable (${slots.length})</h3>
            ${
              slots.length
                ? `<div class="yu-timetable-grid">${slots.map((s) => `<div class="portal-detail"><span>${escapeHtml(s.day_of_week)} · ${escapeHtml(s.start_time)}–${escapeHtml(s.end_time)}</span><strong>${escapeHtml(s.subject_name)}</strong><span>${escapeHtml(s.course_title || "")}${s.batch_name ? " · " + escapeHtml(s.batch_name) : ""} · ${escapeHtml(s.room_name || "Room")}</span></div>`).join("")}</div>`
                : `<p class="portal-hint">No weekly timetable slots assigned yet.</p>`
            }
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Publish Batch / Class Announcement</h3>
            <form class="portal-form" data-t-ann-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course (Optional)</label><select name="courseId"><option value="">All My Students</option>${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
              </div>
              <div class="portal-field"><label>Announcement</label><textarea name="body" required></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Post Announcement</button>
            </form>
          </div>`;
      } else if (tab === "lessons") {
        const editLesson = (lessonsData.lessons || []).find((l) => Number(l.id) === Number(editingLessonId));
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <div class="portal-form-grid" style="margin-bottom:12px;">
              <div class="portal-field">
                <label>Select Assigned Course</label>
                <select data-t-course>${(dash.courses || []).map((c) => `<option value="${c.id}"${Number(selectedCourseId) === Number(c.id) ? " selected" : ""}>${escapeHtml(c.title)}</option>`).join("")}</select>
              </div>
            </div>
            ${
              selectedCourse
                ? `<form class="portal-form" data-t-course-edit style="margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--pt-border);">
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course Description</label><input name="description" value="${escAttr(selectedCourse.description || "")}"></div>
                      <div class="portal-field"><label>Duration (Months)</label><input name="durationMonths" type="number" min="1" max="60" value="${Number(selectedCourse.duration_months || 12)}"></div>
                      <div class="portal-field"><label>Update Course Thumbnail</label><input name="thumbnail" type="file" accept=".png,.jpg,.jpeg,.webp"></div>
                    </div>
                    <div><button type="submit" class="portal-button portal-button--small portal-button--quiet">Update Course Details</button></div>
                  </form>`
                : ""
            }
            <h3 class="portal-section-title">${editLesson ? `Edit Lesson: ${escapeHtml(editLesson.title)}` : "Add Lesson"}</h3>
            <form class="portal-form" ${editLesson ? `data-t-edit-lesson="${editLesson.id}"` : "data-t-lesson-form"}>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Lesson Title *</label><input name="title" required value="${escAttr(editLesson?.title || "")}"></div>
                <div class="portal-field"><label>Type</label><select name="lessonType"><option value="text"${editLesson?.lesson_type === "text" ? " selected" : ""}>Text Notes</option><option value="video"${editLesson?.lesson_type === "video" ? " selected" : ""}>Video</option><option value="pdf"${editLesson?.lesson_type === "pdf" ? " selected" : ""}>PDF Notes</option></select></div>
                <div class="portal-field"><label>Material / Video URL</label><input name="materialUrl" value="${escAttr(editLesson?.material_url || editLesson?.video_url || "")}" placeholder="https:// or uploaded PDF URL"></div>
                <div class="portal-field"><label>Or Upload Study PDF / Image</label><input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></div>
              </div>
              <div class="portal-field"><label>Content / Summary</label><textarea name="content">${escapeHtml(editLesson?.content || "")}</textarea></div>
              <div class="portal-actions">
                <button type="submit" class="portal-button portal-button--small">${editLesson ? "Save Lesson" : "Add Lesson"}</button>
                ${editLesson ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-cancel-edit-lesson>Cancel</button>` : ""}
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Lessons Order (Drag &amp; Drop or use ↑ / ↓)</h3>
            <div data-drag-lesson-list>
              ${(lessonsData.lessons || []).map((l, idx) => `
                <div class="portal-detail portal-drag-row" draggable="true" data-lesson-id="${l.id}" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div><strong>${idx + 1}. ${escapeHtml(l.title)}</strong><span>${escapeHtml(l.lesson_type)} · ${l.is_visible ? "Visible" : "Hidden"}${l.material_url ? " · Attachment linked" : ""}</span></div>
                  <div class="portal-actions">
                    ${idx > 0 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="-1">${icon("arrowUp")}</button>` : ""}
                    ${idx < lessonsData.lessons.length - 1 ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-move-l="${l.id}" data-dir="1">${icon("arrowDown")}</button>` : ""}
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-edit-l="${l.id}">${icon("edit")} Edit</button>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-vis-l="${l.id}" data-vis="${l.is_visible ? 0 : 1}">${l.is_visible ? "Hide" : "Show"}</button>
                    <button type="button" class="portal-button portal-button--small portal-button--danger" data-del-l="${l.id}">${icon("trash")}</button>
                  </div>
                </div>`).join("") || `<p class="portal-hint">No lessons yet.</p>`}
            </div>
          </div>`;
      } else if (tab === "students") {
        const qrList = dash.activeQrSessions || [];
        const perfRows = perfRes.report || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">QR Classroom Attendance Generator</h3>
            <form class="portal-form" data-t-qr-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course *</label><select name="courseId" required>${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch (Optional)</label><select name="batchId"><option value="">All Batches</option>${(dash.batches || []).map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Valid Minutes</label><input name="expiresMinutes" type="number" min="5" max="180" value="20"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">${icon("calendar")} Generate Live Classroom QR</button>
            </form>
            ${
              qrList.length
                ? `<div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));">
                    ${qrList.map((q) => `<div class="portal-detail" style="display:flex;gap:12px;align-items:center;">
                      <div class="yu-qr-box">${q.qrSvg || ""}</div>
                      <div style="min-width:0;">
                        <strong>${escapeHtml(q.course_title)}</strong>
                        <span>${escapeHtml(q.batch_name || "All Batches")} · ${escapeHtml(q.session_date)}</span>
                        <span>Code: <strong>${escapeHtml(q.token_code)}</strong></span>
                        <div style="margin-top:6px;"><button type="button" class="portal-button portal-button--small portal-button--quiet" data-copy-qr="${escAttr(q.checkinUrl || q.token_code)}">Copy Link</button></div>
                      </div>
                    </div>`).join("")}
                  </div>`
                : `<p class="portal-hint">No active QR attendance sessions right now.</p>`
            }
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Mark Today's Classroom Attendance</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student</th><th>Course</th><th>Progress</th><th>Mark Today</th></tr></thead>
            <tbody>
              ${(dash.students || []).map((s) => `<tr>
                <td><span class="portal-cell-title">${escapeHtml(s.full_name)}</span><span class="portal-cell-sub">${escapeHtml(s.phone)}</span></td>
                <td>${escapeHtml(s.course_title)}</td>
                <td>${s.progress_percent}%</td>
                <td><div class="portal-actions">
                  <button type="button" class="portal-button portal-button--small" data-att="${s.id}" data-cid="${s.course_id}" data-st="present">Present</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-att="${s.id}" data-cid="${s.course_id}" data-st="late">Late</button>
                  <button type="button" class="portal-button portal-button--small portal-button--quiet" data-att="${s.id}" data-cid="${s.course_id}" data-st="absent">Absent</button>
                </div></td>
              </tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No assigned students yet.</td></tr>`}
            </tbody>
          </table></div></div>
          <div class="portal-card portal-table-card"><div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Student Performance Analytics Report</div><div class="portal-table-scroll"><table class="portal-table">
            <thead><tr><th>Student (Roll No)</th><th>Course</th><th>Attendance</th><th>Offline Avg / Best Rank</th><th>Quiz Avg</th><th>Course Progress</th></tr></thead>
            <tbody>
              ${perfRows.map((r) => `<tr><td>${escapeHtml(r.full_name)} <span class="portal-cell-sub">${escapeHtml(r.roll_number || "")}</span></td><td>${escapeHtml(r.course_title)}</td><td>${r.attendance_pct != null ? r.attendance_pct + "%" : "—"}</td><td>${r.offline_avg_pct != null ? r.offline_avg_pct + "%" : "—"}${r.best_rank ? ` · Rank #${r.best_rank}` : ""}</td><td>${r.quiz_avg_pct != null ? r.quiz_avg_pct + "%" : "—"}</td><td>${r.progress_percent || 0}%</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No student performance metrics yet.</td></tr>`}
            </tbody>
          </table></div></div>`;
      } else if (tab === "schedules") {
        const offTests = dash.offlineTests || [];
        bodyHtml = `
          ${
            selectedTeacherTest
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <div class="portal-profile-head">
                    <div><h3>Marks Entry &amp; Rank List: ${escapeHtml(selectedTeacherTest.test.title)}</h3><p>Max Marks: ${selectedTeacherTest.test.max_marks} · Passing: ${selectedTeacherTest.test.passing_marks}</p></div>
                    <button type="button" class="portal-button portal-button--small portal-button--quiet" data-t-close-marks>Close Sheet</button>
                  </div>
                  <form class="portal-form" data-t-save-marks="${selectedTeacherTest.test.id}">
                    <div class="portal-table-scroll" style="margin-bottom:12px;"><table class="portal-table">
                      <thead><tr><th>Rank</th><th>Student (Roll No)</th><th>Marks</th><th>Absent?</th><th>Remarks</th></tr></thead>
                      <tbody>
                        ${(selectedTeacherTest.students || []).map((st) => `<tr data-t-mark-row="${st.student_id}">
                          <td>${st.rank_position ? `<strong>#${st.rank_position}</strong>` : "—"}</td>
                          <td>${escapeHtml(st.full_name)} <span class="portal-cell-sub">${escapeHtml(st.roll_number || "")}</span></td>
                          <td><input name="marks" type="number" step="0.5" min="0" max="${Number(selectedTeacherTest.test.max_marks || 100)}" value="${escAttr(st.marks_obtained ?? 0)}" style="width:90px;"></td>
                          <td><input name="absent" type="checkbox"${st.is_absent ? " checked" : ""}></td>
                          <td><input name="remarks" value="${escAttr(st.remarks || "")}" placeholder="Remarks"></td>
                        </tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No enrolled students found.</td></tr>`}
                      </tbody>
                    </table></div>
                    <button type="submit" class="portal-button portal-button--small">Save Marks &amp; Update Ranks</button>
                  </form>
                </div>`
              : ""
          }
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Offline Tests &amp; Bulk Marks Entry (${offTests.length})</h3>
            <form class="portal-form" data-t-offline-test-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course *</label><select name="courseId" required>${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Batch (Optional)</label><select name="batchId"><option value="">All Batches</option>${(dash.batches || []).map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Test Title *</label><input name="title" required placeholder="e.g. Weekly Mock Test 4"></div>
                <div class="portal-field"><label>Subject</label><input name="subjectName" value="All Subjects"></div>
                <div class="portal-field"><label>Test Date</label><input name="testDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
                <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="100"></div>
                <div class="portal-field"><label>Exam Room</label><input name="roomName" value="Exam Hall 1"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Create Offline Test</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Test</th><th>Course / Batch</th><th>Date</th><th>Graded / Avg</th><th>Action</th></tr></thead>
              <tbody>
                ${offTests.map((t) => `<tr><td><strong>${escapeHtml(t.title)}</strong><span class="portal-cell-sub">${escapeHtml(t.subject_name)} · Max ${t.max_marks}</span></td><td>${escapeHtml(t.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(t.batch_name || "All")}</span></td><td>${escapeHtml(t.test_date)}</td><td>${t.marks_entered || 0} · Avg ${t.avg_marks ?? "—"}</td><td><button type="button" class="portal-button portal-button--small" data-t-open-marks="${t.id}">Enter Marks &amp; Ranks</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No offline tests created yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Schedule Class / Online Session</h3>
            <form class="portal-form" data-t-sched-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Session Title</label><input name="title" required placeholder="e.g. Algebra Doubt Session"></div>
                <div class="portal-field"><label>Date</label><input name="scheduledDate" type="date" required></div>
                <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00" required></div>
                <div class="portal-field"><label>End Time</label><input name="endTime" value="17:00" required></div>
                <div class="portal-field"><label>Mode</label><select name="mode"><option value="offline">Classroom (Muradnagar)</option><option value="online">Online (Meet/Zoom)</option></select></div>
                <div class="portal-field"><label>Meeting Link (if online)</label><input name="meetingLink" placeholder="https://meet.google.com/..."></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Schedule Class</button>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Create Assignment &amp; Grade Submissions</h3>
            <form class="portal-form" data-t-assign-form style="margin-bottom:16px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Title</label><input name="title" required></div>
                <div class="portal-field"><label>Due Date</label><input name="dueDate" type="date" required></div>
                <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="50"></div>
              </div>
              <div class="portal-field"><label>Instructions</label><textarea name="description"></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Publish Assignment</button>
            </form>
            ${(dash.assignments || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;"><div><strong>${escapeHtml(a.title)} (${escapeHtml(a.course_title)})</strong><span>Due: ${escapeHtml(a.due_date)} · Submissions: ${a.submissions_count}</span></div><button type="button" class="portal-button portal-button--small portal-button--quiet" data-view-subs="${a.id}">Review Submissions</button></div>`).join("")}
            ${activeSubmissions ? `<div style="margin-top:12px;"><h4>Submissions</h4>${(activeSubmissions.submissions || []).map((s) => { const fUrl = safeHref(s.file_url); return `<form class="portal-form" data-grade-sub="${s.id}" style="border-top:1px solid var(--pt-border);padding-top:10px;margin-top:10px;"><div><strong>${escapeHtml(s.student_name)}</strong>: ${escapeHtml(s.submission_text)} ${fUrl ? `<a href="${escAttr(fUrl)}" target="_blank" rel="noopener noreferrer">View Attachment</a>` : ""}</div><div class="portal-form-grid"><input name="marksObtained" type="number" placeholder="Marks" value="${s.marks_obtained ?? ""}" required><input name="feedback" placeholder="Feedback" value="${escAttr(s.feedback || "")}"></div><button type="submit" class="portal-button portal-button--small">Save Grade</button></form>`; }).join("") || `<p class="portal-hint">No student submissions yet.</p>`}</div>` : ""}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quick MCQ Quiz Builder</h3>
            <form class="portal-form" data-t-quiz-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Course</label><select name="courseId">${(dash.courses || []).map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                <div class="portal-field"><label>Quiz Title</label><input name="title" required></div>
                <div class="portal-field"><label>Question 1</label><input name="qText" required placeholder="e.g. What is SI unit of Force?"></div>
                <div class="portal-field"><label>4 Comma-Separated Options</label><input name="qOptions" required placeholder="Newton, Joule, Watt, Pascal"></div>
                <div class="portal-field"><label>Correct Option Index (0–3)</label><input name="correctIndex" type="number" min="0" max="3" value="0"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Publish Quiz</button>
            </form>
          </div>`;
      } else if (tab === "messages") {
        const pMsgs = dash.parentMessages || [];
        const doubts = dash.studentDoubts || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Parent–Teacher Messages (${pMsgs.length})</h3>
            ${pMsgs.map((m) => `
              <div class="portal-detail" style="margin-bottom:10px;">
                <span>${escapeHtml(m.created_at)} · <strong>${escapeHtml(m.sender_role === "teacher" ? "You" : m.parent_name)}</strong> regarding <strong>${escapeHtml(m.student_name)}</strong> (${escapeHtml(m.parent_phone || "")})</span>
                <div>${escapeHtml(m.message)}</div>
                ${
                  m.sender_role === "parent"
                    ? `<form class="portal-form" data-t-preply-form style="margin-top:8px;">
                        <input type="hidden" name="parentId" value="${m.parent_id}">
                        <input type="hidden" name="studentId" value="${m.student_id}">
                        <div class="portal-actions">
                          <input name="message" required placeholder="Write reply to parent..." style="flex:1 1 200px;min-width:0;max-width:100%;">
                          <button type="submit" class="portal-button portal-button--small">Send Reply</button>
                        </div>
                      </form>`
                    : ""
                }
              </div>`).join("") || `<p class="portal-hint">No messages from parents yet.</p>`}
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Student Subject Doubts (${doubts.length})</h3>
            ${doubts.map((d) => `
              <div class="portal-detail" style="margin-bottom:10px;">
                <span>${escapeHtml(d.created_at)} · ${escapeHtml(d.student_name)}${d.course_title ? " · " + escapeHtml(d.course_title) : ""} · ${statusBadge(d.status || "open")}</span>
                <strong>${escapeHtml(d.subject)}</strong>
                <div>${escapeHtml(d.body)}</div>
                ${d.admin_reply ? `<div style="margin-top:6px;padding:8px 10px;border-radius:8px;background:rgba(16,185,129,.12);"><strong>Answered:</strong> ${escapeHtml(d.admin_reply)}</div>` : ""}
                <form class="portal-form" data-t-doubt-reply="${d.id}" style="margin-top:8px;">
                  <div class="portal-actions">
                    <input name="reply" required placeholder="Type answer to student doubt..." style="flex:1 1 200px;min-width:0;max-width:100%;">
                    <button type="submit" class="portal-button portal-button--small">Reply to Student</button>
                  </div>
                </form>
              </div>`).join("") || `<p class="portal-hint">No student doubts assigned right now.</p>`}
          </div>`;
      } else {
        const tp = dash.profile || {};
        const earn = dash.earningsSummary || {};
        const leaves = dash.leaveRequests || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Earnings &amp; Payout Status</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Monthly Payout Rate</span><strong>${formatINR(earn.monthlyPayoutRate || tp.monthly_payout_rate || 0)}</strong></div>
              <div class="portal-detail"><span>Assigned Active Students</span><strong>${Number(earn.activeStudentsCount || 0)}</strong></div>
              <div class="portal-detail"><span>Configured Payout UPI</span><strong>${escapeHtml(earn.payoutUpi || tp.payout_upi || "Not set yet")}</strong></div>
            </div>
            ${earn.limitationNote ? `<p class="portal-hint" style="margin-top:10px;">${escapeHtml(earn.limitationNote)}</p>` : ""}
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Leave Request &amp; History (${leaves.length})</h3>
            <form class="portal-form" data-t-leave-form style="margin-bottom:14px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>From Date *</label><input name="fromDate" type="date" required></div>
                <div class="portal-field"><label>To Date *</label><input name="toDate" type="date" required></div>
              </div>
              <div class="portal-field"><label>Reason *</label><textarea name="reason" rows="2" required placeholder="Reason for leave & substitute batch note..."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Submit Leave Request</button>
            </form>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Dates</th><th>Reason</th><th>Status</th><th>Admin Note</th></tr></thead>
              <tbody>
                ${leaves.map((l) => `<tr><td>${escapeHtml(l.from_date)} to ${escapeHtml(l.to_date)}</td><td>${escapeHtml(l.reason)}</td><td>${statusBadge(l.status)}</td><td>${escapeHtml(l.admin_note || "-")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No leave requests submitted.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Profile Photo</h3>
            <form class="portal-form" data-t-avatar-form>
              <div class="portal-actions">
                <img src="${escAttr(safeHref(session.user.avatar_url, "/yuitor-icon-192.png"))}" alt="Avatar" class="portal-avatar">
                <input type="file" name="file" accept=".png,.jpg,.jpeg,.webp" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Upload Photo</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Resume &amp; Verification Document</h3>
            <div class="portal-personal-grid" style="margin-bottom:12px;">
              <div class="portal-detail"><span>Current Resume File</span><strong>${escapeHtml(tp.resume_filename || "Uploaded")}</strong></div>
              <div class="portal-detail"><span>Verification Status</span><strong>${statusBadge(tp.resume_status || "submitted")}</strong></div>
              <div class="portal-detail"><span>Uploaded Timestamp</span><strong>${escapeHtml(tp.resume_uploaded_at || "Recorded")}</strong></div>
            </div>
            <form class="portal-form" data-t-resume-update-form>
              <div class="portal-actions">
                ${tp.resume_url ? `<a href="/api/teacher/resume" target="_blank" rel="noopener" class="portal-button portal-button--small portal-button--quiet">${icon("download")} View / Download Resume</a>` : ""}
                <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
                <button type="submit" class="portal-button portal-button--small">${icon("upload")} Update Resume</button>
              </div>
            </form>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Faculty Profile &amp; Availability</h3>
            <form class="portal-form" data-t-prof-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Full Name</label><input name="fullName" value="${escAttr(session.user.full_name)}"></div>
                <div class="portal-field"><label>Qualification</label><input name="qualification" value="${escAttr(tp.qualification || "")}"></div>
                <div class="portal-field"><label>Availability Status</label><select name="availabilityStatus"><option value="available"${tp.availability_status === "available" ? " selected" : ""}>Available</option><option value="vacation"${tp.availability_status === "vacation" ? " selected" : ""}>Vacation Mode</option></select></div>
                <div class="portal-field"><label>Vacation Note</label><input name="vacationNote" value="${escAttr(tp.vacation_note || "")}"></div>
                <div class="portal-field"><label>Payout UPI (Optional)</label><input name="payoutUpi" value="${escAttr(tp.payout_upi || "")}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Save Profile</button>
            </form>
          </div>`;
      }
      if (tab === "referrals" || tab === "wallet") {
        bodyHtml = `<div data-yu-user-addon="${escAttr(tab)}"></div>`;
      }

      const noticeHtml = teacherNotice
        ? `<div class="portal-message portal-message--${teacherNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(teacherNotice)}</div>`
        : "";

      if (tab === "crm_doubts") {
        bodyHtml = `<div data-yu-teacher-crm></div>`;
      }

      const main = renderWorkspace({
        session,
        portalTitle: "Teacher Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          editingLessonId = null;
          selectedTeacherTest = null;
          teacherNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        bodyHtml: noticeHtml + bodyHtml,
      });

      window.YuitorUI?.enhanceTables?.(main?.querySelector("[data-ws-body]"));

      const tchProfEl = main?.querySelector("[data-v31-postreg-profile]");
      if (tchProfEl && window.YuitorV31) {
        window.YuitorV31.renderPostRegProfileCard(tchProfEl, "teacher", () => loadAndDraw());
      }

      const tAddonEl = main?.querySelector("[data-yu-user-addon]");
      if (tAddonEl && window.YuitorAddons) {
        if (tab === "referrals") window.YuitorAddons.renderUserReferralsTab(tAddonEl, "teacher");
        else if (tab === "wallet") window.YuitorAddons.renderUserWalletTab(tAddonEl, "teacher");
      }
      const tCrmEl = main?.querySelector("[data-yu-teacher-crm]");
      if (tCrmEl && window.YuitorCrmV25) {
        window.YuitorCrmV25.renderTeacherCrmTab(tCrmEl);
      }

      main.querySelectorAll("[data-t-stat-nav]").forEach((card) => {
        card.addEventListener("click", (e) => {
          e.preventDefault();
          const dest = card.getAttribute("data-t-stat-nav");
          if (dest === "batches") {
            const target = main.querySelector("#teacher-assigned-batches");
            if (target) {
              target.scrollIntoView({ behavior: "smooth", block: "start" });
              target.style.boxShadow = "0 0 0 2px var(--pt-primary)";
              setTimeout(() => {
                target.style.boxShadow = "";
              }, 1400);
            }
            return;
          }
          if (dest) {
            tab = dest;
            editingLessonId = null;
            selectedTeacherTest = null;
            teacherNotice = "";
            loadAndDraw();
          }
        });
      });

      const runTeacherAction = async (fn, successMsg) => {
        try {
          await fn();
          teacherNoticeType = "success";
          teacherNotice = successMsg || "";
        } catch (err) {
          teacherNoticeType = "error";
          teacherNotice = err?.message || "Action failed. Please check inputs and try again.";
        }
        loadAndDraw();
      };

      main.querySelector("[data-t-ann-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/announcements", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Announcement published.");
      });
      main.querySelector("[data-t-course]")?.addEventListener("change", (e) => {
        selectedCourseId = Number(e.target.value);
        editingLessonId = null;
        teacherNotice = "";
        loadAndDraw();
      });
      main.querySelector("[data-t-course-edit]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let thumbnailUrl;
          const f = fd.get("thumbnail");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            thumbnailUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}`, {
            method: "PATCH",
            body: { description: fd.get("description"), durationMonths: Number(fd.get("durationMonths") || 12), thumbnailUrl },
          });
        }, "Course details updated.");
      });
      main.querySelector("[data-t-lesson-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/courses/${selectedCourseId}/lessons`, {
            method: "POST",
            body: {
              title: fd.get("title"),
              lessonType: fd.get("lessonType"),
              materialUrl,
              content: fd.get("content"),
            },
          });
        }, "Lesson added.");
      });
      main.querySelector("[data-t-edit-lesson]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const lid = e.target.getAttribute("data-t-edit-lesson");
        const fd = new FormData(e.target);
        await runTeacherAction(async () => {
          let materialUrl = String(fd.get("materialUrl") || "");
          const f = fd.get("file");
          if (f instanceof File && f.size > 0) {
            const up = await uploadFile(f);
            materialUrl = up.url;
          }
          await api(`/api/teacher/lessons/${lid}`, {
            method: "PATCH",
            body: { title: fd.get("title"), lessonType: fd.get("lessonType"), materialUrl, content: fd.get("content") },
          });
          editingLessonId = null;
        }, "Lesson updated.");
      });
      main.querySelector("[data-cancel-edit-lesson]")?.addEventListener("click", () => {
        editingLessonId = null;
        loadAndDraw();
      });
      main.querySelectorAll("[data-edit-l]").forEach((b) => {
        b.addEventListener("click", () => {
          editingLessonId = Number(b.getAttribute("data-edit-l"));
          loadAndDraw().then(() => window.YuitorV31?.scrollToAndFocus("[data-t-edit-lesson]"));
        });
      });
      main.querySelectorAll("[data-del-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (window.YuitorV31?.confirmModal) {
            const ok = await window.YuitorV31.confirmModal({
              title: "Delete Lesson",
              message: "Are you sure you want to delete this lesson?",
              confirmLabel: "Yes, Delete",
              variant: "danger",
            });
            if (!ok) return;
          }
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-del-l")}`, { method: "DELETE" });
          }, "Lesson deleted.");
        });
      });

      // Drag-and-drop lesson reorder
      const dragList = main.querySelector("[data-drag-lesson-list]");
      let draggedId = null;
      dragList?.querySelectorAll("[data-lesson-id]").forEach((row) => {
        row.addEventListener("dragstart", () => {
          draggedId = Number(row.getAttribute("data-lesson-id"));
          row.classList.add("is-dragging");
        });
        row.addEventListener("dragend", () => row.classList.remove("is-dragging"));
        row.addEventListener("dragover", (e) => e.preventDefault());
        row.addEventListener("drop", async (e) => {
          e.preventDefault();
          const targetId = Number(row.getAttribute("data-lesson-id"));
          if (!draggedId || draggedId === targetId) return;
          const ids = (lessonsData.lessons || []).map((l) => Number(l.id));
          const fromIdx = ids.indexOf(draggedId);
          const toIdx = ids.indexOf(targetId);
          if (fromIdx >= 0 && toIdx >= 0) {
            ids.splice(toIdx, 0, ids.splice(fromIdx, 1)[0]);
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });

      main.querySelectorAll("[data-move-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          const id = Number(b.getAttribute("data-move-l"));
          const dir = Number(b.getAttribute("data-dir"));
          const ids = (lessonsData.lessons || []).map((l) => l.id);
          const idx = ids.indexOf(id);
          if (idx >= 0 && idx + dir >= 0 && idx + dir < ids.length) {
            [ids[idx], ids[idx + dir]] = [ids[idx + dir], ids[idx]];
            await runTeacherAction(async () => {
              await api(`/api/teacher/courses/${selectedCourseId}/lessons/reorder`, { method: "POST", body: { orderedIds: ids } });
            }, "Lesson order updated.");
          }
        });
      });
      main.querySelectorAll("[data-vis-l]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api(`/api/teacher/lessons/${b.getAttribute("data-vis-l")}`, {
              method: "PATCH",
              body: { isVisible: b.getAttribute("data-vis") === "1" },
            });
          }, "Lesson visibility updated.");
        });
      });
      main.querySelector("[data-t-qr-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          const r = await api("/api/teacher/attendance/qr-session", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
          teacherNotice = `QR Session active (${r.tokenCode}) for ${r.expiresMinutes} minutes.`;
        });
      });
      main.querySelectorAll("[data-copy-qr]").forEach((b) => {
        b.addEventListener("click", async () => {
          const text = b.getAttribute("data-copy-qr") || "";
          try {
            await navigator.clipboard.writeText(text);
            b.textContent = "Copied!";
          } catch {
            b.textContent = text;
          }
        });
      });
      main.querySelectorAll("[data-att]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            await api("/api/teacher/attendance", {
              method: "POST",
              body: {
                courseId: Number(b.getAttribute("data-cid")),
                attDate: new Date().toISOString().slice(0, 10),
                records: [{ studentId: Number(b.getAttribute("data-att")), status: b.getAttribute("data-st") }],
              },
            });
          }, "Attendance marked.");
        });
      });
      main.querySelector("[data-t-offline-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/offline-tests", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Offline test created.");
      });
      main.querySelectorAll("[data-t-open-marks]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            selectedTeacherTest = await api(`/api/teacher/offline-tests/${b.getAttribute("data-t-open-marks")}/marks`);
          }, "");
        });
      });
      main.querySelector("[data-t-close-marks]")?.addEventListener("click", () => {
        selectedTeacherTest = null;
        loadAndDraw();
      });
      main.querySelector("[data-t-save-marks]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const tid = e.target.getAttribute("data-t-save-marks");
        const marks = Array.from(e.target.querySelectorAll("[data-t-mark-row]")).map((tr) => ({
          studentId: Number(tr.getAttribute("data-t-mark-row")),
          marksObtained: Number(tr.querySelector('input[name="marks"]')?.value || 0),
          isAbsent: Boolean(tr.querySelector('input[name="absent"]')?.checked),
          remarks: tr.querySelector('input[name="remarks"]')?.value || "",
        }));
        await runTeacherAction(async () => {
          await api(`/api/teacher/offline-tests/${tid}/marks`, { method: "POST", body: { marks } });
          selectedTeacherTest = await api(`/api/teacher/offline-tests/${tid}/marks`);
        }, "Marks saved & class rank list updated.");
      });
      main.querySelector("[data-t-sched-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/schedules", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Class schedule saved.");
      });
      main.querySelector("[data-t-assign-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/assignments", { method: "POST", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Assignment published.");
      });
      main.querySelectorAll("[data-view-subs]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runTeacherAction(async () => {
            activeSubmissions = await api(`/api/teacher/assignments/${b.getAttribute("data-view-subs")}/submissions`);
          }, "");
        });
      });
      main.querySelectorAll("[data-grade-sub]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          await runTeacherAction(async () => {
            await api(`/api/teacher/submissions/${f.getAttribute("data-grade-sub")}/grade`, {
              method: "POST",
              body: Object.fromEntries(new FormData(f).entries()),
            });
          }, "Submission graded.");
        });
      });
      main.querySelector("[data-t-quiz-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const options = String(fd.get("qOptions") || "").split(",").map((s) => s.trim()).filter(Boolean);
        await runTeacherAction(async () => {
          await api("/api/teacher/quizzes", {
            method: "POST",
            body: {
              courseId: Number(fd.get("courseId")),
              title: fd.get("title"),
              maxMarks: 10,
              durationMinutes: 15,
              questions: [{ question: fd.get("qText"), options, correctIndex: Number(fd.get("correctIndex") || 0) }],
            },
          });
        }, "Quiz published.");
      });
      main.querySelectorAll("[data-t-preply-form]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          await runTeacherAction(async () => {
            await api("/api/teacher/parent-messages/reply", { method: "POST", body: Object.fromEntries(new FormData(f).entries()) });
          }, "Reply sent to parent.");
        });
      });
      main.querySelectorAll("[data-t-doubt-reply]").forEach((f) => {
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          await runTeacherAction(async () => {
            await api("/api/teacher/support-reply", {
              method: "POST",
              body: { supportId: Number(f.getAttribute("data-t-doubt-reply")), reply: new FormData(f).get("reply") },
            });
          }, "Doubt reply sent to student.");
        });
      });
      main.querySelector("[data-t-leave-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runTeacherAction(async () => {
          await api("/api/teacher/leave-requests", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Leave request submitted for Admin review.");
      });
      main.querySelector("[data-t-avatar-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const file = new FormData(e.target).get("file");
        if (file instanceof File && file.size > 0) {
          await runTeacherAction(async () => {
            const up = await uploadFile(file);
            await api("/api/auth/avatar", { method: "PATCH", body: { avatarUrl: up.url } });
            session.user.avatar_url = up.url;
          }, "Profile photo updated.");
        }
      });
      main.querySelector("[data-t-resume-update-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const file = fd.get("resume");
        if (file instanceof File && file.size > 0) {
          await runTeacherAction(async () => {
            await api("/api/auth/teacher-resume", { method: "POST", body: fd });
          }, "Resume updated and recorded.");
        }
      });
      main.querySelector("[data-t-prof-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formEl = e.target;
        await runTeacherAction(async () => {
          await api("/api/teacher/profile", { method: "PATCH", body: Object.fromEntries(new FormData(formEl).entries()) });
        }, "Faculty profile saved.");
      });
    }
    await loadAndDraw();
  }

  // ==================== PARENT PANEL ====================
  async function renderParentPanel(session) {
    if (session.user.verification_status !== "approved" && !session.impersonation?.active) {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Parent Account Status</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let selectedChildIdx = 0;
    let showLinkForm = false;
    let parentNotice = "";
    let parentNoticeType = "success";

    async function loadAndDraw() {
      const dash = await api("/api/parent/dashboard");
      const children = dash.children || [];
      if (selectedChildIdx >= children.length) selectedChildIdx = 0;
      const child = children[selectedChildIdx] || null;

      const navItems = [
        ["overview", "Overview", "dashboard"],
        ["attendance", "Attendance", "calendar"],
        ["marks", "Marks", "award"],
        ["fees", "Fees", "wallet"],
        ["messages", "Teachers", "mail"],
      ];

      const linkChildCard = `
        <div class="portal-card portal-profile" style="margin-bottom:16px;">
          <h3 class="portal-section-title">Link Student / Child Account</h3>
          <p class="portal-hint" style="margin-bottom:12px;">Enter your child's Student Roll Number (e.g. <code>YTR-STU-0002</code>) or registered Student Mobile Number to view attendance, test ranks, fees, and message faculty.</p>
          <form class="portal-form" data-p-link-form>
            <div class="portal-form-grid">
              <div class="portal-field"><label>Student Roll Number</label><input name="rollNumber" placeholder="e.g. YTR-STU-0002"></div>
              <div class="portal-field"><label>Student Mobile (Optional if Roll No entered)</label><input name="studentPhone" placeholder="10-digit mobile"></div>
              <div class="portal-field"><label>Relation</label>
                <select name="relation">
                  <option value="Father">Father</option>
                  <option value="Mother">Mother</option>
                  <option value="Guardian">Guardian</option>
                </select>
              </div>
            </div>
            <div class="portal-actions">
              <button type="submit" class="portal-button portal-button--small">Link Child Account</button>
              ${children.length ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-p-toggle-link>Close</button>` : ""}
            </div>
          </form>
        </div>`;

      const childBar = children.length
        ? `<div class="portal-card portal-profile" style="margin-bottom:16px;padding:12px 16px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;">
              <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;">
                <span class="portal-hint" style="font-weight:700;">Viewing Child:</span>
                ${children
                  .map(
                    (c, idx) =>
                      `<button type="button" class="portal-button portal-button--small ${idx === selectedChildIdx ? "" : "portal-button--quiet"}" data-p-child-idx="${idx}">${escapeHtml(c.student?.full_name || "Student")} (${escapeHtml(c.student?.roll_number || `#${c.student?.id}`)})</button>`
                  )
                  .join("")}
              </div>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-p-toggle-link>${showLinkForm ? "Hide Link Form" : "+ Link Another Child"}</button>
            </div>
          </div>`
        : "";

      let bodyHtml = childBar + (!children.length || showLinkForm ? linkChildCard : "");

      if (!child) {
        bodyHtml += `
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">No Child Linked Yet</h3>
            <p class="portal-subtitle">Use the form above with your child's Yuitor Roll Number or registered mobile number to connect their academic record.</p>
          </div>`;
      } else if (tab === "overview") {
        const st = child.student || {};
        const attSum = child.attendanceSummary || {};
        const dueInsts = (child.installments || []).filter((i) => i.status !== "paid");
        const overdueCount = dueInsts.filter((i) => i.status === "overdue").length;
        const pendingFeeBalance = (child.feeRecords || []).reduce(
          (acc, f) => acc + Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0) - Number(f.paid_amount || 0)),
          0
        );
        bodyHtml += `
          ${
            dueInsts.length
              ? `<div class="portal-message portal-message--${overdueCount ? "error" : "success"}" style="margin-bottom:14px;">
                  <strong>${overdueCount ? "Fee Overdue Alert" : "Upcoming Fee Due Alert"}:</strong>
                  ${dueInsts.length} pending installment(s) for <strong>${escapeHtml(st.full_name)}</strong> — next due <strong>${escapeHtml(dueInsts[0].due_date)}</strong> (${formatINR(Math.max(0, Number(dueInsts[0].amount) - Number(dueInsts[0].paid_amount || 0)))}).
                </div>`
              : ""
          }
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${Number(attSum.percentage ?? 100)}%</strong><span>Attendance Rate</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${(child.offlineTests || []).length}</strong><span>Offline Tests</span></div><div class="portal-stat-icon">${icon("award")}</div></div>
            <div class="portal-stat"><div><strong>${formatINR(pendingFeeBalance)}</strong><span>Pending Fee Balance</span></div><div class="portal-stat-icon">${icon("wallet")}</div></div>
            <div class="portal-stat"><div><strong>${(child.enrollments || []).length}</strong><span>Enrolled Courses</span></div><div class="portal-stat-icon">${icon("book")}</div></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Student Profile &amp; Batch Assignment</h3>
            <div class="portal-personal-grid">
              <div class="portal-detail"><span>Student Name</span><strong>${escapeHtml(st.full_name)}</strong></div>
              <div class="portal-detail"><span>Roll Number</span><strong>${escapeHtml(st.roll_number || `#${st.id}`)}</strong></div>
              <div class="portal-detail"><span>Class &amp; Board</span><strong>${escapeHtml(st.class_level || "-")} · ${escapeHtml(st.board || "-")}</strong></div>
              <div class="portal-detail"><span>Centre / Branch</span><strong>${escapeHtml(st.branch_name || "Main Centre")}</strong></div>
              <div class="portal-detail"><span>Assigned Batch</span><strong>${escapeHtml(st.batch_name || "Regular Batch")}</strong></div>
              <div class="portal-detail"><span>Schedule &amp; Room</span><strong>${escapeHtml(st.schedule_days || "-")} ${escapeHtml(st.start_time || "")}${st.end_time ? "–" + escapeHtml(st.end_time) : ""} ${st.room_name ? "(" + escapeHtml(st.room_name) + ")" : ""}</strong></div>
            </div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Institute Notices &amp; Announcements</h3>
            ${(dash.announcements || []).map((a) => `<div class="portal-detail" style="margin-bottom:8px;"><span>${escapeHtml(a.created_at)} · ${escapeHtml(a.audience)}</span><strong>${escapeHtml(a.title)}</strong><div style="font-size:13px;margin-top:4px;">${escapeHtml(a.body)}</div></div>`).join("") || `<p class="portal-hint">No recent announcements.</p>`}
          </div>`;
      } else if (tab === "attendance") {
        const attSum = child.attendanceSummary || {};
        const slots = child.timetable || [];
        const attRows = child.attendance || [];
        bodyHtml += `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${Number(attSum.percentage ?? 100)}%</strong><span>Overall Attendance</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${Number(attSum.present || 0)}</strong><span>Present Days</span></div><div class="portal-stat-icon">${icon("check")}</div></div>
            <div class="portal-stat"><div><strong>${Number(attSum.late || 0)}</strong><span>Late Check-ins</span></div><div class="portal-stat-icon">${icon("calendar")}</div></div>
            <div class="portal-stat"><div><strong>${Number(attSum.absent || 0)}</strong><span>Absent Days</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
          </div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Weekly Class Timetable</h3>
            ${
              slots.length
                ? `<div class="yu-timetable-grid">${slots
                    .map(
                      (s) => `
                  <div class="portal-detail">
                    <span>${escapeHtml(s.day_of_week)} · ${escapeHtml(s.start_time)}–${escapeHtml(s.end_time)}</span>
                    <strong>${escapeHtml(s.subject_name || s.course_title || "Class")}</strong>
                    <div class="portal-hint">${escapeHtml(s.teacher_name || "Faculty")} · ${escapeHtml(s.room_name || "Classroom")} (${escapeHtml(s.mode || "offline")})</div>
                  </div>`
                    )
                    .join("")}</div>`
                : `<p class="portal-hint">No timetable slots assigned to this student's batches yet.</p>`
            }
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Daily Attendance Log (${attRows.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Date</th><th>Course</th><th>Status</th><th>Marked Via</th><th>Remarks</th></tr></thead>
              <tbody>
                ${attRows.map((a) => `<tr><td>${escapeHtml(a.att_date)}</td><td>${escapeHtml(a.course_title)}</td><td>${statusBadge(a.status)}</td><td>${escapeHtml(a.marked_via || "manual")}</td><td>${escapeHtml(a.remarks || "-")}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No attendance records marked yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "marks") {
        const tests = child.offlineTests || [];
        const quizzes = child.quizAttempts || [];
        bodyHtml += `
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Offline Test Results &amp; Class Ranks (${tests.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Date</th><th>Test &amp; Subject</th><th>Course / Batch</th><th>Score</th><th>Rank</th><th>Topper</th><th>Remarks</th></tr></thead>
              <tbody>
                ${tests
                  .map(
                    (t) => `<tr>
                  <td>${escapeHtml(t.test_date)}</td>
                  <td><strong>${escapeHtml(t.title)}</strong><span class="portal-cell-sub">${escapeHtml(t.subject_name)}</span></td>
                  <td>${escapeHtml(t.course_title)}${t.batch_name ? `<span class="portal-cell-sub">${escapeHtml(t.batch_name)}</span>` : ""}</td>
                  <td>${t.is_absent ? statusBadge("absent") : t.marks_obtained !== null && t.marks_obtained !== undefined ? `<strong>${t.marks_obtained}/${t.max_marks}</strong> (${t.percentage ?? 0}%)` : `<span class="portal-hint">Pending</span>`}</td>
                  <td>${t.rank_position ? `<strong>#${t.rank_position}</strong> / ${t.total_appeared || "-"}` : "-"}</td>
                  <td>${t.topper_marks !== null && t.topper_marks !== undefined ? `${t.topper_marks}/${t.max_marks}` : "-"}</td>
                  <td>${escapeHtml(t.remarks || "-")}</td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="7" class="portal-empty">No offline test scores recorded yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Online Quiz Attempts (${quizzes.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Quiz</th><th>Course</th><th>Score</th><th>Attempted On</th></tr></thead>
              <tbody>
                ${quizzes.map((q) => `<tr><td><strong>${escapeHtml(q.quiz_title)}</strong></td><td>${escapeHtml(q.course_title)}</td><td><strong>${q.score}/${q.max_marks}</strong></td><td>${escapeHtml(String(q.attempted_at || "").slice(0, 10))}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No online quizzes attempted yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "fees") {
        const insts = child.installments || [];
        const recs = child.feeRecords || [];
        const pays = child.payments || [];
        const dueInsts = insts.filter((i) => i.status !== "paid");
        bodyHtml += `
          ${
            dueInsts.length
              ? `<div class="portal-message portal-message--${dueInsts.some((i) => i.status === "overdue") ? "error" : "success"}" style="margin-bottom:14px;">
                  <strong>Fee Payment Reminder:</strong> ${dueInsts.length} installment(s) due. Next installment due on <strong>${escapeHtml(dueInsts[0].due_date)}</strong> (${formatINR(Math.max(0, Number(dueInsts[0].amount) - Number(dueInsts[0].paid_amount || 0)))}).
                </div>`
              : ""
          }
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Installment / EMI Schedule (${insts.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Installment</th><th>Due Date</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead>
              <tbody>
                ${insts
                  .map((i) => {
                    const bal = Math.max(0, Number(i.amount || 0) - Number(i.paid_amount || 0));
                    return `<tr><td><strong>${escapeHtml(i.title)}</strong></td><td>${escapeHtml(i.due_date)}</td><td>${formatINR(i.amount)}</td><td>${formatINR(i.paid_amount)}</td><td><strong>${formatINR(bal)}</strong></td><td>${statusBadge(i.status)}</td></tr>`;
                  })
                  .join("") || `<tr><td colspan="6" class="portal-empty">No installment plan generated yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Fee Ledger (${recs.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Fee Description</th><th>Total</th><th>Discount</th><th>Paid</th><th>Pending</th><th>Due Date</th><th>Status</th></tr></thead>
              <tbody>
                ${recs
                  .map((f) => {
                    const bal = Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0) - Number(f.paid_amount || 0));
                    return `<tr><td><strong>${escapeHtml(f.course_title || f.title)}</strong></td><td>${formatINR(f.total_amount)}</td><td>${formatINR(f.discount_amount)}</td><td>${formatINR(f.paid_amount)}</td><td><strong>${formatINR(bal)}</strong></td><td>${escapeHtml(f.due_date || "-")}</td><td>${statusBadge(f.status)}</td></tr>`;
                  })
                  .join("") || `<tr><td colspan="7" class="portal-empty">No fee records found.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Payment Receipts (${pays.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Receipt #</th><th>Course</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th>Receipt</th></tr></thead>
              <tbody>
                ${pays
                  .map(
                    (p) => `<tr>
                  <td>${escapeHtml(p.receipt_number || "Pending")}</td>
                  <td>${escapeHtml(p.course_title)}</td>
                  <td><strong>${formatINR(p.amount)}</strong></td>
                  <td>${escapeHtml(p.payment_method)}</td>
                  <td>${escapeHtml(String(p.paid_at || p.created_at || "").slice(0, 10))}</td>
                  <td>${statusBadge(p.verification_status)}</td>
                  <td>${p.receipt_number ? `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-p-print-receipt="${escAttr(JSON.stringify({ receipt: p.receipt_number, student: child.student?.full_name || "Student", course: p.course_title, amount: p.amount, date: p.paid_at || p.created_at, invoice: p.invoice_number }))}">Print Receipt</button>` : "-"}</td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="7" class="portal-empty">No payment transactions recorded yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else {
        const teachers = child.teachers || [];
        const msgs = dash.messages || [];
        bodyHtml += `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Message Faculty Teacher</h3>
            ${
              teachers.length
                ? `<form class="portal-form" data-p-msg-form>
                    <input type="hidden" name="studentId" value="${child.student.id}">
                    <div class="portal-field"><label>Select Subject Teacher *</label>
                      <select name="teacherId" required>
                        ${teachers.map((t) => `<option value="${t.id}">${escapeHtml(t.full_name)} · ${escapeHtml(t.course_title)}</option>`).join("")}
                      </select>
                    </div>
                    <div class="portal-field"><label>Message for Teacher *</label><textarea name="message" required placeholder="Write regarding attendance, homework, test preparation, or PTM..."></textarea></div>
                    <button type="submit" class="portal-button portal-button--small">Send Message</button>
                  </form>`
                : `<p class="portal-hint">No active course teachers are assigned to <strong>${escapeHtml(child.student?.full_name || "this student")}</strong> yet.</p>`
            }
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Parent–Teacher Conversation History (${msgs.length})</h3>
            ${msgs
              .map(
                (m) => `
              <div class="portal-detail" style="margin-bottom:8px;">
                <span>${escapeHtml(m.created_at)} · Student: ${escapeHtml(m.student_name)} · Teacher: ${escapeHtml(m.teacher_name)}</span>
                <strong>${m.sender_role === "teacher" ? `${escapeHtml(m.teacher_name)} (Teacher)` : "You (Parent)"}</strong>
                <div style="margin-top:4px;">${escapeHtml(m.message)}</div>
              </div>`
              )
              .join("") || `<p class="portal-hint">No messages exchanged with teachers yet.</p>`}
          </div>`;
      }

      const noticeHtml = parentNotice
        ? `<div class="portal-message portal-message--${parentNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(parentNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: "Parent Portal",
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          parentNotice = "";
          loadAndDraw();
        },
        notifications: dash.notifications || [],
        onReadNotifs: async () => {
          await api("/api/parent/notifications/read-all", { method: "POST" });
          loadAndDraw();
        },
        bodyHtml: noticeHtml + bodyHtml,
      });

      window.YuitorUI?.enhanceTables?.(main?.querySelector("[data-ws-body]"));

      main.querySelectorAll("[data-p-child-idx]").forEach((b) => {
        b.addEventListener("click", () => {
          selectedChildIdx = Number(b.getAttribute("data-p-child-idx") || 0);
          parentNotice = "";
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-p-toggle-link]").forEach((b) => {
        b.addEventListener("click", () => {
          showLinkForm = !showLinkForm;
          loadAndDraw();
        });
      });
      main.querySelector("[data-p-link-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        try {
          const res = await api("/api/parent/link-child", {
            method: "POST",
            body: {
              rollNumber: fd.get("rollNumber"),
              studentPhone: fd.get("studentPhone"),
              relation: fd.get("relation"),
            },
          });
          showLinkForm = false;
          parentNoticeType = "success";
          parentNotice = `Linked child account: ${res.studentName || "Student"}!`;
        } catch (err) {
          parentNoticeType = "error";
          parentNotice = err.message || "Could not link child account.";
        }
        loadAndDraw();
      });
      main.querySelector("[data-p-msg-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        try {
          await api("/api/parent/messages", {
            method: "POST",
            body: {
              studentId: Number(fd.get("studentId")),
              teacherId: Number(fd.get("teacherId")),
              message: fd.get("message"),
            },
          });
          parentNoticeType = "success";
          parentNotice = "Message sent to teacher.";
        } catch (err) {
          parentNoticeType = "error";
          parentNotice = err.message || "Could not send message.";
        }
        loadAndDraw();
      });
      main.querySelectorAll("[data-p-print-receipt]").forEach((b) => {
        b.addEventListener("click", () => {
          const info = JSON.parse(b.getAttribute("data-p-print-receipt"));
          mountShell(`
            <div class="portal-card portal-profile" style="max-width:640px;margin:0 auto;">
              <p class="portal-kicker">Official Fee Receipt · Yuitor Smart Classes</p>
              <div class="portal-heading"><h1>Receipt ${escapeHtml(info.receipt)}</h1><button type="button" class="portal-button portal-button--small" onclick="window.print()">Print</button></div>
              <p class="portal-subtitle">Trimurti Vihar, Near Venus Academy, Muradnagar - 201206 · +91 78-2728-9292 · fee@yuitor.com</p>
              <div class="portal-personal-grid" style="margin-top:16px;">
                <div class="portal-detail"><span>Student</span><strong>${escapeHtml(info.student)}</strong></div>
                <div class="portal-detail"><span>Invoice</span><strong>${escapeHtml(info.invoice)}</strong></div>
                <div class="portal-detail"><span>Course</span><strong>${escapeHtml(info.course)}</strong></div>
                <div class="portal-detail"><span>Amount Paid</span><strong>${formatINR(info.amount)}</strong></div>
                <div class="portal-detail"><span>Date</span><strong>${escapeHtml(info.date)}</strong></div>
              </div>
              <div style="margin-top:18px;"><button type="button" class="portal-button portal-button--quiet portal-button--small" data-p-back-fees>← Back to Fees</button></div>
            </div>`);
          getMain().querySelector("[data-p-back-fees]")?.addEventListener("click", loadAndDraw);
        });
      });
    }
    await loadAndDraw();
  }

  // ==================== STAFF / COORDINATOR PANEL ====================
  async function renderStaffPanel(session) {
    if (session.user.verification_status !== "approved" && !session.impersonation?.active) {
      mountShell(`
        ${impersonationBanner(session)}
        <div class="portal-card portal-login-card">
          <p class="portal-kicker">Staff Account Status</p>
          <div class="portal-heading"><h1>Verification Pending</h1></div>
          <div class="portal-message">${escapeHtml(session.pendingMessage || BRAND_PENDING_MSG)}</div>
          <button type="button" class="portal-button portal-button--quiet" data-portal-logout>Sign Out</button>
        </div>`);
      root.querySelector("[data-portal-logout]")?.addEventListener("click", async () => {
        await api("/api/auth/logout", { method: "POST" });
        window.location.assign("/login");
      });
      return;
    }

    let tab = "overview";
    let staffNotice = "";
    let staffNoticeType = "success";
    let selectedTestMarks = null;
    let attFilterCourse = "";
    let attFilterFrom = "";
    let attFilterTo = "";
    let lastFeeWaLinks = [];
    let lastAlertWaLinks = [];

    async function loadAndDraw() {
      const dash = await api("/api/staff/dashboard");
      const staff = dash.staff || {};
      const perms = new Set(staff.permissions || []);
      const hasPerm = (p) => perms.has("all") || perms.has(p);

      const navItems = [["overview", "Staff Desk", "dashboard"]];
      if (hasPerm("inquiries")) navItems.push(["inquiries", "Inquiries & Leads", "mail"]);
      if (hasPerm("batches") || hasPerm("timetable") || hasPerm("branches")) navItems.push(["academics", "Batches & Timetable", "calendar"]);
      if (hasPerm("tests") || hasPerm("attendance")) navItems.push(["tests", "Tests & Attendance", "award"]);
      if (hasPerm("fees")) navItems.push(["fees", "Fee Collection & EMI", "wallet"]);
      if (hasPerm("library")) navItems.push(["library", "Library & Modules", "book"]);
      if (hasPerm("alerts")) navItems.push(["alerts", "Bulk Alerts", "megaphone"]);
      if (hasPerm("reports")) navItems.push(["reports", "Reports", "database"]);

      if (!navItems.some((n) => n[0] === tab)) tab = "overview";

      const courses = dash.courses || [];
      const students = dash.students || [];

      const safeGet = (url) => api(url).catch(() => null);
      let branchesData = null;
      let batchesData = null;
      let timetableData = null;
      let testsData = null;
      let attData = null;
      let feeData = null;
      let libData = null;
      let alertData = null;
      let reportData = null;

      const attQuery = new URLSearchParams();
      if (attFilterCourse) attQuery.set("courseId", attFilterCourse);
      if (attFilterFrom) attQuery.set("from", attFilterFrom);
      if (attFilterTo) attQuery.set("to", attFilterTo);
      const attQs = attQuery.toString() ? `?${attQuery.toString()}` : "";

      if (tab === "academics") {
        [branchesData, batchesData, timetableData] = await Promise.all([
          hasPerm("batches") ? safeGet("/api/staff/branches") : Promise.resolve(null),
          hasPerm("batches") ? safeGet("/api/staff/batches") : Promise.resolve(null),
          hasPerm("timetable") ? safeGet("/api/staff/timetable") : Promise.resolve(null),
        ]);
      } else if (tab === "tests") {
        [testsData, batchesData, attData] = await Promise.all([
          hasPerm("tests") ? safeGet("/api/staff/offline-tests") : Promise.resolve(null),
          hasPerm("batches") ? safeGet("/api/staff/batches") : Promise.resolve(null),
          hasPerm("attendance") ? safeGet(`/api/staff/reports/attendance${attQs}`) : Promise.resolve(null),
        ]);
      } else if (tab === "fees") {
        feeData = await safeGet("/api/staff/fee-installments");
      } else if (tab === "library") {
        [libData, branchesData] = await Promise.all([
          safeGet("/api/staff/library"),
          hasPerm("batches") ? safeGet("/api/staff/branches") : Promise.resolve(null),
        ]);
      } else if (tab === "alerts") {
        [alertData, batchesData] = await Promise.all([
          safeGet("/api/staff/alerts"),
          hasPerm("batches") ? safeGet("/api/staff/batches") : Promise.resolve(null),
        ]);
      } else if (tab === "reports") {
        reportData = await safeGet("/api/staff/reports/overview");
      }

      const runStaffAction = async (fn, msg) => {
        try {
          await fn();
          if (msg) {
            staffNoticeType = "success";
            staffNotice = msg;
          }
        } catch (err) {
          staffNoticeType = "error";
          staffNotice = err.message || "Action failed.";
        }
        await loadAndDraw();
      };

      let bodyHtml = "";
      if (tab === "overview") {
        const permList = Array.from(perms);
        bodyHtml = `
          <div class="portal-metrics" style="margin-bottom:16px;">
            <div class="portal-stat"><div><strong>${escapeHtml(staff.staffRole || "coordinator")}</strong><span>Staff Role</span></div><div class="portal-stat-icon">${icon("user")}</div></div>
            <div class="portal-stat"><div><strong>${escapeHtml(staff.branch?.name || "All Branches")}</strong><span>Assigned Centre</span></div><div class="portal-stat-icon">${icon("dashboard")}</div></div>
            <div class="portal-stat"><div><strong>${students.length}</strong><span>Active Students</span></div><div class="portal-stat-icon">${icon("users")}</div></div>
            <div class="portal-stat"><div><strong>${hasPerm("inquiries") ? (dash.inquiries || []).length : permList.length}</strong><span>${hasPerm("inquiries") ? "Recent Inquiries" : "Active Permissions"}</span></div><div class="portal-stat-icon">${icon("mail")}</div></div>
          </div>
          <div data-v31-postreg-profile style="margin-bottom:16px;"></div>
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Assigned Permissions &amp; Desk Access</h3>
            <div class="portal-actions">
              ${permList.length ? permList.map((p) => `<span class="portal-status portal-status--paid">${escapeHtml(p)}</span>`).join("") : `<span class="portal-hint">No module permissions assigned yet. Contact Super Admin.</span>`}
            </div>
          </div>
          <div class="portal-card portal-profile">
            <h3 class="portal-section-title">Quick Desk Modules</h3>
            <div class="portal-actions">
              ${navItems.filter((n) => n[0] !== "overview").map(([id, label]) => `<button type="button" class="portal-button portal-button--small portal-button--quiet" data-st-jump="${escAttr(id)}">${escapeHtml(label)}</button>`).join("") || `<p class="portal-hint">Ask an Administrator to assign module permissions to your staff role.</p>`}
            </div>
          </div>`;
      } else if (tab === "inquiries") {
        const inquiries = dash.inquiries || [];
        bodyHtml = `
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Admission Leads, Demo Bookings &amp; Follow-Ups (${inquiries.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Lead / Student</th><th>Course &amp; Demo Slot</th><th>Status</th><th>Follow-Up Date</th><th>Follow-Up Notes</th><th>Save</th></tr></thead>
              <tbody>
                ${inquiries
                  .map(
                    (q) => `<tr>
                  <td><strong>${escapeHtml(q.name)}</strong><span class="portal-cell-sub">${escapeHtml(q.phone)}${q.email ? " · " + escapeHtml(q.email) : ""}</span></td>
                  <td>${escapeHtml(q.class_or_course)}${q.demo_date ? `<span class="portal-cell-sub">Demo: ${escapeHtml(q.demo_date)} ${escapeHtml(q.demo_time_slot || "")}</span>` : ""}</td>
                  <td><select data-st-inq-status="${q.id}">${["new", "contacted", "admitted", "closed"].map((st) => `<option value="${st}" ${q.status === st ? "selected" : ""}>${st}</option>`).join("")}</select></td>
                  <td><input type="date" data-st-inq-fdate value="${escAttr(q.follow_up_date || "")}"></td>
                  <td><input data-st-inq-fnotes value="${escAttr(q.follow_up_notes || "")}" placeholder="Callback remarks"></td>
                  <td><button type="button" class="portal-button portal-button--small" data-st-inq-save="${q.id}">Save</button></td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="6" class="portal-empty">No inquiries found.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "academics") {
        const branches = branchesData?.branches || [];
        const batches = batchesData?.batches || [];
        const slots = timetableData?.slots || [];
        bodyHtml = `
          ${
            hasPerm("branches")
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Add Coaching Branch</h3>
                  <form class="portal-form" data-st-branch-form>
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Branch Name *</label><input name="name" required placeholder="e.g. Muradnagar Extension"></div>
                      <div class="portal-field"><label>Code</label><input name="code" placeholder="YTR-EXT"></div>
                      <div class="portal-field"><label>City</label><input name="city" value="Muradnagar"></div>
                      <div class="portal-field"><label>Phone</label><input name="phone" value="+91 78-2728-9292"></div>
                      <div class="portal-field"><label>Address</label><input name="address" placeholder="Street & landmark"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Add Branch</button>
                  </form>
                </div>`
              : ""
          }
          ${
            hasPerm("batches")
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Create Batch &amp; Seat Capacity</h3>
                  <form class="portal-form" data-st-batch-form>
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course *</label><select name="courseId" required>${courses.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                      <div class="portal-field"><label>Batch Name *</label><input name="name" required placeholder="e.g. Class 10 Evening"></div>
                      <div class="portal-field"><label>Branch</label><select name="branchId"><option value="">Main Centre</option>${branches.map((br) => `<option value="${br.id}">${escapeHtml(br.name)}</option>`).join("")}</select></div>
                      <div class="portal-field"><label>Room</label><input name="roomName" value="Room 101"></div>
                      <div class="portal-field"><label>Seat Limit</label><input name="seatLimit" type="number" value="40" min="1"></div>
                      <div class="portal-field"><label>Days</label><input name="scheduleDays" value="Mon–Sat"></div>
                      <div class="portal-field"><label>Start Time</label><input name="startTime" value="16:00"></div>
                      <div class="portal-field"><label>End Time</label><input name="endTime" value="17:30"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Create Batch</button>
                  </form>
                </div>
                <div class="portal-card portal-table-card" style="margin-bottom:16px;">
                  <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Batches &amp; Seat Occupancy (${batches.length})</div>
                  <div class="portal-table-scroll"><table class="portal-table">
                    <thead><tr><th>Batch</th><th>Course / Branch</th><th>Timing &amp; Room</th><th>Seats</th><th>Action</th></tr></thead>
                    <tbody>
                      ${batches.map((b) => `<tr><td><strong>${escapeHtml(b.name)}</strong><span class="portal-cell-sub">${escapeHtml(b.code)}</span></td><td>${escapeHtml(b.course_title || "-")}<span class="portal-cell-sub">${escapeHtml(b.branch_name || "Main Centre")}</span></td><td>${escapeHtml(b.schedule_days)} · ${escapeHtml(b.start_time)}–${escapeHtml(b.end_time)} (${escapeHtml(b.room_name)})</td><td><strong>${b.seats_used}/${b.seat_limit}</strong> (${b.seats_remaining} left)</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-st-del-batch="${b.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No batches configured.</td></tr>`}
                    </tbody>
                  </table></div>
                </div>`
              : ""
          }
          ${
            hasPerm("timetable")
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Add Weekly Timetable Slot</h3>
                  <form class="portal-form" data-st-tt-form>
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Day</label><select name="dayOfWeek">${["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((d) => `<option>${d}</option>`).join("")}</select></div>
                      <div class="portal-field"><label>Subject *</label><input name="subjectName" required placeholder="e.g. Mathematics"></div>
                      <div class="portal-field"><label>Course</label><select name="courseId"><option value="">All</option>${courses.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                      ${batches.length ? `<div class="portal-field"><label>Batch</label><select name="batchId"><option value="">All Batches</option>${batches.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>` : ""}
                      <div class="portal-field"><label>Start</label><input name="startTime" value="16:00"></div>
                      <div class="portal-field"><label>End</label><input name="endTime" value="17:00"></div>
                      <div class="portal-field"><label>Room</label><input name="roomName" value="Room 101"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Add Timetable Slot</button>
                  </form>
                </div>
                <div class="portal-card portal-table-card">
                  <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Master Timetable (${slots.length})</div>
                  <div class="portal-table-scroll"><table class="portal-table">
                    <thead><tr><th>Day &amp; Time</th><th>Subject</th><th>Course / Batch</th><th>Room</th><th>Action</th></tr></thead>
                    <tbody>
                      ${slots.map((s) => `<tr><td><strong>${escapeHtml(s.day_of_week)}</strong><span class="portal-cell-sub">${escapeHtml(s.start_time)}–${escapeHtml(s.end_time)}</span></td><td>${escapeHtml(s.subject_name)}</td><td>${escapeHtml(s.course_title || "-")}${s.batch_name ? ` · ${escapeHtml(s.batch_name)}` : ""}</td><td>${escapeHtml(s.room_name || "-")}</td><td><button type="button" class="portal-button portal-button--small portal-button--danger" data-st-del-slot="${s.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No timetable slots added yet.</td></tr>`}
                    </tbody>
                  </table></div>
                </div>`
              : ""
          }`;
      } else if (tab === "tests") {
        const tests = testsData?.tests || [];
        const batches = batchesData?.batches || [];
        const attSummary = attData?.summary || [];
        bodyHtml = `
          ${
            hasPerm("tests")
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <h3 class="portal-section-title">Create Offline Test</h3>
                  <form class="portal-form" data-st-test-form>
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course *</label><select name="courseId" required>${courses.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
                      ${batches.length ? `<div class="portal-field"><label>Batch (Optional)</label><select name="batchId"><option value="">All Batches</option>${batches.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>` : ""}
                      <div class="portal-field"><label>Test Title *</label><input name="title" required placeholder="e.g. Unit Test 2"></div>
                      <div class="portal-field"><label>Subject</label><input name="subjectName" value="All Subjects"></div>
                      <div class="portal-field"><label>Date</label><input name="testDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
                      <div class="portal-field"><label>Max Marks</label><input name="maxMarks" type="number" value="100" min="1"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Create Test</button>
                  </form>
                </div>
                ${
                  selectedTestMarks
                    ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;">
                          <h3 class="portal-section-title" style="margin:0;">Marks Entry &amp; Rank List · ${escapeHtml(selectedTestMarks.test?.title || "")} (Max ${selectedTestMarks.test?.max_marks || 100})</h3>
                          <button type="button" class="portal-button portal-button--small portal-button--quiet" data-st-close-marks>Close</button>
                        </div>
                        <form data-st-save-marks="${selectedTestMarks.test?.id}">
                          <div class="portal-table-scroll"><table class="portal-table">
                            <thead><tr><th>Rank</th><th>Student</th><th>Marks</th><th>Absent</th><th>Remarks</th></tr></thead>
                            <tbody>
                              ${(selectedTestMarks.students || [])
                                .map(
                                  (s) => `
                                <tr data-st-mark-row="${s.student_id}">
                                  <td>${s.rank_position ? `<strong>#${s.rank_position}</strong>` : "-"}</td>
                                  <td><strong>${escapeHtml(s.full_name)}</strong><span class="portal-cell-sub">${escapeHtml(s.roll_number || "")}</span></td>
                                  <td><input type="number" name="marks" step="0.5" min="0" max="${selectedTestMarks.test?.max_marks || 100}" value="${escAttr(s.marks_obtained ?? "")}" style="max-width:95px;"></td>
                                  <td><input type="checkbox" name="absent" ${s.is_absent ? "checked" : ""}></td>
                                  <td><input name="remarks" value="${escAttr(s.remarks || "")}" placeholder="Optional note"></td>
                                </tr>`
                                )
                                .join("") || `<tr><td colspan="5" class="portal-empty">No enrolled students found.</td></tr>`}
                            </tbody>
                          </table></div>
                          <div class="portal-actions" style="margin-top:12px;"><button type="submit" class="portal-button portal-button--small">Save Marks &amp; Recalculate Ranks</button></div>
                        </form>
                      </div>`
                    : ""
                }
                <div class="portal-card portal-table-card" style="margin-bottom:16px;">
                  <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Offline Tests (${tests.length})</div>
                  <div class="portal-table-scroll"><table class="portal-table">
                    <thead><tr><th>Date</th><th>Test</th><th>Course / Batch</th><th>Marks Entered</th><th>Actions</th></tr></thead>
                    <tbody>
                      ${tests.map((t) => `<tr><td>${escapeHtml(t.test_date)}</td><td><strong>${escapeHtml(t.title)}</strong><span class="portal-cell-sub">${escapeHtml(t.subject_name)} · Max ${t.max_marks}</span></td><td>${escapeHtml(t.course_title || "-")}${t.batch_name ? ` · ${escapeHtml(t.batch_name)}` : ""}</td><td>${Number(t.marks_entered || 0)} student(s)</td><td><button type="button" class="portal-button portal-button--small" data-st-open-marks="${t.id}">Enter Marks / Ranks</button></td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No offline tests created.</td></tr>`}
                    </tbody>
                  </table></div>
                </div>`
              : ""
          }
          ${
            hasPerm("attendance")
              ? `<div class="portal-card portal-profile" style="margin-bottom:16px;">
                  <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
                    <h3 class="portal-section-title" style="margin:0;">Student Attendance Reports</h3>
                    <a href="${escAttr(`/api/staff/reports/attendance${attQs ? attQs + "&" : "?"}format=csv`)}" class="portal-button portal-button--small portal-button--quiet">${icon("download")} Download CSV</a>
                  </div>
                  <form class="portal-form" data-st-att-filter>
                    <div class="portal-form-grid">
                      <div class="portal-field"><label>Course</label><select name="courseId"><option value="">All Courses</option>${courses.map((c) => `<option value="${c.id}" ${String(c.id) === attFilterCourse ? "selected" : ""}>${escapeHtml(c.title)}</option>`).join("")}</select></div>
                      <div class="portal-field"><label>From</label><input type="date" name="from" value="${escAttr(attFilterFrom)}"></div>
                      <div class="portal-field"><label>To</label><input type="date" name="to" value="${escAttr(attFilterTo)}"></div>
                    </div>
                    <button type="submit" class="portal-button portal-button--small">Filter Report</button>
                  </form>
                </div>
                <div class="portal-card portal-table-card">
                  <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Attendance Summary (${attSummary.length})</div>
                  <div class="portal-table-scroll"><table class="portal-table">
                    <thead><tr><th>Student</th><th>Course</th><th>Total</th><th>Present</th><th>Late</th><th>Absent</th><th>%</th></tr></thead>
                    <tbody>
                      ${attSummary.map((s) => `<tr><td><strong>${escapeHtml(s.full_name)}</strong><span class="portal-cell-sub">${escapeHtml(s.roll_number || "")}</span></td><td>${escapeHtml(s.course_title)}</td><td>${s.total_days}</td><td>${s.present_days}</td><td>${s.late_days}</td><td>${s.absent_days}</td><td><strong>${s.percentage}%</strong></td></tr>`).join("") || `<tr><td colspan="7" class="portal-empty">No attendance data matches filter.</td></tr>`}
                    </tbody>
                  </table></div>
                </div>`
              : ""
          }`;
      } else if (tab === "fees") {
        const feeRecords = feeData?.feeRecords || [];
        const installments = feeData?.installments || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Generate Installments &amp; Send Fee Due Reminders</h3>
            <form class="portal-form" data-st-gen-inst style="margin-bottom:12px;">
              <div class="portal-form-grid">
                <div class="portal-field"><label>Fee Record *</label><select name="feeRecordId" required>${feeRecords.map((f) => `<option value="${f.id}">${escapeHtml(f.student_name)} · ${escapeHtml(f.course_title || f.title)} (Due ${formatINR(Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0) - Number(f.paid_amount || 0)))})</option>`).join("")}</select></div>
                <div class="portal-field"><label>Installments</label><input name="installmentsCount" type="number" value="3" min="1" max="12"></div>
                <div class="portal-field"><label>First Due Date</label><input name="firstDueDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
              </div>
              <button type="submit" class="portal-button portal-button--small">Generate EMI Plan</button>
            </form>
            <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;border-top:1px solid var(--pt-border);padding-top:12px;">
              <label style="display:flex;align-items:center;gap:6px;font-size:12px;"><input type="checkbox" name="stRemSms"> Fast2SMS</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:12px;"><input type="checkbox" name="stRemWa"> WhatsApp API</label>
              <button type="button" class="portal-button portal-button--small portal-button--quiet" data-st-send-rem>Send Due Reminders &amp; Generate WhatsApp Links</button>
            </div>
            ${
              lastFeeWaLinks.length
                ? `<div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:8px;">${lastFeeWaLinks.map((w) => `<a class="portal-button portal-button--small portal-button--quiet" href="${escAttr(safeHref(w.waLink))}" target="_blank" rel="noopener">WhatsApp ${escapeHtml(w.studentName)} (${formatINR(w.dueAmount)})</a>`).join("")}</div>`
                : ""
            }
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Fee Installments Register (${installments.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Student</th><th>Installment</th><th>Due Date</th><th>Amount</th><th>Status</th><th>Collect Fee</th></tr></thead>
              <tbody>
                ${installments
                  .map(
                    (i) => `<tr>
                  <td><strong>${escapeHtml(i.student_name)}</strong><span class="portal-cell-sub">${escapeHtml(i.roll_number || i.student_phone || "")}</span></td>
                  <td>${escapeHtml(i.title)}</td>
                  <td>${escapeHtml(i.due_date)}</td>
                  <td><strong>${formatINR(i.amount)}</strong>${Number(i.paid_amount || 0) > 0 ? `<span class="portal-cell-sub">Paid ${formatINR(i.paid_amount)}</span>` : ""}</td>
                  <td>${statusBadge(i.status)}</td>
                  <td>${i.status !== "paid" ? `<div class="portal-actions"><button type="button" class="portal-button portal-button--small" data-st-pay-inst="${i.id}" data-method="cash">Cash Paid</button><button type="button" class="portal-button portal-button--small portal-button--quiet" data-st-pay-inst="${i.id}" data-method="upi">UPI Paid</button></div>` : `<span class="portal-hint">Cleared</span>`}</td>
                </tr>`
                  )
                  .join("") || `<tr><td colspan="6" class="portal-empty">No fee installments generated yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "library") {
        const books = libData?.books || [];
        const issues = libData?.issues || [];
        const branches = branchesData?.branches || [];
        bodyHtml = `
          <div class="portal-form-grid" style="margin-bottom:16px;">
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Add Study Material / Book</h3>
              <form class="portal-form" data-st-lib-book>
                <div class="portal-field"><label>Title *</label><input name="title" required placeholder="e.g. Class 10 Science Module"></div>
                <div class="portal-field"><label>Code</label><input name="code" placeholder="SCI-10"></div>
                <div class="portal-field"><label>Category</label><input name="category" value="Study Module"></div>
                <div class="portal-field"><label>Total Copies</label><input name="totalCopies" type="number" value="25" min="1"></div>
                ${branches.length ? `<div class="portal-field"><label>Branch</label><select name="branchId"><option value="">Main</option>${branches.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>` : ""}
                <button type="submit" class="portal-button portal-button--small">Add to Inventory</button>
              </form>
            </div>
            <div class="portal-card portal-profile">
              <h3 class="portal-section-title">Issue Material to Student</h3>
              <form class="portal-form" data-st-lib-issue>
                <div class="portal-field"><label>Book / Module *</label><select name="bookId" required>${books.map((b) => `<option value="${b.id}">${escapeHtml(b.title)} (${b.available_copies}/${b.total_copies} avail)</option>`).join("")}</select></div>
                <div class="portal-field"><label>Student *</label><select name="studentId" required>${students.map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.roll_number || s.phone)})</option>`).join("")}</select></div>
                <div class="portal-field"><label>Due Return Date</label><input name="dueReturnDate" type="date" value="${new Date(Date.now() + 14 * 86400 * 1000).toISOString().slice(0, 10)}"></div>
                <button type="submit" class="portal-button portal-button--small">Issue Copy</button>
              </form>
            </div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Issued Study Materials (${issues.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Student</th><th>Material</th><th>Issued</th><th>Due Date</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${issues.map((li) => `<tr><td><strong>${escapeHtml(li.student_name)}</strong><span class="portal-cell-sub">${escapeHtml(li.roll_number || "")}</span></td><td>${escapeHtml(li.book_title)} (${escapeHtml(li.book_code)})</td><td>${escapeHtml(String(li.issued_at || "").slice(0, 10))}</td><td>${escapeHtml(li.due_return_date || "-")}</td><td>${statusBadge(li.status)}</td><td>${li.status === "issued" ? `<button type="button" class="portal-button portal-button--small" data-st-lib-return="${li.id}">Mark Returned</button>` : escapeHtml(String(li.returned_at || "").slice(0, 10))}</td></tr>`).join("") || `<tr><td colspan="6" class="portal-empty">No books issued yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else if (tab === "alerts") {
        const logs = alertData?.logs || [];
        const batches = batchesData?.batches || [];
        bodyHtml = `
          <div class="portal-card portal-profile" style="margin-bottom:16px;">
            <h3 class="portal-section-title">Bulk SMS, WhatsApp &amp; In-App Alert Dispatcher</h3>
            <form class="portal-form" data-st-alert-form>
              <div class="portal-form-grid">
                <div class="portal-field"><label>Channel</label><select name="channel"><option value="whatsapp">WhatsApp + In-App</option><option value="sms">SMS + In-App</option><option value="in_app">In-App Only</option></select></div>
                <div class="portal-field"><label>Audience</label><select name="audience"><option value="all_students">All Students</option><option value="all_parents">All Parents</option><option value="fee_due">Students with Fee Due</option>${batches.length ? `<option value="batch">Specific Batch</option>` : ""}<option value="course">Specific Course</option></select></div>
                ${batches.length ? `<div class="portal-field"><label>Batch (If Batch Selected)</label><select name="batchId"><option value="">-</option>${batches.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join("")}</select></div>` : ""}
                <div class="portal-field"><label>Course (If Course Selected)</label><select name="courseId"><option value="">-</option>${courses.map((c) => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join("")}</select></div>
              </div>
              <div class="portal-field"><label>Message *</label><textarea name="message" required placeholder="Class schedule update, test notice, or fee alert..."></textarea></div>
              <button type="submit" class="portal-button portal-button--small">Send Bulk Alert</button>
            </form>
            ${lastAlertWaLinks.length ? `<div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;">${lastAlertWaLinks.slice(0, 20).map((w) => `<a class="portal-button portal-button--small portal-button--quiet" href="${escAttr(safeHref(w.waLink))}" target="_blank" rel="noopener">WhatsApp ${escapeHtml(w.name)}</a>`).join("")}</div>` : ""}
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Alert Dispatch Log (${logs.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Date</th><th>Recipient</th><th>Channel</th><th>Status</th><th>Message</th></tr></thead>
              <tbody>
                ${logs.map((l) => `<tr><td>${escapeHtml(String(l.created_at || "").slice(0, 16))}</td><td><strong>${escapeHtml(l.recipient_name)}</strong><span class="portal-cell-sub">${escapeHtml(l.recipient_contact)}</span></td><td>${escapeHtml(l.channel)}</td><td>${statusBadge(l.status)}</td><td>${escapeHtml(l.message)}</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No alerts dispatched yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      } else {
        const bp = reportData?.batchPerformance || [];
        const mc = reportData?.monthlyCollection || [];
        const drops = reportData?.dropouts || [];
        bodyHtml = `
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Batch Performance &amp; Seat Report</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Batch</th><th>Course</th><th>Enrolled</th><th>Attendance %</th><th>Avg Test %</th></tr></thead>
              <tbody>
                ${bp.map((b) => `<tr><td><strong>${escapeHtml(b.name)}</strong></td><td>${escapeHtml(b.course_title || "-")}</td><td>${Number(b.enrolled_count || 0)}/${b.seat_limit}</td><td>${b.attendance_pct ?? 0}%</td><td>${b.test_avg_pct ?? 0}%</td></tr>`).join("") || `<tr><td colspan="5" class="portal-empty">No batch metrics yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card" style="margin-bottom:16px;">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Monthly Fee Collection</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Month</th><th>Receipts</th><th>Collected</th></tr></thead>
              <tbody>
                ${mc.map((m) => `<tr><td>${escapeHtml(m.month)}</td><td>${m.receipt_count}</td><td><strong>${formatINR(m.total_collected)}</strong></td></tr>`).join("") || `<tr><td colspan="3" class="portal-empty">No collection history yet.</td></tr>`}
              </tbody>
            </table></div>
          </div>
          <div class="portal-card portal-table-card">
            <div style="padding:14px 16px;font-weight:750;border-bottom:1px solid var(--pt-border);">Dropouts &amp; Expired Enrollments (${drops.length})</div>
            <div class="portal-table-scroll"><table class="portal-table">
              <thead><tr><th>Student</th><th>Course / Batch</th><th>Status</th><th>Expires At</th></tr></thead>
              <tbody>
                ${drops.map((d) => `<tr><td><strong>${escapeHtml(d.full_name)}</strong><span class="portal-cell-sub">${escapeHtml(d.phone)}</span></td><td>${escapeHtml(d.course_title)}${d.batch_name ? ` · ${escapeHtml(d.batch_name)}` : ""}</td><td>${statusBadge(d.status)}</td><td>${escapeHtml(d.expires_at || "-")}</td></tr>`).join("") || `<tr><td colspan="4" class="portal-empty">No dropouts or expired enrollments.</td></tr>`}
              </tbody>
            </table></div>
          </div>`;
      }

      const noticeHtml = staffNotice
        ? `<div class="portal-message portal-message--${staffNoticeType === "error" ? "error" : "success"}" style="margin-bottom:14px;">${escapeHtml(staffNotice)}</div>`
        : "";

      const main = renderWorkspace({
        session,
        portalTitle: `Staff Desk (${staff.staffRole || "coordinator"})`,
        navItems,
        activeTab: tab,
        onTabChange: (next) => {
          tab = next;
          staffNotice = "";
          loadAndDraw();
        },
        notifications: [],
        bodyHtml: noticeHtml + bodyHtml,
      });

      window.YuitorUI?.enhanceTables?.(main?.querySelector("[data-ws-body]"));

      const staffProfEl = main?.querySelector("[data-v31-postreg-profile]");
      if (staffProfEl && window.YuitorV31) {
        window.YuitorV31.renderPostRegProfileCard(staffProfEl, "staff", () => loadAndDraw());
      }

      main.querySelectorAll("[data-st-jump]").forEach((b) => {
        b.addEventListener("click", () => {
          tab = b.getAttribute("data-st-jump");
          loadAndDraw();
        });
      });
      main.querySelectorAll("[data-st-inq-save]").forEach((b) => {
        b.addEventListener("click", async () => {
          const qid = b.getAttribute("data-st-inq-save");
          const row = b.closest("tr");
          await runStaffAction(async () => {
            await api(`/api/staff/inquiries/${qid}`, {
              method: "PATCH",
              body: {
                status: row?.querySelector("[data-st-inq-status]")?.value || "contacted",
                followUpDate: row?.querySelector("[data-st-inq-fdate]")?.value || "",
                followUpNotes: row?.querySelector("[data-st-inq-fnotes]")?.value || "",
              },
            });
          }, "Inquiry follow-up saved.");
        });
      });
      main.querySelector("[data-st-branch-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/branches", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Branch added.");
      });
      main.querySelector("[data-st-batch-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/batches", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Batch created.");
      });
      main.querySelectorAll("[data-st-del-batch]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (window.YuitorV31?.confirmModal) {
            const ok = await window.YuitorV31.confirmModal({ title: "Delete Batch", message: "Confirm deleting this batch?", confirmLabel: "Yes, Delete", variant: "danger" });
            if (!ok) return;
          }
          await runStaffAction(async () => {
            await api(`/api/staff/batches/${b.getAttribute("data-st-del-batch")}`, { method: "DELETE" });
          }, "Batch deleted.");
        });
      });
      main.querySelector("[data-st-tt-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/timetable", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Timetable slot added.");
      });
      main.querySelectorAll("[data-st-del-slot]").forEach((b) => {
        b.addEventListener("click", async () => {
          if (window.YuitorV31?.confirmModal) {
            const ok = await window.YuitorV31.confirmModal({ title: "Delete Timetable Slot", message: "Confirm deleting this timetable slot?", confirmLabel: "Yes, Delete", variant: "danger" });
            if (!ok) return;
          }
          await runStaffAction(async () => {
            await api(`/api/staff/timetable/${b.getAttribute("data-st-del-slot")}`, { method: "DELETE" });
          }, "Timetable slot deleted.");
        });
      });
      main.querySelector("[data-st-test-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/offline-tests", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Offline test created.");
      });
      main.querySelectorAll("[data-st-open-marks]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runStaffAction(async () => {
            selectedTestMarks = await api(`/api/staff/offline-tests/${b.getAttribute("data-st-open-marks")}/marks`);
          }, "");
        });
      });
      main.querySelector("[data-st-close-marks]")?.addEventListener("click", () => {
        selectedTestMarks = null;
        loadAndDraw();
      });
      main.querySelector("[data-st-save-marks]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const tid = e.target.getAttribute("data-st-save-marks");
        const marks = Array.from(e.target.querySelectorAll("[data-st-mark-row]")).map((tr) => ({
          studentId: Number(tr.getAttribute("data-st-mark-row")),
          marksObtained: Number(tr.querySelector('input[name="marks"]')?.value || 0),
          isAbsent: Boolean(tr.querySelector('input[name="absent"]')?.checked),
          remarks: tr.querySelector('input[name="remarks"]')?.value || "",
        }));
        await runStaffAction(async () => {
          await api(`/api/staff/offline-tests/${tid}/marks`, { method: "POST", body: { marks } });
          selectedTestMarks = await api(`/api/staff/offline-tests/${tid}/marks`);
        }, "Marks saved & class rank sheet updated.");
      });
      main.querySelector("[data-st-att-filter]")?.addEventListener("submit", (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        attFilterCourse = String(fd.get("courseId") || "");
        attFilterFrom = String(fd.get("from") || "");
        attFilterTo = String(fd.get("to") || "");
        loadAndDraw();
      });
      main.querySelector("[data-st-gen-inst]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        await runStaffAction(async () => {
          await api("/api/staff/fee-installments/generate", {
            method: "POST",
            body: {
              feeRecordId: Number(fd.get("feeRecordId")),
              installmentsCount: Number(fd.get("installmentsCount") || 3),
              firstDueDate: fd.get("firstDueDate"),
            },
          });
        }, "EMI installment plan generated.");
      });
      main.querySelectorAll("[data-st-pay-inst]").forEach((b) => {
        b.addEventListener("click", async () => {
          const iid = b.getAttribute("data-st-pay-inst");
          const method = b.getAttribute("data-method") || "cash";
          await runStaffAction(async () => {
            const res = await api(`/api/staff/fee-installments/${iid}/pay`, { method: "POST", body: { paymentMethod: method } });
            staffNoticeType = "success";
            staffNotice = `Installment recorded (${method.toUpperCase()} · Receipt ${res.receiptNumber}).`;
          }, "");
        });
      });
      main.querySelector("[data-st-send-rem]")?.addEventListener("click", async () => {
        const sendSms = Boolean(main.querySelector('input[name="stRemSms"]')?.checked);
        const sendWhatsApp = Boolean(main.querySelector('input[name="stRemWa"]')?.checked);
        await runStaffAction(async () => {
          const res = await api("/api/staff/fee-installments/send-reminders", { method: "POST", body: { sendSms, sendWhatsApp } });
          lastFeeWaLinks = res.waLinks || [];
          staffNoticeType = "success";
          staffNotice = `Processed ${res.remindersProcessed} due installment(s) (${res.inAppSent} in-app, ${res.smsSent} SMS, ${res.waSent} WhatsApp).`;
        }, "");
      });
      main.querySelector("[data-st-lib-book]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/library/books", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Study material added to inventory.");
      });
      main.querySelector("[data-st-lib-issue]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          await api("/api/staff/library/issues", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
        }, "Material issued to student.");
      });
      main.querySelectorAll("[data-st-lib-return]").forEach((b) => {
        b.addEventListener("click", async () => {
          await runStaffAction(async () => {
            await api(`/api/staff/library/issues/${b.getAttribute("data-st-lib-return")}/return`, { method: "POST" });
          }, "Material marked returned.");
        });
      });
      main.querySelector("[data-st-alert-form]")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        await runStaffAction(async () => {
          const res = await api("/api/staff/alerts/send", { method: "POST", body: Object.fromEntries(new FormData(e.target).entries()) });
          lastAlertWaLinks = res.waLinks || [];
          staffNoticeType = "success";
          staffNotice = `Dispatched alert to ${res.totalRecipients} recipient(s) via ${res.channel}.`;
        }, "");
      });
    }
    await loadAndDraw();
  }

  // ==================== ROUTER ====================
  const CUSTOM_PUBLIC_PATHS = new Set([]);

  function normalizePortalPath(rawPath) {
    return (
      String(rawPath || "/")
        .split(/[?#]/)[0]
        .replace(/\/+/g, "/")
        .replace(/\/+$/, "") || "/"
    );
  }

  function isHandledPath(rawPath) {
    const path = normalizePortalPath(rawPath);
    if (GATE_BASE && (path === GATE_BASE || path.startsWith(GATE_BASE + "/"))) {
      return true;
    }
    return (
      path.startsWith("/student") ||
      path.startsWith("/teacher") ||
      path.startsWith("/parent") ||
      path.startsWith("/staff") ||
      path === "/teacher-apply.php" ||
      path.startsWith("/unsubscribe/") ||
      path === "/login" ||
      path === "/login.php" ||
      path === "/student-login" ||
      path === "/teacher-login" ||
      path === "/parent-login" ||
      path === "/student-register" ||
      path === "/teacher-register" ||
      path === "/parent-register" ||
      path === "/register" ||
      path === "/register.php" ||
      path.startsWith("/register/") ||
      path === "/erp" ||
      path.startsWith("/erp/") ||
      path === "/cart" ||
      path.startsWith("/ref/") ||
      CUSTOM_PUBLIC_PATHS.has(path)
    );
  }

  async function startPortal(rawPath) {
    const path = normalizePortalPath(rawPath);
    if (path === "/cart") {
      await renderPublicExtension("/courses");
      window.YuitorAddons?.openCartDrawer();
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (path.startsWith("/ref/")) {
      window.YuitorAddons?.initReferralCapture();
      renderRegister("student");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (CUSTOM_PUBLIC_PATHS.has(path) || path.startsWith("/unsubscribe/")) {
      await renderPublicExtension(path);
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (GATE_BASE && (path === `${GATE_BASE}/setup` || path === `${GATE_BASE}/setup.php`)) {
      await renderAdminSetup();
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (
      path === "/register" ||
      path === "/register.php" ||
      path === "/register/student" ||
      path === "/student/register" ||
      path === "/student/register.php" ||
      path === "/student-register"
    ) {
      renderRegister("student");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (
      path === "/register/parent" ||
      path === "/parent/register" ||
      path === "/parent/register.php" ||
      path === "/parent-register"
    ) {
      renderRegister("parent");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
    if (
      path === "/register/teacher" ||
      path === "/teacher/register" ||
      path === "/teacher/register.php" ||
      path === "/teacher-register" ||
      path === "/teacher-apply.php"
    ) {
      renderRegister("teacher");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    let session = null;
    try {
      session = await api("/api/auth/me");
    } catch {
      session = null;
    }
    const user = session?.authenticated ? session.user : null;

    if (GATE_BASE && (path === GATE_BASE || path.startsWith(GATE_BASE + "/"))) {
      if (user && (user.role === "super_admin" || user.role === "admin")) {
        await renderAdminPanel(session);
      } else {
        renderAdminGateLogin(user ? "Signed in with a non-administrator account. Sign in with an Admin account." : "");
      }
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (
      path === "/login" ||
      path === "/login.php" ||
      path === "/student/login" ||
      path === "/student-login" ||
      path === "/teacher/login" ||
      path === "/teacher-login" ||
      path === "/parent/login" ||
      path === "/parent-login" ||
      path === "/staff/login" ||
      path === "/student/login.php" ||
      path === "/teacher/login.php" ||
      path === "/parent/login.php" ||
      path === "/staff/login.php"
    ) {
      const defRole = path.startsWith("/teacher")
        ? "teacher"
        : path.startsWith("/parent")
          ? "parent"
          : path.startsWith("/staff")
            ? "staff"
            : "student";
      if (user) {
        if (user.role === "teacher" && (!session.teacherResume?.hasResume || session.teacherResume?.resumeStatus === "missing" || session.teacherResume?.resumeStatus === "rejected")) {
          renderTeacherResumeGate(session, TEACHER_MISSING_RESUME_MSG);
          window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
          return;
        }
        if (user.role === "super_admin" || user.role === "admin") {
          renderLogin(defRole, "Administrator sessions stay isolated from Student/Parent/Teacher/Staff login.");
          window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
          return;
        }
        const dest =
          user.role === "teacher"
            ? "/teacher/"
            : user.role === "parent"
              ? "/parent/"
              : user.role === "staff"
                ? "/staff/"
                : "/student/";
        window.location.replace(dest);
        return;
      }
      renderLogin(defRole);
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/parent")) {
      if (user && user.role === "parent") {
        await renderParentPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("parent", user ? "Signed in as non-parent. Please sign in with a Parent account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/staff")) {
      if (user && user.role === "staff") {
        await renderStaffPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("staff", user ? "Signed in as non-staff. Please sign in with a Staff account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/teacher")) {
      if (user && user.role === "teacher") {
        await renderTeacherPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("teacher", user ? "Signed in as non-teacher. Please sign in with a Teacher account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }

    if (path.startsWith("/student") || path === "/erp" || path.startsWith("/erp/")) {
      if (user && user.role === "student") {
        await renderStudentPanel(session);
        window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
        return;
      }
      renderLogin("student", user ? "Signed in as non-student. Please sign in with a Student account." : "");
      window.dispatchEvent(new CustomEvent("yuitor:route-changed"));
      return;
    }
  }

  function boot() {
    let lastMountedPath = null;
    let mountRaf = 0;

    const clearPortalClasses = () => {
      const main = getMain();
      if (main) {
        main.classList.remove("portal-main", "portal-dark");
        delete main.dataset.yuPortalMounted;
      }
      lastMountedPath = null;
      document.documentElement.removeAttribute("data-yu-portal-active");
      document.documentElement.removeAttribute("data-yu-portal-workspace");
    };

    const tryMountForCurrentPath = () => {
      const path = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(path)) {
        clearPortalClasses();
        return false;
      }
      const main = getMain();
      const header = root.querySelector(".yu-shared-header");
      const footer = root.querySelector(".yu-shared-footer");
      if (!main || !header || !footer) return false;
      let host = main.querySelector("[data-yu-portal-host]");
      if (!host && (path === "/cart" || path.startsWith("/ref/"))) {
        main.innerHTML = "";
        host = getPortalHost(main);
      }
      if (!host) return false;
      const hasPortalDom = Boolean(host.querySelector(".portal-shell, .portal-workspace"));
      if (main.dataset.yuPortalMounted === "true" && lastMountedPath === path && hasPortalDom) {
        document.documentElement.removeAttribute("data-yu-portal-active");
        return true;
      }
      lastMountedPath = path;
      main.classList.add("portal-main");
      main.dataset.yuPortalMounted = "true";
      document.documentElement.removeAttribute("data-yu-portal-active");
      startPortal(path);
      return true;
    };

    tryMountForCurrentPath();

    const scheduleMount = () => {
      const path = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(path)) {
        clearPortalClasses();
        return;
      }
      if (mountRaf) return;
      mountRaf = window.requestAnimationFrame(() => {
        mountRaf = 0;
        tryMountForCurrentPath();
      });
    };

    const observer = new MutationObserver(scheduleMount);
    observer.observe(root, { childList: true, subtree: true });

    const origPush = history.pushState;
    history.pushState = function (...args) {
      origPush.apply(this, args);
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    };

    const origReplace = history.replaceState;
    history.replaceState = function (...args) {
      origReplace.apply(this, args);
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    };

    window.addEventListener("popstate", () => {
      const nextPath = normalizePortalPath(window.location.pathname);
      if (!isHandledPath(nextPath)) {
        clearPortalClasses();
        return;
      }
      lastMountedPath = null;
      window.setTimeout(tryMountForCurrentPath, 10);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
