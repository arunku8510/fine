// server.ts
import "dotenv/config";
import fs13 from "node:fs";
import path11 from "node:path";
import zlib3 from "node:zlib";
import express, { Router as Router12 } from "express";
import cookieParser from "cookie-parser";

// server/db.ts
import fs2 from "node:fs";
import path from "node:path";
import crypto2 from "node:crypto";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { ensureAddonsSchema } from "./server/addons-db.mjs";
import { ensureCrmV25Schema, getAutomationConfig } from "./server/crm-db.mjs";
import { assignSubstituteOnTeacherLeave, buildRoleWelcomeEmailTemplate, isTeacherPhoneMaskingEnabled, maskPhoneForTeacher } from "./server/crm-engine.mjs";
import { createCrmAdminRouter, createCrmUserRouter } from "./server/crm-routes.mjs";
import { startCentralCrmScheduler } from "./server/crm-scheduler.mjs";
import { BILLING_CYCLES, CLASS_FEE_PLANS, calculateClassFeePlan, normalizeBillingCycle, parseClassNumberFromLabel } from "./server/fee-plans.mjs";
import { ensureReferralProfile, attributeReferralSignup, recomputeReferralForStudent } from "./server/referral-engine.mjs";
import { createAddonsUserRouter, createAddonsAdminRouter } from "./server/addons-routes.mjs";
import {
  SHREYA_OFFICIAL_INTRO,
  answerFromOfficialKnowledge,
  buildFullWebsiteKnowledgeContext,
  buildSecurityRefusalReply,
  buildShreyaSystemInstruction,
  detectSecurityLeakAttempt,
  sanitizeShreyaOutput
} from "./server/shreya-guard.mjs";
import {
  resolveTrustProxySetting,
  safeClientIp,
  verifyStrictSetupKey,
  isInstallerWindowExpired,
  resolveInstallerOwnerEmail,
  generateHighEntropyAdminSlug,
  redactSecretsForLog,
  buildCspHeader,
  issueCsrfCookieIfMissing,
  verifyCsrfProtection,
  validateUploadMagicAndMime,
  scanUploadedFileWithClamAv,
  verifyResumeDocumentContent,
  isStrictLibrarian,
  getStaffBranchScope,
  stripLibrarianStudentPii,
  stripLibrarianLibraryIssues,
  hardenRuntimePermissions
} from "./server/security-hardening.mjs";

// server/security.ts
import crypto from "node:crypto";
import fs from "node:fs";
import bcrypt from "bcryptjs";
var BRAND_PENDING_MSG = "Your OTP verification is complete. Your account verification is currently pending from the Yuitor Team. We will contact you soon. Thank you for your patience.";
var TEACHER_MISSING_RESUME_MSG = "We would love to know more about you! Kindly share your updated resume with us so our academic team can review your profile and complete your teacher registration.";
var SESSION_COOKIE = "yu_session";
var SESSION_TTL_SECONDS = 60 * 60 * 12;
var IMPERSONATION_TTL_SECONDS = 60 * 30;
var OTP_TTL_SECONDS = 60 * 10;
var EPHEMERAL_SESSION_SECRET = "";
function getSessionSecret() {
  const s = (process.env.SESSION_SECRET || "").trim();
  if (s && s !== "replace-with-64-char-random-hex-secret" && s.length >= 32) {
    return s;
  }
  if (!EPHEMERAL_SESSION_SECRET) {
    EPHEMERAL_SESSION_SECRET = crypto.randomBytes(32).toString("hex");
    if (process.env.NODE_ENV === "production") {
      console.warn("[Yuitor Security Warning] SESSION_SECRET is unset or too short in .env; generated ephemeral CSPRNG secret.");
    }
  }
  return EPHEMERAL_SESSION_SECRET;
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function clientIp(req) {
  return safeClientIp(req);
}
function normalizePhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  if (digits.length === 12 && digits.startsWith("91")) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith("0")) {
    return digits.slice(1);
  }
  return digits;
}
function isValidIndianMobile(phone) {
  return /^[6-9]\d{9}$/.test(phone);
}
function isValidPhone(raw) {
  const digits = String(raw ?? "").replace(/\D+/g, "");
  return digits.length >= 10 && digits.length <= 15;
}
function normalizeEmail(raw) {
  return String(raw ?? "").trim().toLowerCase();
}
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 254;
}
function cleanText(raw, maxLen = 500) {
  return String(raw ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, maxLen);
}
function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] || c);
}
function sanitizeHttpOrUploadUrl(raw, maxLen = 400) {
  const s = cleanText(raw, maxLen);
  if (!s) return "";
  if (s.startsWith("/") && !s.startsWith("//")) {
    return s;
  }
  try {
    const u = new URL(s);
    if (u.protocol === "https:" || u.protocol === "http:") {
      return u.toString();
    }
  } catch {
  }
  return "";
}
function validateUploadMagicBytes(filePath, ext, originalName = "", mimeType = "") {
  const allowed = new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp", ".txt", ".md"]);
  const safeName = originalName || `upload${String(ext || "").toLowerCase()}`;
  const res = validateUploadMagicAndMime(filePath, safeName, mimeType, allowed);
  return res.ok;
}
function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}
function verifyPassword(password, storedHash) {
  if (!storedHash || !password) return false;
  const normalizedHash = storedHash.startsWith("$2y$") ? "$2b$" + storedHash.slice(4) : storedHash;
  try {
    return bcrypt.compareSync(password, normalizedHash);
  } catch {
    return false;
  }
}
function hashOtp(phoneOrEmail, purpose, otp) {
  return crypto.createHmac("sha256", getSessionSecret()).update(`${phoneOrEmail}|${purpose}|${otp}`).digest("hex");
}
function generateOtpCode() {
  return String(crypto.randomInt(1e5, 999999));
}
function verifySetupKey(providedKey) {
  return verifyStrictSetupKey(providedKey, process.env.YU_ADMIN_SETUP_KEY);
}
function signSessionToken(sessionId) {
  const sig = crypto.createHmac("sha256", getSessionSecret()).update(sessionId).digest("hex");
  return `${sessionId}.${sig}`;
}
function verifySessionToken(cookieVal) {
  if (typeof cookieVal !== "string" || !cookieVal.includes(".")) return null;
  const [sid, sig] = cookieVal.split(".", 2);
  if (!sid || !sig || !/^[a-f0-9]{32,64}$/i.test(sid)) return null;
  const expected = crypto.createHmac("sha256", getSessionSecret()).update(sid).digest("hex");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  return crypto.timingSafeEqual(a, b) ? sid : null;
}
function isRequestHttps(req) {
  if (!req) return process.env.NODE_ENV === "production";
  if (req.secure) return true;
  if (req.app?.get("trust proxy") && String(req.headers?.["x-forwarded-proto"] || "").split(",")[0].trim() === "https") {
    return true;
  }
  return false;
}
function setSessionCookie(res, req, sessionId, ttlSeconds = SESSION_TTL_SECONDS) {
  const isHttps = isRequestHttps(req);
  res.cookie(SESSION_COOKIE, signSessionToken(sessionId), {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: ttlSeconds * 1e3
  });
}
function clearSessionCookie(res, req) {
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    sameSite: "lax",
    secure: isRequestHttps(req),
    path: "/"
  });
}
function createSession(db, userId, options) {
  if (options?.replaceSessionId) {
    db.prepare("DELETE FROM sessions WHERE id = ?").run(options.replaceSessionId);
  }
  const sid = crypto.randomBytes(24).toString("hex");
  const now = Math.floor(Date.now() / 1e3);
  const ttl = options?.ttlSeconds ?? (options?.impersonatorId ? IMPERSONATION_TTL_SECONDS : SESSION_TTL_SECONDS);
  db.prepare(
    `INSERT INTO sessions (id, user_id, impersonator_id, impersonation_reason, expires_at, created_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    sid,
    userId,
    options?.impersonatorId ?? null,
    options?.reason ?? "",
    now + ttl,
    now,
    now
  );
  return sid;
}
function checkRateLimit(db, key, maxAttempts, windowSeconds, lockSeconds = 300) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare("SELECT key, window_started, attempts, locked_until FROM rate_limits WHERE key = ?").get(key);
  if (!row) {
    return { allowed: true };
  }
  if (row.locked_until && row.locked_until > now) {
    return { allowed: false, retryAfterSeconds: row.locked_until - now };
  }
  if (now - row.window_started > windowSeconds) {
    db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
    return { allowed: true };
  }
  if (row.attempts >= maxAttempts) {
    const until = now + lockSeconds;
    db.prepare("UPDATE rate_limits SET locked_until = ? WHERE key = ?").run(until, key);
    return { allowed: false, retryAfterSeconds: lockSeconds };
  }
  return { allowed: true };
}
function recordRateLimitHit(db, key, windowSeconds) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare("SELECT window_started, attempts FROM rate_limits WHERE key = ?").get(key);
  if (!row || now - row.window_started > windowSeconds) {
    db.prepare(
      "INSERT OR REPLACE INTO rate_limits (key, window_started, attempts, locked_until) VALUES (?, ?, 1, NULL)"
    ).run(key, now);
  } else {
    db.prepare("UPDATE rate_limits SET attempts = attempts + 1 WHERE key = ?").run(key);
  }
}
function clearRateLimit(db, key) {
  db.prepare("DELETE FROM rate_limits WHERE key = ?").run(key);
}
function issueOtp(db, params) {
  const now = Math.floor(Date.now() / 1e3);
  const otp = generateOtpCode();
  const target = params.phone || params.email || "";
  const otpHash = hashOtp(target, params.purpose, otp);
  const expiresAt = now + OTP_TTL_SECONDS;
  db.prepare(
    `INSERT INTO otp_tokens (user_id, phone, email, purpose, otp_hash, attempts, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, 0, ?, ?)`
  ).run(params.userId, params.phone, params.email ?? "", params.purpose, otpHash, expiresAt, now);
  return { otp, expiresAt };
}
function verifyOtpToken(db, params) {
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare(
    `SELECT * FROM otp_tokens
       WHERE (phone = ? OR email = ?) AND purpose = ? AND consumed_at IS NULL
       ORDER BY id DESC LIMIT 1`
  ).get(params.target, params.target, params.purpose);
  if (!row) {
    return { ok: false, error: "No active OTP request found. Please request a new OTP." };
  }
  if (row.expires_at < now) {
    return { ok: false, error: "This OTP has expired. Please request a new OTP." };
  }
  if (row.attempts >= 5) {
    return { ok: false, error: "Too many incorrect OTP attempts. Please request a new OTP." };
  }
  const candidateTarget = row.phone || row.email || params.target;
  const candidateHash = hashOtp(candidateTarget, params.purpose, params.otp.trim());
  const altHash = hashOtp(params.target, params.purpose, params.otp.trim());
  const storedBuf = Buffer.from(String(row.otp_hash || ""));
  const candBuf = Buffer.from(candidateHash);
  const altBuf = Buffer.from(altHash);
  const match = candBuf.length === storedBuf.length && crypto.timingSafeEqual(candBuf, storedBuf) || altBuf.length === storedBuf.length && crypto.timingSafeEqual(altBuf, storedBuf);
  if (!match) {
    db.prepare("UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = ?").run(row.id);
    return { ok: false, error: "Invalid OTP code. Please check and try again." };
  }
  db.prepare("UPDATE otp_tokens SET consumed_at = ? WHERE id = ?").run(now, row.id);
  return { ok: true, tokenRow: row };
}
function writeAuditLog(db, entryOrActor, actionArg, targetIdArg, targetNameArg, detailsArg, ipAddressArg) {
  let entry = entryOrActor || {};
  if (typeof actionArg === "string") {
    const actor = entryOrActor && typeof entryOrActor === "object" ? entryOrActor : null;
    entry = {
      actorId: actor?.id ?? null,
      actorName: actor?.full_name || actor?.name || actor?.email || "System",
      targetId: targetIdArg ?? null,
      targetName: targetNameArg ?? "",
      action: actionArg,
      details: detailsArg ?? "",
      ipAddress: ipAddressArg ?? ""
    };
  }
  db.prepare(
    `INSERT INTO audit_logs (actor_id, actor_name, target_id, target_name, action, details, ip_address, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    entry.actorId ?? null,
    redactSecretsForLog(entry.actorName ?? "").slice(0, 120),
    entry.targetId ?? null,
    redactSecretsForLog(entry.targetName ?? "").slice(0, 160),
    cleanText(entry.action, 80),
    redactSecretsForLog(entry.details ?? "").slice(0, 500),
    cleanText(entry.ipAddress ?? "", 64),
    nowIso()
  );
}
function parseStaffPermissions(raw) {
  if (Array.isArray(raw)) {
    return raw.map((x) => cleanText(x, 60)).filter(Boolean);
  }
  const str = String(raw || "").trim();
  if (!str) return [];
  try {
    const parsed = JSON.parse(str);
    if (Array.isArray(parsed)) return parsed.map((x) => cleanText(x, 60)).filter(Boolean);
  } catch {
  }
  return str.split(",").map((x) => cleanText(x, 60)).filter(Boolean);
}
function hasStaffPermission(ctx, perm) {
  if (!ctx) return false;
  if (ctx.user.role === "super_admin" || ctx.user.role === "admin") return true;
  if (ctx.user.role !== "staff") return false;
  if (ctx.user.staff_permissions.includes("*") || ctx.user.staff_permissions.includes(perm)) return true;
  const roleDefaults = {
    accountant: ["fees", "payments", "expenses", "payouts", "reports"],
    receptionist: ["inquiries", "admissions", "batches", "library", "alerts"],
    librarian: ["library"],
    coordinator: ["batches", "timetable", "attendance", "tests", "inquiries", "reports", "alerts"]
  };
  const defaults = roleDefaults[String(ctx.user.staff_role || "").toLowerCase()] || [];
  return defaults.includes(perm);
}
function getSessionContext(db, req) {
  const sid = verifySessionToken(req.cookies?.[SESSION_COOKIE]);
  if (!sid) return null;
  const now = Math.floor(Date.now() / 1e3);
  const row = db.prepare(
    `SELECT s.id as session_id, s.impersonator_id, s.impersonation_reason, s.expires_at,
              u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url, u.profile_photo,
              u.mobile_verified, u.verification_status, u.is_active, u.marketing_opt_in,
              u.staff_role, u.staff_permissions_json, u.branch_id
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.id = ?`
  ).get(sid);
  if (!row || row.expires_at < now || Number(row.is_active) !== 1) {
    db.prepare("DELETE FROM sessions WHERE id = ?").run(sid);
    return null;
  }
  db.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(now, sid);
  const effectiveAvatar = row.profile_photo || row.avatar_url || "";
  return {
    sessionId: row.session_id,
    user: {
      id: Number(row.id),
      role: row.role,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      avatar_url: effectiveAvatar,
      profile_photo: effectiveAvatar,
      mobile_verified: Number(row.mobile_verified),
      verification_status: row.verification_status,
      is_active: Number(row.is_active),
      marketing_opt_in: Number(row.marketing_opt_in),
      staff_role: row.staff_role || "",
      staff_permissions: parseStaffPermissions(row.staff_permissions_json),
      branch_id: row.branch_id ? Number(row.branch_id) : null
    },
    impersonation: row.impersonator_id ? {
      active: true,
      adminId: Number(row.impersonator_id),
      reason: row.impersonation_reason || "Support troubleshooting"
    } : { active: false }
  };
}
function sameOriginGuard(req, res, next) {
  const check = verifyCsrfProtection(req);
  if (!check.ok) {
    try {
      if (dbInstance) {
        writeAuditLog(dbInstance, {
          actorId: null,
          actorName: "Security Guard",
          targetName: cleanText(req.originalUrl || req.path || "/api", 120),
          action: "csrf_blocked",
          details: `${req.method} blocked: ${check.reason}`,
          ipAddress: clientIp(req)
        });
      }
    } catch {
    }
    res.status(403).json({ error: check.reason || "CSRF protection blocked this request." });
    return;
  }
  next();
}
function signReleaseDownload(expiresUnix, variant = "deploy") {
  const prefix = variant === "source" ? "source-zip" : "release-zip";
  return crypto.createHmac("sha256", getSessionSecret()).update(`${prefix}|${expiresUnix}`).digest("hex");
}
function verifyReleaseDownload(expiresRaw, sigRaw, variant = "deploy") {
  const expires = Number(expiresRaw);
  const sig = String(sigRaw || "").trim();
  if (!Number.isFinite(expires) || expires < Math.floor(Date.now() / 1e3) || !/^[a-f0-9]{64}$/i.test(sig)) {
    return false;
  }
  const expected = signReleaseDownload(expires, variant);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function signAdminOtpChallenge(userId, expiresUnix, nonce) {
  const payload = `${userId}.${expiresUnix}.${nonce}`;
  const sig = crypto.createHmac("sha256", getSessionSecret()).update(`admin-otp|${payload}`).digest("hex");
  return `${payload}.${sig}`;
}
function verifyAdminOtpChallenge(token) {
  const parts = String(token || "").trim().split(".");
  if (parts.length !== 4) return { ok: false };
  const [uidStr, expStr, nonce, sig] = parts;
  const userId = Number(uidStr);
  const expiresUnix = Number(expStr);
  if (!Number.isInteger(userId) || userId <= 0 || !Number.isFinite(expiresUnix) || expiresUnix < Math.floor(Date.now() / 1e3)) {
    return { ok: false };
  }
  if (!/^[a-f0-9]{16,64}$/i.test(nonce) || !/^[a-f0-9]{64}$/i.test(sig)) {
    return { ok: false };
  }
  const expected = signAdminOtpChallenge(userId, expiresUnix, nonce).split(".")[3];
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { ok: false };
  }
  return { ok: true, userId };
}
function encryptVaultSecret(plaintext, keyBuf) {
  const plain = String(plaintext || "");
  if (!plain) return "";
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", keyBuf, iv);
  const encrypted = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("hex")}:${tag.toString("hex")}:${encrypted.toString("hex")}`;
}
function decryptVaultSecret(payload, keyBuf) {
  const raw = String(payload || "").trim();
  if (!raw.startsWith("enc:v1:")) return "";
  const parts = raw.split(":");
  if (parts.length !== 5) return "";
  try {
    const iv = Buffer.from(parts[2], "hex");
    const tag = Buffer.from(parts[3], "hex");
    const data = Buffer.from(parts[4], "hex");
    const decipher = crypto.createDecipheriv("aes-256-gcm", keyBuf, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

// server/settings.ts
var SETTING_DEFINITIONS = [
  {
    key: "APP_URL",
    category: "general",
    label: "Public App URL (APP_URL)",
    description: "Primary live domain URL used in emails, unsubscribe links, and origin checks.",
    isSecret: false,
    defaultValue: "https://yuitor.com",
    placeholder: "https://yuitor.com",
    inputType: "url"
  },
  {
    key: "SESSION_SECRET",
    category: "general",
    label: "Session Signing Secret (SESSION_SECRET)",
    description: "Strong random secret (min 16 chars, recommended 64-char hex) for signing cookies, OTPs, and download links.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter or generate a strong 64-char hex secret",
    inputType: "password"
  },
  {
    key: "YU_ADMIN_SETUP_KEY",
    category: "general",
    label: "First-Admin Setup Key (YU_ADMIN_SETUP_KEY)",
    description: "Optional security key required when creating the first Super Admin in the installer.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Optional secret key for installer setup",
    inputType: "password"
  },
  {
    key: "ADMIN_IP_ALLOWLIST",
    category: "general",
    label: "Admin IP Allow-List (Optional)",
    description: "Optional comma-separated IPs or IPv4 CIDRs allowed to sign into the Admin Gate (leave blank for any IP).",
    isSecret: false,
    defaultValue: "",
    placeholder: "e.g. 127.0.0.1, 203.0.113.0/24",
    inputType: "text"
  },
  {
    key: "ADMIN_OTP_EMAIL",
    category: "general",
    label: "Admin & Installer 2FA OTP Email (ADMIN_OTP_EMAIL)",
    description: "Verification email address that receives a 6-digit OTP for Installer verification and every Admin Console sign-in.",
    isSecret: false,
    defaultValue: "info@yuitor.com",
    placeholder: "admin@yuitor.com",
    inputType: "email"
  },
  {
    key: "GEMINI_API_KEY",
    category: "ai",
    label: "Google Gemini API Key (GEMINI_API_KEY)",
    description: "Enables live Gemini LLM responses for Shreya Smart AI (deterministic bilingual fallback runs when unset).",
    isSecret: true,
    defaultValue: "",
    placeholder: "AIza...",
    inputType: "password"
  },
  {
    key: "GEMINI_MODEL",
    category: "ai",
    label: "Gemini Model Name (GEMINI_MODEL)",
    description: "Gemini model ID used for live Shreya AI replies (recommended: gemini-2.5-flash).",
    isSecret: false,
    defaultValue: "gemini-2.5-flash",
    placeholder: "gemini-2.5-flash",
    inputType: "text"
  },
  {
    key: "SMTP_HOST",
    category: "email",
    label: "SMTP Host (SMTP_HOST)",
    description: "Outgoing mail server hostname (e.g. mail.yuitor.com).",
    isSecret: false,
    defaultValue: "",
    placeholder: "mail.yuitor.com",
    inputType: "text"
  },
  {
    key: "SMTP_PORT",
    category: "email",
    label: "SMTP Port (SMTP_PORT)",
    description: "SMTP port number (465 for SSL/TLS recommended on cPanel, 587 for STARTTLS).",
    isSecret: false,
    defaultValue: "465",
    placeholder: "465",
    inputType: "number"
  },
  {
    key: "SMTP_SECURE",
    category: "email",
    label: "Use SSL/TLS (SMTP_SECURE)",
    description: "Enable direct TLS (true for port 465 SSL/TLS, false for port 587 STARTTLS).",
    isSecret: false,
    defaultValue: "true",
    placeholder: "true",
    inputType: "boolean"
  },
  {
    key: "SMTP_USER",
    category: "email",
    label: "SMTP Username (SMTP_USER)",
    description: "Authenticated email login username.",
    isSecret: false,
    defaultValue: "",
    placeholder: "no-reply@yuitor.com",
    inputType: "text"
  },
  {
    key: "SMTP_PASS",
    category: "email",
    label: "SMTP Password (SMTP_PASS)",
    description: "SMTP mailbox password or app password (stored securely on server).",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter SMTP password or app password",
    inputType: "password"
  },
  {
    key: "MAIL_FROM_NAME",
    category: "email",
    label: "Sender Display Name (MAIL_FROM_NAME)",
    description: "Display name shown in outgoing emails.",
    isSecret: false,
    defaultValue: "Yuitor Smart Classes",
    placeholder: "Yuitor Smart Classes",
    inputType: "text"
  },
  {
    key: "MAIL_FROM_EMAIL",
    category: "email",
    label: "Sender Email (MAIL_FROM_EMAIL)",
    description: "From address for system & marketing emails (default: no-reply@yuitor.com).",
    isSecret: false,
    defaultValue: "no-reply@yuitor.com",
    placeholder: "no-reply@yuitor.com",
    inputType: "email"
  },
  {
    key: "REPLY_TO_EMAIL",
    category: "email",
    label: "Reply-To Email (REPLY_TO_EMAIL)",
    description: "Address where replies from students/parents are delivered.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "ADMIN_NOTIFY_EMAIL",
    category: "email",
    label: "Admin Alert Email (ADMIN_NOTIFY_EMAIL)",
    description: "Recipient email for new admission enquiries and registration approvals.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_ADMISSION",
    category: "email",
    label: "Department: Admissions Email",
    description: "Shown on Admission & Contact sections and used as Reply-To for enquiry/admission notifications.",
    isSecret: false,
    defaultValue: "admission@yuitor.com",
    placeholder: "admission@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_INQUIRY",
    category: "email",
    label: "Department: General Inquiry Email",
    description: "Primary public general inquiry address in header, footer, and contact cards.",
    isSecret: false,
    defaultValue: "inquiry@yuitor.com",
    placeholder: "inquiry@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_COMPLAIN",
    category: "email",
    label: "Department: Complaints Email",
    description: "Official complaints address displayed in footer, contact, and student support sections.",
    isSecret: false,
    defaultValue: "complain@yuitor.com",
    placeholder: "complain@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_SUPPORT",
    category: "email",
    label: "Department: Student & Portal Support Email",
    description: "Technical and student support contact inside Contact & Student Support portal tabs.",
    isSecret: false,
    defaultValue: "support@yuitor.com",
    placeholder: "support@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_GRIEVANCE",
    category: "email",
    label: "Department: Academic Grievance Email",
    description: "Escalation & dispute contact linked on Terms of Use and Student Support.",
    isSecret: false,
    defaultValue: "grievance@yuitor.com",
    placeholder: "grievance@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_FEE",
    category: "email",
    label: "Department: Fee & Billing Desk Email",
    description: "Reply-To for fee receipts and shown inside Student Fees & Receipts.",
    isSecret: false,
    defaultValue: "fee@yuitor.com",
    placeholder: "fee@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_CAREER",
    category: "email",
    label: "Department: Faculty Careers Email",
    description: "Contact email for teaching applications & resume queries on Teacher Registration.",
    isSecret: false,
    defaultValue: "career@yuitor.com",
    placeholder: "career@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_PRIVACY",
    category: "email",
    label: "Department: Privacy & Data Officer Email",
    description: "Data protection contact email displayed on Privacy Policy.",
    isSecret: false,
    defaultValue: "privacy@yuitor.com",
    placeholder: "privacy@yuitor.com",
    inputType: "email"
  },
  {
    key: "EMAIL_REFUND",
    category: "email",
    label: "Department: Refund Desk Email",
    description: "Refund requests & withdrawal contact linked on Refund Policy and Fees.",
    isSecret: false,
    defaultValue: "refund@yuitor.com",
    placeholder: "refund@yuitor.com",
    inputType: "email"
  },
  {
    key: "FAST2SMS_API_KEY",
    category: "sms",
    label: "Fast2SMS API Key (FAST2SMS_API_KEY)",
    description: "Sends live 6-digit SMS OTPs to mobile numbers during registration and password reset.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Fast2SMS authorization key",
    inputType: "password"
  },
  {
    key: "FAST2SMS_ROUTE",
    category: "sms",
    label: "Fast2SMS Route (FAST2SMS_ROUTE)",
    description: "Choose 'q' for Quick SMS, 'otp' for OTP route, or 'dlt' for TRAI DLT approved templates.",
    isSecret: false,
    defaultValue: "q",
    placeholder: "q",
    inputType: "text"
  },
  {
    key: "FAST2SMS_SENDER_ID",
    category: "sms",
    label: "Fast2SMS Sender ID (Optional)",
    description: "Approved 6-character DLT sender ID (e.g. YUITOR) when using DLT route.",
    isSecret: false,
    defaultValue: "",
    placeholder: "YUITOR",
    inputType: "text"
  },
  {
    key: "FAST2SMS_DLT_TEMPLATE_ID",
    category: "sms",
    label: "Fast2SMS DLT Template ID (Optional)",
    description: "Registered TRAI DLT Template/Message ID when FAST2SMS_ROUTE is set to dlt.",
    isSecret: false,
    defaultValue: "",
    placeholder: "17071...",
    inputType: "text"
  },
  {
    key: "WHATSAPP_ACCESS_TOKEN",
    category: "sms",
    label: "WhatsApp Cloud API Access Token (Optional)",
    description: "Meta WhatsApp Business Cloud API Bearer token for automated one-click WhatsApp fee & attendance alerts (1-click wa.me links work without token).",
    isSecret: true,
    defaultValue: "",
    placeholder: "EAAG...",
    inputType: "password"
  },
  {
    key: "WHATSAPP_PHONE_NUMBER_ID",
    category: "sms",
    label: "WhatsApp Phone Number ID (Optional)",
    description: "Meta WhatsApp Business Phone Number ID paired with WHATSAPP_ACCESS_TOKEN.",
    isSecret: false,
    defaultValue: "",
    placeholder: "1029384756...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_ID",
    category: "payments",
    label: "Razorpay Key ID (RAZORPAY_KEY_ID)",
    description: "Public Razorpay Merchant Key ID (starts with rzp_live_ or rzp_test_).",
    isSecret: false,
    defaultValue: "",
    placeholder: "rzp_live_...",
    inputType: "text"
  },
  {
    key: "RAZORPAY_KEY_SECRET",
    category: "payments",
    label: "Razorpay Key Secret (RAZORPAY_KEY_SECRET)",
    description: "Secret key used to create Razorpay orders and verify HMAC-SHA256 payment signatures.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter Razorpay key secret",
    inputType: "password"
  },
  {
    key: "RAZORPAY_WEBHOOK_SECRET",
    category: "payments",
    label: "Razorpay Webhook Secret (Optional)",
    description: "Webhook signing secret used to verify incoming Razorpay webhook events.",
    isSecret: true,
    defaultValue: "",
    placeholder: "Enter webhook secret",
    inputType: "password"
  }
];
var SETTING_MAP = new Map(SETTING_DEFINITIONS.map((d) => [d.key, d]));
var ENV_BASELINE = /* @__PURE__ */ new Map();
var baselineCaptured = false;
function captureEnvBaseline() {
  if (baselineCaptured) return;
  for (const def of SETTING_DEFINITIONS) {
    ENV_BASELINE.set(def.key, process.env[def.key]);
  }
  baselineCaptured = true;
}
function isEffectiveValue(key, val) {
  const v = val.trim();
  if (!v) return false;
  if (key === "APP_URL" && v === "MY_APP_URL") return false;
  if (key === "GEMINI_API_KEY" && v === "MY_GEMINI_API_KEY") return false;
  if (key === "SESSION_SECRET" && v === "replace-with-64-char-random-hex-secret") return false;
  if (key === "SMTP_HOST" && v === "smtp.example.com") return false;
  if (key === "SMTP_PASS" && v.startsWith("replace-with")) return false;
  return true;
}
function maskSecret(val) {
  const trimmed = val.trim();
  if (!trimmed) return "";
  if (trimmed.length <= 6) return "\u2022\u2022\u2022\u2022\u2022\u2022";
  return `${trimmed.slice(0, 2)}${"\u2022".repeat(Math.min(12, trimmed.length - 6))}${trimmed.slice(-4)}`;
}
function hydrateRuntimeSettings(db) {
  captureEnvBaseline();
  const rows = db.prepare("SELECT key, value FROM system_settings").all();
  const dbMap = new Map(rows.map((r) => [r.key, String(r.value ?? "")]));
  for (const def of SETTING_DEFINITIONS) {
    const saved = dbMap.get(def.key);
    if (saved !== void 0 && saved.trim() !== "") {
      process.env[def.key] = saved;
    } else {
      const orig = ENV_BASELINE.get(def.key);
      if (orig !== void 0) {
        process.env[def.key] = orig;
      } else {
        delete process.env[def.key];
      }
    }
  }
  hydrateRuntimeSettingsExtra(dbMap);
}
function hydrateRuntimeSettingsExtra(dbMap) {
  const adminPathSaved = dbMap.get("ADMIN_PATH");
  if (adminPathSaved !== void 0 && adminPathSaved.trim() !== "") {
    process.env.ADMIN_PATH = adminPathSaved.trim();
  }
}
function getDepartmentEmails() {
  const pick = (key, fallback) => {
    const val = String(process.env[key] || "").trim();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val) ? val : fallback;
  };
  return {
    admission: pick("EMAIL_ADMISSION", "admission@yuitor.com"),
    support: pick("EMAIL_SUPPORT", "support@yuitor.com"),
    grievance: pick("EMAIL_GRIEVANCE", "grievance@yuitor.com"),
    fee: pick("EMAIL_FEE", "fee@yuitor.com"),
    career: pick("EMAIL_CAREER", "career@yuitor.com"),
    privacy: pick("EMAIL_PRIVACY", "privacy@yuitor.com"),
    refund: pick("EMAIL_REFUND", "refund@yuitor.com"),
    inquiry: pick("EMAIL_INQUIRY", "inquiry@yuitor.com"),
    complain: pick("EMAIL_COMPLAIN", "complain@yuitor.com")
  };
}
var DEFAULT_ADMIN_OTP_EMAIL = "info@yuitor.com";
function getAdminOtpEmail() {
  const raw = String(process.env.ADMIN_OTP_EMAIL || "").trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(raw) ? raw : DEFAULT_ADMIN_OTP_EMAIL;
}
function maskEmailAddress(email) {
  const clean = String(email || "").trim();
  const at = clean.indexOf("@");
  if (at <= 1) return clean;
  const local = clean.slice(0, at);
  const domain = clean.slice(at);
  if (local.length <= 4) {
    return `${local[0]}***${local[local.length - 1]}${domain}`;
  }
  return `${local.slice(0, 2)}${"*".repeat(Math.min(6, local.length - 4))}${local.slice(-2)}${domain}`;
}
var INTEGRATION_STATUS_META_KEY = "integration_test_statuses";
function getIntegrationTestStatuses(db) {
  const empty = () => ({ tested: false, connected: false, message: "", testedAt: null });
  const base = {
    razorpay: empty(),
    fast2sms: empty(),
    smtp: empty(),
    gemini: empty()
  };
  try {
    const row = db.prepare("SELECT value FROM schema_meta WHERE key = ?").get(INTEGRATION_STATUS_META_KEY);
    if (!row?.value) return base;
    const parsed = JSON.parse(row.value);
    for (const k of ["razorpay", "fast2sms", "smtp", "gemini"]) {
      if (parsed?.[k] && typeof parsed[k] === "object") {
        base[k] = {
          tested: Boolean(parsed[k].tested),
          connected: Boolean(parsed[k].connected),
          message: String(parsed[k].message || ""),
          testedAt: parsed[k].testedAt ? String(parsed[k].testedAt) : null
        };
      }
    }
  } catch {
  }
  return base;
}
function recordIntegrationTestStatus(db, key, connected, message) {
  const current = getIntegrationTestStatuses(db);
  current[key] = {
    tested: true,
    connected,
    message: cleanText(message, 280),
    testedAt: nowIso()
  };
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES (?, ?)").run(
    INTEGRATION_STATUS_META_KEY,
    JSON.stringify(current)
  );
  return current;
}
function clearIntegrationTestStatusesForKeys(db, touchedKeys) {
  if (touchedKeys.length === 0) return;
  const current = getIntegrationTestStatuses(db);
  let dirty = false;
  const reset = () => ({ tested: false, connected: false, message: "Credentials updated \u2014 re-test connection.", testedAt: null });
  if (touchedKeys.some((k) => k.startsWith("RAZORPAY_"))) {
    current.razorpay = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("FAST2SMS_"))) {
    current.fast2sms = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("SMTP_") || k.endsWith("_EMAIL") || k === "MAIL_FROM_NAME")) {
    current.smtp = reset();
    dirty = true;
  }
  if (touchedKeys.some((k) => k.startsWith("GEMINI_"))) {
    current.gemini = reset();
    dirty = true;
  }
  if (dirty) {
    try {
      db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES (?, ?)").run(
        INTEGRATION_STATUS_META_KEY,
        JSON.stringify(current)
      );
    } catch {
    }
  }
}
function getAdminSettingsView(db) {
  hydrateRuntimeSettings(db);
  const rows = db.prepare("SELECT key, value, updated_at FROM system_settings").all();
  const dbMap = new Map(rows.map((r) => [r.key, r]));
  const items = SETTING_DEFINITIONS.map((def) => {
    const dbRow = dbMap.get(def.key);
    const dbVal = dbRow?.value ?? "";
    const envVal = String(ENV_BASELINE.get(def.key) ?? "");
    const activeRaw = String(process.env[def.key] ?? "");
    const hasDbOverride = dbVal.trim() !== "";
    const configured = isEffectiveValue(def.key, activeRaw);
    const source = hasDbOverride ? "admin" : isEffectiveValue(def.key, envVal) ? "env" : def.defaultValue ? "default" : "unset";
    return {
      key: def.key,
      category: def.category,
      label: def.label,
      description: def.description,
      isSecret: def.isSecret,
      inputType: def.inputType,
      defaultValue: def.defaultValue,
      placeholder: def.placeholder,
      value: def.isSecret ? "" : activeRaw || def.defaultValue,
      maskedValue: def.isSecret && configured ? maskSecret(activeRaw) : "",
      isConfigured: configured,
      hasDbOverride,
      source,
      updatedAt: dbRow?.updated_at || null
    };
  });
  const active = (k) => isEffectiveValue(k, String(process.env[k] ?? ""));
  const readiness = {
    appUrl: active("APP_URL"),
    sessionSecret: active("SESSION_SECRET"),
    setupKeyProtected: active("YU_ADMIN_SETUP_KEY"),
    geminiAi: active("GEMINI_API_KEY"),
    geminiModel: (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash",
    smtpMail: active("SMTP_HOST") && active("SMTP_USER") && active("SMTP_PASS"),
    fast2sms: active("FAST2SMS_API_KEY"),
    whatsapp: active("WHATSAPP_ACCESS_TOKEN") && active("WHATSAPP_PHONE_NUMBER_ID"),
    razorpay: active("RAZORPAY_KEY_ID") && active("RAZORPAY_KEY_SECRET"),
    razorpayMode: (process.env.RAZORPAY_KEY_ID || "").trim().startsWith("rzp_live_") ? "live" : (process.env.RAZORPAY_KEY_ID || "").trim().startsWith("rzp_test_") ? "sandbox" : "unconfigured",
    razorpayWebhook: active("RAZORPAY_WEBHOOK_SECRET")
  };
  return { settings: items, readiness, integrationStatuses: getIntegrationTestStatuses(db) };
}
function updateAdminSettings(db, valuesInput, clearKeysInput, actorUserId) {
  const now = nowIso();
  const updatedKeys = [];
  const clearedKeys = [];
  let sessionSecretRotated = false;
  const upsert = db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET
       value = excluded.value,
       is_secret = excluded.is_secret,
       updated_at = excluded.updated_at,
       updated_by = excluded.updated_by`
  );
  const del = db.prepare("DELETE FROM system_settings WHERE key = ?");
  for (const rawKey of clearKeysInput) {
    const key = cleanText(rawKey, 80);
    if (!SETTING_MAP.has(key)) continue;
    del.run(key);
    clearedKeys.push(key);
    if (key === "SESSION_SECRET") sessionSecretRotated = true;
  }
  for (const [rawKey, rawVal] of Object.entries(valuesInput || {})) {
    const key = cleanText(rawKey, 80);
    const def = SETTING_MAP.get(key);
    if (!def) continue;
    if (clearedKeys.includes(key)) continue;
    const strVal = cleanText(rawVal, 1e3);
    if (def.isSecret && strVal === "") {
      continue;
    }
    if (key === "APP_URL" && strVal) {
      let parsed;
      try {
        parsed = new URL(strVal);
      } catch {
        throw new Error("APP_URL must be a valid full URL (e.g. https://yuitor.com).");
      }
      if (!["http:", "https:"].includes(parsed.protocol)) {
        throw new Error("APP_URL must start with http:// or https://.");
      }
    }
    if (key === "SMTP_PORT" && strVal) {
      const port = Number(strVal);
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error("SMTP_PORT must be a valid port number between 1 and 65535.");
      }
    }
    if (key === "SESSION_SECRET" && strVal.length < 16) {
      throw new Error("SESSION_SECRET must be at least 16 characters (64-char hex recommended).");
    }
    if (key === "FAST2SMS_ROUTE" && strVal && !["q", "otp", "dlt"].includes(strVal.toLowerCase())) {
      throw new Error("FAST2SMS_ROUTE must be one of: q, otp, or dlt.");
    }
    if (key === "RAZORPAY_KEY_ID" && strVal && !/^rzp_(test|live)_[A-Za-z0-9]{4,}$/.test(strVal)) {
      throw new Error("RAZORPAY_KEY_ID must start with rzp_test_ or rzp_live_ followed by the Razorpay key ID.");
    }
    if (key === "SMTP_HOST" && strVal && (!/^[a-z0-9.-]+$/i.test(strVal) || !strVal.includes("."))) {
      throw new Error("SMTP_HOST must be a valid mail server hostname (e.g. smtp.hostinger.com).");
    }
    if (key === "GEMINI_MODEL" && strVal && !/^gemini-[A-Za-z0-9._-]+$/i.test(strVal)) {
      throw new Error("GEMINI_MODEL must be a valid Gemini model ID (e.g. gemini-2.5-flash).");
    }
    if (def.inputType === "email" && strVal && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(strVal)) {
      throw new Error(`${def.label} must be a valid email address.`);
    }
    if (strVal === "" && !def.isSecret) {
      del.run(key);
      clearedKeys.push(key);
    } else {
      const normalized = key === "APP_URL" ? strVal.replace(/\/+$/, "") : key === "SMTP_SECURE" ? String(strVal).toLowerCase() === "true" ? "true" : "false" : key === "FAST2SMS_ROUTE" ? strVal.toLowerCase() : strVal;
      upsert.run(key, normalized, def.isSecret ? 1 : 0, now, actorUserId);
      updatedKeys.push(key);
      if (key === "SESSION_SECRET") sessionSecretRotated = true;
    }
  }
  hydrateRuntimeSettings(db);
  clearIntegrationTestStatusesForKeys(db, [...updatedKeys, ...clearedKeys]);
  return { updatedKeys, clearedKeys, sessionSecretRotated };
}

// server/db.ts
function resolveAppRoot() {
  const hasPublicContext = (dir) => fs2.existsSync(path.join(dir, "public")) || fs2.existsSync(path.join(dir, "index.html")) || fs2.existsSync(path.resolve(dir, "..", "public_html"));
  const candidates = [];
  try {
    const selfDir = path.dirname(fileURLToPath(import.meta.url));
    candidates.push(selfDir, path.resolve(selfDir, ".."));
  } catch {
  }
  candidates.push(process.cwd());
  if (process.argv[1]) {
    const argvDir = path.dirname(path.resolve(process.argv[1]));
    candidates.push(argvDir, path.resolve(argvDir, ".."));
  }
  for (const dir of candidates) {
    if (fs2.existsSync(path.join(dir, "database")) && hasPublicContext(dir)) {
      return dir;
    }
  }
  return process.cwd();
}
var APP_ROOT = resolveAppRoot();
function resolvePublicDir(appRoot = APP_ROOT) {
  const envDir = (process.env.YUITOR_PUBLIC_DIR || "").trim();
  if (envDir) {
    const resolved = path.isAbsolute(envDir) ? envDir : path.resolve(appRoot, envDir);
    if (fs2.existsSync(resolved)) {
      return resolved;
    }
  }
  const bundledPublic = path.join(appRoot, "public");
  if (fs2.existsSync(bundledPublic)) {
    return bundledPublic;
  }
  if (fs2.existsSync(path.join(appRoot, "index.html"))) {
    return appRoot;
  }
  const siblingPublicHtml = path.resolve(appRoot, "..", "public_html");
  if (fs2.existsSync(siblingPublicHtml)) {
    return siblingPublicHtml;
  }
  return bundledPublic;
}
var PUBLIC_DIR = resolvePublicDir();
var DATA_DIR = path.join(APP_ROOT, "data");
var BACKUPS_DIR = path.join(APP_ROOT, "backups");
var LOGS_DIR = path.join(APP_ROOT, "logs");
var UPLOADS_DIR = path.join(APP_ROOT, "uploads");
var RESUMES_DIR = path.join(UPLOADS_DIR, "resumes");
var KNOWLEDGE_DIR = path.join(UPLOADS_DIR, "knowledge");
var DB_PATH = path.join(DATA_DIR, "yuitor.db");
var LEGACY_DB_PATH = path.join(DATA_DIR, "legacy-portal.sqlite");
var MIGRATION_PATH = path.join(APP_ROOT, "database", "migrations", "001_unified_portal.sql");
var dbInstance = null;
function addMissingColumn(db, table, col, ddl) {
  if (!/^[a-z0-9_]+$/i.test(table) || !/^[a-z0-9_]+$/i.test(col)) {
    throw new Error("Invalid SQL identifier");
  }
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === col)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
function upgradeUsersRoleConstraintIfNeeded(db) {
  const row = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'").get();
  const sql = String(row?.sql || "");
  if (!sql || sql.includes("'parent'")) {
    return;
  }
  db.exec("PRAGMA foreign_keys = OFF;");
  db.exec("BEGIN IMMEDIATE;");
  try {
    db.exec(`
      CREATE TABLE users_upgraded (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL CHECK (role IN ('super_admin', 'admin', 'teacher', 'student', 'parent', 'staff')),
        staff_role TEXT NOT NULL DEFAULT '',
        staff_permissions_json TEXT NOT NULL DEFAULT '[]',
        branch_id INTEGER,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL COLLATE NOCASE UNIQUE,
        phone TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        avatar_url TEXT NOT NULL DEFAULT '',
        mobile_verified INTEGER NOT NULL DEFAULT 0,
        verification_status TEXT NOT NULL DEFAULT 'pending_otp'
          CHECK (verification_status IN ('pending_otp', 'otp_verified', 'pending_approval', 'approved', 'rejected', 'suspended')),
        is_active INTEGER NOT NULL DEFAULT 1,
        marketing_opt_in INTEGER NOT NULL DEFAULT 1,
        unsubscribe_token TEXT NOT NULL UNIQUE,
        last_login_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      INSERT INTO users_upgraded (
        id, role, full_name, email, phone, password_hash, avatar_url, mobile_verified,
        verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at
      )
      SELECT
        id, role, full_name, email, phone, password_hash, avatar_url, mobile_verified,
        verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at
      FROM users;
      DROP TABLE users;
      ALTER TABLE users_upgraded RENAME TO users;
      CREATE INDEX IF NOT EXISTS idx_users_role_status ON users(role, verification_status);
      CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    `);
    db.exec("COMMIT;");
  } catch (err) {
    try {
      db.exec("ROLLBACK;");
    } catch {
    }
    throw err;
  } finally {
    db.exec("PRAGMA foreign_keys = ON;");
  }
}
function upgradeOtpTokensConstraintIfNeeded(db) {
  const row = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'otp_tokens'").get();
  const sql = String(row?.sql || "");
  if (!sql || (sql.includes("'login_otp'") && sql.includes("'parent_link'"))) {
    return;
  }
  db.exec("PRAGMA foreign_keys = OFF;");
  db.exec("BEGIN IMMEDIATE;");
  try {
    db.exec(`
      CREATE TABLE otp_tokens_upgraded (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        phone TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL DEFAULT '',
        purpose TEXT NOT NULL CHECK (purpose IN ('registration', 'password_reset', 'admin_2fa', 'login_otp', 'parent_link')),
        otp_hash TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        expires_at INTEGER NOT NULL,
        consumed_at INTEGER,
        created_at INTEGER NOT NULL
      );
      INSERT INTO otp_tokens_upgraded (
        id, user_id, phone, email, purpose, otp_hash, attempts, expires_at, consumed_at, created_at
      )
      SELECT
        id, user_id, phone, email, purpose, otp_hash, attempts, expires_at, consumed_at, created_at
      FROM otp_tokens;
      DROP TABLE otp_tokens;
      ALTER TABLE otp_tokens_upgraded RENAME TO otp_tokens;
      CREATE INDEX IF NOT EXISTS idx_otp_phone_purpose ON otp_tokens(phone, purpose, created_at);
      CREATE INDEX IF NOT EXISTS idx_otp_email_purpose ON otp_tokens(email, purpose, created_at);
    `);
    db.exec("COMMIT;");
  } catch (err) {
    try {
      db.exec("ROLLBACK;");
    } catch {
    }
    throw err;
  } finally {
    db.exec("PRAGMA foreign_keys = ON;");
  }
}
function ensureSchemaUpgrades(db) {
  upgradeUsersRoleConstraintIfNeeded(db);
  upgradeOtpTokensConstraintIfNeeded(db);
  addMissingColumn(db, "users", "staff_role", "staff_role TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "users", "staff_permissions_json", "staff_permissions_json TEXT NOT NULL DEFAULT '[]'");
  addMissingColumn(db, "users", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "users", "profile_photo", "profile_photo TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_url", "resume_url TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_filename", "resume_filename TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_mime", "resume_mime TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "teacher_profiles", "resume_size", "resume_size INTEGER NOT NULL DEFAULT 0");
  addMissingColumn(db, "teacher_profiles", "resume_status", "resume_status TEXT NOT NULL DEFAULT 'missing'");
  addMissingColumn(db, "teacher_profiles", "resume_uploaded_at", "resume_uploaded_at TEXT");
  addMissingColumn(db, "teacher_profiles", "resume_notes", "resume_notes TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "student_profiles", "roll_number", "roll_number TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "student_profiles", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "student_profiles", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "student_profiles", "billing_cycle", "billing_cycle TEXT NOT NULL DEFAULT '1m'");
  addMissingColumn(db, "courses", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "enrollments", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "attendance", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "attendance", "marked_via", "marked_via TEXT NOT NULL DEFAULT 'manual'");
  addMissingColumn(db, "class_schedules", "batch_id", "batch_id INTEGER");
  addMissingColumn(db, "class_schedules", "room_name", "room_name TEXT NOT NULL DEFAULT 'Room 101'");
  addMissingColumn(db, "fee_records", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "fee_records", "billing_cycle", "billing_cycle TEXT NOT NULL DEFAULT '1m'");
  addMissingColumn(db, "inquiries", "branch_id", "branch_id INTEGER");
  addMissingColumn(db, "inquiries", "follow_up_date", "follow_up_date TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "follow_up_notes", "follow_up_notes TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "assigned_staff", "assigned_staff TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "demo_date", "demo_date TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "inquiries", "demo_time_slot", "demo_time_slot TEXT NOT NULL DEFAULT ''");
  addMissingColumn(db, "support_messages", "course_id", "course_id INTEGER");
  addMissingColumn(db, "support_messages", "teacher_id", "teacher_id INTEGER");
  db.exec(`
    CREATE TABLE IF NOT EXISTS parent_link_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      relation TEXT NOT NULL DEFAULT 'Parent / Guardian',
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
      requested_by_ip TEXT NOT NULL DEFAULT '',
      reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      review_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      reviewed_at TEXT,
      UNIQUE(parent_user_id, student_user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_parent_link_req_status ON parent_link_requests(status, created_at DESC);
    CREATE TABLE IF NOT EXISTS cart_gateway_orders (
      gateway_order_id TEXT PRIMARY KEY,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expected_amount INTEGER NOT NULL,
      coupon_code TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'verified', 'failed')),
      gateway_payment_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      completed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT '',
      is_secret INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT '',
      updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS knowledge_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/pdf',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      file_path TEXT NOT NULL DEFAULT '',
      extracted_text TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS admin_login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      identifier TEXT NOT NULL DEFAULT '',
      ip_address TEXT NOT NULL DEFAULT '',
      user_agent TEXT NOT NULL DEFAULT '',
      outcome TEXT NOT NULL DEFAULT 'failed',
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_created ON admin_login_attempts(created_at DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_gateway_payment_id
      ON payments(gateway_payment_id)
      WHERE gateway_payment_id != '';

    CREATE TABLE IF NOT EXISTS branches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      address TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT 'Muradnagar',
      phone TEXT NOT NULL DEFAULT '+91 78-2728-9292',
      email TEXT NOT NULL DEFAULT 'inquiry@yuitor.com',
      timing_note TEXT NOT NULL DEFAULT 'Mon\u2013Sat \xB7 7:00 AM \u2013 8:00 PM',
      map_url TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      room_name TEXT NOT NULL DEFAULT 'Room 101',
      seat_limit INTEGER NOT NULL DEFAULT 40,
      schedule_days TEXT NOT NULL DEFAULT 'Mon\u2013Sat',
      start_time TEXT NOT NULL DEFAULT '16:00',
      end_time TEXT NOT NULL DEFAULT '17:30',
      start_date TEXT NOT NULL DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS timetable_slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE CASCADE,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      day_of_week TEXT NOT NULL DEFAULT 'Monday',
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      subject_name TEXT NOT NULL DEFAULT '',
      room_name TEXT NOT NULL DEFAULT 'Room 101',
      mode TEXT NOT NULL DEFAULT 'offline',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS parent_links (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      relation TEXT NOT NULL DEFAULT 'Parent / Guardian',
      created_at TEXT NOT NULL,
      UNIQUE(parent_user_id, student_user_id)
    );
    CREATE TABLE IF NOT EXISTS parent_teacher_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_role TEXT NOT NULL DEFAULT 'parent',
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS qr_attendance_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      session_date TEXT NOT NULL,
      token_code TEXT NOT NULL UNIQUE,
      expires_at INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS offline_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      batch_id INTEGER REFERENCES batches(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      subject_name TEXT NOT NULL DEFAULT 'All Subjects',
      test_date TEXT NOT NULL,
      max_marks INTEGER NOT NULL DEFAULT 100,
      passing_marks INTEGER NOT NULL DEFAULT 33,
      room_name TEXT NOT NULL DEFAULT 'Exam Hall 1',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS offline_test_marks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL REFERENCES offline_tests(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      marks_obtained REAL NOT NULL DEFAULT 0,
      is_absent INTEGER NOT NULL DEFAULT 0,
      remarks TEXT NOT NULL DEFAULT '',
      rank_position INTEGER,
      graded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(test_id, student_id)
    );
    CREATE TABLE IF NOT EXISTS teacher_leave_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      from_date TEXT NOT NULL,
      to_date TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      admin_note TEXT NOT NULL DEFAULT '',
      reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL,
      reviewed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS fee_installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fee_record_id INTEGER NOT NULL REFERENCES fee_records(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      installment_no INTEGER NOT NULL DEFAULT 1,
      title TEXT NOT NULL,
      amount INTEGER NOT NULL DEFAULT 0,
      paid_amount INTEGER NOT NULL DEFAULT 0,
      due_date TEXT NOT NULL,
      payment_id INTEGER REFERENCES payments(id) ON DELETE SET NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      reminder_sent_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS teacher_payouts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      salary_month TEXT NOT NULL,
      base_amount INTEGER NOT NULL DEFAULT 0,
      bonus_amount INTEGER NOT NULL DEFAULT 0,
      deduction_amount INTEGER NOT NULL DEFAULT 0,
      net_amount INTEGER NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'upi',
      reference_no TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      paid_at TEXT,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Operations',
      amount INTEGER NOT NULL DEFAULT 0,
      expense_date TEXT NOT NULL,
      payment_method TEXT NOT NULL DEFAULT 'upi',
      notes TEXT NOT NULL DEFAULT '',
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS library_books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL DEFAULT 'Study Module',
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      total_copies INTEGER NOT NULL DEFAULT 10,
      available_copies INTEGER NOT NULL DEFAULT 10,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS library_issues (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES library_books(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      issued_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      issued_at TEXT NOT NULL,
      due_return_date TEXT NOT NULL,
      returned_at TEXT,
      status TEXT NOT NULL DEFAULT 'issued',
      remarks TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS toppers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
      student_name TEXT NOT NULL,
      exam_name TEXT NOT NULL,
      rank_label TEXT NOT NULL DEFAULT '',
      score_label TEXT NOT NULL DEFAULT '',
      batch_label TEXT NOT NULL DEFAULT '',
      photo_url TEXT NOT NULL DEFAULT '/assets/images/student-achievement.webp',
      is_featured INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS alert_dispatch_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel TEXT NOT NULL DEFAULT 'sms',
      recipient_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      recipient_name TEXT NOT NULL DEFAULT '',
      recipient_contact TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'announcement',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'logged',
      provider_response TEXT NOT NULL DEFAULT '',
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS mail_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL COLLATE NOCASE UNIQUE,
      display_name TEXT NOT NULL DEFAULT 'Yuitor Smart Classes',
      smtp_host TEXT NOT NULL DEFAULT 'mail.yuitor.com',
      smtp_port INTEGER NOT NULL DEFAULT 465,
      smtp_secure INTEGER NOT NULL DEFAULT 1,
      smtp_user TEXT NOT NULL DEFAULT '',
      imap_host TEXT NOT NULL DEFAULT 'mail.yuitor.com',
      imap_port INTEGER NOT NULL DEFAULT 993,
      imap_secure INTEGER NOT NULL DEFAULT 1,
      imap_user TEXT NOT NULL DEFAULT '',
      password_enc TEXT NOT NULL DEFAULT '',
      is_default INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      last_sync_at TEXT,
      last_uid INTEGER NOT NULL DEFAULT 0,
      last_error TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS mail_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id INTEGER NOT NULL REFERENCES mail_accounts(id) ON DELETE CASCADE,
      folder TEXT NOT NULL DEFAULT 'inbox',
      direction TEXT NOT NULL DEFAULT 'inbound',
      remote_uid INTEGER,
      message_id TEXT NOT NULL DEFAULT '',
      in_reply_to TEXT NOT NULL DEFAULT '',
      from_name TEXT NOT NULL DEFAULT '',
      from_email TEXT NOT NULL DEFAULT '',
      to_emails TEXT NOT NULL DEFAULT '',
      cc_emails TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL DEFAULT '(No Subject)',
      snippet TEXT NOT NULL DEFAULT '',
      text_body TEXT NOT NULL DEFAULT '',
      html_body TEXT NOT NULL DEFAULT '',
      has_attachments INTEGER NOT NULL DEFAULT 0,
      attachments_json TEXT NOT NULL DEFAULT '[]',
      is_read INTEGER NOT NULL DEFAULT 0,
      is_starred INTEGER NOT NULL DEFAULT 0,
      mail_date TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mail_messages_account_folder ON mail_messages(account_id, folder, mail_date DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_mail_messages_uid ON mail_messages(account_id, folder, remote_uid) WHERE remote_uid IS NOT NULL;
  `);
  seedDefaultMailAccounts(db);
}
function seedDefaultMailAccounts(db) {
  const seeded = db.prepare("SELECT value FROM schema_meta WHERE key = 'mail_accounts_seeded_v1'").get();
  if (seeded?.value === "1") return;
  const now = nowIso();
  const defaults = [
    { email: "no-reply@yuitor.com", displayName: "Yuitor Smart Classes (No-Reply)", isDefault: 1 },
    { email: "admission@yuitor.com", displayName: "Yuitor Admissions Desk", isDefault: 0 },
    { email: "info@yuitor.com", displayName: "Yuitor Info Desk", isDefault: 0 },
    { email: "support@yuitor.com", displayName: "Yuitor Student Support", isDefault: 0 }
  ];
  const ins = db.prepare(
    `INSERT OR IGNORE INTO mail_accounts (
      email, display_name, smtp_host, smtp_port, smtp_secure, smtp_user,
      imap_host, imap_port, imap_secure, imap_user, password_enc,
      is_default, is_active, created_at, updated_at
    ) VALUES (?, ?, 'mail.yuitor.com', 465, 1, ?, 'mail.yuitor.com', 993, 1, ?, '', ?, 1, ?, ?)`
  );
  for (const item of defaults) {
    ins.run(item.email, item.displayName, item.email, item.email, item.isDefault, now, now);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('mail_accounts_seeded_v1', '1')").run();
}
function ensureSessionSecret(db) {
  const cur = (process.env.SESSION_SECRET || "").trim();
  if (cur && cur !== "replace-with-64-char-random-hex-secret") {
    return;
  }
  const row = db.prepare("SELECT value FROM system_settings WHERE key = 'SESSION_SECRET'").get();
  if (row?.value && row.value.trim().length >= 16) {
    process.env.SESSION_SECRET = row.value.trim();
    return;
  }
  const generated = crypto2.randomBytes(32).toString("hex");
  db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES ('SESSION_SECRET', ?, 1, ?, NULL)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, is_secret = 1, updated_at = excluded.updated_at`
  ).run(generated, nowIso());
  process.env.SESSION_SECRET = generated;
}
function openHealthySqliteDb(dbPath, backupsDir) {
  const tryOpenAndCheck = (filePath) => {
    const conn = new DatabaseSync(filePath);
    try {
      conn.exec("PRAGMA busy_timeout = 5000;");
      conn.exec("PRAGMA journal_mode = WAL;");
      conn.exec("PRAGMA foreign_keys = ON;");
      const chk = conn.prepare("PRAGMA quick_check;").get();
      const result = Object.values(chk || {})[0];
      if (result !== "ok") {
        throw new Error(`SQLite quick_check failed: ${result}`);
      }
      return conn;
    } catch (err) {
      try {
        conn.close();
      } catch {
        // ignore close error
      }
      throw err;
    }
  };

  try {
    return tryOpenAndCheck(dbPath);
  } catch (err) {
    const msg = String(err?.message || err || "");
    if (!/malformed|corrupt|not a database|quick_check/i.test(msg)) {
      throw err;
    }
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    console.warn(`[Yuitor DB Recovery] Detected malformed SQLite file (${msg}). Quarantining and recovering...`);
    for (const suffix of ["", "-wal", "-shm"]) {
      const f = `${dbPath}${suffix}`;
      if (fs2.existsSync(f)) {
        try {
          fs2.renameSync(f, `${f}.corrupt-${stamp}`);
        } catch {
          try {
            fs2.unlinkSync(f);
          } catch {
            // ignore
          }
        }
      }
    }
    // Attempt restoring latest healthy backup from BACKUPS_DIR if available
    try {
      if (fs2.existsSync(backupsDir)) {
        const candidates = fs2
          .readdirSync(backupsDir)
          .filter((n) => n.endsWith(".db") || n.endsWith(".sqlite"))
          .map((n) => ({ name: n, full: path.join(backupsDir, n), mtime: fs2.statSync(path.join(backupsDir, n)).mtimeMs }))
          .sort((a, b) => b.mtime - a.mtime);
        for (const cand of candidates) {
          try {
            fs2.copyFileSync(cand.full, dbPath);
            const restored = tryOpenAndCheck(dbPath);
            console.warn(`[Yuitor DB Recovery] Restored healthy SQLite backup: ${cand.name}`);
            return restored;
          } catch {
            for (const suffix of ["", "-wal", "-shm"]) {
              try {
                if (fs2.existsSync(`${dbPath}${suffix}`)) fs2.unlinkSync(`${dbPath}${suffix}`);
              } catch {}
            }
          }
        }
      }
    } catch {
      // fall through to clean fresh bootstrap
    }
    console.warn("[Yuitor DB Recovery] Bootstrapping fresh clean SQLite database.");
    return tryOpenAndCheck(dbPath);
  }
}
function getDb() {
  if (dbInstance) return dbInstance;
  fs2.mkdirSync(DATA_DIR, { recursive: true });
  fs2.mkdirSync(BACKUPS_DIR, { recursive: true });
  fs2.mkdirSync(LOGS_DIR, { recursive: true });
  fs2.mkdirSync(UPLOADS_DIR, { recursive: true });
  fs2.mkdirSync(RESUMES_DIR, { recursive: true });
  fs2.mkdirSync(KNOWLEDGE_DIR, { recursive: true });
  const db = openHealthySqliteDb(DB_PATH, BACKUPS_DIR);
  const schemaSql = fs2.readFileSync(MIGRATION_PATH, "utf8");
  db.exec(schemaSql);
  ensureSchemaUpgrades(db);
  hydrateRuntimeSettings(db);
  ensureSessionSecret(db);
  migrateLegacySqliteIfNeeded(db);
  seedDefaultContent(db);
  ensureAddonsSchema(db);
  ensureCrmV25Schema(db);
  ensureStartupBackup(db);
  dbInstance = db;
  return db;
}
function migrateLegacySqliteIfNeeded(db) {
  const migratedFlag = db.prepare("SELECT value FROM schema_meta WHERE key = 'legacy_portal_migrated'").get();
  if (migratedFlag?.value === "1") return;
  if (!fs2.existsSync(LEGACY_DB_PATH)) {
    db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
    return;
  }
  try {
    const legacy = new DatabaseSync(LEGACY_DB_PATH, { readOnly: true });
    const now = nowIso();
    const admins = legacy.prepare("SELECT * FROM admins").all();
    for (const a of admins) {
      const email = normalizeEmail(a.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
           VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', ?, 0, ?, ?, ?, ?)`
        ).run(
          a.display_name || "Admin",
          email,
          normalizePhone(a.phone || "7827289292"),
          a.password_hash,
          Number(a.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          a.last_login_at || null,
          a.created_at || now,
          now
        );
      }
    }
    const students = legacy.prepare("SELECT * FROM students").all();
    for (const s of students) {
      const email = normalizeEmail(s.email);
      if (!email) continue;
      const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
      if (!existing) {
        const vStatus = s.registration_status === "active" || s.registration_status === "completed" ? "approved" : s.registration_status === "inactive" ? "suspended" : "pending_approval";
        const res = db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, last_login_at, created_at, updated_at)
             VALUES ('student', ?, ?, ?, ?, 1, ?, ?, 1, ?, ?, ?, ?)`
        ).run(
          s.full_name || "Student",
          email,
          normalizePhone(s.phone || ""),
          s.password_hash,
          vStatus,
          Number(s.is_active ?? 1),
          crypto2.randomBytes(18).toString("hex"),
          s.last_login_at || null,
          s.created_at || now,
          s.updated_at || now
        );
        const uid = Number(res.lastInsertRowid);
        db.prepare(
          `INSERT OR IGNORE INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, admission_date, enrollment_status)
           VALUES (?, ?, 'CBSE', ?, ?, ?, ?)`
        ).run(
          uid,
          s.class_level ? `Class ${s.class_level}`.replace(/^Class Class /i, "Class ") : "Class 10",
          JSON.stringify(s.selected_subject ? [s.selected_subject] : ["Mathematics", "Science"]),
          Number(s.course_duration_months || 12),
          s.admission_date || null,
          s.registration_status || "active"
        );
      }
    }
    const inqs = legacy.prepare("SELECT * FROM inquiries").all();
    for (const q of inqs) {
      const exists = db.prepare("SELECT id FROM inquiries WHERE name = ? AND phone = ? AND created_at = ?").get(q.name || "", q.phone || "", q.received_at || now);
      if (!exists) {
        const mappedStatus = q.status === "converted" ? "admitted" : ["new", "contacted", "admitted", "closed"].includes(q.status) ? q.status : "new";
        db.prepare(
          `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, created_at)
           VALUES (?, ?, ?, ?, ?, 'legacy_import', ?, ?)`
        ).run(
          q.name || "Visitor",
          q.phone || "",
          q.email || "",
          q.course || "General Inquiry",
          q.message || "",
          mappedStatus,
          q.received_at || now
        );
      }
    }
    const fest = legacy.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    if (fest) {
      db.prepare(
        `INSERT OR REPLACE INTO festival_settings (id, mode, manual_festival_id, simulated_date_ist, overrides_json, updated_at)
         VALUES (1, ?, ?, ?, ?, ?)`
      ).run(
        fest.mode || "automatic",
        fest.manual_festival_id || null,
        fest.simulated_date_ist || null,
        fest.overrides_json || "{}",
        fest.updated_at || now
      );
    }
    legacy.close();
  } catch (err) {
    console.warn("[Yuitor DB] Legacy SQLite migration skipped:", err);
  }
  db.prepare("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('legacy_portal_migrated', '1')").run();
}
function seedDefaultContent(db) {
  const now = nowIso();
  const courseCount = db.prepare("SELECT COUNT(*) as c FROM courses").get().c;
  if (courseCount === 0) {
    const courses = [
      {
        title: "CBSE Board Mastery Batch (Classes 6–12)",
        slug: "cbse-board-mastery",
        category: "Classes 6-12",
        class_range: "Classes 6–12",
        board: "CBSE (NCERT)",
        description: "Line-by-line NCERT + Exemplar coverage, CBSE competency questions, sample papers, and weekly Sunday mocks at affordable Muradnagar fees.",
        duration_months: 12,
        monthly_fee: 800,
        yearly_fee: 8640,
        thumbnail_url: "/assets/images/teacher-classroom-guidance.webp"
      },
      {
        title: "Class 6th\u20138th Foundation Batch",
        slug: "class-6-8-foundation",
        category: "Classes 6-12",
        class_range: "Classes 6\u20138",
        board: "CBSE / ICSE / UP Board",
        description: "Strong conceptual foundation in Mathematics, Science, English, and Social Studies with weekly unit tests and doubt-clearing sessions.",
        duration_months: 12,
        monthly_fee: 650,
        yearly_fee: 7020,
        thumbnail_url: "/assets/images/teacher-led-class.webp"
      },
      {
        title: "Class 9th\u201310th Board Mastery Batch",
        slug: "class-9-10-board-mastery",
        category: "Classes 6-12",
        class_range: "Classes 9\u201310",
        board: "CBSE / UP Board / ICSE",
        description: "Complete NCERT + reference syllabus coverage, board sample papers, practical prep, and personal mentor tracking in Muradnagar.",
        duration_months: 12,
        monthly_fee: 800,
        yearly_fee: 8640,
        thumbnail_url: "/assets/images/math-board.webp"
      },
      {
        title: "Class 11th\u201312th Science & Commerce",
        slug: "class-11-12-board-stream",
        category: "Classes 6-12",
        class_range: "Classes 11\u201312",
        board: "CBSE / UP Board / ICSE",
        description: "In-depth coaching for Physics, Chemistry, Mathematics, Biology, Accountancy, and Economics with full board mock series.",
        duration_months: 12,
        monthly_fee: 900,
        yearly_fee: 9720,
        thumbnail_url: "/assets/images/science-lab.webp"
      },
      {
        title: "NEET UG & JEE Foundation / Target",
        slug: "neet-jee-target",
        category: "Competitive",
        class_range: "Classes 11\u201312 & Dropper",
        board: "NTA / Competitive",
        description: "Structured Physics, Chemistry, Biology & Mathematics coaching with daily DPPs, OMR/CBT mock tests, and error analysis.",
        duration_months: 12,
        monthly_fee: 1800,
        yearly_fee: 18400,
        thumbnail_url: "/assets/images/exam-writing.webp"
      },
      {
        title: "CUET UG Entrance Preparation",
        slug: "cuet-ug-prep",
        category: "Competitive",
        class_range: "Class 12 & Graduates",
        board: "NTA CUET",
        description: "Domain subjects, General Test (Quant & Reasoning), and English Language speed-accuracy drills for top central universities.",
        duration_months: 6,
        monthly_fee: 1200,
        yearly_fee: 6500,
        thumbnail_url: "/assets/images/group-study.webp"
      },
      {
        title: "Computer Courses (DCA, Tally Prime & Web)",
        slug: "computer-dca-tally",
        category: "Computer",
        class_range: "Students & Job Seekers",
        board: "Practical Certification",
        description: "Hands-on training in MS Office, Tally Prime with GST, CCC, HTML/CSS, and practical computer lab sessions.",
        duration_months: 6,
        monthly_fee: 600,
        yearly_fee: 3300,
        thumbnail_url: "/assets/images/computer-class.webp"
      },
      {
        title: "Python & Web Coding Lab",
        slug: "ai-learning-python",
        category: "Coding",
        class_range: "Class 6th to College",
        board: "Applied Tech Track",
        description: "Learn Python programming, HTML/CSS/JavaScript, school Computer Science, and real student mini-projects in our guided lab.",
        duration_months: 6,
        monthly_fee: 900,
        yearly_fee: 4900,
        thumbnail_url: "/assets/images/coding-workshop.webp"
      },
      {
        title: "Spoken English & Communication Skills",
        slug: "spoken-english-fluency",
        category: "English Speaking",
        class_range: "All Age Groups",
        board: "Fluency & Confidence",
        description: "Daily speaking practice, grammar correction, pronunciation drills, group discussions, and interview readiness.",
        duration_months: 4,
        monthly_fee: 600,
        yearly_fee: 2200,
        thumbnail_url: "/assets/images/student-project-presentation.webp"
      }
    ];
    const insertCourse = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, thumbnail_url, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );
    for (const c of courses) {
      insertCourse.run(
        c.title,
        c.slug,
        c.category,
        c.class_range,
        c.board,
        c.description,
        c.duration_months,
        c.monthly_fee,
        c.yearly_fee,
        c.thumbnail_url,
        now
      );
    }
    const firstCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insLesson = db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, '', ?, 35, ?, 1, ?)`
    );
    for (const fc of firstCourses) {
      insLesson.run(fc.id, `Orientation & Syllabus Roadmap \u2014 ${fc.title}`, "text", "Complete chapter weightage, study calendar, and weekly test schedule.", 1, now);
      insLesson.run(fc.id, "Core Concepts & Formula Sheet (Module 1)", "pdf", "Structured concept notes and solved board-level practice questions.", 2, now);
    }
  }
  const subjCount = db.prepare("SELECT COUNT(*) as c FROM subjects").get().c;
  if (subjCount === 0) {
    const subjects = [
      ["Mathematics", "MATH-612", "Classes 6\u201312", "NCERT concept clarity, shortcut methods, and weekly chapter tests for CBSE, ICSE, and UP Board."],
      ["Science (Foundation)", "SCI-610", "Classes 6\u201310", "Integrated Physics, Chemistry, and Biology with visual demonstrations and diagram practice."],
      ["Physics", "PHY-1112", "Classes 11\u201312 / JEE / NEET", "Mechanics, Electrostatics, Optics, and numerical problem solving for Boards and competitive exams."],
      ["Chemistry", "CHEM-1112", "Classes 11\u201312 / JEE / NEET", "Physical, Organic, and Inorganic Chemistry with reaction mechanisms and NCERT line-by-line mastery."],
      ["Biology", "BIO-1112", "Classes 11\u201312 / NEET", "Botany & Zoology diagrams, NCERT assertion-reason drills, and NEET PYQ practice."],
      ["English & Spoken Communication", "ENG-ALL", "Classes 6\u201312 & Spoken", "Reading comprehension, board writing formats, grammar accuracy, and daily speaking fluency."],
      ["Computer Applications & DCA", "COMP-DCA", "Classes 6\u201312 & Skill Track", "MS Office, Tally Prime with GST, Internet tools, and fundamentals of computing."],
      ["AI Learning & Python Coding", "AI-PY", "Classes 6\u201312 & Tech", "Python syntax, logic building, responsible AI tools, and practical project creation."]
    ];
    const insSubj = db.prepare(
      "INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const s of subjects) insSubj.run(s[0], s[1], s[2], s[3], now);
  }
  const faqCount = db.prepare("SELECT COUNT(*) as c FROM faqs").get().c;
  if (faqCount === 0) {
    const faqs = [
      ["Where is Yuitor Smart Classes located?", "Our coaching centre is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India."],
      ["Which classes and boards do you teach?", "We offer coaching for Classes 5th to 12th across CBSE, UP Board, and ICSE, alongside JEE, NEET, CUET, Computer Courses, AI Learning, and Spoken English."],
      ["Can students attend a demo class before admission?", "Yes! You can book a free counselling and demo session by submitting the Admission form or calling +91 78-2728-9292."],
      ["How does portal registration and approval work?", "Students and teachers register online, verify their 6-digit mobile OTP, and then the Yuitor Team reviews and approves the account for portal access."],
      ["What is your refund policy?", "Yuitor offers a transparent 7-day refund policy subject to the published admission and refund terms on our website."]
    ];
    const insFaq = db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, ?, 1, ?)");
    faqs.forEach((f, idx) => insFaq.run(f[0], f[1], idx + 1, now));
  }
  const testCount = db.prepare("SELECT COUNT(*) as c FROM testimonials").get().c;
  if (testCount === 0) {
    const tests = [
      ["Aarav Verma", "Class 10 CBSE Student", "95.4% in Board Exams", "Weekly tests and personal doubt sessions at Yuitor Muradnagar made Mathematics and Science much easier to score high in."],
      ["Ananya Tyagi", "Class 12 Science Student", "94% in Physics & Chemistry", "Small batch sizes meant our teachers checked every answer sheet and guided us step by step before boards."],
      ["Mrs. Sunita Chaudhary", "Parent, Muradnagar", "Consistent Academic Growth", "Regular attendance updates and transparent fee tracking keep parents completely informed throughout the session."]
    ];
    const insTest = db.prepare(
      "INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)"
    );
    for (const t of tests) insTest.run(t[0], t[1], t[2], t[3], now);
  }
  const couponCount = db.prepare("SELECT COUNT(*) as c FROM coupons").get().c;
  if (couponCount === 0) {
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES ('YUITOR10', 'percent', 10, 500, 0, 1, ?)"
    ).run(now);
  }
  const tmplCount = db.prepare("SELECT COUNT(*) as c FROM email_templates").get().c;
  if (tmplCount === 0) {
    const templates = [
      ["New Batch Admission Open", "Admission", "Admissions Open at Yuitor Smart Classes, Muradnagar!", "Limited seats for Classes 6th\u201312th, JEE, NEET & Skills.", "<p>Dear {{name}},</p><p>Admissions are now open for our upcoming batches at <strong>Yuitor Smart Classes, Muradnagar</strong> (Classes 6th\u201312th, JEE/NEET/CUET, Computer, AI Learning &amp; Spoken English).</p><p>Book your counselling or demo session today at Trimurti Vihar, Near Venus Academy.</p>"],
      ["Skill & AI Course Promotion", "Course Promotion", "Upgrade Your Skills: AI Learning, Coding & Spoken English", "Practical weekend & weekday batches in Muradnagar.", "<p>Dear {{name}},</p><p>Build future-ready skills with Yuitor Smart Classes! Join our hands-on batches for <strong>AI Learning &amp; Python Coding</strong>, <strong>DCA + Tally Prime</strong>, and <strong>Spoken English</strong>.</p>"],
      ["Monthly Fee Reminder", "Fee Reminder", "Friendly Fee Schedule Reminder \u2014 Yuitor Smart Classes", "Check your fee status and downloadable receipt in Student Portal.", "<p>Dear {{name}},</p><p>This is a gentle reminder to review your current fee schedule in your Student Portal or at the Muradnagar centre desk. Kindly ignore if already settled.</p>"],
      ["Unit & Board Exam Announcement", "Exam Announcement", "Upcoming Test Series & Exam Schedule \u2014 Yuitor Smart Classes", "Important dates and revision checklist inside.", "<p>Dear {{name}},</p><p>Our upcoming weekly evaluation and mock test schedule has been published. Please review your syllabus notes in the Student Portal and arrive 10 minutes early.</p>"],
      ["Student Important Notice", "Student Notice", "Important Student Notice \u2014 Yuitor Smart Classes", "Batch timing and study material update.", "<p>Dear {{name}},</p><p>Please check your Student Dashboard for the latest batch timing updates and newly uploaded PDF notes from your faculty.</p>"],
      ["Faculty & Teacher Notice", "Teacher Notice", "Faculty Coordination Notice \u2014 Yuitor Smart Classes", "Academic schedule and attendance update reminder.", "<p>Dear {{name}},</p><p>Kindly ensure daily batch attendance and weekly assignment grades are updated in the Teacher Portal before 7:00 PM.</p>"],
      ["Festive Wishes from Yuitor", "Festival", "Warm Festive Wishes from Yuitor Smart Classes!", "Wishing you and your family joy, health, and success.", "<p>Dear {{name}},</p><p>Yuitor Smart Classes wishes you and your family a joyful and prosperous celebration! Keep learning and shining.</p>"],
      ["Yuitor Monthly Newsletter", "Newsletter", "Yuitor Monthly Academic Digest & Study Tips", "Highlights, topper strategies, and upcoming workshops.", "<p>Dear {{name}},</p><p>Here is your monthly summary of upcoming workshops, board preparation strategies, and new study resources at Yuitor Smart Classes, Muradnagar.</p>"],
      ["Special Workshop & Occasion", "Special Occasion", "Special Career & Scholarship Seminar \u2014 Yuitor Muradnagar", "Reserve your seat for our weekend seminar.", "<p>Dear {{name}},</p><p>You are invited to our upcoming Career Guidance &amp; Scholarship Evaluation Session at Yuitor Smart Classes, Trimurti Vihar, Muradnagar.</p>"]
    ];
    const insTmpl = db.prepare(
      "INSERT INTO email_templates (name, category, subject, preview_text, html_body, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const t of templates) insTmpl.run(t[0], t[1], t[2], t[3], t[4], now);
  }
  const branchCount = db.prepare("SELECT COUNT(*) as c FROM branches").get().c;
  if (branchCount === 0) {
    db.prepare(
      `INSERT INTO branches (name, code, address, city, phone, email, timing_note, map_url, is_active, created_at)
       VALUES (?, 'MRD-01', ?, 'Muradnagar', '+91 78-2728-9292', 'inquiry@yuitor.com', 'Mon\u2013Sat \xB7 7:00 AM \u2013 8:00 PM', 'https://maps.google.com/?q=Trimurti+Vihar+Muradnagar+201206', 1, ?)`
    ).run("Muradnagar Main Centre", "Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh", now);
  }
  const mainBranch = db.prepare("SELECT id FROM branches ORDER BY id ASC LIMIT 1").get();
  if (mainBranch) {
    db.prepare("UPDATE courses SET branch_id = ? WHERE branch_id IS NULL").run(mainBranch.id);
    db.prepare("UPDATE student_profiles SET branch_id = ? WHERE branch_id IS NULL").run(mainBranch.id);
  }
  const missingRolls = db.prepare("SELECT user_id FROM student_profiles WHERE COALESCE(roll_number, '') = ''").all();
  const updRoll = db.prepare("UPDATE student_profiles SET roll_number = ? WHERE user_id = ?");
  for (const r of missingRolls) {
    updRoll.run(`YTR-STU-${String(r.user_id).padStart(4, "0")}`, r.user_id);
  }
  const batchCount = db.prepare("SELECT COUNT(*) as c FROM batches").get().c;
  if (batchCount === 0 && mainBranch) {
    const sampleCourses = db.prepare("SELECT id, title FROM courses ORDER BY id ASC LIMIT 4").all();
    const insBatch = db.prepare(
      `INSERT INTO batches (course_id, branch_id, name, code, room_name, seat_limit, schedule_days, start_time, end_time, start_date, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, 40, 'Mon\u2013Sat', ?, ?, ?, 1, ?)`
    );
    const timings = [
      ["Room 101", "15:30", "17:00"],
      ["Room 102", "17:00", "18:30"],
      ["Hall A", "16:00", "18:00"],
      ["Lab 1", "18:00", "19:30"]
    ];
    sampleCourses.forEach((c, idx) => {
      const [room, st, et] = timings[idx % timings.length];
      insBatch.run(c.id, mainBranch.id, `${c.title} \u2014 Batch A`, `YTR-B${c.id}A`, room, st, et, now.slice(0, 10), now);
    });
  }
  const topperCount = db.prepare("SELECT COUNT(*) as c FROM toppers").get().c;
  if (topperCount === 0) {
    const defaultToppers = [
      ["Anjali Yadav", "NEET 2025", "AIR 842", "680/720", "NEET Batch 2023-25", "/assets/images/student-medical-future.webp"],
      ["Mohit Kumar", "JEE Mains 2025", "99.2 Percentile", "285/300", "JEE Batch 2024-25", "/assets/images/engineering-aspirant.webp"],
      ["Priya Singh", "Class 12 CBSE", "School Topper", "98.2%", "Class 12 2024-25", "/assets/images/students-group.webp"],
      ["Arjun Sharma", "Class 10 UP Board", "District 2nd", "95.4%", "Class 10 2024-25", "/assets/images/happy-students.webp"],
      ["Nisha Gupta", "NEET 2024", "AIR 1240", "660/720", "NEET Batch 2022-24", "/assets/images/student-achievement.webp"],
      ["Rahul Tiwari", "JEE Advanced 2025", "AIR 3840", "Qualified", "JEE Batch 2023-25", "/assets/images/math-board.webp"]
    ];
    const insTop = db.prepare(
      `INSERT INTO toppers (branch_id, student_name, exam_name, rank_label, score_label, batch_label, photo_url, is_featured, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    );
    defaultToppers.forEach((t, idx) => {
      insTop.run(mainBranch?.id || null, t[0], t[1], t[2], t[3], t[4], t[5], idx + 1, now);
    });
  }
}
function verifyBackupIntegrity(backupPath) {
  let checkDb = null;
  try {
    checkDb = new DatabaseSync(backupPath, { readOnly: true });
    const row = checkDb.prepare("PRAGMA quick_check").get();
    const result = row ? Object.values(row)[0] : "";
    return { ok: result === "ok", detail: result || "unknown" };
  } catch (err) {
    return { ok: false, detail: err?.message || "Integrity check failed" };
  } finally {
    try {
      checkDb?.close();
    } catch {
    }
  }
}
function createDatabaseBackup(db, label = "manual") {
  fs2.mkdirSync(BACKUPS_DIR, { recursive: true });
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const safeLabel = label.replace(/[^a-z0-9_-]/gi, "").slice(0, 20) || "backup";
  const filename = `yuitor-${safeLabel}-${stamp}.db`;
  const dest = path.join(BACKUPS_DIR, filename);
  const escaped = dest.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}';`);
  const stat = fs2.statSync(dest);
  const integrity = verifyBackupIntegrity(dest);
  return { filename, sizeBytes: stat.size, createdAt: nowIso(), integrityOk: integrity.ok };
}
function ensureStartupBackup(db) {
  try {
    const files = fs2.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db"));
    if (files.length === 0) {
      createDatabaseBackup(db, "startup");
    }
  } catch (err) {
    console.warn("[Yuitor DB] Startup backup warning:", err);
  }
}

// server/mailer.ts
import nodemailer2 from "nodemailer";
import path3 from "node:path";
import fs4 from "node:fs";

// server/mail-hub.ts
import crypto3 from "node:crypto";
import fs3 from "node:fs";
import path2 from "node:path";
import nodemailer from "nodemailer";
import { ImapFlow } from "imapflow";
import { simpleParser } from "mailparser";
var VAULT_KEY_PATH = path2.join(DATA_DIR, ".mail-vault.key");
var cachedVaultKey = null;
var syncLoopRunning = false;
function getMailVaultKey() {
  const envRaw = (process.env.MAIL_VAULT_KEY || "").trim();
  if (envRaw) {
    if (/^[a-f0-9]{64}$/i.test(envRaw)) {
      return Buffer.from(envRaw, "hex");
    }
    return crypto3.createHash("sha256").update(envRaw).digest();
  }
  if (cachedVaultKey) return cachedVaultKey;
  fs3.mkdirSync(DATA_DIR, { recursive: true });
  if (fs3.existsSync(VAULT_KEY_PATH)) {
    const hex = fs3.readFileSync(VAULT_KEY_PATH, "utf8").trim();
    if (/^[a-f0-9]{64}$/i.test(hex)) {
      cachedVaultKey = Buffer.from(hex, "hex");
      return cachedVaultKey;
    }
  }
  const key = crypto3.randomBytes(32);
  fs3.writeFileSync(VAULT_KEY_PATH, key.toString("hex"), { mode: 384 });
  cachedVaultKey = key;
  return key;
}
function sanitizeEmailHtml(rawHtml) {
  let html = String(rawHtml || "");
  if (!html) return "";
  html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "").replace(/<(?:object|embed|applet|form|meta|link|base)\b[^>]*>[\s\S]*?<\/(?:object|embed|applet|form)>/gi, "").replace(/<(?:object|embed|applet|form|meta|link|base)\b[^>]*\/?>/gi, "").replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "").replace(/\b(href|src|action)\s*=\s*(["'])\s*(?:javascript|vbscript|data:text\/html)[^"']*\2/gi, '$1="#"');
  return html.slice(0, 25e4);
}
function getMailboxPassword(row) {
  if (!row?.password_enc) return "";
  return decryptVaultSecret(row.password_enc, getMailVaultKey());
}
function encryptMailboxPassword(plainPassword) {
  const clean = String(plainPassword || "");
  if (!clean) return "";
  return encryptVaultSecret(clean, getMailVaultKey());
}
function toSafeMailAccount(db, row) {
  const stats = db.prepare(
    `SELECT
         SUM(CASE WHEN folder = 'inbox' THEN 1 ELSE 0 END) as inbox_c,
         SUM(CASE WHEN folder = 'inbox' AND is_read = 0 THEN 1 ELSE 0 END) as unread_c,
         SUM(CASE WHEN folder = 'sent' THEN 1 ELSE 0 END) as sent_c
       FROM mail_messages WHERE account_id = ?`
  ).get(row.id);
  return {
    id: Number(row.id),
    email: row.email,
    displayName: row.display_name,
    smtpHost: row.smtp_host,
    smtpPort: Number(row.smtp_port || 465),
    smtpSecure: Number(row.smtp_secure) === 1,
    smtpUser: row.smtp_user || row.email,
    imapHost: row.imap_host,
    imapPort: Number(row.imap_port || 993),
    imapSecure: Number(row.imap_secure) === 1,
    imapUser: row.imap_user || row.email,
    hasPassword: Boolean(row.password_enc && getMailboxPassword(row)),
    isDefault: Number(row.is_default) === 1,
    isActive: Number(row.is_active) === 1,
    lastSyncAt: row.last_sync_at || null,
    lastUid: Number(row.last_uid || 0),
    lastError: row.last_error || "",
    unreadCount: Number(stats?.unread_c || 0),
    inboxCount: Number(stats?.inbox_c || 0),
    sentCount: Number(stats?.sent_c || 0)
  };
}
function getDefaultMailAccountWithSecret(db) {
  const rows = db.prepare(
    `SELECT * FROM mail_accounts
       WHERE is_active = 1 AND password_enc != ''
       ORDER BY is_default DESC, id ASC`
  ).all();
  for (const row of rows) {
    const pass = getMailboxPassword(row);
    if (pass && row.smtp_host) {
      return { account: row, password: pass };
    }
  }
  return null;
}
function createMailboxSmtpTransport(row, password) {
  const port = Number(row.smtp_port || 465);
  const secure = port === 465 ? true : port === 587 ? false : Number(row.smtp_secure) === 1;
  return nodemailer.createTransport({
    host: row.smtp_host || "mail.yuitor.com",
    port,
    secure,
    auth: {
      user: (row.smtp_user || row.email).trim(),
      pass: password
    },
    connectionTimeout: 12e3,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}
function createImapClient(row, password) {
  const port = Number(row.imap_port || 993);
  const secure = port === 993 ? true : port === 143 ? false : Number(row.imap_secure) === 1;
  return new ImapFlow({
    host: row.imap_host || row.smtp_host || "mail.yuitor.com",
    port,
    secure,
    auth: {
      user: (row.imap_user || row.smtp_user || row.email).trim(),
      pass: password
    },
    logger: false,
    connectionTimeout: 12e3,
    greetingTimeout: 1e4
  });
}
async function testMailboxConnection(db, accountId) {
  const row = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(accountId);
  if (!row) {
    return {
      ok: false,
      smtp: { ok: false, detail: "Mailbox not found." },
      imap: { ok: false, detail: "Mailbox not found." }
    };
  }
  const pass = getMailboxPassword(row);
  if (!pass) {
    return {
      ok: false,
      smtp: { ok: false, detail: "Mailbox password is not set yet. Save password first." },
      imap: { ok: false, detail: "Mailbox password is not set yet. Save password first." }
    };
  }
  let smtpRes = { ok: false, detail: "Not tested" };
  try {
    const transporter = createMailboxSmtpTransport(row, pass);
    await transporter.verify();
    smtpRes = { ok: true, detail: `SMTP connected (${row.smtp_host}:${row.smtp_port})` };
  } catch (err) {
    smtpRes = { ok: false, detail: cleanText(err?.message || "SMTP connection failed", 240) };
  }
  let imapRes = { ok: false, detail: "Not tested" };
  const client = createImapClient(row, pass);
  try {
    await client.connect();
    const mailbox = await client.mailboxOpen("INBOX", { readOnly: true });
    const count = Number(mailbox?.exists || 0);
    imapRes = {
      ok: true,
      detail: `IMAP connected (${row.imap_host}:${row.imap_port}) \xB7 ${count} message(s) in INBOX`,
      messagesInInbox: count
    };
    await client.logout().catch(() => void 0);
  } catch (err) {
    imapRes = { ok: false, detail: cleanText(err?.message || "IMAP connection failed", 240) };
    try {
      client.close();
    } catch {
    }
  }
  const allOk = smtpRes.ok && imapRes.ok;
  db.prepare("UPDATE mail_accounts SET last_error = ?, updated_at = ? WHERE id = ?").run(
    allOk ? "" : [smtpRes.ok ? "" : `SMTP: ${smtpRes.detail}`, imapRes.ok ? "" : `IMAP: ${imapRes.detail}`].filter(Boolean).join(" | "),
    nowIso(),
    row.id
  );
  return { ok: allOk, smtp: smtpRes, imap: imapRes };
}
function formatAddressList(addrObj) {
  if (!addrObj) return "";
  const list = Array.isArray(addrObj) ? addrObj : addrObj.value;
  if (!Array.isArray(list)) return cleanText(addrObj.text || "", 400);
  return list.map((x) => x?.address ? x.name ? `${x.name} <${x.address}>` : x.address : "").filter(Boolean).join(", ");
}
async function syncMailboxInbox(db, accountId, limit = 40) {
  const row = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(accountId);
  if (!row || Number(row.is_active) !== 1) {
    return { ok: false, imported: 0, error: "Mailbox inactive or not found." };
  }
  const pass = getMailboxPassword(row);
  if (!pass) {
    return { ok: false, imported: 0, error: "Password not configured for this mailbox." };
  }
  const client = createImapClient(row, pass);
  let imported = 0;
  let maxUid = Number(row.last_uid || 0);
  try {
    await client.connect();
    const lock = await client.getMailboxLock("INBOX");
    try {
      const uids = await client.search({ seen: void 0 }, { uid: true }).catch(async () => {
        return client.search({ all: true }, { uid: true });
      });
      const allUids = Array.isArray(uids) ? uids.map(Number).filter((n) => n > 0).sort((a, b) => a - b) : [];
      const freshUids = row.last_uid > 0 ? allUids.filter((u) => u > Number(row.last_uid)).slice(-limit) : allUids.slice(-limit);
      if (freshUids.length > 0) {
        const range = freshUids.join(",");
        const insertStmt = db.prepare(
          `INSERT OR IGNORE INTO mail_messages (
            account_id, folder, direction, remote_uid, message_id, in_reply_to,
            from_name, from_email, to_emails, cc_emails, subject, snippet,
            text_body, html_body, has_attachments, attachments_json,
            is_read, is_starred, mail_date, created_at
          ) VALUES (?, 'inbox', 'inbound', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`
        );
        for await (const msg of client.fetch(range, { uid: true, flags: true, source: true }, { uid: true })) {
          const uid = Number(msg.uid || 0);
          if (uid > maxUid) maxUid = uid;
          if (!msg.source) continue;
          const parsed = await simpleParser(msg.source);
          const fromFirst = parsed.from?.value?.[0];
          const fromEmail = normalizeEmail(fromFirst?.address || "");
          const fromName = cleanText(fromFirst?.name || fromEmail || "Unknown Sender", 160);
          const toEmails = cleanText(formatAddressList(parsed.to) || row.email, 500);
          const ccEmails = cleanText(formatAddressList(parsed.cc), 500);
          const subject = cleanText(parsed.subject || "(No Subject)", 300) || "(No Subject)";
          const textBody = cleanText(parsed.text || "", 6e4);
          const rawHtml = typeof parsed.html === "string" ? parsed.html : "";
          const htmlBody = rawHtml ? sanitizeEmailHtml(rawHtml) : `<pre style="white-space:pre-wrap;font-family:inherit;">${escapeHtml(textBody)}</pre>`;
          const snippet = cleanText((textBody || rawHtml.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " "), 200);
          const attachmentsMeta = (parsed.attachments || []).map((att) => ({
            filename: cleanText(att.filename || "attachment", 120),
            contentType: cleanText(att.contentType || "application/octet-stream", 80),
            size: Number(att.size || 0)
          }));
          const isRead = msg.flags && typeof msg.flags.has === "function" && msg.flags.has("\\Seen") ? 1 : 0;
          const mailDate = parsed.date instanceof Date && !Number.isNaN(parsed.date.getTime()) ? parsed.date.toISOString() : nowIso();
          const res = insertStmt.run(
            row.id,
            uid,
            cleanText(parsed.messageId || "", 240),
            cleanText(typeof parsed.inReplyTo === "string" ? parsed.inReplyTo : "", 240),
            fromName,
            fromEmail,
            toEmails,
            ccEmails,
            subject,
            snippet,
            textBody,
            htmlBody,
            attachmentsMeta.length > 0 ? 1 : 0,
            JSON.stringify(attachmentsMeta),
            isRead,
            mailDate,
            nowIso()
          );
          if (Number(res.changes || 0) > 0) imported++;
        }
      }
    } finally {
      lock.release();
    }
    await client.logout().catch(() => void 0);
    db.prepare(
      "UPDATE mail_accounts SET last_sync_at = ?, last_uid = ?, last_error = '', updated_at = ? WHERE id = ?"
    ).run(nowIso(), maxUid, nowIso(), row.id);
    return { ok: true, imported };
  } catch (err) {
    const errMsg = cleanText(err?.message || "IMAP sync error", 240);
    db.prepare("UPDATE mail_accounts SET last_error = ?, updated_at = ? WHERE id = ?").run(errMsg, nowIso(), row.id);
    try {
      client.close();
    } catch {
    }
    return { ok: false, imported, error: errMsg };
  }
}
async function syncAllActiveMailboxes(db) {
  const rows = db.prepare("SELECT id, email, password_enc FROM mail_accounts WHERE is_active = 1 AND password_enc != '' ORDER BY is_default DESC, id ASC").all();
  const results = [];
  for (const r of rows) {
    if (!getMailboxPassword(r)) continue;
    const syncRes = await syncMailboxInbox(db, Number(r.id), 35);
    results.push({ id: Number(r.id), email: r.email, ...syncRes });
  }
  return results;
}
function startMailSyncScheduler(db) {
  setInterval(async () => {
    if (syncLoopRunning) return;
    syncLoopRunning = true;
    try {
      await syncAllActiveMailboxes(db);
    } catch (err) {
      console.warn("[Yuitor MailHub] Background IMAP sync warning:", err);
    } finally {
      syncLoopRunning = false;
    }
  }, 18e4);
}
async function sendFromMailbox(db, opts) {
  let account;
  if (opts.accountId && Number(opts.accountId) > 0) {
    account = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(Number(opts.accountId));
  } else {
    account = db.prepare("SELECT * FROM mail_accounts WHERE is_active = 1 AND password_enc != '' ORDER BY is_default DESC, id ASC LIMIT 1").get();
  }
  if (!account) {
    return { ok: false, error: "Selected mailbox not found or inactive." };
  }
  const pass = getMailboxPassword(account);
  if (!pass) {
    return {
      ok: false,
      error: `Password is not set for ${account.email}. Open Admin \u2192 Mail \u2192 Mailboxes Setup to enter password.`
    };
  }
  try {
    const transporter = createMailboxSmtpTransport(account, pass);
    const plainText = (opts.text || "").trim() || String(opts.html || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    const rawHtml = (opts.html || "").trim() || `<div style="font-family:system-ui,sans-serif;line-height:1.6;">${escapeHtml(plainText).replace(/\n/g, "<br>")}</div>`;
    const safeHtml = sanitizeEmailHtml(rawHtml);
    const info = await transporter.sendMail({
      from: `"${account.display_name || "Yuitor Smart Classes"}" <${account.email}>`,
      replyTo: opts.replyTo || account.email,
      to: opts.to,
      cc: opts.cc || void 0,
      subject: opts.subject,
      text: plainText,
      html: rawHtml,
      inReplyTo: opts.inReplyTo || void 0,
      attachments: (opts.attachments || []).map((a) => ({
        filename: a.filename,
        content: a.content,
        contentType: a.contentType
      }))
    });
    const msgId = cleanText(info.messageId || `sent-${Date.now()}`, 240);
    const now = nowIso();
    const snippet = cleanText(plainText.replace(/\s+/g, " "), 200);
    const attMeta = (opts.attachments || []).map((a) => ({
      filename: a.filename,
      contentType: a.contentType || "application/octet-stream",
      size: a.content.length
    }));
    const ins = db.prepare(
      `INSERT INTO mail_messages (
          account_id, folder, direction, remote_uid, message_id, in_reply_to,
          from_name, from_email, to_emails, cc_emails, subject, snippet,
          text_body, html_body, has_attachments, attachments_json,
          is_read, is_starred, mail_date, created_at
        ) VALUES (?, 'sent', 'outbound', NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)`
    ).run(
      account.id,
      msgId,
      cleanText(opts.inReplyTo || "", 240),
      account.display_name || "Yuitor Smart Classes",
      account.email,
      cleanText(opts.to, 500),
      cleanText(opts.cc || "", 500),
      cleanText(opts.subject, 300),
      snippet,
      cleanText(plainText, 6e4),
      safeHtml,
      attMeta.length > 0 ? 1 : 0,
      JSON.stringify(attMeta),
      now,
      now
    );
    return {
      ok: true,
      messageId: msgId,
      savedId: Number(ins.lastInsertRowid),
      fromEmail: account.email
    };
  } catch (err) {
    const errMsg = cleanText(err?.message || "SMTP delivery failed", 240);
    db.prepare("UPDATE mail_accounts SET last_error = ?, updated_at = ? WHERE id = ?").run(
      `Send failed: ${errMsg}`,
      nowIso(),
      account.id
    );
    return { ok: false, error: errMsg };
  }
}

// server/mailer.ts
var mailerDbRef = null;
function registerMailerDb(db) {
  mailerDbRef = db;
}
function isEnvSmtpConfigured() {
  const host = (process.env.SMTP_HOST || "").trim();
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").trim();
  return Boolean(host && host !== "smtp.example.com" && user && pass && !pass.startsWith("replace-with"));
}
function getFallbackMailbox() {
  if (!mailerDbRef) return null;
  try {
    return getDefaultMailAccountWithSecret(mailerDbRef);
  } catch {
    return null;
  }
}
var getSenderName = () => {
  const envName = (process.env.MAIL_FROM_NAME || "").trim();
  if (envName) return envName;
  if (!isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb?.account.display_name) return fb.account.display_name;
  }
  return "Yuitor Smart Classes";
};
var getSenderEmail = () => {
  const envEmail = (process.env.MAIL_FROM_EMAIL || "").trim();
  const smtpUser = (process.env.SMTP_USER || "").trim();
  if (isEnvSmtpConfigured()) {
    if (envEmail && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(envEmail)) return envEmail;
    if (smtpUser && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(smtpUser)) return smtpUser;
    return envEmail || smtpUser || "no-reply@yuitor.com";
  }
  const fb = getFallbackMailbox();
  if (fb?.account?.email) return fb.account.email;
  return envEmail || smtpUser || "no-reply@yuitor.com";
};
var getReplyToEmail = (department) => {
  if (department) {
    const deptMap = getDepartmentEmails();
    if (deptMap[department]) return deptMap[department];
  }
  return (process.env.REPLY_TO_EMAIL || "").trim() || getDepartmentEmails().inquiry || "inquiry@yuitor.com";
};
var getAdminNotifyEmail = () => (process.env.ADMIN_NOTIFY_EMAIL || "").trim() || getDepartmentEmails().admission || "admission@yuitor.com";
var SENDER_NAME = getSenderName();
var SENDER_EMAIL = getSenderEmail();
var REPLY_TO_EMAIL = getReplyToEmail();
var ADMIN_NOTIFY_EMAIL = getAdminNotifyEmail();
function isSmtpConfigured() {
  if (isEnvSmtpConfigured()) return true;
  return Boolean(getFallbackMailbox());
}
function resolveSmtpSecure(port, secureRaw) {
  if (port === 465) return true;
  if (port === 587) return false;
  if (typeof secureRaw === "boolean") return secureRaw;
  const norm = String(secureRaw ?? "").trim().toLowerCase();
  return norm === "true" || norm === "1";
}
function getTransporter(smtpOverride) {
  if (smtpOverride) {
    const port2 = Number(smtpOverride.port || 465);
    const secure2 = resolveSmtpSecure(port2, smtpOverride.secure);
    return nodemailer2.createTransport({
      host: smtpOverride.host.trim(),
      port: port2,
      secure: secure2,
      auth: { user: smtpOverride.user.trim(), pass: smtpOverride.pass },
      connectionTimeout: 12e3,
      greetingTimeout: 1e4,
      socketTimeout: 15e3
    });
  }
  if (!isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb) {
      return createMailboxSmtpTransport(fb.account, fb.password);
    }
  }
  const host = (process.env.SMTP_HOST || "").trim();
  const port = Number(process.env.SMTP_PORT || 465);
  const secure = resolveSmtpSecure(port, process.env.SMTP_SECURE);
  const user = (process.env.SMTP_USER || "").trim();
  const pass = process.env.SMTP_PASS || "";
  return nodemailer2.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    connectionTimeout: 12e3,
    greetingTimeout: 1e4,
    socketTimeout: 15e3
  });
}
function getPublicSiteUrl(preferredOrigin) {
  const candidates = [preferredOrigin, process.env.APP_URL, process.env.SITE_URL, process.env.PUBLIC_URL, "https://yuitor.com"];
  for (const raw of candidates) {
    const val = String(raw || "").trim().replace(/\/+$/, "");
    if (!val || /^MY_APP_URL$/i.test(val)) continue;
    if (/^https?:\/\/[a-z0-9.-]+(?::\d+)?(?:\/.*)?$/i.test(val)) {
      return val;
    }
  }
  return "https://yuitor.com";
}
function renderBrandedEmailHtml(opts) {
  const siteUrl = getPublicSiteUrl(opts.siteUrl);
  const logoUrl = `${siteUrl}/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png`;
  const personalized = opts.htmlBody.replace(/\{\{\s*name\s*\}\}/gi, escapeHtml(opts.recipientName || "Student"));
  const ctaBlock = opts.ctaLabel && opts.ctaUrl ? `<p style="margin:24px 0;"><a href="${escapeHtml(opts.ctaUrl)}" style="display:inline-block;background:#1677ff;color:#ffffff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:10px;">${escapeHtml(opts.ctaLabel)}</a></p>` : "";
  const unsubBlock = opts.unsubscribeUrl ? `<p style="margin-top:16px;font-size:12px;color:#64748b;">Prefer not to receive promotional updates? <a href="${escapeHtml(opts.unsubscribeUrl)}" style="color:#0f54c4;">Manage email preferences / Unsubscribe</a></p>` : "";
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(opts.subject)}</title></head>
<body style="margin:0;padding:0;background:#f6f8fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
  ${opts.previewText ? `<div style="display:none;max-height:0;overflow:hidden;">${escapeHtml(opts.previewText)}</div>` : ""}
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;">
        <tr><td style="background:#0f172a;padding:20px 24px;color:#ffffff;">
          <table role="presentation" width="100%"><tr>
            <td><strong style="font-size:18px;letter-spacing:-0.01em;">Yuitor Smart Classes</strong><div style="font-size:12px;color:#78d3d3;margin-top:2px;">Muradnagar, Ghaziabad \xB7 Classes 6th\u201312th, JEE, NEET &amp; Skills</div></td>
            <td align="right"><div style="display:inline-block;background:#ffffff;padding:4px;border-radius:10px;"><img src="${escapeHtml(logoUrl)}" alt="Yuitor Smart Classes" width="42" height="42" style="border-radius:6px;display:block;object-fit:contain;"></div></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:26px 24px;font-size:15px;line-height:1.65;">
          ${personalized}
          ${ctaBlock}
          <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
            <strong>Yuitor Smart Classes</strong><br>
            Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh<br>
            Call / WhatsApp: <a href="tel:+917827289292" style="color:#0f54c4;">+91 78-2728-9292</a> \xB7 <a href="${siteUrl}/admission" style="color:#0f54c4;">Apply for Admission</a>
            ${unsubBlock}
          </div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
async function sendEmailDirect(opts) {
  if (!opts.smtpOverride && !isSmtpConfigured()) {
    return { ok: false, sent: false, error: "SMTP credentials (SMTP_HOST, SMTP_USER, SMTP_PASS) or a default Mail Account are not configured on the server." };
  }
  const attachments = [];
  if (opts.attachmentUrl && opts.attachmentUrl.startsWith("/uploads/")) {
    const safeName = path3.basename(opts.attachmentUrl);
    const fullPath = path3.join(UPLOADS_DIR, safeName);
    if (fs4.existsSync(fullPath)) {
      attachments.push({ filename: safeName, path: fullPath });
    }
  }
  const plainText = opts.text || opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  const replyTo = opts.replyTo || getReplyToEmail(opts.department);
  const trySend = async (transporter, fromName, fromEmail) => {
    const info = await transporter.sendMail({
      from: `"${fromName}" <${fromEmail}>`,
      replyTo,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: plainText,
      attachments
    });
    return { ok: true, sent: true, messageId: info.messageId || "sent" };
  };
  const fromName = opts.smtpOverride?.fromName || getSenderName();
  const fromEmail = opts.smtpOverride?.fromEmail || opts.smtpOverride?.user || getSenderEmail();
  let primaryErr = null;
  try {
    const transporter = getTransporter(opts.smtpOverride);
    return await trySend(transporter, fromName, fromEmail);
  } catch (err) {
    primaryErr = err;
  }
  // Automatic retry 1: If SMTP rejected custom MAIL_FROM_EMAIL (553/550), retry using authenticated SMTP_USER as From address
  const smtpUser = (opts.smtpOverride?.user || process.env.SMTP_USER || "").trim();
  if (smtpUser && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(smtpUser) && smtpUser.toLowerCase() !== String(fromEmail || "").toLowerCase()) {
    try {
      const transporter = getTransporter(opts.smtpOverride);
      return await trySend(transporter, fromName, smtpUser);
    } catch (retryErr) {
      primaryErr = retryErr;
    }
  }
  // Automatic retry 2: If env SMTP failed and a default Admin Mail Account exists, fall back to that mailbox transport
  if (!opts.smtpOverride && isEnvSmtpConfigured()) {
    const fb = getFallbackMailbox();
    if (fb?.account?.email && fb?.password) {
      try {
        const fbTransport = createMailboxSmtpTransport(fb.account, fb.password);
        return await trySend(fbTransport, fb.account.display_name || fromName, fb.account.email);
      } catch (fbErr) {
        primaryErr = fbErr;
      }
    }
  }
  return { ok: false, sent: false, error: primaryErr?.message || "SMTP delivery failed." };
}
async function sendTransactionalEmail(opts) {
  if (!opts.smtpOverride && !isSmtpConfigured() || !opts.to) {
    return { ok: false, sent: false, error: "SMTP not configured or recipient missing." };
  }
  const html = renderBrandedEmailHtml({
    subject: opts.subject,
    previewText: opts.previewText,
    htmlBody: opts.htmlBody,
    recipientName: opts.recipientName,
    ctaLabel: opts.ctaLabel,
    ctaUrl: opts.ctaUrl
  });
  const res = await sendEmailDirect({
    to: opts.to,
    subject: opts.subject,
    html,
    department: opts.department,
    replyTo: opts.replyTo,
    smtpOverride: opts.smtpOverride
  });
  if (!res.ok) {
    console.warn(`[Yuitor Mailer] Transactional email to ${opts.to} (${opts.subject}) failed: ${res.error}`);
    return { ok: false, sent: false, error: res.error };
  }
  return { ok: true, sent: true, messageId: res.messageId };
}
async function testSmtpConnection(testRecipient) {
  if (!isSmtpConfigured()) {
    return { ok: false, error: "SMTP_HOST, SMTP_USER, and SMTP_PASS must be configured before testing SMTP." };
  }
  try {
    const transporter = getTransporter();
    await transporter.verify();
    if (testRecipient && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(testRecipient.trim())) {
      const testHtml = renderBrandedEmailHtml({
        subject: "Yuitor Smart Classes \u2014 SMTP Test Successful",
        previewText: "SMTP verification confirmation from Yuitor Smart Classes.",
        recipientName: "Administrator",
        htmlBody: "<p>Your SMTP configuration for <strong>Yuitor Smart Classes</strong> is verified and working properly.</p>"
      });
      const info = await transporter.sendMail({
        from: `"${getSenderName()}" <${getSenderEmail()}>`,
        replyTo: getReplyToEmail(),
        to: testRecipient.trim(),
        subject: "Yuitor Smart Classes \u2014 SMTP Test Successful",
        html: testHtml,
        text: "Your SMTP configuration for Yuitor Smart Classes is verified and working properly."
      });
      return { ok: true, message: `SMTP verified & test email sent (Message ID: ${info.messageId || "ok"}).` };
    }
    return { ok: true, message: "SMTP connection & authentication verified successfully." };
  } catch (err) {
    return { ok: false, error: err?.message || "SMTP verification failed." };
  }
}
function buildFast2SmsPayload(phone, otp, purposeLabel) {
  const route = (process.env.FAST2SMS_ROUTE || "q").trim().toLowerCase() || "q";
  const senderId = (process.env.FAST2SMS_SENDER_ID || "").trim();
  const dltTemplateId = (process.env.FAST2SMS_DLT_TEMPLATE_ID || "").trim();
  if (route === "dlt") {
    const payload = {
      route: "dlt",
      message: dltTemplateId || `Your Yuitor Smart Classes ${purposeLabel} OTP is ${otp}. Valid for 10 minutes. Do not share it with anyone.`,
      variables_values: otp,
      flash: 0,
      numbers: phone
    };
    if (senderId) payload.sender_id = senderId;
    return payload;
  }
  if (route === "otp") {
    return {
      route: "otp",
      variables_values: otp,
      flash: 0,
      numbers: phone
    };
  }
  return {
    route: "q",
    message: `Your Yuitor Smart Classes ${purposeLabel} OTP is ${otp}. Valid for 10 minutes. Do not share it with anyone.`,
    language: "english",
    flash: 0,
    numbers: phone
  };
}
async function dispatchSmsOtp(phone, otp, purposeLabel) {
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return {
      sent: false,
      note: `SMS gateway (FAST2SMS_API_KEY) is not configured in Admin \u2192 Settings & API. A secure time-limited ${purposeLabel} OTP was generated on the server, but SMS delivery is disabled until FAST2SMS_API_KEY is configured.`
    };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/bulkV2", {
      method: "POST",
      headers: {
        authorization: fast2smsKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(buildFast2SmsPayload(phone, otp, purposeLabel)),
      signal: AbortSignal.timeout(1e4)
    });
    const data = await resp.json();
    if (resp.ok && data?.return === true) {
      return { sent: true, note: "OTP sent to your registered mobile number." };
    }
    return {
      sent: false,
      note: `SMS provider rejected delivery (${data?.message || resp.status}). Check FAST2SMS_API_KEY configuration in Admin \u2192 Settings & API.`
    };
  } catch (err) {
    return {
      sent: false,
      note: `SMS gateway connection error: ${err?.message || "network error"}.`
    };
  }
}
async function testFast2SmsConnection(testPhone) {
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return { ok: false, error: "Save a valid FAST2SMS_API_KEY first before testing Fast2SMS." };
  }
  const cleanPhone = String(testPhone || "").replace(/\D+/g, "").slice(-10);
  if (cleanPhone && /^[6-9]\d{9}$/.test(cleanPhone)) {
    const testOtp = generateOtpCode();
    const result = await dispatchSmsOtp(cleanPhone, testOtp, "Admin Test");
    if (!result.sent) {
      return { ok: false, error: result.note };
    }
    return { ok: true, message: `Test SMS OTP dispatched to ${cleanPhone} via Fast2SMS (${(process.env.FAST2SMS_ROUTE || "q").trim()} route).` };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/wallet", {
      method: "POST",
      headers: { authorization: fast2smsKey },
      signal: AbortSignal.timeout(1e4)
    });
    const data = await resp.json();
    if (resp.ok && data?.return === true) {
      const bal = data?.wallet !== void 0 ? ` (Wallet balance: \u20B9${data.wallet})` : "";
      return { ok: true, message: `Fast2SMS API key verified successfully${bal}.` };
    }
    return { ok: false, error: data?.message || `Fast2SMS returned status ${resp.status}.` };
  } catch (err) {
    return { ok: false, error: err?.message || "Unable to reach Fast2SMS API." };
  }
}
async function dispatchSmsMessage(phoneRaw, message) {
  const phone = String(phoneRaw || "").replace(/\D+/g, "").slice(-10);
  if (!/^[6-9]\d{9}$/.test(phone)) {
    return { sent: false, providerResponse: "Invalid 10-digit Indian mobile number." };
  }
  const fast2smsKey = (process.env.FAST2SMS_API_KEY || "").trim();
  if (!fast2smsKey) {
    return {
      sent: false,
      providerResponse: "FAST2SMS_API_KEY is not configured in Admin \u2192 Settings & API."
    };
  }
  try {
    const resp = await fetch("https://www.fast2sms.com/dev/bulkV2", {
      method: "POST",
      headers: {
        authorization: fast2smsKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        route: "q",
        message: message.slice(0, 480),
        language: "english",
        flash: 0,
        numbers: phone
      }),
      signal: AbortSignal.timeout(1e4)
    });
    const data = await resp.json();
    if (resp.ok && data?.return === true) {
      return { sent: true, providerResponse: "Sent via Fast2SMS." };
    }
    return {
      sent: false,
      providerResponse: data?.message || `Fast2SMS returned HTTP ${resp.status}`
    };
  } catch (err) {
    return { sent: false, providerResponse: err?.message || "SMS connection error" };
  }
}
function buildWhatsAppDirectLink(phoneRaw, message) {
  const digits = String(phoneRaw || "").replace(/\D+/g, "");
  const e164 = digits.length === 10 ? `91${digits}` : digits;
  if (!e164) return "";
  return `https://wa.me/${e164}?text=${encodeURIComponent(message)}`;
}
async function dispatchWhatsAppMessage(phoneRaw, message) {
  const digits = String(phoneRaw || "").replace(/\D+/g, "");
  const e164 = digits.length === 10 ? `91${digits}` : digits;
  const waLink = buildWhatsAppDirectLink(phoneRaw, message);
  if (!e164 || e164.length < 10) {
    return { sent: false, providerResponse: "Invalid WhatsApp mobile number.", waLink: "" };
  }
  const token = (process.env.WHATSAPP_ACCESS_TOKEN || "").trim();
  const phoneId = (process.env.WHATSAPP_PHONE_NUMBER_ID || "").trim();
  if (!token || !phoneId) {
    return {
      sent: false,
      providerResponse: "WhatsApp Cloud API credentials not configured \u2014 use 1-click wa.me dispatch link or configure WHATSAPP_ACCESS_TOKEN in Settings.",
      waLink
    };
  }
  try {
    const resp = await fetch(`https://graph.facebook.com/v20.0/${encodeURIComponent(phoneId)}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: e164,
        type: "text",
        text: { body: message.slice(0, 1e3) }
      }),
      signal: AbortSignal.timeout(1e4)
    });
    const data = await resp.json();
    if (resp.ok && Array.isArray(data?.messages) && data.messages[0]?.id) {
      return { sent: true, providerResponse: `WhatsApp ID: ${data.messages[0].id}`, waLink };
    }
    return {
      sent: false,
      providerResponse: data?.error?.message || `WhatsApp API status ${resp.status}`,
      waLink
    };
  } catch (err) {
    return {
      sent: false,
      providerResponse: err?.message || "WhatsApp Cloud API connection error",
      waLink
    };
  }
}
function resolveCampaignRecipients(db, filters) {
  const suppressedSet = new Set(
    db.prepare("SELECT email FROM email_suppressions").all().map((r) => normalizeEmail(r.email))
  );
  let users = [];
  if (Array.isArray(filters.selectedUserIds) && filters.selectedUserIds.length > 0) {
    const ids = filters.selectedUserIds.map(Number).filter((n) => Number.isInteger(n) && n > 0);
    if (ids.length > 0) {
      const ph = ids.map(() => "?").join(",");
      users = db.prepare(
        `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                  tp.subjects_json as teacher_subjects
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
           WHERE u.id IN (${ph}) AND u.role IN ('student', 'teacher', 'parent')`
      ).all(...ids);
    }
  } else {
    users = db.prepare(
      `SELECT u.*, sp.class_level, sp.subjects_json as student_subjects,
                tp.subjects_json as teacher_subjects
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role IN ('student', 'teacher', 'parent')`
    ).all();
  }
  let enrolledUserIds = null;
  if (filters.courseId && Number(filters.courseId) > 0) {
    const rows = db.prepare("SELECT student_id FROM enrollments WHERE course_id = ? AND status IN ('active', 'completed')").all(Number(filters.courseId));
    const courseTeacher = db.prepare("SELECT teacher_id FROM courses WHERE id = ?").get(Number(filters.courseId));
    enrolledUserIds = new Set(rows.map((r) => Number(r.student_id)));
    if (courseTeacher?.teacher_id) enrolledUserIds.add(Number(courseTeacher.teacher_id));
  }
  const feeDueUserIds = filters.audienceGroup === "fee_due" ? new Set(
    db.prepare(
      `SELECT DISTINCT student_id FROM fee_records
                 WHERE status IN ('pending', 'partial', 'overdue') AND (total_amount - discount_amount - paid_amount) > 0`
    ).all().map((r) => Number(r.student_id))
  ) : null;
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400 * 1e3).toISOString();
  const eligible = [];
  let excludedCount = 0;
  for (const u of users) {
    if (!filters.selectedUserIds?.length) {
      if (filters.audienceGroup === "all_students" && u.role !== "student") continue;
      if (filters.audienceGroup === "all_teachers" && u.role !== "teacher") continue;
      if (filters.audienceGroup === "all_parents" && u.role !== "parent") continue;
      if (filters.audienceGroup === "fee_due" && (!feeDueUserIds || !feeDueUserIds.has(Number(u.id)))) continue;
      if (filters.audienceGroup === "recently_registered" && (u.role !== "student" || u.created_at < thirtyDaysAgo)) continue;
      if (filters.accountStatus === "approved" && u.verification_status !== "approved") continue;
      if (filters.accountStatus === "pending_approval" && u.verification_status !== "pending_approval") continue;
      if (filters.classLevel && u.role === "student" && !String(u.class_level || "").toLowerCase().includes(filters.classLevel.toLowerCase())) {
        continue;
      }
      if (filters.subject) {
        const subBlob = `${u.student_subjects || ""} ${u.teacher_subjects || ""}`.toLowerCase();
        if (!subBlob.includes(filters.subject.toLowerCase())) continue;
      }
      if (enrolledUserIds && !enrolledUserIds.has(Number(u.id))) continue;
      if (filters.registeredAfter && u.created_at < filters.registeredAfter) continue;
    }
    const email = normalizeEmail(u.email);
    const isSuppressed = suppressedSet.has(email) || Number(u.marketing_opt_in) !== 1 || Number(u.is_active) !== 1;
    if (isSuppressed) {
      excludedCount++;
      continue;
    }
    eligible.push({
      id: Number(u.id),
      full_name: u.full_name,
      email,
      role: u.role,
      unsubscribe_token: u.unsubscribe_token
    });
  }
  return { eligible, excludedCount };
}
async function processCampaignQueue(db, campaignId, batchSize = 25) {
  const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(campaignId);
  if (!camp || ["paused", "cancelled", "draft"].includes(camp.status)) {
    return { sent: 0, failed: 0 };
  }
  db.prepare("UPDATE email_campaigns SET status = 'sending', updated_at = ? WHERE id = ?").run(nowIso(), campaignId);
  const pendingRows = db.prepare(
    `SELECT d.*, u.unsubscribe_token
       FROM email_deliveries d
       LEFT JOIN users u ON u.id = d.user_id
       WHERE d.campaign_id = ? AND (d.status = 'pending' OR (d.status = 'failed' AND d.retry_count < 2))
       ORDER BY d.id ASC LIMIT ?`
  ).all(campaignId, batchSize);
  const siteUrl = getPublicSiteUrl();
  let sent = 0;
  let failed = 0;
  for (const row of pendingRows) {
    const latest = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
    if (!latest || latest.status === "paused" || latest.status === "cancelled") break;
    const unsubUrl = row.unsubscribe_token ? `${siteUrl}/unsubscribe/${row.unsubscribe_token}` : void 0;
    const html = renderBrandedEmailHtml({
      subject: camp.subject,
      previewText: camp.preview_text,
      htmlBody: camp.html_body,
      recipientName: row.recipient_name,
      ctaLabel: camp.cta_label,
      ctaUrl: camp.cta_url,
      unsubscribeUrl: unsubUrl
    });
    const result = await sendEmailDirect({
      to: row.recipient_email,
      subject: camp.subject,
      html,
      attachmentUrl: camp.attachment_url
    });
    if (result.ok) {
      db.prepare(
        "UPDATE email_deliveries SET status = 'sent', provider_message_id = ?, error_message = '', sent_at = ? WHERE id = ?"
      ).run(result.messageId, nowIso(), row.id);
      sent++;
    } else {
      db.prepare(
        "UPDATE email_deliveries SET status = 'failed', error_message = ?, retry_count = retry_count + 1 WHERE id = ?"
      ).run(result.error, row.id);
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40));
  }
  const counts = db.prepare(
    `SELECT
         SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent_c,
         SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_c,
         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_c
       FROM email_deliveries WHERE campaign_id = ?`
  ).get(campaignId);
  const currentCamp = db.prepare("SELECT status FROM email_campaigns WHERE id = ?").get(campaignId);
  let nextStatus = currentCamp?.status || "completed";
  if (nextStatus !== "paused" && nextStatus !== "cancelled") {
    nextStatus = Number(counts?.pending_c || 0) > 0 ? "queued" : Number(counts?.sent_c || 0) > 0 ? "completed" : "failed";
  }
  db.prepare(
    "UPDATE email_campaigns SET status = ?, sent_count = ?, failed_count = ?, updated_at = ? WHERE id = ?"
  ).run(nextStatus, Number(counts?.sent_c || 0), Number(counts?.failed_c || 0), nowIso(), campaignId);
  return { sent, failed };
}
function startEmailScheduler(db) {
  setInterval(() => {
    try {
      const now = nowIso();
      const due = db.prepare(
        `SELECT id FROM email_campaigns
           WHERE (status = 'queued' AND (scheduled_at IS NULL OR scheduled_at <= ?))
              OR (send_mode = 'scheduled' AND status = 'queued' AND scheduled_at <= ?)`
      ).all(now, now);
      for (const c of due) {
        void processCampaignQueue(db, c.id, 20);
      }
    } catch (err) {
      console.warn("[Yuitor Mailer] Scheduler error:", err);
    }
  }, 3e4);
}

// server/updater.ts
import fs5 from "node:fs";
import path4 from "node:path";
import zlib from "node:zlib";
var MAX_ZIP_ENTRIES = 6e3;
var MAX_ENTRY_BYTES = 40 * 1024 * 1024;
var MAX_TOTAL_BYTES = 250 * 1024 * 1024;
var PROTECTED_TOP_DIRS = /* @__PURE__ */ new Set(["data", "backups", "logs", "uploads", "tmp", ".git"]);
var PROTECTED_EXACT_PATHS = /* @__PURE__ */ new Set(["database/initial-gate.txt", ".env", ".env.local", ".env.production"]);
var FORBIDDEN_FILE_RE = /(?:^|\/)(?:\.env(?:\.[^/]+)?$)|(?:\.(?:db|db-shm|db-wal|sqlite|sqlite3|log)$)/i;
var CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();
function computeCrc32(buf) {
  if (typeof zlib.crc32 === "function") {
    return zlib.crc32(buf) >>> 0;
  }
  let crc = 4294967295;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 255] ^ crc >>> 8;
  }
  return (crc ^ 4294967295) >>> 0;
}
function sanitizeZipRelativePath(raw) {
  const replaced = String(raw || "").replace(/\\/g, "/");
  if (!replaced || replaced.includes("\0")) {
    throw new Error(`Unsafe ZIP entry name detected.`);
  }
  if (replaced.startsWith("/") || /^[A-Za-z]:/.test(replaced)) {
    throw new Error(`Absolute path not allowed inside upgrade ZIP: ${replaced}`);
  }
  const trimmed = replaced.replace(/^\.\//, "").replace(/\/+$/, "");
  if (!trimmed) return "";
  const parts = trimmed.split("/");
  if (parts.some((p) => !p || p === "." || p === "..")) {
    throw new Error(`Path traversal not allowed inside upgrade ZIP: ${replaced}`);
  }
  return parts.join("/");
}
function parseZipBuffer(zipBuf) {
  if (!Buffer.isBuffer(zipBuf) || zipBuf.length < 22) {
    throw new Error("Invalid ZIP file: archive is empty or truncated.");
  }
  const minOffset = Math.max(0, zipBuf.length - (65536 + 22));
  let eocdOffset = -1;
  for (let i = zipBuf.length - 22; i >= minOffset; i--) {
    if (zipBuf.readUInt32LE(i) === 101010256) {
      const commentLen = zipBuf.readUInt16LE(i + 20);
      if (i + 22 + commentLen === zipBuf.length) {
        eocdOffset = i;
        break;
      }
    }
  }
  if (eocdOffset < 0) {
    throw new Error("Invalid ZIP file: End of Central Directory signature missing.");
  }
  const entryCount = zipBuf.readUInt16LE(eocdOffset + 10);
  const cdSize = zipBuf.readUInt32LE(eocdOffset + 12);
  const cdOffset = zipBuf.readUInt32LE(eocdOffset + 16);
  if (entryCount > MAX_ZIP_ENTRIES) {
    throw new Error(`ZIP archive contains too many entries (${entryCount} > ${MAX_ZIP_ENTRIES}).`);
  }
  if (cdOffset + cdSize > eocdOffset) {
    throw new Error("Invalid ZIP central directory offsets.");
  }
  const entries = [];
  let cursor = cdOffset;
  let totalUncompressed = 0;
  for (let idx = 0; idx < entryCount; idx++) {
    if (cursor + 46 > eocdOffset || zipBuf.readUInt32LE(cursor) !== 33639248) {
      throw new Error("Corrupt ZIP central directory header.");
    }
    const flags = zipBuf.readUInt16LE(cursor + 8);
    const compressionMethod = zipBuf.readUInt16LE(cursor + 10);
    const crc32 = zipBuf.readUInt32LE(cursor + 16);
    const compressedSize = zipBuf.readUInt32LE(cursor + 20);
    const uncompressedSize = zipBuf.readUInt32LE(cursor + 24);
    const nameLen = zipBuf.readUInt16LE(cursor + 28);
    const extraLen = zipBuf.readUInt16LE(cursor + 30);
    const commentLen = zipBuf.readUInt16LE(cursor + 32);
    const extAttr = zipBuf.readUInt32LE(cursor + 38);
    const localHeaderOffset = zipBuf.readUInt32LE(cursor + 42);
    const rawName = zipBuf.subarray(cursor + 46, cursor + 46 + nameLen).toString("utf8");
    cursor += 46 + nameLen + extraLen + commentLen;
    if ((flags & 1) !== 0) {
      throw new Error(`Encrypted ZIP entries are not supported (${rawName}).`);
    }
    const unixMode = extAttr >>> 16 & 61440;
    const isSymlink = unixMode === 40960;
    if (isSymlink) {
      throw new Error(`Symlinks are not permitted inside upgrade ZIP (${rawName}).`);
    }
    const isDirectory = rawName.endsWith("/");
    const normalizedName = sanitizeZipRelativePath(rawName);
    if (!normalizedName) continue;
    if (uncompressedSize > MAX_ENTRY_BYTES) {
      throw new Error(`ZIP entry exceeds 40 MB limit: ${normalizedName}`);
    }
    totalUncompressed += uncompressedSize;
    if (totalUncompressed > MAX_TOTAL_BYTES) {
      throw new Error("Upgrade ZIP uncompressed total exceeds 250 MB safety limit.");
    }
    if (isDirectory) {
      entries.push({
        rawName,
        normalizedName,
        isDirectory: true,
        compressionMethod,
        crc32,
        compressedSize,
        uncompressedSize,
        isSymlink: false,
        data: Buffer.alloc(0)
      });
      continue;
    }
    if (localHeaderOffset + 30 > zipBuf.length || zipBuf.readUInt32LE(localHeaderOffset) !== 67324752) {
      throw new Error(`Corrupt local file header for entry: ${normalizedName}`);
    }
    const lNameLen = zipBuf.readUInt16LE(localHeaderOffset + 26);
    const lExtraLen = zipBuf.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + lNameLen + lExtraLen;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > zipBuf.length) {
      throw new Error(`Truncated data for ZIP entry: ${normalizedName}`);
    }
    const compSlice = zipBuf.subarray(dataStart, dataEnd);
    let data;
    if (compressionMethod === 0) {
      data = Buffer.from(compSlice);
    } else if (compressionMethod === 8) {
      data = zlib.inflateRawSync(compSlice, { maxOutputLength: MAX_ENTRY_BYTES });
    } else {
      throw new Error(`Unsupported ZIP compression method (${compressionMethod}) for ${normalizedName}`);
    }
    if (data.length !== uncompressedSize) {
      throw new Error(`Size mismatch after extracting ${normalizedName}`);
    }
    if (computeCrc32(data) !== crc32) {
      throw new Error(`CRC-32 checksum verification failed for ${normalizedName}`);
    }
    entries.push({
      rawName,
      normalizedName,
      isDirectory: false,
      compressionMethod,
      crc32,
      compressedSize,
      uncompressedSize,
      isSymlink: false,
      data
    });
  }
  return entries;
}
function getAppVersionInfo(appRoot) {
  try {
    const pkgPath = path4.join(appRoot, "package.json");
    if (fs5.existsSync(pkgPath)) {
      const parsed = JSON.parse(fs5.readFileSync(pkgPath, "utf8"));
      return {
        version: String(parsed?.version || "1.0.0"),
        name: String(parsed?.name || "yuitor-smart-classes")
      };
    }
  } catch {
  }
  return { version: "1.0.0", name: "yuitor-smart-classes" };
}
function resolveReleaseStripPrefix(entries) {
  const fileNames = entries.filter((e) => !e.isDirectory).map((e) => e.normalizedName);
  if (fileNames.length === 0) {
    throw new Error("Upgrade ZIP contains no files.");
  }
  const yuitorFiles = fileNames.filter((n) => n.startsWith("yuitor/"));
  if (yuitorFiles.length > 0 && yuitorFiles.length === fileNames.length) {
    return { stripPrefix: "yuitor/", detectedLayout: "yuitor-folder" };
  }
  if (fileNames.includes("server.js") && fileNames.includes("public/index.html")) {
    return { stripPrefix: "", detectedLayout: "flat-root" };
  }
  const topSegments = new Set(fileNames.map((n) => n.split("/")[0]));
  if (topSegments.size === 1) {
    const [onlyTop] = topSegments;
    const prefix = `${onlyTop}/`;
    if (fileNames.includes(`${prefix}server.js`) && fileNames.includes(`${prefix}public/index.html`)) {
      return { stripPrefix: prefix, detectedLayout: "wrapped-folder" };
    }
  }
  throw new Error(
    "Invalid Yuitor release ZIP: must contain a Yuitor release bundle (yuitor/server.js + yuitor/public/index.html)."
  );
}
function isProtectedRuntimePath(relPath) {
  const clean = relPath.replace(/^\/+/, "");
  const top = clean.split("/")[0];
  if (PROTECTED_TOP_DIRS.has(top)) return true;
  if (PROTECTED_EXACT_PATHS.has(clean)) return true;
  return false;
}
function validateReleaseZipEntries(zipBuf) {
  const entries = parseZipBuffer(zipBuf);
  const { stripPrefix, detectedLayout } = resolveReleaseStripPrefix(entries);
  const files = [];
  let hasServerJs = false;
  let hasPublicIndex = false;
  let packageJsonBuf = null;
  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const relPath = stripPrefix && entry.normalizedName.startsWith(stripPrefix) ? entry.normalizedName.slice(stripPrefix.length) : entry.normalizedName;
    if (!relPath) continue;
    const baseName = relPath.split("/").pop() || "";
    if (baseName !== ".env.example" && FORBIDDEN_FILE_RE.test(relPath)) {
      throw new Error(`Security check rejected ZIP: forbidden runtime/secret file "${relPath}".`);
    }
    if (relPath === "server.js") hasServerJs = true;
    if (relPath === "public/index.html") hasPublicIndex = true;
    if (relPath === "package.json") packageJsonBuf = entry.data;
    files.push({ relPath, data: entry.data });
  }
  if (!hasServerJs || !hasPublicIndex || !packageJsonBuf) {
    throw new Error("Invalid Yuitor release ZIP: missing required core files (server.js, package.json, or public/index.html).");
  }
  let newVersion = "1.0.0";
  try {
    const pkgMeta = JSON.parse(packageJsonBuf.toString("utf8"));
    newVersion = String(pkgMeta?.version || "1.0.0");
  } catch {
    throw new Error("Invalid package.json inside uploaded release ZIP.");
  }
  return { detectedLayout, newVersion, files };
}
function applyReleaseZipUpdate(zipBuf, appRoot) {
  const resolvedRoot = path4.resolve(appRoot);
  const previousVersion = getAppVersionInfo(resolvedRoot).version;
  const validated = validateReleaseZipEntries(zipBuf);
  let updatedFiles = 0;
  let skippedProtected = 0;
  for (const file of validated.files) {
    if (isProtectedRuntimePath(file.relPath)) {
      skippedProtected++;
      continue;
    }
    const destPath = path4.resolve(resolvedRoot, file.relPath);
    if (!destPath.startsWith(resolvedRoot + path4.sep)) {
      throw new Error(`Target path escaped application root: ${file.relPath}`);
    }
    fs5.mkdirSync(path4.dirname(destPath), { recursive: true });
    const tmpPath = `${destPath}.yu-tmp-${process.pid}`;
    fs5.writeFileSync(tmpPath, file.data);
    fs5.renameSync(tmpPath, destPath);
    updatedFiles++;
  }
  let restartFileWritten = false;
  try {
    const tmpDir = path4.join(resolvedRoot, "tmp");
    fs5.mkdirSync(tmpDir, { recursive: true });
    fs5.writeFileSync(path4.join(tmpDir, "restart.txt"), `upgraded=${(/* @__PURE__ */ new Date()).toISOString()}
`, "utf8");
    restartFileWritten = true;
  } catch {
    restartFileWritten = false;
  }
  return {
    previousVersion,
    newVersion: validated.newVersion,
    updatedFiles,
    skippedProtected,
    detectedLayout: validated.detectedLayout,
    restartFileWritten
  };
}

// server/admin-gate.ts
import { Router } from "express";
import crypto4 from "node:crypto";
import fs7 from "node:fs";
import path6 from "node:path";

// server/installer.ts
import fs6 from "node:fs";
import path5 from "node:path";
function sanitizeInstallerError(raw) {
  const str = String(raw?.message || raw || "Unknown installation error");
  return str.replace(/(password|passwd|pwd|secret|token|key|passphrase)\s*[:=]\s*(['"]?)[^\s'"]+\2/gi, "$1=[REDACTED]").replace(/for user ['"][^'"]+['"]@['"][^'"]+['"]/gi, "for configured user").replace(/Bearer\s+[A-Za-z0-9._-]+/gi, "Bearer [REDACTED]").replace(/[\u0000-\u001F\u007F]/g, " ").slice(0, 500);
}
function writeInstallLog(step, technicalDetail, extra) {
  try {
    fs6.mkdirSync(LOGS_DIR, { recursive: true });
    const logPath = path5.join(LOGS_DIR, "install.log");
    const msg = sanitizeInstallerError(
      technicalDetail instanceof Error ? `${technicalDetail.name}: ${technicalDetail.message}
${technicalDetail.stack || ""}` : technicalDetail
    );
    const meta = extra ? ` | meta=${sanitizeInstallerError(JSON.stringify(extra))}` : "";
    fs6.appendFileSync(logPath, `[${nowIso()}] [${step}] ${msg}${meta}
`, "utf8");
  } catch {
  }
}
function buildStructuredError(step, whatFailed, why, howToFix, technicalError) {
  if (technicalError !== void 0) {
    writeInstallLog(step, technicalError, { whatFailed, why });
  } else {
    writeInstallLog(step, `${whatFailed}: ${why}`);
  }
  return {
    step,
    whatFailed: sanitizeInstallerError(whatFailed),
    why: sanitizeInstallerError(why),
    howToFix
  };
}
function checkDirectoryWritable(dirPath) {
  try {
    fs6.mkdirSync(dirPath, { recursive: true });
    const probe = path5.join(dirPath, `.yuitor-write-test-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.tmp`);
    fs6.writeFileSync(probe, "ok", "utf8");
    fs6.unlinkSync(probe);
    return { ok: true };
  } catch (err) {
    const code = err?.code || "EACCES";
    return {
      ok: false,
      why: `Write test failed (${code}) in ${path5.basename(dirPath) || dirPath}`,
      howToFix: `Set directory permission to 755 (or 775) in cPanel File Manager for '${path5.basename(dirPath)}/' so Node.js can read and write files.`
    };
  }
}
function checkEnvWritable(envPath) {
  const exists = fs6.existsSync(envPath);
  if (exists) {
    try {
      fs6.accessSync(envPath, fs6.constants.R_OK | fs6.constants.W_OK);
      return { exists: true, writable: true };
    } catch (err) {
      return {
        exists: true,
        writable: false,
        why: `Existing .env file cannot be modified (${err?.code || "EACCES"}).`,
        howToFix: "Set .env permissions to 644 (writable by the Node.js owner) in cPanel File Manager, or update values manually inside cPanel."
      };
    }
  }
  try {
    const probe = path5.join(path5.dirname(envPath), `.yuitor-env-probe-${Date.now()}.tmp`);
    fs6.writeFileSync(probe, "", "utf8");
    fs6.unlinkSync(probe);
    return { exists: false, writable: true };
  } catch (err) {
    return {
      exists: false,
      writable: false,
      why: `Application directory is not writable to create .env (${err?.code || "EACCES"}).`,
      howToFix: "Create .env from .env.example manually in cPanel File Manager with permissions 644."
    };
  }
}
function runInstallerPreflight(db) {
  const checks = [];
  const warnings = [];
  const verParts = process.versions.node.split(".").map((n) => Number(n));
  const major = verParts[0] || 0;
  const nodeOk = major >= 22;
  checks.push({
    id: "node_version",
    label: `Node.js Runtime (${process.version})`,
    ok: nodeOk,
    required: true,
    detail: nodeOk ? `Node.js ${process.version} meets >= 22.0.0 requirement.` : `Node.js ${process.version} is below 22.0.0.`,
    ...nodeOk ? {} : {
      step: "Runtime Check",
      whatFailed: `Node.js version ${process.version} is too old`,
      why: "Built-in SQLite (node:sqlite) requires Node.js 22.x or higher.",
      howToFix: "Open cPanel -> Setup Node.js App and change Node.js version to 22.x, then restart the app."
    }
  });
  let sqliteModOk = false;
  try {
    sqliteModOk = typeof process.getBuiltinModule === "function" ? Boolean(process.getBuiltinModule("node:sqlite")) : major >= 22;
  } catch {
    sqliteModOk = major >= 22;
  }
  checks.push({
    id: "node_sqlite",
    label: "SQLite Engine (node:sqlite)",
    ok: sqliteModOk,
    required: true,
    detail: sqliteModOk ? "Built-in node:sqlite driver is available." : "node:sqlite module missing.",
    ...sqliteModOk ? {} : {
      step: "Database Engine Check",
      whatFailed: "Built-in node:sqlite driver missing",
      why: "Current Node runtime was built without SQLite support.",
      howToFix: "Select standard Node.js 22.x+ in cPanel -> Setup Node.js App."
    }
  });
  const publicIndexOk = fs6.existsSync(path5.join(PUBLIC_DIR, "index.html"));
  const migrationOk = fs6.existsSync(path5.join(APP_ROOT, "database", "migrations", "001_unified_portal.sql"));
  checks.push({
    id: "core_files",
    label: "Core Files & Public Assets",
    ok: publicIndexOk && migrationOk,
    required: true,
    detail: publicIndexOk && migrationOk ? `Public HTML (${PUBLIC_DIR}) and SQL migration found.` : `Missing ${!publicIndexOk ? "public/index.html" : ""} ${!migrationOk ? "database/migrations/001_unified_portal.sql" : ""}`.trim(),
    ...publicIndexOk && migrationOk ? {} : {
      step: "Core Files Check",
      whatFailed: "Required application files or public directory missing",
      why: !publicIndexOk ? `Could not locate index.html inside ${PUBLIC_DIR}.` : "Could not locate database/migrations/001_unified_portal.sql.",
      howToFix: "Upload the complete deploy-shared-hosting.zip contents, and if public_html is separate, set YUITOR_PUBLIC_DIR=../public_html in .env."
    }
  });
  const folderTargets = [
    { id: "writable_data", label: "Writable Folder: data/", dir: DATA_DIR },
    { id: "writable_backups", label: "Writable Folder: backups/", dir: BACKUPS_DIR },
    { id: "writable_uploads", label: "Writable Folder: uploads/", dir: UPLOADS_DIR },
    { id: "writable_logs", label: "Writable Folder: logs/", dir: LOGS_DIR }
  ];
  for (const target of folderTargets) {
    const res = checkDirectoryWritable(target.dir);
    checks.push({
      id: target.id,
      label: target.label,
      ok: res.ok,
      required: true,
      detail: res.ok ? `${target.dir} is writable.` : res.why || "Directory not writable.",
      ...res.ok ? {} : {
        step: "Filesystem Permissions",
        whatFailed: `${target.label.replace("Writable Folder: ", "")} is not writable`,
        why: res.why || "Insufficient filesystem permissions.",
        howToFix: res.howToFix || "Set permission 755 on this folder."
      }
    });
  }
  const envPath = path5.join(APP_ROOT, ".env");
  const envCheck = checkEnvWritable(envPath);
  if (!envCheck.writable) {
    warnings.push(envCheck.howToFix || "Configure .env manually with 644 permissions.");
  }
  checks.push({
    id: "env_status",
    label: envCheck.exists ? "Environment File (.env)" : "Environment File (.env optional)",
    ok: envCheck.writable || envCheck.exists,
    required: false,
    detail: envCheck.exists ? envCheck.writable ? ".env exists and is writable." : ".env exists (read-only; runtime settings will persist inside database system_settings)." : envCheck.writable ? ".env not created yet (runtime folder is writable; system_settings also persists configuration)." : ".env absent and root directory is read-only."
  });
  const htaccessExists = fs6.existsSync(path5.join(PUBLIC_DIR, ".htaccess"));
  checks.push({
    id: "clean_urls",
    label: "Clean URLs & .htaccess Protection",
    ok: true,
    required: false,
    detail: htaccessExists ? "public/.htaccess present + Express clean URL routing active." : "Express clean URL routing active (add public/.htaccess when deploying under Apache/cPanel)."
  });
  if (!htaccessExists) {
    warnings.push("public/.htaccess was not found; copy public/.htaccess when uploading to Apache/cPanel.");
  }
  const smtpReady = isSmtpConfigured();
  const maskedOtpEmail = maskEmailAddress(getAdminOtpEmail());
  checks.push({
    id: "smtp_otp",
    label: "Email OTP Delivery (SMTP)",
    ok: smtpReady,
    required: false,
    detail: smtpReady ? `SMTP configured \u2014 Installer & Admin Sign-In OTPs will be emailed to ${maskedOtpEmail}.` : `SMTP not configured yet \u2014 configure SMTP below or in .env so verification OTPs can be sent to ${maskedOtpEmail}.`,
    ...smtpReady ? {} : {
      howToFix: `Enter your SMTP credentials (cPanel email or Gmail App Password) in Step 1 below or in yuitor_core/.env to deliver OTP to ${maskedOtpEmail}.`
    }
  });
  let dbOk = false;
  let dbErrDetail = "";
  let adminCount = 0;
  let userCount = 0;
  let courseCount = 0;
  try {
    if (db) {
      db.prepare("SELECT 1 as ok").get();
      adminCount = db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get().c;
      userCount = db.prepare("SELECT COUNT(*) as c FROM users").get().c;
      courseCount = db.prepare("SELECT COUNT(*) as c FROM courses").get().c;
      dbOk = true;
    } else {
      dbErrDetail = "Database handle was not initialized.";
    }
  } catch (err) {
    dbErrDetail = sanitizeInstallerError(err);
    writeInstallLog("Database Check", err);
  }
  checks.push({
    id: "db_connectivity",
    label: "SQLite Database Connectivity & Schema",
    ok: dbOk,
    required: true,
    detail: dbOk ? `Connected (${userCount} users, ${courseCount} courses, ${adminCount} admin account${adminCount === 1 ? "" : "s"}).` : `Database query failed: ${dbErrDetail}`,
    ...dbOk ? {} : {
      step: "Database Connectivity",
      whatFailed: "SQLite database query failed",
      why: dbErrDetail || "Unable to execute queries against data/yuitor.db.",
      howToFix: "Ensure data/ has 755 permissions and valid SQLite file integrity."
    }
  });
  const failedRequired = checks.find((c) => c.required && !c.ok);
  return {
    ok: !failedRequired,
    checks,
    warnings,
    existingState: {
      hasEnvFile: envCheck.exists,
      hasDatabaseFile: fs6.existsSync(DB_PATH),
      adminCount,
      userCount,
      courseCount,
      needsFirstAdminSetup: adminCount === 0,
      requiresSetupKey: true,
      setupKeyConfigured: Boolean((process.env.YU_ADMIN_SETUP_KEY || "").trim().length >= 16),
      setupWindowExpired: isInstallerWindowExpired(),
      smtpConfigured: smtpReady,
      otpRecipientMasked: maskedOtpEmail
    },
    error: failedRequired ? {
      step: failedRequired.step || failedRequired.label,
      whatFailed: failedRequired.whatFailed || failedRequired.label,
      why: failedRequired.why || failedRequired.detail,
      howToFix: failedRequired.howToFix || "Fix the failing requirement above and click Retry."
    } : void 0
  };
}

// server/admin-gate.ts
var ADMIN_SLUG_REGEX = /^[a-z0-9][a-z0-9-]{7,78}[a-z0-9]$/;
var RESERVED_ADMIN_SLUGS = /* @__PURE__ */ new Set([
  "admin",
  "admin-setup",
  "admin-login",
  "login-admin",
  "administrator",
  "wp-admin",
  "wp-login",
  "panel",
  "dashboard",
  "cpanel",
  "root",
  "api",
  "auth",
  "public",
  "student",
  "teacher",
  "payments",
  "marketing",
  "health",
  "uploads",
  "assets",
  "backups",
  "data",
  "database",
  "logs",
  "scripts",
  "login",
  "register",
  "unsubscribe",
  "erp",
  "contact",
  "courses",
  "admission"
]);
function generateRandomAdminSlug() {
  return generateHighEntropyAdminSlug();
}
function normalizeAdminSlug(raw) {
  return String(raw ?? "").trim().replace(/^\/+|\/+$/g, "").toLowerCase();
}
function validateAdminSlug(raw) {
  const slug = normalizeAdminSlug(raw);
  if (!slug) {
    return { ok: false, error: "Admin gate slug cannot be empty." };
  }
  if (!ADMIN_SLUG_REGEX.test(slug)) {
    return {
      ok: false,
      error: "Admin gate slug must be 9\u201380 characters using lowercase letters, numbers, and hyphens only."
    };
  }
  if (RESERVED_ADMIN_SLUGS.has(slug) || /^(?:wp-admin|admin[-_]?|login[-_]?admin|administrator)/i.test(slug)) {
    return {
      ok: false,
      error: "Predictable or reserved words like 'admin', 'wp-admin', or 'administrator' are blocked for security."
    };
  }
  return { ok: true, slug };
}
function persistEnvVariable(key, value) {
  const envPath = path6.join(APP_ROOT, ".env");
  try {
    if (!fs7.existsSync(envPath)) {
      return { updated: false, reason: ".env file does not exist (value persisted in database system_settings)." };
    }
    const existing = fs7.readFileSync(envPath, "utf8");
    const safeVal = value.replace(/[\r\n"]/g, "");
    const line = `${key}="${safeVal}"`;
    const re = new RegExp(`^\\s*${key}\\s*=.*$`, "m");
    const next = re.test(existing) ? existing.replace(re, line) : `${existing.replace(/\s*$/, "")}
${line}
`;
    fs7.writeFileSync(envPath, next, { encoding: "utf8", mode: 0o600 });
    try {
      fs7.chmodSync(envPath, 0o600);
    } catch {
    }
    return { updated: true };
  } catch (err) {
    return { updated: false, reason: err?.message || "Could not write .env" };
  }
}
function getAdminPath(db) {
  const envRaw = (process.env.ADMIN_PATH || "").trim();
  if (envRaw) {
    const check = validateAdminSlug(envRaw);
    if (check.ok) {
      const row2 = db.prepare("SELECT value FROM system_settings WHERE key = 'ADMIN_PATH'").get();
      if (!row2 || row2.value !== check.slug) {
        db.prepare(
          "INSERT OR REPLACE INTO system_settings (key, value, is_secret, updated_at, updated_by) VALUES ('ADMIN_PATH', ?, 1, ?, NULL)"
        ).run(check.slug, nowIso());
      }
      process.env.ADMIN_PATH = check.slug;
      return check.slug;
    }
  }
  const row = db.prepare("SELECT value FROM system_settings WHERE key = 'ADMIN_PATH'").get();
  if (row?.value) {
    const check = validateAdminSlug(row.value);
    if (check.ok) {
      process.env.ADMIN_PATH = check.slug;
      return check.slug;
    }
  }
  const generated = generateRandomAdminSlug();
  db.prepare(
    "INSERT OR REPLACE INTO system_settings (key, value, is_secret, updated_at, updated_by) VALUES ('ADMIN_PATH', ?, 1, ?, NULL)"
  ).run(generated, nowIso());
  process.env.ADMIN_PATH = generated;
  persistEnvVariable("ADMIN_PATH", generated);
  // Security: NEVER write ADMIN_PATH to install-gate-url.txt or stdout logs!
  try {
    const staleHint = path6.join(LOGS_DIR, "install-gate-url.txt");
    if (fs7.existsSync(staleHint)) fs7.unlinkSync(staleHint);
  } catch {
  }
  return generated;
}
function setAdminPathSlug(db, newSlugRaw, actorUserId) {
  const check = validateAdminSlug(newSlugRaw);
  if (!check.ok) {
    return { ok: false, error: check.error };
  }
  const now = nowIso();
  db.prepare(
    `INSERT INTO system_settings (key, value, is_secret, updated_at, updated_by)
     VALUES ('ADMIN_PATH', ?, 0, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, updated_by = excluded.updated_by`
  ).run(check.slug, now, actorUserId);
  process.env.ADMIN_PATH = check.slug;
  hydrateRuntimeSettings(db);
  const envRes = persistEnvVariable("ADMIN_PATH", check.slug);
  return { ok: true, slug: check.slug, envUpdated: envRes.updated };
}
function isLegacyAdminProbePath(reqPath) {
  const p = String(reqPath || "/").trim() || "/";
  return /^\/(?:admin(?:-setup|\.php)?|wp-admin|wp-login\.php|login-admin|administrator|adminpanel)(?:\/|$|\.)/i.test(p) || /^\/api\/(?:admin|marketing)(?:\/|$)/i.test(p);
}
function ipToUint32(ip) {
  const cleaned = ip.replace(/^::ffff:/, "");
  const parts = cleaned.split(".");
  if (parts.length !== 4) return null;
  let num = 0;
  for (const part of parts) {
    if (!/^\d+$/.test(part)) return null;
    const n = Number(part);
    if (n < 0 || n > 255) return null;
    num = (num << 8 | n) >>> 0;
  }
  return num;
}
function isIpAllowedForAdmin(ipRaw, allowlistRaw = process.env.ADMIN_IP_ALLOWLIST || "") {
  const raw = String(allowlistRaw || "").trim();
  if (!raw || raw === "*") return true;
  const entries = raw.split(/[,\s]+/).map((x) => x.trim()).filter(Boolean);
  if (entries.length === 0) return true;
  const ip = String(ipRaw || "").replace(/^::ffff:/, "").trim();
  for (const entry of entries) {
    const cleanEntry = entry.replace(/^::ffff:/, "");
    if (cleanEntry === "*" || cleanEntry === ip) return true;
    if ((ip === "127.0.0.1" || ip === "::1") && (cleanEntry === "127.0.0.1" || cleanEntry === "::1")) {
      return true;
    }
    if (cleanEntry.includes("/")) {
      const [baseIp, prefixStr] = cleanEntry.split("/");
      const prefix = Number(prefixStr);
      const ipInt = ipToUint32(ip);
      const baseInt = ipToUint32(baseIp);
      if (ipInt !== null && baseInt !== null && Number.isInteger(prefix) && prefix >= 0 && prefix <= 32) {
        const mask = prefix === 0 ? 0 : 4294967295 << 32 - prefix >>> 0;
        if ((ipInt & mask) === (baseInt & mask)) return true;
      }
    }
  }
  return false;
}
function recordAdminLoginAttempt(db, params) {
  try {
    db.prepare(
      `INSERT INTO admin_login_attempts (identifier, ip_address, user_agent, outcome, reason, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      cleanText(params.identifier, 180),
      cleanText(params.ipAddress, 80),
      cleanText(params.userAgent || "", 260),
      cleanText(params.outcome, 40),
      cleanText(params.reason || "", 260),
      nowIso()
    );
  } catch {
  }
}
async function sendAdminGateOtpEmail(toEmail, otp, opts) {
  const isInstall = opts.mode === "installer";
  const subject = isInstall ? `Yuitor Installer Verification OTP: ${otp}` : `Yuitor Admin Sign-In OTP: ${otp}`;
  const htmlBody = `
    <p>Hello${opts.actorName ? ` <strong>${escapeHtml(opts.actorName)}</strong>` : ""},</p>
    <p>${isInstall ? "A request was made to run the <strong>Yuitor Platform Installer</strong> and initialize the Super Admin account." : "A sign-in attempt was verified with your administrator password for the <strong>Yuitor Admin Console</strong>."}</p>
    <div style="margin:20px 0;padding:18px 20px;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc;text-align:center;">
      <div style="font-size:12px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#475569;margin-bottom:6px;">
        One-Time Verification Code (Valid for 10 Minutes)
      </div>
      <div style="font-size:32px;font-weight:800;letter-spacing:0.24em;color:#0f172a;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;">
        ${escapeHtml(otp)}
      </div>
    </div>
    <p style="font-size:13px;color:#475569;">
      <strong>Request IP:</strong> ${escapeHtml(opts.ip)}<br>
      <strong>Timestamp (UTC):</strong> ${escapeHtml(nowIso())}
    </p>
    <p style="font-size:13px;color:#b91c1c;">
      Do not share this code with anyone. If you did not initiate this request, secure your Secret Admin URL immediately.
    </p>`;
  return sendTransactionalEmail({
    to: toEmail,
    recipientName: opts.actorName || "Yuitor Administrator",
    subject,
    previewText: `Your Yuitor verification OTP is ${otp} (valid 10 minutes).`,
    htmlBody,
    smtpOverride: opts.smtpOverride
  });
}
function createAdminGateAuthRouter(db) {
  const router = Router();
  router.use((_req, res, next) => {
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  const checkInstallerAvailability = () => {
    const adminCount = Number(db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get()?.c || 0);
    const lockRow = db.prepare("SELECT value FROM system_settings WHERE key = 'INSTALLER_LOCKED'").get();
    if (adminCount > 0 || String(lockRow?.value || "") === "1") {
      return { available: false, status: 410, error: "First-time installer is permanently disabled after administrator setup." };
    }
    if (isInstallerWindowExpired()) {
      return { available: false, status: 410, error: "Installer setup window has expired. Update YU_ADMIN_SETUP_EXPIRES_AT in server .env if needed." };
    }
    return { available: true };
  };
  router.get("/installer/preflight", (req, res) => {
    try {
      const ip = clientIp(req);
      if (!isIpAllowedForAdmin(ip)) {
        res.status(403).json({ error: "Access restricted for this IP address." });
        return;
      }
      const gate = checkInstallerAvailability();
      if (!gate.available) {
        res.status(gate.status).json({ locked: true, error: gate.error });
        return;
      }
      const preflight = runInstallerPreflight(db);
      res.json({ ...preflight });
    } catch (err) {
      res.status(500).json({ ok: false, error: { step: "Preflight Check", whatFailed: "Unable to run installer preflight check." } });
    }
  });
  router.post("/installer/send-otp", async (req, res) => {
    const ip = clientIp(req);
    if (!isIpAllowedForAdmin(ip)) {
      res.status(403).json({ error: "Access restricted for this IP address." });
      return;
    }
    const gate = checkInstallerAvailability();
    if (!gate.available) {
      res.status(gate.status).json({ locked: true, error: gate.error });
      return;
    }
    if (req.body?.smtp && typeof req.body.smtp === "object") {
      writeAuditLog(db, {
        actorName: "Installer Guard",
        action: "installer_smtp_override_blocked",
        details: "Blocked attempt to supply custom SMTP settings via public installer request",
        ipAddress: ip
      });
      res.status(403).json({
        error: "Public SMTP configuration is disabled for security. Configure SMTP_HOST, SMTP_PORT, SMTP_USER, and SMTP_PASS in server .env."
      });
      return;
    }
    if (String(req.body?.otpEmail ?? "").trim()) {
      writeAuditLog(db, {
        actorName: "Installer Guard",
        action: "installer_email_override_blocked",
        details: "Blocked attempt to override installer OTP recipient email",
        ipAddress: ip
      });
      res.status(403).json({
        error: "Custom OTP recipient email is disabled. Installer OTP is delivered exclusively to OWNER_EMAIL configured in server .env."
      });
      return;
    }
    const otpLimitKey = `setup-otp:${ip}`;
    const rl = checkRateLimit(db, otpLimitKey, 6, 900, 900);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many Installer OTP requests. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }
    const setupKey = cleanText(req.body?.setupKey, 200);
    if (!verifySetupKey(setupKey)) {
      recordRateLimitHit(db, otpLimitKey, 900);
      writeAuditLog(db, {
        actorName: "Installer Guard",
        action: "installer_setup_key_rejected",
        details: "Invalid or unconfigured YU_ADMIN_SETUP_KEY on /installer/send-otp",
        ipAddress: ip
      });
      res.status(403).json({
        error: "Invalid or unconfigured YU_ADMIN_SETUP_KEY (minimum 16 characters required in server .env)."
      });
      return;
    }
    const targetOtpEmail = resolveInstallerOwnerEmail();
    if (!targetOtpEmail) {
      res.status(503).json({
        error: "OWNER_EMAIL (or ADMIN_OTP_EMAIL) must be configured in server .env before running first-time setup."
      });
      return;
    }
    const masked = maskEmailAddress(targetOtpEmail);
    if (!isSmtpConfigured()) {
      res.status(503).json({
        error: `SMTP mail server is not configured in server .env. Set SMTP_HOST, SMTP_PORT, SMTP_USER, and SMTP_PASS to deliver OTP to ${masked}.`
      });
      return;
    }
    recordRateLimitHit(db, otpLimitKey, 900);
    const { otp } = issueOtp(db, {
      userId: null,
      phone: "",
      email: targetOtpEmail,
      purpose: "admin_2fa"
    });
    const mailRes = await sendAdminGateOtpEmail(targetOtpEmail, otp, {
      mode: "installer",
      ip
    });
    if (!mailRes.ok) {
      db.prepare("DELETE FROM otp_tokens WHERE email = ? AND purpose = 'admin_2fa' AND consumed_at IS NULL").run(targetOtpEmail);
      res.status(502).json({ error: "Could not send Installer verification OTP email. Verify server .env SMTP credentials." });
      return;
    }
    writeInstallLog("Installer OTP Sent", `6-digit setup verification OTP sent to ${masked}`);
    res.json({
      sent: true,
      recipientMasked: masked,
      expiresInSeconds: 600,
      message: `6-digit verification OTP sent to ${masked}. Check Inbox / Spam folder.`
    });
  });
  router.post("/installer/run", (req, res) => {
    const ip = clientIp(req);
    if (!isIpAllowedForAdmin(ip)) {
      res.status(403).json({ error: "Access restricted for this IP address." });
      return;
    }
    const gate = checkInstallerAvailability();
    if (!gate.available) {
      res.status(gate.status).json({ locked: true, error: gate.error });
      return;
    }
    const rl = checkRateLimit(db, `setup:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many setup attempts. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }
    const setupKey = cleanText(req.body?.setupKey, 200);
    if (!verifySetupKey(setupKey)) {
      recordRateLimitHit(db, `setup:${ip}`, 900);
      writeAuditLog(db, {
        actorName: "Installer Guard",
        action: "installer_setup_key_rejected",
        details: "Invalid or unconfigured YU_ADMIN_SETUP_KEY on /installer/run",
        ipAddress: ip
      });
      res.status(403).json({
        error: "Invalid or unconfigured YU_ADMIN_SETUP_KEY (minimum 16 characters required in server .env)."
      });
      return;
    }
    const preflight = runInstallerPreflight(db);
    if (!preflight.ok) {
      res.status(400).json({
        error: preflight.error?.whatFailed || "Pre-install checks failed.",
        structuredError: preflight.error
      });
      return;
    }
    if (preflight.existingState.userCount > 0 && req.body?.confirmExistingDb !== true) {
      res.status(409).json({
        requiresConfirmation: true,
        confirmationType: "existing_db",
        error: "Existing database tables contain user records. Confirm to safely create the Super Admin without modifying existing data."
      });
      return;
    }
    const otpEmail = resolveInstallerOwnerEmail();
    if (!otpEmail) {
      res.status(503).json({ error: "OWNER_EMAIL must be configured in server .env to complete setup." });
      return;
    }
    const maskedOtpEmail = maskEmailAddress(otpEmail);
    const otpCode = cleanText(req.body?.otp, 12);
    if (!/^\d{6}$/.test(otpCode)) {
      res.status(400).json({ error: `Enter the 6-digit Email OTP sent to ${maskedOtpEmail}.` });
      return;
    }
    const otpVerify = verifyOtpToken(db, {
      target: otpEmail,
      purpose: "admin_2fa",
      otp: otpCode
    });
    if (!otpVerify.ok) {
      recordRateLimitHit(db, `setup:${ip}`, 900);
      res.status(403).json({ error: otpVerify.error });
      return;
    }
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    if (fullName.length < 2 || !isValidEmail(email) || password.length < 10) {
      res.status(400).json({
        error: "Enter a valid full name, email address, and a strong password (minimum 10 characters)."
      });
      return;
    }
    const existingEmail = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (existingEmail) {
      res.status(409).json({ error: "A user with this email already exists." });
      return;
    }
    const now = nowIso();
    try {
      const adminId = runInTransaction(db, () => {
        const currentAdmins = Number(db.prepare("SELECT COUNT(*) as c FROM users WHERE role IN ('super_admin', 'admin')").get()?.c || 0);
        if (currentAdmins > 0) {
          throw new Error("INSTALLER_ALREADY_COMPLETED");
        }
        const result = db.prepare(
          `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
             VALUES ('super_admin', ?, ?, ?, ?, 1, 'approved', 1, 0, ?, ?, ?)`
        ).run(
          fullName,
          email,
          phone || "7827289292",
          hashPassword(password),
          crypto4.randomBytes(18).toString("hex"),
          now,
          now
        );
        db.prepare(
          "INSERT OR REPLACE INTO system_settings (key, value, is_secret, updated_at, updated_by) VALUES ('INSTALLER_LOCKED', '1', 0, ?, ?)"
        ).run(now, Number(result.lastInsertRowid));
        db.prepare("DELETE FROM otp_tokens WHERE purpose = 'admin_2fa' AND user_id IS NULL").run();
        return Number(result.lastInsertRowid);
      });
      const adminPath = getAdminPath(db);
      try {
        const hintFile = path6.join(LOGS_DIR, "install-gate-url.txt");
        if (fs7.existsSync(hintFile)) fs7.unlinkSync(hintFile);
      } catch {
      }
      clearRateLimit(db, `setup:${ip}`);
      clearRateLimit(db, `setup-otp:${ip}`);
      writeInstallLog("Installer Completed", `First Super Admin initialized (id=${adminId}) via ${maskedOtpEmail} OTP; installer permanently locked.`);
      writeAuditLog(db, {
        actorId: adminId,
        actorName: fullName,
        targetId: adminId,
        targetName: fullName,
        action: "super_admin_initialized",
        details: "Initial Super Admin created via one-time OTP-protected installer (installer locked)",
        ipAddress: ip
      });
      res.status(201).json({
        created: true,
        locked: true,
        message: "Super Admin created and first-time installer permanently disabled."
      });
    } catch (err) {
      if (String(err?.message) === "INSTALLER_ALREADY_COMPLETED") {
        res.status(410).json({ locked: true, error: "First-time installer has already been completed." });
        return;
      }
      res.status(500).json({ error: "Failed to initialize Super Admin account." });
    }
  });
  router.post("/auth/login", async (req, res) => {
    const ip = clientIp(req);
    const ua = String(req.headers["user-agent"] || "");
    const identifier = cleanText(req.body?.identifier, 254);
    const password = String(req.body?.password || "");
    if (!isIpAllowedForAdmin(ip)) {
      recordAdminLoginAttempt(db, {
        identifier,
        ipAddress: ip,
        userAgent: ua,
        outcome: "blocked_ip",
        reason: "IP outside ADMIN_IP_ALLOWLIST"
      });
      res.status(403).json({ error: "Access denied from your current IP address." });
      return;
    }
    const rateKey = `adminlogin:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, rateKey, 5, 900, 900);
    if (!rl.allowed) {
      recordAdminLoginAttempt(db, {
        identifier,
        ipAddress: ip,
        userAgent: ua,
        outcome: "locked_out",
        reason: `Lockout active (${rl.retryAfterSeconds}s remaining)`
      });
      res.status(429).json({
        error: `Too many failed administrator login attempts. Account sign-in temporarily locked for ${rl.retryAfterSeconds}s.`
      });
      return;
    }
    if (!identifier || !password) {
      res.status(400).json({ error: "Enter both email/mobile and password." });
      return;
    }
    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db.prepare("SELECT * FROM users WHERE (email = ? OR (phone != '' AND phone = ?)) AND role IN ('admin', 'super_admin') LIMIT 1").get(normalizedEmail, normalizedPhone);
    const dummyHash = "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";
    const ok = verifyPassword(password, user ? user.password_hash : dummyHash);
    if (!user || !ok) {
      recordRateLimitHit(db, rateKey, 900);
      recordAdminLoginAttempt(db, {
        identifier,
        ipAddress: ip,
        userAgent: ua,
        outcome: "failed",
        reason: user ? "Invalid password" : "Admin account not found or non-admin role"
      });
      res.status(401).json({ error: "Incorrect administrator credentials." });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status !== "approved") {
      recordAdminLoginAttempt(db, {
        identifier,
        ipAddress: ip,
        userAgent: ua,
        outcome: "disabled",
        reason: `Status: ${user.verification_status}`
      });
      res.status(403).json({ error: "This administrator account is currently disabled." });
      return;
    }
    const otpEmail = getAdminOtpEmail();
    const maskedOtpEmail = maskEmailAddress(otpEmail);
    if (!isSmtpConfigured()) {
      recordAdminLoginAttempt(db, {
        identifier: user.email,
        ipAddress: ip,
        userAgent: ua,
        outcome: "otp_smtp_missing",
        reason: "SMTP credentials missing for mandatory Admin Email OTP"
      });
      res.status(503).json({
        error: `Admin Email OTP requires SMTP configuration. Configure SMTP_HOST, SMTP_USER, and SMTP_PASS in yuitor_core/.env to deliver OTP to ${maskedOtpEmail}.`
      });
      return;
    }
    const { otp } = issueOtp(db, {
      userId: Number(user.id),
      phone: "",
      email: otpEmail,
      purpose: "admin_2fa"
    });
    const mailRes = await sendAdminGateOtpEmail(otpEmail, otp, {
      mode: "admin_login",
      ip,
      actorName: user.full_name
    });
    if (!mailRes.ok) {
      db.prepare("DELETE FROM otp_tokens WHERE user_id = ? AND email = ? AND purpose = 'admin_2fa' AND consumed_at IS NULL").run(
        Number(user.id),
        otpEmail
      );
      recordAdminLoginAttempt(db, {
        identifier: user.email,
        ipAddress: ip,
        userAgent: ua,
        outcome: "otp_send_failed",
        reason: cleanText(mailRes.error || "SMTP delivery failed", 200)
      });
      res.status(502).json({
        error: `Could not send verification OTP email to ${maskedOtpEmail}: ${mailRes.error || "SMTP delivery error"}.`
      });
      return;
    }
    const expiresUnix = Math.floor(Date.now() / 1e3) + 600;
    const challengeToken = signAdminOtpChallenge(Number(user.id), expiresUnix, crypto4.randomBytes(16).toString("hex"));
    clearRateLimit(db, rateKey);
    recordAdminLoginAttempt(db, {
      identifier: user.email,
      ipAddress: ip,
      userAgent: ua,
      outcome: "otp_sent",
      reason: `2FA OTP emailed to ${maskedOtpEmail}`
    });
    res.json({
      authenticated: false,
      otpRequired: true,
      challengeToken,
      recipientMasked: maskedOtpEmail,
      expiresInSeconds: 600,
      message: `Password verified. Enter the 6-digit OTP sent to ${maskedOtpEmail}.`
    });
  });
  router.post("/auth/verify-otp", (req, res) => {
    const ip = clientIp(req);
    const ua = String(req.headers["user-agent"] || "");
    if (!isIpAllowedForAdmin(ip)) {
      res.status(403).json({ error: "Access denied from your current IP address." });
      return;
    }
    const otpRateKey = `adminotp:${ip}`;
    const rl = checkRateLimit(db, otpRateKey, 5, 900, 900);
    if (!rl.allowed) {
      res.status(429).json({
        error: `Too many invalid OTP attempts. Try again in ${rl.retryAfterSeconds}s.`
      });
      return;
    }
    const challengeToken = cleanText(req.body?.challengeToken, 400);
    const otpCode = cleanText(req.body?.otp, 12);
    const verifiedChallenge = verifyAdminOtpChallenge(challengeToken);
    if (!verifiedChallenge.ok) {
      recordRateLimitHit(db, otpRateKey, 900);
      res.status(401).json({ error: "Your sign-in verification session expired. Please sign in with your password again." });
      return;
    }
    if (!/^\d{6}$/.test(otpCode)) {
      res.status(400).json({ error: "Enter the 6-digit OTP sent to your verification email." });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('admin', 'super_admin') AND is_active = 1 AND verification_status = 'approved'").get(verifiedChallenge.userId);
    if (!user) {
      res.status(403).json({ error: "Administrator account unavailable or disabled." });
      return;
    }
    const otpEmail = getAdminOtpEmail();
    const otpVerify = verifyOtpToken(db, {
      target: otpEmail,
      purpose: "admin_2fa",
      otp: otpCode
    });
    if (!otpVerify.ok || Number(otpVerify.tokenRow.user_id) !== Number(user.id)) {
      recordRateLimitHit(db, otpRateKey, 900);
      recordAdminLoginAttempt(db, {
        identifier: user.email,
        ipAddress: ip,
        userAgent: ua,
        outcome: "otp_failed",
        reason: otpVerify.ok ? "OTP challenge mismatch" : otpVerify.error
      });
      res.status(401).json({ error: otpVerify.ok ? "Invalid OTP challenge." : otpVerify.error });
      return;
    }
    const prevCtx = getSessionContext(db, req);
    clearRateLimit(db, otpRateKey);
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    const sid = createSession(db, Number(user.id), { replaceSessionId: prevCtx?.sessionId });
    setSessionCookie(res, req, sid);
    recordAdminLoginAttempt(db, {
      identifier: user.email,
      ipAddress: ip,
      userAgent: ua,
      outcome: "success",
      reason: `${user.role} signed in with Email OTP`
    });
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "admin_login_success",
      details: `${user.role} signed in via secret admin gate + Email OTP`,
      ipAddress: ip
    });
    res.json({
      authenticated: true,
      role: user.role,
      adminGatePath: `/${getAdminPath(db)}/`
    });
  });
  router.post("/auth/resend-otp", async (req, res) => {
    const ip = clientIp(req);
    if (!isIpAllowedForAdmin(ip)) {
      res.status(403).json({ error: "Access denied from your current IP address." });
      return;
    }
    const challengeToken = cleanText(req.body?.challengeToken, 400);
    const verifiedChallenge = verifyAdminOtpChallenge(challengeToken);
    if (!verifiedChallenge.ok) {
      res.status(401).json({ error: "Your sign-in verification session expired. Please enter your password again." });
      return;
    }
    const resendKey = `adminotpresend:${ip}:${verifiedChallenge.userId}`;
    const rl = checkRateLimit(db, resendKey, 3, 600, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `OTP resend limit reached. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('admin', 'super_admin') AND is_active = 1 AND verification_status = 'approved'").get(verifiedChallenge.userId);
    if (!user) {
      res.status(403).json({ error: "Administrator account unavailable." });
      return;
    }
    const otpEmail = getAdminOtpEmail();
    const maskedOtpEmail = maskEmailAddress(otpEmail);
    const { otp } = issueOtp(db, {
      userId: Number(user.id),
      phone: "",
      email: otpEmail,
      purpose: "admin_2fa"
    });
    const mailRes = await sendAdminGateOtpEmail(otpEmail, otp, {
      mode: "admin_login",
      ip,
      actorName: user.full_name
    });
    if (!mailRes.ok) {
      res.status(502).json({ error: `Could not resend OTP email: ${mailRes.error || "SMTP delivery failed"}.` });
      return;
    }
    recordRateLimitHit(db, resendKey, 600);
    res.json({
      sent: true,
      recipientMasked: maskedOtpEmail,
      expiresInSeconds: 600,
      message: `A fresh 6-digit OTP was sent to ${maskedOtpEmail}.`
    });
  });
  return router;
}

// server/routes/auth.ts
import { Router as Router2 } from "express";
import crypto5 from "node:crypto";
import fs8 from "node:fs";
import path7 from "node:path";
import multer from "multer";
var RESUME_ALLOWED_EXT = /* @__PURE__ */ new Set([".pdf", ".doc", ".docx"]);
var RESUME_ALLOWED_MIME = /* @__PURE__ */ new Set([
  "application/pdf",
  "application/x-pdf",
  "application/msword",
  "application/rtf",
  "text/rtf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]);
var RESUME_MAX_BYTES = 5 * 1024 * 1024;
function createResumeUploader() {
  fs8.mkdirSync(RESUMES_DIR, { recursive: true, mode: 0o700 });
  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, RESUMES_DIR),
    filename: (_req, file, cb) => {
      const ext = path7.extname(file.originalname || "").toLowerCase();
      const safeExt = RESUME_ALLOWED_EXT.has(ext) ? ext : ".pdf";
      cb(null, `resume-${Date.now()}-${crypto5.randomBytes(12).toString("hex")}${safeExt}`);
    }
  });
  return multer({
    storage,
    limits: { fileSize: RESUME_MAX_BYTES },
    fileFilter: (_req, file, cb) => {
      const ext = path7.extname(file.originalname || "").toLowerCase();
      if (!RESUME_ALLOWED_EXT.has(ext)) {
        cb(new Error("Please upload your resume in PDF, DOC, or DOCX format (max 5 MB)."));
        return;
      }
      const mime = String(file.mimetype || "").split(";")[0].trim().toLowerCase();
      if (mime && !RESUME_ALLOWED_MIME.has(mime)) {
        cb(new Error("Unsupported resume MIME type. Please upload a valid PDF, DOC, or DOCX file."));
        return;
      }
      cb(null, true);
    }
  }).single("resume");
}
var resumeUploadMiddleware = createResumeUploader();
function runResumeUpload(req, res) {
  return new Promise((resolve, reject) => {
    resumeUploadMiddleware(req, res, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}
function removeUploadedFile(file) {
  if (file?.path && fs8.existsSync(file.path)) {
    try {
      fs8.unlinkSync(file.path);
    } catch {
    }
  }
}
function verifyResumeFile(file) {
  if (!file || !file.path) {
    return { ok: false, code: "RESUME_REQUIRED", error: TEACHER_MISSING_RESUME_MSG };
  }
  return verifyResumeDocumentContent(
    file.path,
    file.originalname || file.filename,
    file.mimetype || "",
    RESUME_ALLOWED_EXT
  );
}
function parseListField(raw) {
  if (Array.isArray(raw)) {
    return raw.map((x) => cleanText(x, 60)).filter(Boolean);
  }
  const str = String(raw || "").trim();
  if (!str) return [];
  if (str.startsWith("[")) {
    try {
      const parsed = JSON.parse(str);
      if (Array.isArray(parsed)) return parsed.map((x) => cleanText(x, 60)).filter(Boolean);
    } catch {
    }
  }
  return str.split(",").map((x) => cleanText(x, 60)).filter(Boolean);
}
function getTeacherResumeSummary(db, userId) {
  const tp = db.prepare("SELECT resume_url, resume_filename, resume_status, resume_uploaded_at, resume_notes FROM teacher_profiles WHERE user_id = ?").get(userId);
  const hasFile = Boolean(tp?.resume_url);
  const status = tp?.resume_status || "missing";
  const valid = hasFile && ["submitted", "verified"].includes(status);
  return {
    hasResume: valid,
    resumeStatus: status,
    resumeFilename: tp?.resume_filename || "",
    resumeUploadedAt: tp?.resume_uploaded_at || null,
    resumeNotes: tp?.resume_notes || "",
    missingResumeMessage: valid ? "" : TEACHER_MISSING_RESUME_MSG
  };
}
function createAuthRouter(db) {
  const router = Router2();
  router.post("/verify-resume", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `resumecheck:${ip}`, 20, 900, 180);
    if (!rl.allowed) {
      res.status(429).json({ valid: false, error: `Too many resume verification attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `resumecheck:${ip}`, 900);
    try {
      await runResumeUpload(req, res);
    } catch (err) {
      removeUploadedFile(req.file);
      res.status(400).json({ valid: false, code: "INVALID_RESUME_FORMAT", error: err?.message || "Invalid resume file. Upload a valid PDF, DOC, or DOCX up to 5 MB." });
      return;
    }
    if (!req.file || req.file.size === 0) {
      removeUploadedFile(req.file);
      res.status(400).json({ valid: false, code: "RESUME_REQUIRED", error: TEACHER_MISSING_RESUME_MSG });
      return;
    }
    const result = verifyResumeFile(req.file);
    removeUploadedFile(req.file);
    if (!result.ok) {
      res.status(400).json({
        valid: false,
        code: result.code || "NOT_A_RESUME",
        error: result.error || "Uploaded file could not be verified as a genuine Resume / CV."
      });
      return;
    }
    res.json({
      valid: true,
      code: result.code,
      format: result.format,
      wordCount: result.wordCount,
      categories: result.categories,
      summary: result.summary
    });
  });
  router.post("/register", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `reg:${ip}`, 10, 900, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many registration requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `reg:${ip}`, 900);
    if (req.is("multipart/form-data")) {
      try {
        await runResumeUpload(req, res);
      } catch (err) {
        removeUploadedFile(req.file);
        res.status(400).json({ error: err?.message || "Invalid resume file. Please upload a PDF, DOC, or DOCX up to 5 MB." });
        return;
      }
    }
    const rawRole = String(req.body?.role || "student").toLowerCase();
    const role = rawRole === "teacher" ? "teacher" : rawRole === "parent" ? "parent" : "student";
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    const fail = (status, error, extra) => {
      removeUploadedFile(req.file);
      res.status(status).json({ error, ...extra || {} });
    };
    if (fullName.length < 2) {
      fail(400, "Please enter your full name.");
      return;
    }
    if (!isValidEmail(email)) {
      fail(400, "Please enter a valid email address.");
      return;
    }
    if (!isValidIndianMobile(phone)) {
      fail(400, "Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.");
      return;
    }
    if (password.length < 8 || password.length > 200) {
      fail(400, "Password must be at least 8 characters.");
      return;
    }
    let verifiedResumeInfo = null;
    if (role === "teacher") {
      if (!req.file || req.file.size === 0) {
        fail(400, TEACHER_MISSING_RESUME_MSG, { code: "RESUME_REQUIRED" });
        return;
      }
      const resumeCheck = verifyResumeFile(req.file);
      if (!resumeCheck.ok) {
        fail(400, resumeCheck.error || "The uploaded file could not be verified as a valid Resume / CV. Please upload your actual Resume in PDF, DOC, or DOCX format.", { code: resumeCheck.code || "NOT_A_RESUME" });
        return;
      }
      verifiedResumeInfo = resumeCheck;
    } else if (req.file) {
      removeUploadedFile(req.file);
    }
    const existing = db.prepare("SELECT id, role, full_name, email, phone, verification_status FROM users WHERE email = ? OR phone = ?").get(email, phone);
    const normalizeOtpChannel = (raw) => {
      const v = String(raw || "").trim().toLowerCase();
      if (v === "sms" || v === "mobile" || v === "phone") return "sms";
      return "email";
    };
    const maskOtpTarget = (channel, targetEmail, targetPhone) => {
      if (channel === "email") {
        const parts = String(targetEmail || "").split("@");
        if (parts.length !== 2) return targetEmail;
        const name = parts[0];
        const visible = name.length <= 2 ? name[0] || "*" : `${name.slice(0, 2)}***`;
        return `${visible}@${parts[1]}`;
      }
      const p = String(targetPhone || "");
      return p.length >= 4 ? `******${p.slice(-4)}` : p;
    };
    const otpChannel = normalizeOtpChannel(req.body?.otpChannel);
    if (existing) {
      if (existing.verification_status === "pending_otp" && existing.role === role) {
        removeUploadedFile(req.file);
        const { otp: resumeOtp } = issueOtp(db, { userId: existing.id, phone: existing.phone, email: existing.email, purpose: "registration" });
        let rEmailSent = false;
        let rSmsSent = false;
        let rNote = "";
        if (otpChannel === "email") {
          if (isSmtpConfigured() && existing.email) {
            const mailRes = await sendTransactionalEmail({
              to: existing.email,
              recipientName: existing.full_name || fullName || "Member",
              subject: "Yuitor Smart Classes — 6-Digit Registration OTP",
              previewText: `Your 6-digit registration OTP is ${resumeOtp}. Valid for 10 minutes.`,
              htmlBody: `<p>Hello {{name}},</p><p>Your 6-digit verification OTP for Yuitor Smart Classes registration is:</p><p style="font-size:24px;font-weight:700;letter-spacing:4px;color:#7A0F28;margin:14px 0;">${escapeHtml(resumeOtp)}</p><p>This OTP is valid for 10 minutes. Never share this code with anyone.</p>`,
              department: "inquiry"
            });
            rEmailSent = Boolean(mailRes?.ok || mailRes?.sent);
            if (!rEmailSent) {
              rNote = mailRes?.error || "Email SMTP delivery could not complete. Try Mobile OTP or contact +91 78-2728-9292.";
            }
          } else {
            rNote = "SMTP mail server is not configured yet on this server. Ask Admin to configure SMTP in Settings or switch to Mobile OTP / call +91 78-2728-9292.";
          }
        } else {
          const sms = await dispatchSmsOtp(existing.phone, resumeOtp, "registration");
          rSmsSent = Boolean(sms.sent);
          if (!rSmsSent) rNote = sms.note;
        }
        const rMasked = maskOtpTarget(otpChannel, existing.email, existing.phone);
        res.status(200).json({
          registered: true,
          resumedPendingOtp: true,
          role: existing.role,
          phone: existing.phone,
          email: existing.email,
          otpChannel,
          otpTargetMasked: rMasked,
          emailSent: rEmailSent,
          smsSent: rSmsSent,
          message: otpChannel === "email"
            ? (rEmailSent ? `A fresh 6-digit OTP has been emailed to ${rMasked}. Please check Inbox / Spam.` : rNote)
            : (rSmsSent ? `A fresh 6-digit OTP has been sent via SMS to ${rMasked}.` : rNote),
          limitationNote: (rEmailSent || rSmsSent) ? "" : rNote,
          resumeSubmitted: existing.role === "teacher"
        });
        return;
      }
      fail(409, "An account already exists with this email or mobile number. Try signing in instead.");
      return;
    }
    const qualification = role === "teacher" ? cleanText(req.body?.qualification || "", 120) : "";
    if (role === "teacher" && qualification.length < 2) {
      fail(400, "Qualification is required for teacher registration.");
      return;
    }
    const now = nowIso();
    const unsubToken = crypto5.randomBytes(18).toString("hex");
    const insertUser = db.prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 0, 'pending_otp', 1, 1, ?, ?, ?)`
    ).run(role, fullName, email, phone, hashPassword(password), unsubToken, now, now);
    const uid = Number(insertUser.lastInsertRowid);
    const subjects = parseListField(req.body?.subjects);
    if (role === "student") {
      const classLevel = cleanText(req.body?.classLevel || "Class 10", 60);
      const board = cleanText(req.body?.board || "UP Board", 40);
      const duration = Math.min(60, Math.max(1, Number(req.body?.courseDurationMonths || 12)));
      const parentPhone = normalizePhone(req.body?.parentPhone || "");
      const rollNumber = `YTR-STU-${String(uid).padStart(4, "0")}`;
      const branchId = req.body?.branchId ? Number(req.body.branchId) : null;
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, subjects_json, course_duration_months, parent_phone, enrollment_status, roll_number, branch_id)
         VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)`
      ).run(uid, classLevel, board, JSON.stringify(subjects), duration, parentPhone, rollNumber, branchId || null);
    } else if (role === "parent") {
      // Security: Never auto-link a parent to a student using unverified roll number or phone on signup.
      // Create a pending Admin approval request instead (or allow verified parent mobile + OTP after sign-in).
      const studentPhone = normalizePhone(req.body?.studentPhone || "");
      const studentRoll = cleanText(req.body?.studentRoll || "", 40).toUpperCase();
      const relation = cleanText(req.body?.relation || "Parent / Guardian", 60) || "Parent / Guardian";
      let matchedStudent;
      if (studentRoll) {
        matchedStudent = db.prepare("SELECT u.id FROM users u JOIN student_profiles sp ON sp.user_id = u.id WHERE u.role = 'student' AND UPPER(sp.roll_number) = ? LIMIT 1").get(studentRoll);
      }
      if (!matchedStudent && studentPhone) {
        matchedStudent = db.prepare(
          `SELECT u.id FROM users u
             LEFT JOIN student_profiles sp ON sp.user_id = u.id
             WHERE u.role = 'student' AND sp.parent_phone = ?
             LIMIT 1`
        ).get(studentPhone);
      }
      if (matchedStudent) {
        db.prepare(
          `INSERT OR IGNORE INTO parent_link_requests (parent_user_id, student_user_id, relation, status, requested_by_ip, created_at)
           VALUES (?, ?, ?, 'pending', ?, ?)`
        ).run(uid, matchedStudent.id, relation, ip, now);
        writeAuditLog(db, {
          actorId: uid,
          actorName: fullName,
          targetId: matchedStudent.id,
          targetName: `Student #${matchedStudent.id}`,
          action: "parent_link_requested_on_signup",
          details: "Pending Admin approval or verified parent mobile OTP",
          ipAddress: ip
        });
      }
    } else {
      const experienceYears = Math.min(50, Math.max(0, Number(req.body?.experienceYears || 0)));
      const assignedClasses = parseListField(req.body?.assignedClasses);
      const resumeFile = req.file;
      db.prepare(
        `INSERT INTO teacher_profiles (
           user_id, qualification, experience_years, subjects_json, assigned_classes_json, availability_status,
           resume_url, resume_filename, resume_mime, resume_size, resume_status, resume_uploaded_at, resume_notes
         ) VALUES (?, ?, ?, ?, ?, 'available', ?, ?, ?, ?, 'verified', ?, ?)`
      ).run(
        uid,
        qualification,
        experienceYears,
        JSON.stringify(subjects),
        JSON.stringify(assignedClasses),
        `resumes/${resumeFile.filename}`,
        cleanText(resumeFile.originalname || resumeFile.filename, 180),
        cleanText(resumeFile.mimetype || "application/pdf", 120),
        Number(resumeFile.size || 0),
        now,
        cleanText(verifiedResumeInfo?.summary || "Auto-verified resume", 240)
      );
    }
    const { otp } = issueOtp(db, { userId: uid, phone, email, purpose: "registration" });
    let smsSent = false;
    let emailSent = false;
    let deliveryNote = "";
    if (otpChannel === "email") {
      if (isSmtpConfigured() && email) {
        const mailRes = await sendTransactionalEmail({
          to: email,
          recipientName: fullName || "Member",
          subject: "Yuitor Smart Classes — 6-Digit Registration OTP",
          previewText: `Your 6-digit registration OTP is ${otp}. Valid for 10 minutes.`,
          htmlBody: `<p>Hello {{name}},</p><p>Your 6-digit verification OTP for Yuitor Smart Classes registration is:</p><p style="font-size:24px;font-weight:700;letter-spacing:4px;color:#7A0F28;margin:14px 0;">${escapeHtml(otp)}</p><p>This OTP is valid for 10 minutes. Never share this code with anyone.</p>`,
          department: "inquiry"
        });
        emailSent = Boolean(mailRes?.ok || mailRes?.sent);
        if (!emailSent) {
          deliveryNote = mailRes?.error || "Email SMTP delivery could not complete. You can switch to Mobile OTP or contact +91 78-2728-9292.";
        }
      } else {
        deliveryNote = "SMTP mail server is not configured yet on this server. Ask Admin to configure SMTP in Settings or switch to Mobile OTP / call +91 78-2728-9292.";
      }
    } else {
      const sms = await dispatchSmsOtp(phone, otp, "registration");
      smsSent = Boolean(sms.sent);
      if (!smsSent) deliveryNote = sms.note;
    }
    const targetMasked = maskOtpTarget(otpChannel, email, phone);
    writeAuditLog(db, {
      actorId: uid,
      actorName: fullName,
      targetId: uid,
      targetName: fullName,
      action: `${role}_registered`,
      details: role === "teacher" ? `Teacher registered with resume (${req.file?.originalname || "uploaded"}); OTP issued via ${otpChannel} to ${targetMasked}` : `OTP issued via ${otpChannel} to ${targetMasked} (sent: ${emailSent || smsSent})`,
      ipAddress: ip
    });
    if (role === "student" || role === "teacher") {
      try {
        ensureReferralProfile(db, uid, role);
        if (role === "student" && req.body?.referralCode) {
          await attributeReferralSignup(
            db,
            { referredUserId: uid, referredRole: role, referralCode: req.body.referralCode, signupIp: ip },
            { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
          );
        }
      } catch {
        // Non-blocking referral attribution guard
      }
    }
    res.status(201).json({
      registered: true,
      role,
      phone,
      email,
      otpChannel,
      otpTargetMasked: targetMasked,
      emailSent,
      smsSent,
      limitationNote: deliveryNote,
      resumeSubmitted: role === "teacher"
    });
  });
  router.post("/teacher-resume", async (req, res) => {
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `resume:${ip}`, 10, 900, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many resume upload attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `resume:${ip}`, 900);
    try {
      await runResumeUpload(req, res);
    } catch (err) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: err?.message || "Invalid resume file. Upload PDF, DOC, or DOCX up to 5 MB." });
      return;
    }
    if (!req.file || req.file.size === 0) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: TEACHER_MISSING_RESUME_MSG, code: "RESUME_REQUIRED" });
      return;
    }
    const resumeCheck = verifyResumeFile(req.file);
    if (!resumeCheck.ok) {
      removeUploadedFile(req.file);
      res.status(400).json({ error: resumeCheck.error || "Uploaded file could not be verified as a valid Resume / CV.", code: resumeCheck.code || "NOT_A_RESUME" });
      return;
    }
    let teacherUser = null;
    const ctx = getSessionContext(db, req);
    if (ctx && ctx.user.role === "teacher") {
      teacherUser = ctx.user;
    } else {
      const identifier = cleanText(req.body?.identifier, 254);
      const password = String(req.body?.password || "");
      const candidate = db.prepare("SELECT * FROM users WHERE role = 'teacher' AND (email = ? OR (phone != '' AND phone = ?)) LIMIT 1").get(normalizeEmail(identifier), normalizePhone(identifier));
      if (!candidate || !verifyPassword(password, candidate.password_hash)) {
        removeUploadedFile(req.file);
        res.status(401).json({ error: "Please sign in as a registered teacher to upload your resume." });
        return;
      }
      teacherUser = candidate;
    }
    const existingTp = db.prepare("SELECT resume_url FROM teacher_profiles WHERE user_id = ?").get(teacherUser.id);
    const oldResumeRel = existingTp?.resume_url ? String(existingTp.resume_url) : "";
    const now = nowIso();
    const resumeFile = req.file;
    const newRel = `resumes/${resumeFile.filename}`;
    db.prepare(
      `INSERT INTO teacher_profiles (
         user_id, resume_url, resume_filename, resume_mime, resume_size, resume_status, resume_uploaded_at, resume_notes
       ) VALUES (?, ?, ?, ?, ?, 'verified', ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         resume_url = excluded.resume_url,
         resume_filename = excluded.resume_filename,
         resume_mime = excluded.resume_mime,
         resume_size = excluded.resume_size,
         resume_status = 'verified',
         resume_uploaded_at = excluded.resume_uploaded_at,
         resume_notes = excluded.resume_notes`
    ).run(
      teacherUser.id,
      newRel,
      cleanText(resumeFile.originalname || resumeFile.filename, 180),
      cleanText(resumeFile.mimetype || "application/pdf", 120),
      Number(resumeFile.size || 0),
      now,
      cleanText(resumeCheck.summary || "Auto-verified resume", 240)
    );
    if (oldResumeRel && oldResumeRel !== newRel) {
      const oldFull = path7.join(RESUMES_DIR, path7.basename(oldResumeRel));
      if (oldFull.startsWith(RESUMES_DIR) && fs8.existsSync(oldFull)) {
        try {
          fs8.unlinkSync(oldFull);
        } catch {
        }
      }
    }
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `Teacher resume verified`,
      `${teacherUser.full_name} uploaded verified resume (${resumeFile.originalname || resumeFile.filename}).`,
      now
    );
    writeAuditLog(db, {
      actorId: teacherUser.id,
      actorName: teacherUser.full_name,
      targetId: teacherUser.id,
      targetName: teacherUser.full_name,
      action: "teacher_resume_uploaded",
      details: `Uploaded & verified ${resumeFile.originalname || resumeFile.filename} (${resumeFile.size} bytes)`,
      ipAddress: clientIp(req)
    });
    res.json({
      uploaded: true,
      resumeFilename: cleanText(resumeFile.originalname || resumeFile.filename, 180),
      resumeStatus: "verified",
      resumeSummary: resumeCheck.summary,
      resumeUploadedAt: now
    });
  });
  router.post("/verify-otp", async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    const email = normalizeEmail(req.body?.email);
    const otp = cleanText(req.body?.otp, 10);
    const target = isValidIndianMobile(phone) ? phone : email;
    const ip = clientIp(req);
    const rlKey = `otpverify:${ip}:${target}`;
    const rl = checkRateLimit(db, rlKey, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP verification attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!target || !/^\d{6}$/.test(otp)) {
      recordRateLimitHit(db, rlKey, 600);
      res.status(400).json({ error: "Enter a valid registered email/mobile and 6-digit OTP." });
      return;
    }
    let check = verifyOtpToken(db, { target, purpose: "registration", otp });
    if (!check.ok && email && target !== email) {
      check = verifyOtpToken(db, { target: email, purpose: "registration", otp });
    }
    if (!check.ok) {
      recordRateLimitHit(db, rlKey, 600);
      res.status(400).json({ error: check.error });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE id = ? OR (phone != '' AND phone = ?) OR (email != '' AND email = ?) LIMIT 1").get(check.tokenRow.user_id, phone, email);
    if (!user) {
      res.status(404).json({ error: "Account not found." });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }
    const teacherResume = user.role === "teacher" ? getTeacherResumeSummary(db, Number(user.id)) : null;
    if (user.role === "teacher" && !teacherResume?.hasResume) {
      res.status(400).json({
        error: TEACHER_MISSING_RESUME_MSG,
        code: "RESUME_REQUIRED",
        resumeRequired: true,
        teacherResume
      });
      return;
    }
    const now = nowIso();
    const nextStatus = "approved";
    db.prepare("UPDATE users SET mobile_verified = 1, verification_status = ?, last_login_at = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      now,
      now,
      user.id
    );
    if (user.role === "student") {
      db.prepare("UPDATE student_profiles SET enrollment_status = 'active' WHERE user_id = ? AND enrollment_status = 'pending'").run(user.id);
    }
    clearRateLimit(db, rlKey);
    const prevSid = verifySessionToken(req.cookies?.[SESSION_COOKIE]) || void 0;
    const sid = createSession(db, Number(user.id), { replaceSessionId: prevSid });
    setSessionCookie(res, req, sid);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(
      `New ${user.role} verified OTP & joined`,
      `${user.full_name} (${user.phone || user.email}) verified registration OTP and unlocked ${user.role} panel access.`,
      now
    );
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "registration_otp_verified",
      details: `OTP verified; ${user.role} account auto-activated and signed into portal`,
      ipAddress: ip
    });
    const notifyEmail = getAdminNotifyEmail();
    if (isSmtpConfigured() && notifyEmail) {
      void sendTransactionalEmail({
        to: notifyEmail,
        recipientName: "Yuitor Admissions Team",
        subject: `New ${user.role} joined (OTP Verified): ${user.full_name}`,
        previewText: `${user.full_name} verified registration OTP and entered the ${user.role} portal.`,
        htmlBody: `<p><strong>${escapeHtml(user.full_name)}</strong> (${escapeHtml(user.role)}, ${escapeHtml(user.phone)}, ${escapeHtml(user.email)}) verified registration OTP and was granted portal access automatically.</p>`
      });
    }
    const portalRedirect =
      user.role === "teacher" ? "/teacher/" :
      user.role === "parent" ? "/parent/" :
      user.role === "staff" ? "/staff/" :
      "/student/";
    const cfgWelcome = getAutomationConfig(db);
    if (Number(cfgWelcome?.welcome_emails_enabled ?? 1) === 1) {
      const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
      const spInfo = user.role === "student" ? db.prepare("SELECT roll_number FROM student_profiles WHERE user_id = ?").get(user.id) : null;
      const tpl = buildRoleWelcomeEmailTemplate({
        fullName: user.full_name || "Member",
        role: user.role,
        rollNumber: spInfo?.roll_number || "",
        portalUrl: `${siteUrl}${portalRedirect}`,
        siteUrl
      });
      try {
        const stamp = nowIso();
        db.prepare(`INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`).run(
          user.id,
          tpl.portalTitle,
          tpl.portalMessage,
          stamp
        );
        db.prepare(
          `INSERT INTO crm_celebration_logs (user_id, role, event_type, year_key, channel, recipient_email, subject, status, created_at)
           VALUES (?, ?, 'welcome_joining', ?, ?, ?, ?, ?, ?)`
        ).run(
          user.id,
          user.role,
          stamp.slice(0, 10),
          user.email ? "email_and_portal" : "portal",
          user.email || "",
          tpl.subject,
          isSmtpConfigured() && user.email ? "sent" : "portal_only",
          stamp
        );
      } catch {}
      if (isSmtpConfigured() && user.email) {
        void sendTransactionalEmail({
          to: user.email,
          recipientName: user.full_name || "Member",
          subject: tpl.subject,
          previewText: tpl.previewText,
          htmlBody: tpl.htmlBody,
          ctaLabel: tpl.ctaLabel,
          ctaUrl: tpl.ctaUrl
        });
      }
    }
    res.json({
      verified: true,
      authenticated: true,
      role: user.role,
      verificationStatus: nextStatus,
      redirectTo: portalRedirect,
      teacherResume,
      message: "OTP verified successfully! Entering your Yuitor portal now."
    });
  });
  router.post("/resend-otp", async (req, res) => {
    try {
    const phone = normalizePhone(req.body?.phone);
    const email = normalizeEmail(req.body?.email);
    const rawChannel = String(req.body?.otpChannel || "").trim().toLowerCase();
    const otpChannel = rawChannel === "sms" || rawChannel === "mobile" || rawChannel === "phone" ? "sms" : "email";
    const ip = clientIp(req);
    if (!isValidIndianMobile(phone) && !isValidEmail(email)) {
      res.status(400).json({ error: "Valid registered email or 10-digit mobile number is required." });
      return;
    }
    const rlTarget = phone || email;
    const rl = checkRateLimit(db, `otpresend:${ip}:${rlTarget}`, 5, 3600, 900);
    if (!rl.allowed) {
      res.status(429).json({ error: `OTP resend limit reached. Try again in ${rl.retryAfterSeconds}s.` });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE (phone != '' AND phone = ?) OR (email != '' AND email = ?) LIMIT 1").get(phone, email);
    if (!user) {
      res.status(404).json({ error: "No registration found for this email or mobile number." });
      return;
    }
    const latest = db.prepare("SELECT created_at FROM otp_tokens WHERE user_id = ? AND purpose = 'registration' ORDER BY id DESC LIMIT 1").get(user.id);
    const nowSec = Math.floor(Date.now() / 1e3);
    if (latest && nowSec - latest.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latest.created_at)}s before requesting another OTP.` });
      return;
    }
    recordRateLimitHit(db, `otpresend:${ip}:${rlTarget}`, 3600);
    const { otp } = issueOtp(db, { userId: user.id, phone: user.phone, email: user.email, purpose: "registration" });
    let emailSent = false;
    let smsSent = false;
    let note = "";
    if (otpChannel === "email") {
      if (isSmtpConfigured() && user.email) {
        const mailRes = await sendTransactionalEmail({
          to: user.email,
          recipientName: user.full_name || "Member",
          subject: "Yuitor Smart Classes — Verification OTP",
          previewText: `Your 6-digit OTP is ${otp}. Valid for 10 minutes.`,
          htmlBody: `<p>Hello {{name}},</p><p>Your fresh 6-digit verification OTP for Yuitor Smart Classes is:</p><p style="font-size:24px;font-weight:700;letter-spacing:4px;color:#7A0F28;margin:14px 0;">${escapeHtml(otp)}</p><p>Valid for 10 minutes. Never share this OTP with anyone.</p>`,
          department: "inquiry"
        });
        emailSent = Boolean(mailRes?.ok || mailRes?.sent);
        if (!emailSent) note = mailRes?.error || "Email OTP delivery failed. Try Mobile OTP or contact +91 78-2728-9292.";
      } else {
        note = "SMTP mail server is not configured yet on this server. Try Mobile OTP or contact +91 78-2728-9292.";
      }
    } else {
      const sms = await dispatchSmsOtp(user.phone, otp, "verification");
      smsSent = Boolean(sms.sent);
      if (!smsSent) note = sms.note;
    }
    res.json({
      resent: true,
      otpChannel,
      emailSent,
      smsSent,
      cooldownSeconds: 30,
      message: otpChannel === "email"
        ? (emailSent ? `A fresh 6-digit OTP has been emailed to ${user.email}. Please check Inbox / Spam.` : note)
        : (smsSent ? `A fresh 6-digit OTP has been sent via SMS to ${user.phone}.` : note),
      limitationNote: (emailSent || smsSent) ? "" : note
    });
    } catch (err) {
      console.error("[auth/resend-otp] Error:", err);
      res.status(500).json({ error: "Unable to send OTP right now. Please try again or contact +91 78-2728-9292." });
    }
  });
  router.post("/login", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const password = String(req.body?.password || "");
    const ip = clientIp(req);
    const rateKey = `login:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, rateKey, 6, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many failed sign-in attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!identifier || !password) {
      res.status(400).json({ error: "Enter both email/mobile and password." });
      return;
    }
    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizedEmail, normalizedPhone);
    const dummyHash = "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";
    const ok = verifyPassword(password, user ? user.password_hash : dummyHash);
    if (!user || !ok) {
      recordRateLimitHit(db, rateKey, 900);
      writeAuditLog(db, {
        actorId: user?.id ?? null,
        actorName: user?.full_name || "Anonymous",
        targetName: identifier.slice(0, 120),
        action: "login_failed",
        details: "Invalid credentials on /api/auth/login",
        ipAddress: ip
      });
      res.status(401).json({ error: "Incorrect email/mobile or password." });
      return;
    }
    if (user.role === "admin" || user.role === "super_admin") {
      recordRateLimitHit(db, rateKey, 900);
      recordAdminLoginAttempt(db, {
        identifier,
        ipAddress: ip,
        userAgent: String(req.headers["user-agent"] || ""),
        outcome: "public_login_blocked",
        reason: "Admin attempted sign-in on public /login"
      });
      res.status(401).json({ error: "Incorrect email/mobile or password." });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }
    const teacherResume = user.role === "teacher" ? getTeacherResumeSummary(db, Number(user.id)) : null;
    if (user.verification_status === "pending_otp" || Number(user.mobile_verified) !== 1) {
      res.json({
        authenticated: false,
        role: user.role,
        verificationStatus: "pending_otp",
        phone: user.phone,
        email: user.email,
        teacherResume,
        message: "Please complete 6-digit OTP verification first before entering your panel."
      });
      return;
    }
    if (user.role === "teacher" && !teacherResume?.hasResume) {
      res.json({
        authenticated: false,
        role: user.role,
        verificationStatus: "resume_required",
        resumeRequired: true,
        code: "RESUME_REQUIRED",
        pendingMessage: TEACHER_MISSING_RESUME_MSG,
        teacherResume
      });
      return;
    }
    if (user.verification_status === "pending_approval" || user.verification_status === "otp_verified") {
      db.prepare("UPDATE users SET verification_status = 'approved', updated_at = ? WHERE id = ?").run(nowIso(), user.id);
      if (user.role === "student") {
        db.prepare("UPDATE student_profiles SET enrollment_status = 'active' WHERE user_id = ? AND enrollment_status = 'pending'").run(user.id);
      }
      user.verification_status = "approved";
    }
    clearRateLimit(db, rateKey);
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    const prevSid = verifySessionToken(req.cookies?.[SESSION_COOKIE]) || void 0;
    const sid = createSession(db, Number(user.id), { replaceSessionId: prevSid });
    setSessionCookie(res, req, sid);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "login_success",
      details: `${user.role} signed in`,
      ipAddress: ip
    });
    res.json({
      authenticated: true,
      role: user.role,
      staffRole: user.staff_role || "",
      verificationStatus: user.verification_status,
      resumeRequired: Boolean(user.role === "teacher" && !teacherResume?.hasResume),
      teacherResume
    });
  });
  router.post("/login-otp/send", async (req, res) => {
    try {
    const identifier = cleanText(req.body?.identifier, 254);
    const rawChannel = String(req.body?.otpChannel || "").trim().toLowerCase();
    const otpChannel = rawChannel === "sms" || rawChannel === "mobile" || rawChannel === "phone" ? "sms" : "email";
    const portalScope = String(req.body?.portalScope || "").trim().toLowerCase();
    const ip = clientIp(req);
    const rateKey = `loginotp-send:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, rateKey, 6, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP requests. Please wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!identifier) {
      res.status(400).json({ error: "Enter your registered email address or mobile number." });
      return;
    }
    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizedEmail, normalizedPhone);
    if (!user || user.role === "admin" || user.role === "super_admin") {
      recordRateLimitHit(db, rateKey, 900);
      res.status(404).json({ error: "No registered Student, Parent, or Teacher account found with this email or mobile number. Please register first." });
      return;
    }
    if (portalScope === "teacher" && user.role !== "teacher") {
      res.status(403).json({ error: "This account belongs to a Student / Parent. Please sign in on the Student & Parent Portal (/student/login)." });
      return;
    }
    if (portalScope === "student_parent" && user.role === "teacher") {
      res.status(403).json({ error: "This account belongs to a Teacher. Please sign in on the Teacher Portal (/teacher/login)." });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }
    const latest = db.prepare("SELECT created_at FROM otp_tokens WHERE user_id = ? AND purpose = 'login_otp' ORDER BY id DESC LIMIT 1").get(user.id);
    const nowSec = Math.floor(Date.now() / 1e3);
    if (latest && nowSec - latest.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latest.created_at)}s before requesting another login OTP.` });
      return;
    }
    if (otpChannel === "email" && !isValidEmail(user.email)) {
      res.status(400).json({ error: "No valid email address is linked to this account. Please select Mobile Number (SMS) OTP instead." });
      return;
    }
    if (otpChannel === "sms" && !isValidIndianMobile(user.phone)) {
      res.status(400).json({ error: "No valid 10-digit mobile number is linked to this account. Please select Email (Mail) OTP instead." });
      return;
    }
    recordRateLimitHit(db, rateKey, 900);
    const { otp } = issueOtp(db, { userId: user.id, phone: user.phone, email: user.email, purpose: "login_otp" });
    let emailSent = false;
    let smsSent = false;
    let deliveryNote = "";
    if (otpChannel === "email") {
      if (isSmtpConfigured()) {
        const mailRes = await sendTransactionalEmail({
          to: user.email,
          recipientName: user.full_name || "Member",
          subject: "Yuitor Smart Classes — 6-Digit Login OTP",
          previewText: `Your 6-digit login OTP is ${otp}. Valid for 10 minutes.`,
          htmlBody: `<p>Hello {{name}},</p><p>Use this 6-digit OTP to sign in to your Yuitor Smart Classes (${escapeHtml(user.role)}) account:</p><p style="font-size:24px;font-weight:700;letter-spacing:4px;color:#7A0F28;margin:14px 0;">${escapeHtml(otp)}</p><p>This code expires in 10 minutes. If you did not request this login OTP, please ignore this email.</p>`,
          department: "inquiry"
        });
        emailSent = Boolean(mailRes?.ok || mailRes?.sent);
        if (!emailSent) deliveryNote = mailRes?.error || "Email OTP could not be delivered right now. Try Mobile OTP or password login.";
      } else {
        deliveryNote = "SMTP mail server is not configured yet on this server. Ask Admin to set up SMTP or use Mobile OTP / Password Sign In.";
      }
    } else {
      const sms = await dispatchSmsOtp(user.phone, otp, "login");
      smsSent = Boolean(sms.sent);
      if (!smsSent) deliveryNote = sms.note;
    }
    const targetMasked = otpChannel === "email"
      ? (() => {
          const [n, d] = String(user.email || "").split("@");
          return d ? `${n.slice(0, 2)}***@${d}` : user.email;
        })()
      : `******${String(user.phone || "").slice(-4)}`;
    res.json({
      otpIssued: true,
      otpChannel,
      otpTargetMasked: targetMasked,
      role: user.role,
      emailSent,
      smsSent,
      cooldownSeconds: 30,
      message: otpChannel === "email"
        ? (emailSent ? `6-digit login OTP sent to your registered email (${targetMasked}). Please check Inbox / Spam.` : deliveryNote)
        : (smsSent ? `6-digit login OTP sent to your registered mobile (${targetMasked}).` : deliveryNote),
      limitationNote: (emailSent || smsSent) ? "" : deliveryNote
    });
    } catch (err) {
      console.error("[auth/login-otp/send] Error:", err);
      res.status(500).json({ error: "Unable to send login OTP right now. Please try again or use Password Sign In." });
    }
  });
  router.post("/login-otp/verify", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const otp = cleanText(req.body?.otp, 10);
    const ip = clientIp(req);
    const rateKey = `loginotp-verify:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, rateKey, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (!identifier || !/^\d{6}$/.test(otp)) {
      recordRateLimitHit(db, rateKey, 600);
      res.status(400).json({ error: "Enter your registered email/mobile and the 6-digit OTP." });
      return;
    }
    const normalizedEmail = normalizeEmail(identifier);
    const normalizedPhone = normalizePhone(identifier);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizedEmail, normalizedPhone);
    if (!user || user.role === "admin" || user.role === "super_admin") {
      recordRateLimitHit(db, rateKey, 600);
      res.status(401).json({ error: "Invalid OTP or account." });
      return;
    }
    let check = verifyOtpToken(db, { target: user.phone || user.email, purpose: "login_otp", otp });
    if (!check.ok && user.email) {
      check = verifyOtpToken(db, { target: user.email, purpose: "login_otp", otp });
    }
    if (!check.ok) {
      recordRateLimitHit(db, rateKey, 600);
      res.status(400).json({ error: check.error });
      return;
    }
    if (Number(user.is_active) !== 1 || user.verification_status === "suspended" || user.verification_status === "rejected") {
      res.status(403).json({ error: `Your account is currently ${user.verification_status}. Contact Yuitor Team at +91 78-2728-9292.` });
      return;
    }
    const teacherResume = user.role === "teacher" ? getTeacherResumeSummary(db, Number(user.id)) : null;
    if (user.role === "teacher" && !teacherResume?.hasResume) {
      res.json({
        authenticated: false,
        role: user.role,
        verificationStatus: "resume_required",
        resumeRequired: true,
        code: "RESUME_REQUIRED",
        pendingMessage: TEACHER_MISSING_RESUME_MSG,
        teacherResume
      });
      return;
    }
    if (user.verification_status === "pending_otp" || user.verification_status === "pending_approval" || user.verification_status === "otp_verified" || Number(user.mobile_verified) !== 1) {
      db.prepare("UPDATE users SET mobile_verified = 1, verification_status = 'approved', updated_at = ? WHERE id = ?").run(nowIso(), user.id);
      if (user.role === "student") {
        db.prepare("UPDATE student_profiles SET enrollment_status = 'active' WHERE user_id = ? AND enrollment_status = 'pending'").run(user.id);
      }
      user.verification_status = "approved";
    }
    clearRateLimit(db, rateKey);
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    const prevSidOtp = verifySessionToken(req.cookies?.[SESSION_COOKIE]) || void 0;
    const sid = createSession(db, Number(user.id), { replaceSessionId: prevSidOtp });
    setSessionCookie(res, req, sid);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "login_otp_success",
      details: `${user.role} signed in via 6-digit OTP`,
      ipAddress: ip
    });
    res.json({
      authenticated: true,
      role: user.role,
      staffRole: user.staff_role || "",
      verificationStatus: user.verification_status,
      resumeRequired: Boolean(user.role === "teacher" && !teacherResume?.hasResume),
      teacherResume
    });
  });
  router.post("/logout", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (ctx) {
      db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    }
    clearSessionCookie(res, req);
    res.json({ loggedOut: true });
  });
  router.get("/me", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.json({ authenticated: false, user: null });
      return;
    }
    const isPending = ctx.user.verification_status !== "approved";
    const teacherResume = ctx.user.role === "teacher" ? getTeacherResumeSummary(db, ctx.user.id) : null;
    const studentMeta = ctx.user.role === "student" ? db.prepare("SELECT roll_number, batch_id, branch_id FROM student_profiles WHERE user_id = ?").get(ctx.user.id) : null;
    const isAdmin = ctx.user.role === "admin" || ctx.user.role === "super_admin";
    res.json({
      authenticated: true,
      user: {
        ...ctx.user,
        rollNumber: studentMeta?.roll_number || void 0
      },
      impersonation: ctx.impersonation,
      pendingMessage: isPending ? BRAND_PENDING_MSG : void 0,
      teacherResume,
      adminGatePath: isAdmin ? `/${getAdminPath(db)}/` : void 0
    });
  });
  router.post("/forgot-password", async (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `forgot:${ip}`, 5, 900, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many reset requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `forgot:${ip}`, 900);
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizeEmail(identifier), normalizePhone(identifier));
    if (!user || user.role === "admin" || user.role === "super_admin") {
      if (user && (user.role === "admin" || user.role === "super_admin")) {
        writeAuditLog(db, {
          actorName: "Security Guard",
          targetId: user.id,
          action: "admin_public_reset_blocked",
          details: "Blocked admin password reset attempt via public /forgot-password",
          ipAddress: ip
        });
      }
      res.json({
        message: "If an account matches that email or mobile number, a 6-digit reset OTP has been generated.",
        limitationNote: "If no SMS/SMTP provider is configured, contact Yuitor Team at +91 78-2728-9292."
      });
      return;
    }
    const latestReset = db.prepare("SELECT created_at FROM otp_tokens WHERE user_id = ? AND purpose = 'password_reset' ORDER BY id DESC LIMIT 1").get(user.id);
    const nowSec = Math.floor(Date.now() / 1e3);
    if (latestReset && nowSec - latestReset.created_at < 30) {
      res.status(429).json({ error: `Please wait ${30 - (nowSec - latestReset.created_at)}s before requesting another reset OTP.` });
      return;
    }
    const { otp } = issueOtp(db, {
      userId: user.id,
      phone: user.phone,
      email: user.email,
      purpose: "password_reset"
    });
    let emailSent = false;
    let smsSent = false;
    let note = "";
    if (isSmtpConfigured() && user.email) {
      const mailRes = await sendTransactionalEmail({
        to: user.email,
        recipientName: user.full_name || "Member",
        subject: "Yuitor Smart Classes — Password Reset OTP",
        previewText: "Use this 6-digit OTP within 10 minutes to reset your password.",
        htmlBody: `<p>Hello {{name}},</p><p>Your 6-digit password reset OTP is <strong style="font-size:20px;letter-spacing:3px;color:#7A0F28;">${escapeHtml(otp)}</strong>.</p><p>This code expires in 10 minutes. If you did not request a password reset, please ignore this email.</p>`,
        department: "inquiry"
      });
      emailSent = Boolean(mailRes?.ok || mailRes?.sent);
      if (!emailSent) note = mailRes?.error || "";
    }
    if (user.phone && isValidIndianMobile(user.phone)) {
      const sms = await dispatchSmsOtp(user.phone, otp, "password reset");
      smsSent = Boolean(sms.sent);
      if (!emailSent && !smsSent) note = note || sms.note;
    }
    res.json({
      emailSent,
      smsSent,
      message: emailSent
        ? "6-digit password reset OTP sent to your registered email (check Inbox / Spam)."
        : smsSent
          ? "6-digit password reset OTP sent to your registered mobile number."
          : "6-digit password reset OTP generated.",
      limitationNote: (emailSent || smsSent) ? "" : (note || "Configure SMTP or Fast2SMS in Admin → Settings & API, or contact +91 78-2728-9292.")
    });
  });
  router.post("/reset-password", (req, res) => {
    const identifier = cleanText(req.body?.identifier, 254);
    const otp = cleanText(req.body?.otp, 10);
    const newPassword = String(req.body?.newPassword || "");
    const ip = clientIp(req);
    const resetRlKey = `resetpw:${ip}:${identifier.toLowerCase()}`;
    const rl = checkRateLimit(db, resetRlKey, 8, 600, 300);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many password reset attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    if (newPassword.length < 8 || newPassword.length > 200) {
      res.status(400).json({ error: "New password must be at least 8 characters." });
      return;
    }
    const user = db.prepare("SELECT * FROM users WHERE email = ? OR (phone != '' AND phone = ?) LIMIT 1").get(normalizeEmail(identifier), normalizePhone(identifier));
    if (!user || user.role === "admin" || user.role === "super_admin") {
      recordRateLimitHit(db, resetRlKey, 600);
      res.status(400).json({ error: "Invalid OTP or account." });
      return;
    }
    const target = user.phone || user.email;
    const check = verifyOtpToken(db, { target, purpose: "password_reset", otp });
    if (!check.ok) {
      recordRateLimitHit(db, resetRlKey, 600);
      res.status(400).json({ error: check.error });
      return;
    }
    clearRateLimit(db, resetRlKey);
    db.prepare("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?").run(
      hashPassword(newPassword),
      nowIso(),
      user.id
    );
    db.prepare("DELETE FROM sessions WHERE user_id = ?").run(user.id);
    writeAuditLog(db, {
      actorId: user.id,
      actorName: user.full_name,
      targetId: user.id,
      targetName: user.full_name,
      action: "password_reset",
      details: "Password reset via OTP",
      ipAddress: ip
    });
    res.json({ message: "Password updated successfully. You can now sign in." });
  });
  router.patch("/avatar", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required." });
      return;
    }
    const avatarUrl = sanitizeHttpOrUploadUrl(req.body?.avatarUrl, 300);
    if (!avatarUrl.startsWith("/uploads/")) {
      res.status(400).json({ error: "Invalid uploaded avatar path." });
      return;
    }
    db.prepare("UPDATE users SET avatar_url = ?, profile_photo = ?, updated_at = ? WHERE id = ?").run(avatarUrl, avatarUrl, nowIso(), ctx.user.id);
    res.json({ updated: true, avatarUrl, profilePhoto: avatarUrl });
  });
  const AVATAR_ALLOWED_EXTS = new Set([".jpg", ".jpeg", ".png", ".webp"]);
  const profilePhotoUpload = multer4({
    storage: multer4.diskStorage({
      destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
      filename: (req, file, cb) => {
        const ext = path10.extname(file.originalname || "").toLowerCase();
        const safeExt = AVATAR_ALLOWED_EXTS.has(ext) ? ext : ".jpg";
        cb(null, `avatar-${Date.now()}-${crypto10.randomBytes(6).toString("hex")}${safeExt}`);
      }
    }),
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      const ext = path10.extname(file.originalname || "").toLowerCase();
      const mime = String(file.mimetype || "").toLowerCase();
      if (!AVATAR_ALLOWED_EXTS.has(ext) || !["image/jpeg", "image/jpg", "image/png", "image/webp"].includes(mime)) {
        cb(new Error("Only JPG, PNG, and WEBP images up to 2 MB are allowed."));
        return;
      }
      cb(null, true);
    }
  });
  router.post("/profile-photo", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required to upload profile photo." });
      return;
    }
    profilePhotoUpload.fields([{ name: "photo", maxCount: 1 }, { name: "file", maxCount: 1 }])(req, res, (err) => {
      if (err) {
        const msg = err?.code === "LIMIT_FILE_SIZE"
          ? "Profile photo must be 2 MB or smaller (JPG, PNG, or WEBP)."
          : err?.message || "Invalid profile photo upload.";
        res.status(400).json({ error: msg });
        return;
      }
      const uploadedFile = (req.files && (req.files.photo?.[0] || req.files.file?.[0])) || req.file || null;
      if (!uploadedFile) {
        res.status(400).json({ error: "Please select a JPG, PNG, or WEBP image (max 2 MB)." });
        return;
      }
      const check = validateUploadMagicAndMime(
        uploadedFile.path,
        uploadedFile.originalname || uploadedFile.filename,
        uploadedFile.mimetype || "",
        AVATAR_ALLOWED_EXTS
      );
      if (!check.ok) {
        try { fs12.unlinkSync(uploadedFile.path); } catch {}
        res.status(400).json({ error: check.error || "File content is not a valid JPG, PNG, or WEBP image." });
        return;
      }
      const av = scanUploadedFileWithClamAv(uploadedFile.path);
      if (!av.clean) {
        try { fs12.unlinkSync(uploadedFile.path); } catch {}
        res.status(400).json({ error: "Uploaded image failed security inspection." });
        return;
      }
      try { fs12.chmodSync(uploadedFile.path, 0o600); } catch {}
      const photoUrl = `/uploads/${uploadedFile.filename}`;
      try {
        db.prepare("UPDATE users SET avatar_url = ?, profile_photo = ?, updated_at = ? WHERE id = ?").run(
          photoUrl,
          photoUrl,
          nowIso(),
          ctx.user.id
        );
        writeAuditLog(db, {
          actorId: ctx.user.id,
          actorName: ctx.user.full_name,
          targetId: ctx.user.id,
          targetName: ctx.user.full_name,
          action: "profile_photo_updated",
          details: `Updated profile photo (${uploadedFile.filename})`,
          ipAddress: clientIp(req)
        });
        res.status(200).json({ ok: true, updated: true, avatarUrl: photoUrl, profilePhoto: photoUrl });
      } catch (saveErr) {
        res.status(500).json({ error: saveErr?.message || "Failed to save profile photo." });
      }
    });
  });
  router.post("/exit-impersonation", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || !ctx.impersonation.active || !ctx.impersonation.adminId) {
      res.status(400).json({ error: "No active impersonation session." });
      return;
    }
    const adminId = ctx.impersonation.adminId;
    db.prepare("DELETE FROM sessions WHERE id = ?").run(ctx.sessionId);
    db.prepare(
      `UPDATE impersonation_logs SET ended_at = ?
       WHERE id = (SELECT id FROM impersonation_logs WHERE admin_id = ? AND target_user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1)`
    ).run(nowIso(), adminId, ctx.user.id);
    const newSid = createSession(db, adminId);
    setSessionCookie(res, req, newSid);
    writeAuditLog(db, {
      actorId: adminId,
      actorName: "Admin",
      targetId: ctx.user.id,
      targetName: ctx.user.full_name,
      action: "impersonation_ended",
      details: "Exited troubleshooting view",
      ipAddress: clientIp(req)
    });
    res.json({ redirectTo: `/${getAdminPath(db)}/` });
  });
  return router;
}

// server/routes/admin.ts
import { Router as Router4 } from "express";
import crypto7 from "node:crypto";
import fs10 from "node:fs";
import path8 from "node:path";
import multer2 from "multer";

// server/chatbot.ts
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

// server/pdf.ts
import zlib2 from "node:zlib";
import fs9 from "node:fs";
function decodePdfLiteralString(raw) {
  let out = "";
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch === "\\" && i + 1 < raw.length) {
      const nxt = raw[++i];
      if (nxt === "n") out += "\n";
      else if (nxt === "r") out += "\r";
      else if (nxt === "t") out += "	";
      else if (nxt === "b") out += "\b";
      else if (nxt === "f") out += "\f";
      else if (nxt === "(" || nxt === ")" || nxt === "\\") out += nxt;
      else if (/[0-7]/.test(nxt)) {
        let oct = nxt;
        if (i + 1 < raw.length && /[0-7]/.test(raw[i + 1])) oct += raw[++i];
        if (i + 1 < raw.length && /[0-7]/.test(raw[i + 1])) oct += raw[++i];
        out += String.fromCharCode(parseInt(oct, 8));
      } else {
        out += nxt;
      }
    } else {
      out += ch;
    }
  }
  return out;
}
function decodePdfHexString(hexRaw) {
  const hex = hexRaw.replace(/[^0-9a-fA-F]/g, "");
  if (!hex || hex.length < 2) return "";
  const padded = hex.length % 2 === 1 ? hex + "0" : hex;
  const bytes = Buffer.from(padded, "hex");
  if (bytes.length >= 2 && bytes[0] === 254 && bytes[1] === 255) {
    let s = "";
    for (let i = 2; i + 1 < bytes.length; i += 2) {
      s += String.fromCharCode(bytes[i] << 8 | bytes[i + 1]);
    }
    return s;
  }
  return bytes.toString("latin1").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
}
function extractTextOperatorsFromStream(content) {
  const chunks = [];
  const litRe = /\(((?:\\.|[^\\()])*)\)\s*(?:Tj|'|")/g;
  let m;
  while ((m = litRe.exec(content)) !== null) {
    const t = decodePdfLiteralString(m[1]).trim();
    if (t) chunks.push(t);
  }
  const tjArrayRe = /\[([\s\S]*?)\]\s*TJ/g;
  while ((m = tjArrayRe.exec(content)) !== null) {
    const inner = m[1];
    const parts = [];
    const tokenRe = /\(((?:\\.|[^\\()])*)\)|<([0-9a-fA-F\s]+)>/g;
    let tm;
    while ((tm = tokenRe.exec(inner)) !== null) {
      if (tm[1] !== void 0) parts.push(decodePdfLiteralString(tm[1]));
      else if (tm[2] !== void 0) parts.push(decodePdfHexString(tm[2]));
    }
    const joined = parts.join("").trim();
    if (joined) chunks.push(joined);
  }
  const hexTjRe = /<([0-9a-fA-F\s]+)>\s*Tj/g;
  while ((m = hexTjRe.exec(content)) !== null) {
    const t = decodePdfHexString(m[1]).trim();
    if (t) chunks.push(t);
  }
  return chunks;
}
function extractTextFromPdfBuffer(buf) {
  if (!buf || buf.length === 0) return "";
  const rawLatin = buf.toString("latin1");
  const pieces = [];
  const streamRe = /stream\r?\n([\s\S]*?)\r?\n?endstream/g;
  let match;
  while ((match = streamRe.exec(rawLatin)) !== null) {
    const headerStart = Math.max(0, match.index - 320);
    const dictSlice = rawLatin.slice(headerStart, match.index);
    const rawStreamBytes = Buffer.from(match[1], "latin1");
    let decoded = "";
    if (/\/FlateDecode/i.test(dictSlice)) {
      try {
        decoded = zlib2.inflateSync(rawStreamBytes).toString("latin1");
      } catch {
        try {
          decoded = zlib2.inflateRawSync(rawStreamBytes).toString("latin1");
        } catch {
          decoded = "";
        }
      }
    } else {
      decoded = match[1];
    }
    if (decoded) {
      pieces.push(...extractTextOperatorsFromStream(decoded));
    }
  }
  if (pieces.length === 0) {
    pieces.push(...extractTextOperatorsFromStream(rawLatin));
  }
  return pieces.join(" ").replace(/\s+/g, " ").trim().slice(0, 6e4);
}
function extractTextFromDocumentFile(filePath, mimeOrExt) {
  const buf = fs9.readFileSync(filePath);
  const hint = mimeOrExt.toLowerCase();
  if (hint.includes("pdf") || filePath.toLowerCase().endsWith(".pdf")) {
    return extractTextFromPdfBuffer(buf);
  }
  return buf.toString("utf8").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ").replace(/\s+/g, " ").trim().slice(0, 6e4);
}
function retrieveRelevantDocumentSnippets(db, query, maxSnippets = 4) {
  const qWords = Array.from(
    new Set(
      String(query || "").toLowerCase().split(/[^a-z0-9\u0900-\u097F]+/).filter((w) => w.length >= 3)
    )
  );
  const candidates = [];
  try {
    const docs = db.prepare("SELECT title, extracted_text FROM knowledge_documents WHERE is_active = 1 AND extracted_text != '' ORDER BY id DESC LIMIT 30").all();
    for (const d of docs) {
      candidates.push({ title: d.title, text: d.extracted_text });
    }
  } catch {
  }
  try {
    const lessons = db.prepare(
      `SELECT l.title, l.content, c.title as course_title
         FROM lessons l
         JOIN courses c ON c.id = l.course_id
         WHERE l.is_visible = 1 AND l.content != ''
         ORDER BY l.id DESC LIMIT 40`
    ).all();
    for (const l of lessons) {
      candidates.push({ title: `${l.course_title} \u2014 ${l.title}`, text: l.content });
    }
  } catch {
  }
  try {
    const posts = db.prepare("SELECT title, excerpt, content FROM blog_posts WHERE is_published = 1 ORDER BY id DESC LIMIT 20").all();
    for (const p of posts) {
      candidates.push({ title: `Blog: ${p.title}`, text: `${p.excerpt} ${p.content}`.trim() });
    }
  } catch {
  }
  if (candidates.length === 0) return [];
  const scored = [];
  for (const item of candidates) {
    const text = item.text.trim();
    if (!text) continue;
    const chunks = [];
    for (let i = 0; i < text.length; i += 450) {
      chunks.push(text.slice(i, i + 550));
    }
    for (const chunk of chunks) {
      const hay = `${item.title} ${chunk}`.toLowerCase();
      let score = 0;
      for (const w of qWords) {
        if (hay.includes(w)) score += w.length >= 5 ? 2 : 1;
      }
      if (score > 0 || qWords.length === 0) {
        scored.push({
          sourceTitle: item.title,
          excerpt: chunk.trim(),
          score
        });
      }
    }
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, maxSnippets);
}

// server/chatbot.ts
var SHREYA_INTRO = SHREYA_OFFICIAL_INTRO;
function redactSensitiveText(text) {
  return text.replace(/\b(password|passwd|pwd)\s*(?:is|was|:|=)\s*\S+/gi, "$1: [REDACTED]").replace(/\b(otp|code|pin)\s*(?:is|was|:|=)?\s*\d{4,8}\b/gi, "$1 [REDACTED]");
}
function buildKnowledgeContext(db) {
  return buildFullWebsiteKnowledgeContext(db, getDepartmentEmails);
}
var FUZZY_VOCAB = [
  "admission",
  "fees",
  "teacher",
  "resume",
  "verify",
  "verification",
  "otp",
  "login",
  "password",
  "register",
  "registration",
  "scholarship",
  "refund",
  "computer",
  "english",
  "python",
  "muradnagar",
  "syllabus",
  "mathematics",
  "physics",
  "chemistry",
  "biology",
  "portal",
  "dashboard",
  "schedule",
  "assignment",
  "quiz",
  "certificate",
  "receipt",
  "contact",
  "razorpay",
  "payment",
  "attendance",
  "timings",
  "cbse",
  "icse"
];
function levenshteinDistance(a, b) {
  if (a === b) return 0;
  const al = a.length;
  const bl = b.length;
  if (Math.abs(al - bl) > 2) return 99;
  const prev = Array.from({ length: bl + 1 }, (_, j) => j);
  const curr = new Array(bl + 1);
  for (let i = 1; i <= al; i++) {
    curr[0] = i;
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= bl; j++) prev[j] = curr[j];
  }
  return prev[bl];
}
function normalizeUserQuery(raw) {
  const lower = raw.toLowerCase();
  const corrected = lower.replace(/\b[a-z]{4,16}\b/g, (word) => {
    if (FUZZY_VOCAB.includes(word)) return word;
    let best = word;
    let bestDist = 3;
    const maxDist = word.length >= 7 ? 2 : 1;
    for (const vocab of FUZZY_VOCAB) {
      const d = levenshteinDistance(word, vocab);
      if (d <= maxDist && d < bestDist) {
        best = vocab;
        bestDist = d;
      }
    }
    return best;
  });
  return corrected;
}
function safeEvalArithmetic(exprRaw) {
  const cleaned = exprRaw.replace(/×/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/[^0-9+\-*/().%\s*]/g, "").trim();
  if (!cleaned || !/\d/.test(cleaned) || !/[+\-*/%]/.test(cleaned)) return null;
  if (cleaned.length > 64) return null;
  try {
    const val = Function(`"use strict"; return (${cleaned});`)();
    return typeof val === "number" && Number.isFinite(val) ? Number(val.toFixed(6)) : null;
  } catch {
    return null;
  }
}
function tryDynamicAcademicSolver(userMsg, isHindi) {
  const q = userMsg.trim();
  const ql = q.toLowerCase();
  const pctMatch = ql.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of|ka|on)\s*(\d+(?:\.\d+)?)/i);
  if (pctMatch) {
    const p = Number(pctMatch[1]);
    const base = Number(pctMatch[2]);
    const ans = Number((p / 100 * base).toFixed(4));
    return isHindi ? `${base} ka ${p}% = ${ans} hota hai.` : `${p}% of ${base} = ${ans}.`;
  }
  const tableMatch = ql.match(/(?:table\s+of|pahada\s+of|(\d+)\s+ka\s+pahada)\s*(\d+)?/i);
  if (tableMatch) {
    const n = Number(tableMatch[1] || tableMatch[2]);
    if (Number.isFinite(n) && n >= 1 && n <= 1e3) {
      const rows = Array.from({ length: 10 }, (_, i) => `${n}\xD7${i + 1}=${n * (i + 1)}`).join(", ");
      return `Table of ${n}: ${rows}.`;
    }
  }
  const sqrtMatch = ql.match(/(?:square\s*root|sqrt|vargmul)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqrtMatch) {
    const n = Number(sqrtMatch[1]);
    if (n >= 0) {
      return `\u221A${n} = ${Number(Math.sqrt(n).toFixed(6))}.`;
    }
  }
  const sqMatch = ql.match(/(?:square|varg)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (sqMatch) {
    const n = Number(sqMatch[1]);
    return `${n}\xB2 = ${Number((n * n).toFixed(6))}.`;
  }
  const cubeMatch = ql.match(/(?:cube|ghan)\s*(?:of|ka)?\s*(\d+(?:\.\d+)?)/i);
  if (cubeMatch) {
    const n = Number(cubeMatch[1]);
    return `${n}\xB3 = ${Number((n * n * n).toFixed(6))}.`;
  }
  const cToF = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:c|celsius)\s*(?:to|in)\s*(?:f|fahrenheit)/i);
  if (cToF) {
    const c = Number(cToF[1]);
    return `${c}\xB0C = ${Number((c * 9 / 5 + 32).toFixed(2))}\xB0F.`;
  }
  const fToC = ql.match(/(-?\d+(?:\.\d+)?)\s*(?:f|fahrenheit)\s*(?:to|in)\s*(?:c|celsius)/i);
  if (fToC) {
    const f = Number(fToC[1]);
    return `${f}\xB0F = ${Number(((f - 32) * 5 / 9).toFixed(2))}\xB0C.`;
  }
  const kmhToMs = ql.match(/(\d+(?:\.\d+)?)\s*km\/?h\s*(?:to|in)\s*m\/?s/i);
  if (kmhToMs) {
    const v = Number(kmhToMs[1]);
    return `${v} km/h = ${Number((v * 5 / 18).toFixed(3))} m/s.`;
  }
  const siMatch = ql.match(/(?:si|simple interest)\s*(?:of|on)?\s*(\d+(?:\.\d+)?)\s*(?:at|rate)?\s*(\d+(?:\.\d+)?)%?\s*(?:for|time)?\s*(\d+(?:\.\d+)?)/i);
  if (siMatch) {
    const p = Number(siMatch[1]);
    const r = Number(siMatch[2]);
    const t = Number(siMatch[3]);
    const si = Number((p * r * t / 100).toFixed(2));
    return `Simple Interest = (P\xD7R\xD7T)/100 = \u20B9${si} (Total Amount: \u20B9${Number((p + si).toFixed(2))}).`;
  }
  const arithCandidate = ql.replace(/^(?:what is|calculate|solve|eval|evaluate|kitna hota hai|batao)\s+/i, "").replace(/\?+$/, "").trim();
  if (/^[\d\s+\-*/().^×÷]+$/.test(arithCandidate) && /[+\-*/^×÷]/.test(arithCandidate)) {
    const res = safeEvalArithmetic(arithCandidate);
    if (res !== null) {
      return `${arithCandidate} = ${res}`;
    }
  }
  return null;
}
var ACADEMIC_CONCEPTS = [
  {
    keys: /\b(newton|laws of motion|f=ma|force formula)\b/i,
    answer: "Newton's Laws: (1) Inertia \u2014 object stays at rest/motion unless external force acts; (2) F = m \xD7 a (Force = mass \xD7 acceleration, SI unit: Newton); (3) Every action has an equal and opposite reaction."
  },
  {
    keys: /\b(ohm'?s law|v=ir|resistance formula)\b/i,
    answer: "Ohm's Law states V = I \xD7 R (at constant temperature, current I is directly proportional to voltage V). SI units: Voltage (Volt), Current (Ampere), Resistance (Ohm \u03A9)."
  },
  {
    keys: /\b(electric power|joule'?s law|current formula)\b/i,
    answer: "Electric Current I = Q / t (Ampere). Electric Power P = V \xD7 I = I\xB2R = V\xB2/R (Watt). Heat produced H = I\xB2Rt (Joule's Law of Heating)."
  },
  {
    keys: /\b(pythagoras|hypotenuse)\b/i,
    answer: "Pythagoras Theorem (right triangle): Hypotenuse\xB2 = Base\xB2 + Perpendicular\xB2 (c\xB2 = a\xB2 + b\xB2)."
  },
  {
    keys: /\b(quadratic|sridharacharya|discriminant)\b/i,
    answer: "Quadratic Formula for ax\xB2 + bx + c = 0: x = [-b \xB1 \u221A(b\xB2 - 4ac)] / (2a), where Discriminant D = b\xB2 - 4ac determines real/equal/complex roots."
  },
  {
    keys: /\b(arithmetic progression|nth term|ap formula)\b/i,
    answer: "Arithmetic Progression (AP): nth term a\u2099 = a + (n - 1)d, and Sum of n terms S\u2099 = (n/2)[2a + (n - 1)d] = (n/2)(a + l)."
  },
  {
    keys: /\b(mensuration|surface area|volume of sphere|cylinder|cone)\b/i,
    answer: "Key Mensuration Formulas: Sphere Volume = (4/3)\u03C0r\xB3 (SA = 4\u03C0r\xB2); Cylinder Volume = \u03C0r\xB2h (CSA = 2\u03C0rh); Cone Volume = (1/3)\u03C0r\xB2h (CSA = \u03C0rl)."
  },
  {
    keys: /\b(photosynthesis)\b/i,
    answer: "Photosynthesis equation: 6CO\u2082 + 6H\u2082O + Sunlight (Chlorophyll) \u2192 C\u2086H\u2081\u2082O\u2086 (Glucose) + 6O\u2082. Plants convert light energy into chemical energy inside chloroplasts."
  },
  {
    keys: /\b(mitochondria|cell organelle|dna|nucleus)\b/i,
    answer: "Cell Biology: Mitochondria are the powerhouse of the cell (synthesize ATP); Nucleus holds DNA and controls cellular activities; Ribosomes synthesize proteins."
  },
  {
    keys: /\b(acid|base|ph scale|neutralization)\b/i,
    answer: "Acids turn blue litmus red (pH < 7, give H\u207A ions); Bases turn red litmus blue (pH > 7, give OH\u207B ions); pH 7 is neutral. Acid + Base \u2192 Salt + Water (Neutralization)."
  },
  {
    keys: /\b(periodic table|atomic number|valency)\b/i,
    answer: "Modern Periodic Law (Moseley): Properties of elements are periodic functions of their atomic number (Z). E.g., H(1), He(2), C(6), N(7), O(8), Na(11), Cl(17), Ca(20)."
  },
  {
    keys: /\b(trigonometry|sin|cos|tan|identity)\b/i,
    answer: "Core Trigonometry Identities: sin\xB2\u03B8 + cos\xB2\u03B8 = 1, 1 + tan\xB2\u03B8 = sec\xB2\u03B8, 1 + cot\xB2\u03B8 = cosec\xB2\u03B8. Standard values: sin30\xB0 = 1/2, sin45\xB0 = 1/\u221A2, sin60\xB0 = \u221A3/2, sin90\xB0 = 1."
  },
  {
    keys: /\b(lens formula|mirror formula|magnification)\b/i,
    answer: "Mirror Formula: 1/f = 1/v + 1/u (m = -v/u). Lens Formula: 1/f = 1/v - 1/u (m = v/u), Power P = 1/f (in metres, Dioptre D)."
  },
  {
    keys: /\b(tense|grammar|parts of speech|noun|verb|active passive)\b/i,
    answer: "English Grammar Basics: 3 main tenses (Present, Past, Future), each with Simple, Continuous, Perfect & Perfect Continuous forms. Yuitor's Spoken English & Class 6\u201312 batches cover grammar, fluency & interview skills."
  },
  {
    keys: /\b(python|loop|function|html|javascript|sql)\b/i,
    answer: "Python uses `def` for functions and `for`/`while` for loops; SQL uses `SELECT/INSERT/UPDATE/DELETE`; HTML structures web pages and JS adds interactivity. All of these are taught practically in Yuitor's Computer & AI Coding tracks!"
  }
];
function ruleBasedFallback(userMsg, history, db) {
  return answerFromOfficialKnowledge(userMsg, history, db, {
    normalizeUserQuery,
    getDepartmentEmails,
    tryDynamicAcademicSolver,
    academicConcepts: ACADEMIC_CONCEPTS,
    retrieveRelevantDocumentSnippets
  });
}
async function generateShreyaReply(db, conversationId, userMessage) {
  const safeQuestion = redactSensitiveText(cleanText(userMessage, 600));
  const adminSlug = (() => {
    try {
      return getAdminPath(db);
    } catch {
      return "";
    }
  })();

  // Step 1: Hard Security & Anti-Leak Guard BEFORE anything else (never even sent to LLM)
  if (detectSecurityLeakAttempt(safeQuestion).blocked) {
    return { reply: buildSecurityRefusalReply(safeQuestion), escalate: false };
  }

  const history = db.prepare("SELECT sender, message FROM chatbot_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 12").all(conversationId);
  history.reverse();
  const quickMatch = ruleBasedFallback(safeQuestion, history, db);
  const isInstantQuery = tryDynamicAcademicSolver(safeQuestion, false) !== null || /^(hi|hello|hey|namaste|hlo|hii+)[!.\s]*$/i.test(safeQuestion.trim());
  if (isInstantQuery) {
    return {
      reply: sanitizeShreyaOutput(quickMatch.reply, adminSlug),
      escalate: Boolean(quickMatch.escalate)
    };
  }
  const apiKey = (process.env.GEMINI_API_KEY || "").trim();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return {
      reply: sanitizeShreyaOutput(quickMatch.reply, adminSlug),
      escalate: Boolean(quickMatch.escalate)
    };
  }
  try {
    const modelName = (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash";
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
    const knowledge = buildKnowledgeContext(db);
    const docSnippets = retrieveRelevantDocumentSnippets(db, safeQuestion, 5);
    const docSection = docSnippets.length > 0 ? `

UPLOADED KNOWLEDGE DOCUMENTS & COURSE NOTES:
${docSnippets.map((s) => `[${s.sourceTitle}]: ${s.excerpt}`).join("\n")}` : "";
    const systemInstruction = buildShreyaSystemInstruction(knowledge, docSection, getDepartmentEmails());
    const transcript = history.map((m) => `${m.sender === "user" ? "Visitor" : "Shreya"}: ${m.message}`).join("\n");
    const genConfig = { systemInstruction };
    if (/^gemini-[34]/i.test(modelName)) {
      genConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
    }
    const response = await Promise.race([
      ai.models.generateContent({
        model: modelName,
        contents: transcript ? `${transcript}
Visitor: ${safeQuestion}` : `Visitor: ${safeQuestion}`,
        config: genConfig
      }),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Gemini response timeout")), 9500)
      )
    ]);
    let raw = (response.text || "").trim();
    if (!raw) {
      return { reply: sanitizeShreyaOutput(quickMatch.reply, adminSlug), escalate: Boolean(quickMatch.escalate) };
    }
    const escalate = raw.includes("[ESCALATE]");
    raw = sanitizeShreyaOutput(raw.replace(/\[ESCALATE\]/g, "").trim(), adminSlug);
    return { reply: raw || quickMatch.reply, escalate };
  } catch (err) {
    const status = err?.status || err?.code || "";
    console.warn("[Shreya AI] Gemini fallback triggered:", status ? `HTTP ${status}` : "", err?.message || err);
    return {
      reply: sanitizeShreyaOutput(quickMatch.reply, adminSlug),
      escalate: Boolean(quickMatch.escalate)
    };
  }
}
function classifyGeminiError(err, modelName) {
  const msg = String(err?.message || "");
  const status = Number(err?.status || 0);
  if (status === 401 || status === 403 || /api[_ ]?key.*invalid|permission denied|API_KEY_INVALID/i.test(msg)) {
    return "Invalid Gemini API key or permission denied. Verify GEMINI_API_KEY in Admin \u2192 Settings & API.";
  }
  if (status === 429 || /quota|resource_exhausted|rate limit/i.test(msg)) {
    return "Gemini API quota or rate limit exceeded. Check billing/quota in Google AI Studio.";
  }
  if (status === 404 || /not found|unsupported model/i.test(msg)) {
    const altModel = modelName === "gemini-2.5-flash" ? "gemini-3-flash-preview" : "gemini-2.5-flash";
    return `Gemini model "${modelName}" is unavailable or unsupported for this API key. Try "${altModel}" or verify GEMINI_API_KEY permissions.`;
  }
  if (/timeout/i.test(msg)) {
    return "Gemini API request timed out after 8 seconds.";
  }
  return msg || "Gemini API connection failed.";
}
async function testGeminiConnection() {
  const apiKey = (process.env.GEMINI_API_KEY || "").trim();
  const modelName = (process.env.GEMINI_MODEL || "").trim() || "gemini-2.5-flash";
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return { ok: false, error: "Save a valid GEMINI_API_KEY first before testing." };
  }
  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
    const config = {};
    if (/^gemini-[34]/i.test(modelName)) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
    }
    const response = await Promise.race([
      ai.models.generateContent({
        model: modelName,
        contents: "Reply with exactly: OK",
        config
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Gemini test timed out")), 8e3))
    ]);
    const txt = (response.text || "").trim();
    if (!txt) {
      return { ok: false, error: "Gemini API returned an empty response." };
    }
    return { ok: true, message: `Gemini API connected cleanly (${modelName}): "${txt.slice(0, 80)}"` };
  } catch (err) {
    return { ok: false, error: classifyGeminiError(err, modelName) };
  }
}
function sanitizeChatTextForStorage(text) {
  return redactSensitiveText(cleanText(text, 2e3));
}
function saveChatTurn(db, conversationId, visitorMsg, assistantMsg, escalated) {
  const safeUser = sanitizeChatTextForStorage(visitorMsg);
  const safeBot = sanitizeChatTextForStorage(assistantMsg);
  const now = nowIso();
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'user', ?, ?)").run(
    conversationId,
    safeUser,
    now
  );
  db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
    conversationId,
    safeBot,
    now
  );
  db.prepare(
    `UPDATE chatbot_conversations
     SET last_message = ?, status = CASE WHEN ? = 1 THEN 'escalated' ELSE status END, updated_at = ?
     WHERE id = ?`
  ).run(safeUser.slice(0, 240), escalated ? 1 : 0, now, conversationId);
}

// server/routes/payments.ts
import { Router as Router3 } from "express";
import crypto6 from "node:crypto";
function verifyRazorpaySignature(orderId, paymentId, signature, secret) {
  if (!orderId || !paymentId || !paymentId.trim() || !signature || !secret) return false;
  const expectedSig = crypto6.createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto6.timingSafeEqual(a, b);
}
function verifyRazorpayWebhookSignature(payloadBody, signature, webhookSecret) {
  if (!payloadBody || !signature || !webhookSecret) return false;
  const expectedSig = crypto6.createHmac("sha256", webhookSecret).update(payloadBody).digest("hex");
  const a = Buffer.from(signature.trim());
  const b = Buffer.from(expectedSig);
  return a.length === b.length && crypto6.timingSafeEqual(a, b);
}
async function testRazorpayConnection() {
  const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
  const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
  if (!keyId || !keySecret) {
    return { ok: false, error: "Save both RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET first before testing." };
  }
  try {
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const resp = await fetch("https://api.razorpay.com/v1/orders?count=1", {
      method: "GET",
      headers: { Authorization: `Basic ${auth}` },
      signal: AbortSignal.timeout(12e3)
    });
    const data = await resp.json();
    if (resp.ok) {
      const mode = keyId.startsWith("rzp_live_") ? "LIVE" : "SANDBOX / TEST";
      return { ok: true, message: `Razorpay ${mode} credentials verified successfully.` };
    }
    return { ok: false, error: data?.error?.description || `Razorpay API returned status ${resp.status}.` };
  } catch (err) {
    return { ok: false, error: err?.message || "Unable to reach Razorpay API." };
  }
}
function runInTransaction(db, fn) {
  db.exec("BEGIN IMMEDIATE;");
  try {
    const result = fn();
    db.exec("COMMIT;");
    return result;
  } catch (err) {
    try {
      db.exec("ROLLBACK;");
    } catch {
    }
    throw err;
  }
}
function sendVerifiedPaymentReceiptEmail(db, studentId, courseTitle, amount, receiptNumber) {
  const student = db.prepare("SELECT full_name, email FROM users WHERE id = ?").get(studentId);
  if (!student?.email) return;
  const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
  void sendTransactionalEmail({
    to: student.email,
    recipientName: student.full_name || "Student",
    subject: `Fee Receipt ${receiptNumber} \u2014 Yuitor Smart Classes`,
    previewText: `Payment of \u20B9${amount} verified for ${courseTitle}.`,
    htmlBody: `<p>Dear {{name}},</p><p>Your payment of <strong>\u20B9${escapeHtml(amount)}</strong> for <strong>${escapeHtml(courseTitle)}</strong> has been verified successfully.</p><p><strong>Official Receipt No.:</strong> ${escapeHtml(receiptNumber)}<br>Your course lessons and materials are now active in your Student Portal.</p>`,
    ctaLabel: "Open Student Portal",
    ctaUrl: `${siteUrl}/student/`,
    department: "fee"
  });
}
function validateBatchCapacity(db, courseId, batchIdRaw, studentId) {
  const batchId = Number(batchIdRaw || 0);
  if (!Number.isInteger(batchId) || batchId <= 0) {
    return { ok: true, batchId: null };
  }
  const batch = db.prepare("SELECT id, name, course_id, seat_limit, is_active FROM batches WHERE id = ?").get(batchId);
  if (!batch || Number(batch.is_active) !== 1 || Number(batch.course_id) !== courseId) {
    return { ok: false, error: "Selected batch was not found for this course." };
  }
  const used = db.prepare(
    "SELECT COUNT(*) as c FROM enrollments WHERE batch_id = ? AND status IN ('active', 'completed') AND student_id != ?"
  ).get(batchId, studentId).c;
  if (used >= Number(batch.seat_limit || 0)) {
    return {
      ok: false,
      error: `Batch "${batch.name}" is full (${used}/${batch.seat_limit} seats occupied). Please choose another batch.`
    };
  }
  return { ok: true, batchId };
}
function createPaymentsRouter(db) {
  const router = Router3();
  router.get("/config", (_req, res) => {
    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    const razorpayEnabled = Boolean(keyId && keySecret);
    res.json({
      razorpayEnabled,
      mode: keyId.startsWith("rzp_live_") ? "live" : razorpayEnabled ? "sandbox" : "unconfigured",
      keyId: razorpayEnabled ? keyId : ""
    });
  });
  router.post("/create-order", async (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required." });
      return;
    }
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `payorder:${ip}:${ctx.user.id}`, 10, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many payment order requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `payorder:${ip}:${ctx.user.id}`, 300);
    const keyId = (process.env.RAZORPAY_KEY_ID || "").trim();
    const keySecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
    if (!keyId || !keySecret) {
      res.status(503).json({ error: "Razorpay credentials are not configured on the server yet." });
      return;
    }
    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId);
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }
    const batchCheck = validateBatchCapacity(db, courseId, req.body?.batchId, ctx.user.id);
    if (!batchCheck.ok) {
      res.status(409).json({ error: batchCheck.error });
      return;
    }
    const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
    let discountAmount = 0;
    const today = nowIso().slice(0, 10);
    if (couponCode) {
      const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode);
      if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses) || coupon.expires_at && coupon.expires_at < today) {
        res.status(400).json({ error: "Invalid or expired coupon code." });
        return;
      }
      discountAmount = coupon.discount_type === "percent" ? Math.round(baseAmount * Number(coupon.discount_value) / 100) : Math.min(baseAmount, Number(coupon.discount_value));
    }
    const finalAmount = Math.max(1, baseAmount - discountAmount);
    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
      const resp = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          amount: finalAmount * 100,
          currency: "INR",
          receipt: `ytr_${ctx.user.id}_${courseId}_${Date.now()}`.slice(0, 40),
          notes: {
            studentId: String(ctx.user.id),
            courseId: String(courseId),
            plan
          }
        }),
        signal: AbortSignal.timeout(12e3)
      });
      const order = await resp.json();
      if (!resp.ok || !order?.id) {
        res.status(502).json({ error: order?.error?.description || "Unable to create Razorpay order." });
        return;
      }
      const now = nowIso();
      const months = plan === "yearly" ? 12 : 1;
      const expiresDate = /* @__PURE__ */ new Date();
      expiresDate.setMonth(expiresDate.getMonth() + months);
      const expiresAt = expiresDate.toISOString().slice(0, 10);
      const invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
      runInTransaction(db, () => {
        const existingEnrollment = db.prepare("SELECT id, status FROM enrollments WHERE student_id = ? AND course_id = ?").get(ctx.user.id, courseId);
        let enrollmentId;
        if (existingEnrollment) {
          enrollmentId = Number(existingEnrollment.id);
          if (batchCheck.batchId) {
            db.prepare("UPDATE enrollments SET batch_id = ? WHERE id = ?").run(batchCheck.batchId, enrollmentId);
          }
        } else {
          const ins = db.prepare(
            `INSERT INTO enrollments (student_id, course_id, batch_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
               VALUES (?, ?, ?, ?, 'pending', 0, 0, ?, ?)`
          ).run(ctx.user.id, courseId, batchCheck.batchId, plan, expiresAt, now);
          enrollmentId = Number(ins.lastInsertRowid);
        }
        db.prepare(
          `INSERT INTO payments
           (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
            gateway_order_id, verification_status, invoice_number, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'gateway', ?, 'pending_verification', ?, ?)`
        ).run(ctx.user.id, courseId, enrollmentId, plan, baseAmount, discountAmount, finalAmount, couponCode, order.id, invoiceNumber, now);
        db.prepare(
          `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
           VALUES (?, ?, ?, ?, ?, 0, ?, 'pending', ?)`
        ).run(ctx.user.id, courseId, `${course.title} (${plan})`, baseAmount, discountAmount, now.slice(0, 10), now);
      });
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: courseId,
        targetName: course.title,
        action: "razorpay_order_created",
        details: `Order ${order.id} for \u20B9${finalAmount} (${plan})`,
        ipAddress: ip
      });
      res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId, invoiceNumber });
    } catch (err) {
      res.status(502).json({ error: err?.message || "Razorpay order creation failed." });
    }
  });
  router.post("/order-failed", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const orderId = cleanText(req.body?.orderId, 100);
    const reason = cleanText(req.body?.reason || "Cancelled or failed in Razorpay Checkout", 300);
    if (!orderId) {
      res.status(400).json({ error: "Order ID required." });
      return;
    }
    const row = db.prepare("SELECT id, verification_status FROM payments WHERE gateway_order_id = ? AND student_id = ? ORDER BY id DESC LIMIT 1").get(orderId, ctx.user.id);
    if (!row) {
      res.status(404).json({ error: "Pending payment order not found." });
      return;
    }
    if (row.verification_status === "pending_verification") {
      db.prepare("UPDATE payments SET verification_status = 'failed' WHERE id = ?").run(row.id);
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: row.id,
        targetName: orderId,
        action: "razorpay_payment_failed_or_cancelled",
        details: reason,
        ipAddress: clientIp(req)
      });
    }
    res.json({ updated: true });
  });
  router.post("/webhook", async (req, res) => {
    const webhookSecret = (process.env.RAZORPAY_WEBHOOK_SECRET || "").trim();
    const signature = String(req.headers["x-razorpay-signature"] || "");
    if (!webhookSecret) {
      res.status(503).json({ error: "RAZORPAY_WEBHOOK_SECRET is not configured." });
      return;
    }
    const rawBody = typeof req.rawBody === "string" ? req.rawBody : JSON.stringify(req.body || {});
    if (!verifyRazorpayWebhookSignature(rawBody, signature, webhookSecret)) {
      res.status(400).json({ error: "Invalid Razorpay webhook signature." });
      return;
    }
    const event = String(req.body?.event || "");
    const paymentEntity = req.body?.payload?.payment?.entity;
    const orderId = cleanText(paymentEntity?.order_id || req.body?.payload?.order?.entity?.id || "", 100);
    const paymentId = cleanText(paymentEntity?.id || "", 100);
    if ((event === "payment.captured" || event === "order.paid") && (orderId || paymentId)) {
      const outcome = runInTransaction(db, () => {
        if (paymentId) {
          const alreadyByPay = db.prepare("SELECT id FROM payments WHERE gateway_payment_id = ? AND verification_status = 'verified' LIMIT 1").get(paymentId);
          if (alreadyByPay) {
            return { updated: false, duplicate: true };
          }
        }
        const row = orderId ? db.prepare(
          `SELECT p.*, c.title as course_title
                 FROM payments p
                 LEFT JOIN courses c ON c.id = p.course_id
                 WHERE p.gateway_order_id = ? ORDER BY p.id DESC LIMIT 1`
        ).get(orderId) : null;
        if (!row) {
          return { updated: false, duplicate: false };
        }
        if (row.verification_status === "verified") {
          return { updated: false, duplicate: true };
        }
        const paidPaise = Number(paymentEntity?.amount || 0);
        const expectedPaise = Math.round(Number(row.amount || 0) * 100);
        const currency = String(paymentEntity?.currency || "INR").toUpperCase();
        if ((paidPaise > 0 && paidPaise !== expectedPaise) || currency !== "INR") {
          writeAuditLog(db, {
            actorId: row.student_id,
            actorName: "Razorpay Webhook",
            targetId: row.id,
            targetName: orderId,
            action: "razorpay_webhook_amount_mismatch",
            details: `Expected ${expectedPaise} paise INR, received ${paidPaise} paise ${currency}`,
            ipAddress: clientIp(req)
          });
          return { updated: false, duplicate: false };
        }
        const now = nowIso();
        const receiptNumber = row.receipt_number || `YTR-RCP-${Date.now().toString().slice(-6)}`;
        db.prepare(
          "UPDATE payments SET verification_status = 'verified', gateway_payment_id = COALESCE(NULLIF(?, ''), gateway_payment_id), receipt_number = ?, paid_at = ? WHERE id = ?"
        ).run(paymentId, receiptNumber, now, row.id);
        if (row.enrollment_id) {
          db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(row.enrollment_id);
        }
        db.prepare(
          `UPDATE fee_records SET status = 'paid', paid_amount = ?
           WHERE id = (SELECT id FROM fee_records WHERE student_id = ? AND course_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1)`
        ).run(row.amount, row.student_id, row.course_id);
        if (row.coupon_code) {
          db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE code = ? AND used_count < max_uses").run(row.coupon_code);
        }
        writeAuditLog(db, {
          actorId: row.student_id,
          actorName: "Razorpay Webhook",
          targetId: row.id,
          targetName: orderId,
          action: "razorpay_webhook_verified",
          details: `Event ${event} verified payment ${paymentId || orderId} (\u20B9${row.amount})`,
          ipAddress: clientIp(req)
        });
        return {
          updated: true,
          duplicate: false,
          paymentId: Number(row.id),
          studentId: Number(row.student_id),
          courseTitle: row.course_title || "Course",
          amount: Number(row.amount),
          receiptNumber
        };
      });
      if (outcome.updated && outcome.studentId) {
        sendVerifiedPaymentReceiptEmail(db, outcome.studentId, outcome.courseTitle, outcome.amount, outcome.receiptNumber);
        await recomputeReferralForStudent(
          db,
          outcome.studentId,
          { eventType: "payment_verified", paymentId: outcome.paymentId, note: "Razorpay webhook verified payment" },
          { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
        );
      }
      res.json({ ok: true, duplicate: outcome.duplicate });
      return;
    }
    if (event === "payment.failed" && orderId) {
      runInTransaction(db, () => {
        const row = db.prepare("SELECT id, student_id, verification_status FROM payments WHERE gateway_order_id = ? ORDER BY id DESC LIMIT 1").get(orderId);
        if (row && row.verification_status === "pending_verification") {
          db.prepare(
            "UPDATE payments SET verification_status = 'failed', gateway_payment_id = COALESCE(NULLIF(?, ''), gateway_payment_id) WHERE id = ?"
          ).run(paymentId, row.id);
          writeAuditLog(db, {
            actorId: row.student_id,
            actorName: "Razorpay Webhook",
            targetId: row.id,
            targetName: orderId,
            action: "razorpay_webhook_failed",
            details: cleanText(paymentEntity?.error_description || "Payment failed", 250),
            ipAddress: clientIp(req)
          });
        }
      });
    }
    res.json({ ok: true });
  });
  router.post("/enroll", async (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student" || ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Approved Student sign-in is required to enroll." });
      return;
    }
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `enroll:${ip}:${ctx.user.id}`, 10, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many enrollment attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `enroll:${ip}:${ctx.user.id}`, 300);
    const courseId = Number(req.body?.courseId);
    const plan = req.body?.plan === "yearly" ? "yearly" : "monthly";
    const paymentMethod = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "upi";
    const utrReference = cleanText(req.body?.utrReference, 80);
    const couponCode = cleanText(req.body?.couponCode, 30).toUpperCase();
    const gOrder = cleanText(req.body?.gatewayOrderId, 100);
    const gPay = cleanText(req.body?.gatewayPaymentId, 100);
    const gSig = cleanText(req.body?.gatewaySignature, 200);
    const course = db.prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1").get(courseId);
    if (!course) {
      res.status(404).json({ error: "Selected course not found." });
      return;
    }
    const batchCheck = validateBatchCapacity(db, courseId, req.body?.batchId, ctx.user.id);
    if (!batchCheck.ok) {
      res.status(409).json({ error: batchCheck.error });
      return;
    }
    if (paymentMethod === "gateway") {
      const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
      if (rzpSecret && (gOrder || gPay || gSig)) {
        if (!gOrder || !gPay || !gSig || !verifyRazorpaySignature(gOrder, gPay, gSig, rzpSecret)) {
          writeAuditLog(db, {
            actorId: ctx.user.id,
            actorName: ctx.user.full_name,
            targetName: gOrder || "missing-order",
            action: "razorpay_signature_failed",
            details: "Invalid Razorpay signature on /api/payments/enroll",
            ipAddress: ip
          });
          res.status(400).json({ error: "Payment gateway signature verification failed." });
          return;
        }
      }
    }
    const txOutcome = runInTransaction(db, () => {
      if (paymentMethod === "gateway" && gPay) {
        const dupByPay = db.prepare("SELECT id, student_id, verification_status, invoice_number, receipt_number, amount FROM payments WHERE gateway_payment_id = ? LIMIT 1").get(gPay);
        if (dupByPay) {
          if (Number(dupByPay.student_id) !== Number(ctx.user.id)) {
            return { statusCode: 409, body: { error: "This payment reference has already been claimed by another account." } };
          }
          if (dupByPay.verification_status === "verified") {
            return {
              statusCode: 200,
              body: {
                enrolled: true,
                duplicatePrevented: true,
                verificationStatus: dupByPay.verification_status,
                invoiceNumber: dupByPay.invoice_number,
                receiptNumber: dupByPay.receipt_number,
                amount: Number(dupByPay.amount),
                message: "Payment already verified! Your enrollment and fee receipt are active."
              }
            };
          }
        }
      }
      const existingOrderRow = paymentMethod === "gateway" && gOrder ? db.prepare("SELECT * FROM payments WHERE gateway_order_id = ? AND student_id = ? ORDER BY id DESC LIMIT 1").get(gOrder, ctx.user.id) : null;
      if (existingOrderRow && existingOrderRow.verification_status === "verified") {
        return {
          statusCode: 200,
          body: {
            enrolled: true,
            duplicatePrevented: true,
            verificationStatus: existingOrderRow.verification_status,
            invoiceNumber: existingOrderRow.invoice_number,
            receiptNumber: existingOrderRow.receipt_number,
            amount: Number(existingOrderRow.amount),
            message: "Payment already verified! Your enrollment and fee receipt are active."
          }
        };
      }
      const baseAmount = plan === "yearly" ? Number(course.yearly_fee) : Number(course.monthly_fee);
      let discountAmount = 0;
      const today = nowIso().slice(0, 10);
      if (couponCode) {
        const coupon = db.prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1").get(couponCode);
        if (!coupon || Number(coupon.used_count) >= Number(coupon.max_uses) || coupon.expires_at && coupon.expires_at < today) {
          return { statusCode: 400, body: { error: "Invalid or expired coupon code." } };
        }
        discountAmount = coupon.discount_type === "percent" ? Math.round(baseAmount * Number(coupon.discount_value) / 100) : Math.min(baseAmount, Number(coupon.discount_value));
        db.prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?").run(coupon.id);
      }
      const computedAmount = Math.max(0, baseAmount - discountAmount);
      const finalAmount = existingOrderRow ? Number(existingOrderRow.amount) : computedAmount;
      const now = nowIso();
      const months = plan === "yearly" ? 12 : 1;
      const expiresDate = /* @__PURE__ */ new Date();
      expiresDate.setMonth(expiresDate.getMonth() + months);
      const expiresAt = expiresDate.toISOString().slice(0, 10);
      let verificationStatus = "pending_verification";
      let receiptNumber = "";
      let paidAt = null;
      let enrollmentStatus = "pending";
      let message = "";
      if (paymentMethod === "gateway") {
        const rzpSecret = (process.env.RAZORPAY_KEY_SECRET || "").trim();
        if (rzpSecret && gOrder && gPay && gSig) {
          // Server-side order ownership + course + amount validation: never verify an order not created on this server for this student & course!
          if (!existingOrderRow || Number(existingOrderRow.course_id) !== Number(courseId) || Number(existingOrderRow.amount) <= 0) {
            return {
              statusCode: 400,
              body: { error: "Gateway order ID does not match a server-created order for this student and course." }
            };
          }
          verificationStatus = "verified";
          enrollmentStatus = "active";
          paidAt = now;
          receiptNumber = `YTR-RCP-${Date.now().toString().slice(-6)}`;
          message = "Gateway signature verified! Your enrollment and fee receipt are now active.";
          writeAuditLog(db, {
            actorId: ctx.user.id,
            actorName: ctx.user.full_name,
            targetId: existingOrderRow.id,
            targetName: gOrder,
            action: "payment_gateway_verified",
            details: `Verified order ${gOrder} / payment ${gPay} (\u20B9${finalAmount})`,
            ipAddress: ip
          });
        } else {
          message = "Online payment gateway credentials (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) are not configured on this server. Enrollment saved as Pending Verification \u2014 submit UTR or pay at the Muradnagar desk.";
        }
      } else {
        message = "Enrollment submitted! Your payment is marked Pending Verification until confirmed by the Yuitor Team.";
      }
      db.prepare(
        `INSERT INTO enrollments (student_id, course_id, batch_id, plan, status, progress_percent, learning_minutes, expires_at, enrolled_at)
         VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)
         ON CONFLICT(student_id, course_id) DO UPDATE SET
           plan = excluded.plan,
           batch_id = COALESCE(excluded.batch_id, enrollments.batch_id),
           status = CASE WHEN enrollments.status IN ('active', 'completed') THEN enrollments.status ELSE excluded.status END,
           expires_at = excluded.expires_at`
      ).run(ctx.user.id, courseId, batchCheck.batchId, plan, enrollmentStatus, expiresAt, now);
      if (batchCheck.batchId) {
        db.prepare("UPDATE student_profiles SET batch_id = ? WHERE user_id = ?").run(batchCheck.batchId, ctx.user.id);
      }
      const enrollment = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?").get(ctx.user.id, courseId);
      let invoiceNumber = "";
      if (existingOrderRow) {
        invoiceNumber = existingOrderRow.invoice_number;
        db.prepare(
          `UPDATE payments
           SET enrollment_id = ?, gateway_payment_id = ?, gateway_signature = ?, verification_status = ?, receipt_number = ?, paid_at = ?
           WHERE id = ?`
        ).run(enrollment.id, gPay, gSig, verificationStatus, receiptNumber, paidAt, existingOrderRow.id);
        if (verificationStatus === "verified") {
          db.prepare(
            `UPDATE fee_records SET status = 'paid', paid_amount = ?
             WHERE id = (SELECT id FROM fee_records WHERE student_id = ? AND course_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1)`
          ).run(finalAmount, ctx.user.id, courseId);
        }
      } else {
        invoiceNumber = `YTR-INV-${Date.now().toString().slice(-6)}`;
        db.prepare(
          `INSERT INTO payments
           (student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount, coupon_code, payment_method,
            utr_reference, gateway_order_id, gateway_payment_id, gateway_signature, verification_status, invoice_number, receipt_number, paid_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          ctx.user.id,
          courseId,
          enrollment.id,
          plan,
          baseAmount,
          discountAmount,
          finalAmount,
          couponCode,
          paymentMethod,
          utrReference,
          gOrder,
          gPay,
          gSig,
          verificationStatus,
          invoiceNumber,
          receiptNumber,
          paidAt,
          now
        );
        db.prepare(
          `INSERT INTO fee_records (student_id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          ctx.user.id,
          courseId,
          `${course.title} (${plan})`,
          baseAmount,
          discountAmount,
          verificationStatus === "verified" ? finalAmount : 0,
          now.slice(0, 10),
          verificationStatus === "verified" ? "paid" : "pending",
          now
        );
      }
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
      ).run(
        `New Enrollment Payment (${paymentMethod.toUpperCase()})`,
        `${ctx.user.full_name} enrolled in ${course.title} (\u20B9${finalAmount}, ${verificationStatus}).`,
        now
      );
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: courseId,
        targetName: course.title,
        action: "enrollment_submitted",
        details: `${plan} \u20B9${finalAmount} (${verificationStatus})`,
        ipAddress: ip
      });
      return {
        statusCode: 201,
        body: {
          enrolled: true,
          verificationStatus,
          invoiceNumber,
          receiptNumber,
          amount: finalAmount,
          message
        },
        sendReceipt: verificationStatus === "verified"
      };
    });
    if (txOutcome.statusCode === 201 && txOutcome.sendReceipt) {
      sendVerifiedPaymentReceiptEmail(
        db,
        ctx.user.id,
        course.title,
        Number(txOutcome.body.amount),
        String(txOutcome.body.receiptNumber || "")
      );
      await recomputeReferralForStudent(
        db,
        ctx.user.id,
        { eventType: "payment_verified", note: "Online gateway enrollment verified" },
        { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
      );
    }
    res.status(txOutcome.statusCode).json(txOutcome.body);
  });
  router.post("/refund-request", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "student") {
      res.status(403).json({ error: "Student sign-in required." });
      return;
    }
    const paymentId = Number(req.body?.paymentId);
    const reason = cleanText(req.body?.reason, 500);
    if (reason.length < 5) {
      res.status(400).json({ error: "Provide a refund reason (min 5 characters)." });
      return;
    }
    const pay = db.prepare("SELECT * FROM payments WHERE id = ? AND student_id = ?").get(paymentId, ctx.user.id);
    if (!pay || pay.verification_status !== "verified") {
      res.status(404).json({ error: "Verified payment record not found." });
      return;
    }
    if (pay.refund_status === "requested" || pay.refund_status === "processed") {
      res.status(409).json({ error: `Refund is already ${pay.refund_status} for this payment.` });
      return;
    }
    db.prepare("UPDATE payments SET refund_status = 'requested', refund_reason = ? WHERE id = ?").run(reason, paymentId);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run("Refund Request", `${ctx.user.full_name} requested refund for payment #${paymentId}: ${reason}`, nowIso());
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: paymentId,
      targetName: `Payment #${paymentId}`,
      action: "refund_requested",
      details: `Student requested refund (\u20B9${pay.amount}): ${reason.slice(0, 200)}`,
      ipAddress: clientIp(req)
    });
    res.json({ requested: true });
  });
  return router;
}

// server/routes/admin.ts
var DOC_ALLOWED_EXT = /* @__PURE__ */ new Set([".pdf", ".txt", ".md"]);
var knowledgeUpload = multer2({
  storage: multer2.diskStorage({
    destination: (_req, _file, cb) => {
      fs10.mkdirSync(KNOWLEDGE_DIR, { recursive: true });
      cb(null, KNOWLEDGE_DIR);
    },
    filename: (_req, file, cb) => {
      const ext = path8.extname(file.originalname || "").toLowerCase();
      const safeExt = DOC_ALLOWED_EXT.has(ext) ? ext : ".pdf";
      cb(null, `doc-${Date.now()}-${crypto7.randomBytes(6).toString("hex")}${safeExt}`);
    }
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path8.extname(file.originalname || "").toLowerCase();
    if (!DOC_ALLOWED_EXT.has(ext)) {
      cb(new Error("Only PDF, TXT, or MD documents up to 8 MB are allowed."));
      return;
    }
    cb(null, true);
  }
}).single("document");
var releaseZipUpload = multer2({
  storage: multer2.diskStorage({
    destination: (_req, _file, cb) => {
      const dir = path8.join(APP_ROOT, "tmp", "uploads");
      fs10.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (_req, _file, cb) => {
      cb(null, `release-${Date.now()}-${crypto7.randomBytes(6).toString("hex")}.zip`);
    }
  }),
  limits: { fileSize: 80 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path8.extname(file.originalname || "").toLowerCase();
    if (ext !== ".zip") {
      cb(new Error("Only .zip release archives up to 80 MB are allowed."));
      return;
    }
    cb(null, true);
  }
}).single("releaseZip");
function createAdminRouter(db) {
  const router = Router4();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/dashboard", (_req, res) => {
    const totalStudents = db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'student'").get().c;
    const totalTeachers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'teacher'").get().c;
    const pendingApprovals = db.prepare(
      "SELECT COUNT(*) as c FROM users WHERE role IN ('student', 'teacher') AND verification_status IN ('pending_approval', 'otp_verified')"
    ).get().c;
    const totalCourses = db.prepare("SELECT COUNT(*) as c FROM courses WHERE is_active = 1").get().c;
    const totalAdmissions = db.prepare("SELECT COUNT(*) as c FROM enrollments WHERE status IN ('active', 'completed')").get().c;
    const newInquiries = db.prepare("SELECT COUNT(*) as c FROM inquiries WHERE status = 'new'").get().c;
    const unresolvedChats = db.prepare("SELECT COUNT(*) as c FROM chatbot_conversations WHERE status IN ('unresolved', 'escalated')").get().c;
    const totalCollected = db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE verification_status = 'verified'").get().s;
    const totalPending = db.prepare(
      "SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) as s FROM fee_records WHERE status != 'refunded'"
    ).get().s;
    const recentActivities = db.prepare("SELECT id, action, actor_name, target_name, details, created_at FROM audit_logs WHERE TRIM(action) != '' ORDER BY id DESC LIMIT 50").all();
    res.json({
      counts: {
        totalStudents,
        totalTeachers,
        pendingApprovals,
        totalCourses,
        totalAdmissions,
        newInquiries,
        unresolvedChats
      },
      feeSummary: {
        totalCollected: Number(totalCollected || 0),
        totalPending: Number(totalPending || 0)
      },
      recentActivities
    });
  });
  router.get("/users", (req, res) => {
    const role = String(req.query.role || "all");
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize || 12)));
    const where = [];
    const params = [];
    if (role !== "all") {
      where.push("u.role = ?");
      params.push(role);
    }
    if (status !== "all") {
      where.push("u.verification_status = ?");
      params.push(status);
    }
    if (search) {
      where.push("(LOWER(u.full_name) LIKE ? OR LOWER(u.email) LIKE ? OR u.phone LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const total = db.prepare(`SELECT COUNT(*) as c FROM users u ${whereSql}`).get(...params).c;
    const users = db.prepare(
      `SELECT u.id, u.role, u.full_name, u.email, u.phone, u.avatar_url, u.mobile_verified,
                u.verification_status, u.is_active, u.marketing_opt_in, u.last_login_at, u.created_at,
                u.staff_role, u.staff_permissions_json, u.branch_id,
                sp.class_level, sp.roll_number, sp.batch_id, sp.branch_id as student_branch_id,
                tp.qualification, tp.resume_filename, tp.resume_status, tp.resume_uploaded_at,
                (CASE WHEN COALESCE(tp.resume_url, '') != '' THEN 1 ELSE 0 END) as has_resume
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         ${whereSql}
         ORDER BY u.id DESC
         LIMIT ? OFFSET ?`
    ).all(...params, pageSize, (page - 1) * pageSize);
    res.json({ users, total, page, pageSize });
  });
  router.post("/users", (req, res) => {
    const ctx = req.ctx;
    const role = String(req.body?.role || "student");
    if (!["student", "teacher", "parent", "staff", "admin"].includes(role)) {
      res.status(400).json({ error: "Invalid role." });
      return;
    }
    if (role === "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Only Super Admin can create Admin accounts." });
      return;
    }
    const fullName = cleanText(req.body?.fullName, 120);
    const email = normalizeEmail(req.body?.email);
    const phone = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || "");
    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone) || password.length < 8) {
      res.status(400).json({ error: "Provide valid name, email, phone, and min 8-char password." });
      return;
    }
    if (db.prepare("SELECT id FROM users WHERE email = ?").get(email)) {
      res.status(409).json({ error: "An account already exists with this email." });
      return;
    }
    const now = nowIso();
    const staffRole = role === "staff" ? cleanText(req.body?.staffRole || "coordinator", 40).toLowerCase() : "";
    const staffPerms = role === "staff" ? JSON.stringify(
      Array.isArray(req.body?.permissions) ? req.body.permissions : String(req.body?.permissions || "").split(",").map((s) => cleanText(s, 40)).filter(Boolean)
    ) : "[]";
    const branchId = req.body?.branchId ? Number(req.body.branchId) : null;
    const resIns = db.prepare(
      `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, staff_role, staff_permissions_json, branch_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, 'approved', 1, 1, ?, ?, ?, ?, ?, ?)`
    ).run(
      role,
      fullName,
      email,
      phone,
      hashPassword(password),
      crypto7.randomBytes(18).toString("hex"),
      staffRole,
      staffPerms,
      branchId,
      now,
      now
    );
    const uid = Number(resIns.lastInsertRowid);
    if (role === "student") {
      const rollNumber = `YTR-STU-${String(uid).padStart(4, "0")}`;
      db.prepare(
        "INSERT INTO student_profiles (user_id, class_level, board, course_duration_months, admission_date, enrollment_status, roll_number, branch_id, parent_phone) VALUES (?, ?, 'CBSE', 12, ?, 'active', ?, ?, ?)"
      ).run(
        uid,
        cleanText(req.body?.classLevel || "Class 10", 60),
        now.slice(0, 10),
        rollNumber,
        branchId,
        normalizePhone(req.body?.parentPhone || "")
      );
    } else if (role === "teacher") {
      db.prepare(
        "INSERT INTO teacher_profiles (user_id, qualification, experience_years, availability_status) VALUES (?, ?, 2, 'available')"
      ).run(uid, cleanText(req.body?.qualification || "Subject Faculty", 120));
    } else if (role === "parent" && req.body?.studentId) {
      db.prepare(
        "INSERT OR IGNORE INTO parent_links (parent_user_id, student_user_id, relation, created_at) VALUES (?, ?, ?, ?)"
      ).run(uid, Number(req.body.studentId), cleanText(req.body?.relation || "Parent / Guardian", 60), now);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_created_user",
      details: `Created approved ${role} (${email})`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ id: uid, created: true });
  });
  router.get("/users/:id", (req, res) => {
    const uid = Number(req.params.id);
    const user = db.prepare(
      `SELECT id, role, full_name, email, phone, avatar_url, mobile_verified,
                verification_status, is_active, marketing_opt_in, last_login_at, created_at,
                staff_role, staff_permissions_json, branch_id
         FROM users WHERE id = ?`
    ).get(uid);
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const studentProfile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || null;
    const teacherProfile = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(uid) || null;
    const otpSummary = db.prepare("SELECT purpose, attempts, consumed_at, created_at FROM otp_tokens WHERE user_id = ? ORDER BY id DESC LIMIT 10").all(uid);
    const history = db.prepare("SELECT action, details, ip_address, created_at FROM audit_logs WHERE target_id = ? OR actor_id = ? ORDER BY id DESC LIMIT 20").all(uid, uid);
    res.json({ user, studentProfile, teacherProfile, otpSummary, history });
  });
  router.patch("/users/:id", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM users WHERE id = ?").get(uid);
    if (!existing) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (existing.role === "super_admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Only Super Admin can edit a Super Admin account." });
      return;
    }
    const fullName = cleanText(req.body?.fullName ?? existing.full_name, 120);
    const email = normalizeEmail(req.body?.email ?? existing.email);
    const phone = normalizePhone(req.body?.phone ?? existing.phone);
    if (fullName.length < 2 || !isValidEmail(email) || !isValidPhone(phone)) {
      res.status(400).json({ error: "Valid name, email, and phone are required." });
      return;
    }
    const conflict = db.prepare("SELECT id FROM users WHERE (email = ? OR (phone != '' AND phone = ?)) AND id != ? LIMIT 1").get(email, phone, uid);
    if (conflict) {
      res.status(409).json({ error: "Another user already uses that email or phone number." });
      return;
    }
    db.prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?").run(
      fullName,
      email,
      phone,
      nowIso(),
      uid
    );
    if (req.body?.studentProfile && existing.role === "student") {
      const sp = req.body.studentProfile;
      db.prepare(
        `INSERT INTO student_profiles (user_id, class_level, board, course_duration_months)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET class_level = excluded.class_level, board = excluded.board, course_duration_months = excluded.course_duration_months`
      ).run(
        uid,
        cleanText(sp.classLevel || "Class 10", 60),
        cleanText(sp.board || "CBSE", 40),
        Math.min(60, Math.max(1, Number(sp.courseDurationMonths || 12)))
      );
    }
    if (req.body?.teacherProfile && existing.role === "teacher") {
      const tp = req.body.teacherProfile;
      db.prepare(
        `INSERT INTO teacher_profiles (user_id, qualification, experience_years)
         VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET qualification = excluded.qualification, experience_years = excluded.experience_years`
      ).run(uid, cleanText(tp.qualification || "", 120), Math.max(0, Number(tp.experienceYears || 0)));
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: fullName,
      action: "admin_edited_user",
      details: "Updated profile details",
      ipAddress: clientIp(req)
    });
    res.json({ updated: true });
  });
  router.post("/users/:id/one-click-mail", async (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const target = db.prepare("SELECT id, role, full_name, email, phone FROM users WHERE id = ?").get(uid);
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (!target.email || !isValidEmail(target.email)) {
      res.status(400).json({ error: "This user does not have a valid email address on file." });
      return;
    }
    if (!isSmtpConfigured()) {
      res.status(400).json({
        error: "SMTP email server is not configured yet. Go to System -> Settings -> Email & SMTP Configuration, verify & save your SMTP credentials first."
      });
      return;
    }
    const customSubject = cleanText(req.body?.subject || "", 200);
    const customMessage = cleanText(req.body?.message || "", 4000);
    const subject = customSubject || `Important Update from Yuitor Smart Classes — ${target.full_name}`;
    const htmlBody = customMessage
      ? `<p>Dear ${escapeHtml(target.full_name)},</p><p>${escapeHtml(customMessage).replace(/\n/g, "<br>")}</p><p>Regards,<br><strong>Yuitor Smart Classes Administration</strong></p>`
      : `<p>Dear ${escapeHtml(target.full_name)},</p><p>Warm greetings from <strong>Yuitor Smart Classes</strong>! This is a quick update from the administration desk regarding your ${escapeHtml(target.role)} portal account.</p><p>Please log in to your Yuitor Portal anytime to view your latest schedules, notices, and records.</p><p>Regards,<br><strong>Yuitor Smart Classes</strong></p>`;
    const result = await sendTransactionalEmail({
      to: target.email,
      recipientName: target.full_name,
      subject,
      previewText: subject,
      htmlBody
    });
    if (!result.ok) {
      res.status(502).json({
        error: `Email delivery failed: ${result.error || "SMTP server rejected the message."}`
      });
      return;
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: customSubject ? "admin_sent_user_mail" : "admin_one_click_mail",
      details: `Sent email "${subject}" to ${target.email}`,
      ipAddress: clientIp(req)
    });
    res.json({ ok: true, sent: true, to: target.email, subject, message: `Email sent successfully to ${target.email}.` });
  });
  router.post("/users/:id/one-click-invoice", async (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const target = db.prepare("SELECT id, role, full_name, email, phone, branch_id FROM users WHERE id = ?").get(uid);
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    const sp = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || null;
    const requestedClass = req.body?.classNumber || req.body?.classLevel || sp?.class_level || "Class 10";
    const requestedCycle = normalizeBillingCycle(req.body?.billingCycle || sp?.billing_cycle || "1m");
    const plan = calculateClassFeePlan(requestedClass, requestedCycle);
    const existingFee = db.prepare("SELECT * FROM fee_records WHERE student_id = ? ORDER BY id DESC LIMIT 1").get(uid);
    const now = nowIso();
    let feeRecordId;
    let invoiceTitle;
    let totalAmount;
    let discountAmount;
    let paidAmount;
    if (existingFee && !req.body?.forceNew && !req.body?.billingCycle) {
      feeRecordId = Number(existingFee.id);
      invoiceTitle = existingFee.title;
      totalAmount = Number(existingFee.total_amount || plan.subtotal);
      discountAmount = Number(existingFee.discount_amount || 0);
      paidAmount = Number(existingFee.paid_amount || 0);
    } else {
      const firstCourse = db.prepare("SELECT id FROM courses WHERE is_active = 1 ORDER BY id ASC LIMIT 1").get();
      const courseId = firstCourse ? Number(firstCourse.id) : null;
      invoiceTitle = `${plan.classLabel} Tuition — ${plan.cycleLabel}`;
      totalAmount = plan.subtotal;
      discountAmount = plan.discountAmount;
      paidAmount = 0;
      const ins = db.prepare(
        `INSERT INTO fee_records (student_id, course_id, branch_id, title, total_amount, discount_amount, paid_amount, due_date, status, billing_cycle, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, ?, 'pending', ?, ?)`
      ).run(uid, courseId, target.branch_id || null, invoiceTitle, totalAmount, discountAmount, now.slice(0, 10), plan.cycle, now);
      feeRecordId = Number(ins.lastInsertRowid);
    }
    const netPayable = Math.max(0, totalAmount - discountAmount);
    const balanceDue = Math.max(0, netPayable - paidAmount);
    const invoiceNumber = `YTR-INV-${String(feeRecordId).padStart(5, "0")}`;
    let emailed = false;
    let emailNote = "Invoice generated ready to print/share.";
    if (target.email && isValidEmail(target.email) && isSmtpConfigured()) {
      const mailRes = await sendTransactionalEmail({
        to: target.email,
        recipientName: target.full_name,
        subject: `Invoice ${invoiceNumber} — Yuitor Smart Classes`,
        previewText: `${invoiceTitle}: ₹${netPayable}`,
        htmlBody: `<p>Dear ${escapeHtml(target.full_name)},</p><p>Your official fee invoice <strong>${escapeHtml(invoiceNumber)}</strong> has been generated.</p><ul><li><strong>Description:</strong> ${escapeHtml(invoiceTitle)}</li><li><strong>Subtotal:</strong> ₹${totalAmount.toLocaleString("en-IN")}</li>${discountAmount > 0 ? `<li><strong>Discount (10% Yearly OFF):</strong> -₹${discountAmount.toLocaleString("en-IN")}</li>` : ""}<li><strong>Net Payable:</strong> ₹${netPayable.toLocaleString("en-IN")}</li><li><strong>Paid:</strong> ₹${paidAmount.toLocaleString("en-IN")}</li><li><strong>Balance Due:</strong> ₹${balanceDue.toLocaleString("en-IN")}</li></ul><p>Regards,<br><strong>Yuitor Smart Classes Accounts Desk</strong></p>`
      });
      emailed = Boolean(mailRes.ok);
      emailNote = emailed ? `Invoice ${invoiceNumber} generated & emailed to ${target.email}.` : `Invoice ${invoiceNumber} generated (email skipped: ${mailRes.error || "SMTP error"}).`;
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: "admin_one_click_invoice",
      details: `Generated ${invoiceNumber} (${invoiceTitle}, net ₹${netPayable})`,
      ipAddress: clientIp(req)
    });
    res.json({
      ok: true,
      feeRecordId,
      invoiceNumber,
      title: invoiceTitle,
      classLabel: plan.classLabel,
      cycleLabel: plan.cycleLabel,
      subtotal: totalAmount,
      discountAmount,
      netPayable,
      paidAmount,
      balanceDue,
      emailed,
      message: emailNote,
      invoicePath: `/users/${uid}/invoice-view/${feeRecordId}`
    });
  });
  router.get("/users/:id/invoice-view/:feeRecordId", (req, res) => {
    const uid = Number(req.params.id);
    const fid = Number(req.params.feeRecordId);
    const user = db.prepare("SELECT id, role, full_name, email, phone FROM users WHERE id = ?").get(uid);
    const fee = db.prepare("SELECT * FROM fee_records WHERE id = ? AND student_id = ?").get(fid, uid);
    if (!user || !fee) {
      res.status(404).send("Invoice not found.");
      return;
    }
    const sp = db.prepare("SELECT roll_number, class_level, board FROM student_profiles WHERE user_id = ?").get(uid) || {};
    const subtotal = Number(fee.total_amount || 0);
    const discount = Number(fee.discount_amount || 0);
    const net = Math.max(0, subtotal - discount);
    const paid = Number(fee.paid_amount || 0);
    const balance = Math.max(0, net - paid);
    const invNo = `YTR-INV-${String(fee.id).padStart(5, "0")}`;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Invoice ${escapeHtml(invNo)} — Yuitor Smart Classes</title>
<style>body{font-family:system-ui,-apple-system,sans-serif;background:#f5f7fb;color:#0f172a;padding:24px;margin:0}.inv{max-width:740px;margin:0 auto;background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:28px}.head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0f172a;padding-bottom:16px;margin-bottom:20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px}table{width:100%;border-collapse:collapse;margin-bottom:20px}th,td{padding:10px 12px;border-bottom:1px solid #e2e8f0;text-align:left;font-size:14px}th{background:#f8fafc;font-size:12px;text-transform:uppercase;color:#475569}.tot{font-size:18px;font-weight:800}.btn{background:#1d63ed;color:#fff;border:0;border-radius:8px;padding:9px 16px;font-weight:700;cursor:pointer}@media print{.no-print{display:none}body{background:#fff;padding:0}.inv{border:0}}</style></head>
<body><div class="inv">
<div class="head"><div><h1 style="margin:0;font-size:22px">Yuitor Smart Classes</h1><p style="margin:4px 0 0;color:#475569;font-size:13px">Muradnagar, Ghaziabad · Official Tuition Fee Invoice</p></div>
<div style="text-align:right"><strong>${escapeHtml(invNo)}</strong><div style="font-size:12px;color:#475569">Date: ${escapeHtml(String(fee.created_at || "").slice(0, 10))}</div><div style="font-size:12px;color:#475569">Status: ${escapeHtml(fee.status || "pending")}</div></div></div>
<div class="grid"><div><strong>Billed To</strong><div>${escapeHtml(user.full_name)} (${escapeHtml(user.role)})</div><div style="font-size:13px;color:#475569">${escapeHtml(user.email)} · ${escapeHtml(user.phone)}</div></div>
<div><strong>Academic Info</strong><div>Class: ${escapeHtml(sp.class_level || "General")} · Board: ${escapeHtml(sp.board || "-")}</div><div style="font-size:13px;color:#475569">Roll No: ${escapeHtml(sp.roll_number || `#${user.id}`)} · Cycle: ${escapeHtml(fee.billing_cycle || "1m")}</div></div></div>
<table><thead><tr><th>Description</th><th style="text-align:right">Amount (INR)</th></tr></thead><tbody>
<tr><td>${escapeHtml(fee.title)}</td><td style="text-align:right">₹${subtotal.toLocaleString("en-IN")}</td></tr>
${discount > 0 ? `<tr><td>Plan / Yearly Discount</td><td style="text-align:right;color:#15803d">- ₹${discount.toLocaleString("en-IN")}</td></tr>` : ""}
<tr><td><strong>Net Payable</strong></td><td style="text-align:right" class="tot">₹${net.toLocaleString("en-IN")}</td></tr>
<tr><td>Amount Paid</td><td style="text-align:right">₹${paid.toLocaleString("en-IN")}</td></tr>
<tr><td><strong>Balance Due</strong></td><td style="text-align:right"><strong>₹${balance.toLocaleString("en-IN")}</strong></td></tr>
</tbody></table>
<div class="no-print" style="display:flex;gap:10px;justify-content:flex-end"><button class="btn" onclick="window.print()">Print / Save PDF</button></div>
</div></body></html>`);
  });
  router.delete("/users/:id", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    if (!Number.isInteger(uid) || uid <= 0) {
      res.status(400).json({ error: "Invalid user ID." });
      return;
    }
    if (uid === Number(ctx.user.id)) {
      res.status(400).json({ error: "You cannot delete your own currently logged-in Admin account." });
      return;
    }
    const target = db.prepare("SELECT id, role, full_name, email, phone FROM users WHERE id = ?").get(uid);
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (target.role === "super_admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Only a Super Admin can delete another Super Admin account." });
      return;
    }
    try {
      db.exec("PRAGMA foreign_keys = OFF;");
      db.exec("BEGIN IMMEDIATE;");
      try {
        const safeExec = (sql, ...params) => {
          try { db.prepare(sql).run(...params); } catch {}
        };
        safeExec("DELETE FROM sessions WHERE user_id = ? OR impersonator_id = ?", uid, uid);
        safeExec("DELETE FROM otp_tokens WHERE user_id = ?", uid);
        safeExec("DELETE FROM notifications WHERE user_id = ?", uid);
        safeExec("DELETE FROM student_profiles WHERE user_id = ?", uid);
        safeExec("DELETE FROM teacher_profiles WHERE user_id = ?", uid);
        safeExec("DELETE FROM parent_student_links WHERE parent_id = ? OR student_id = ?", uid, uid);
        safeExec("DELETE FROM enrollments WHERE student_id = ?", uid);
        safeExec("DELETE FROM attendance WHERE student_id = ?", uid);
        safeExec("DELETE FROM fee_installments WHERE student_id = ?", uid);
        safeExec("DELETE FROM fee_records WHERE student_id = ?", uid);
        safeExec("DELETE FROM payments WHERE student_id = ?", uid);
        safeExec("DELETE FROM library_issues WHERE student_id = ?", uid);
        safeExec("DELETE FROM referral_profiles WHERE user_id = ?", uid);
        safeExec("DELETE FROM wallet_accounts WHERE user_id = ?", uid);
        safeExec("DELETE FROM users WHERE id = ?", uid);
        db.exec("COMMIT;");
      } catch (innerErr) {
        try { db.exec("ROLLBACK;"); } catch {}
        throw innerErr;
      }
    } catch (err) {
      res.status(500).json({ error: err?.message || "Failed to delete user safely." });
      return;
    } finally {
      try { db.exec("PRAGMA foreign_keys = ON;"); } catch {}
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: "admin_deleted_user",
      details: `Safely deleted ${target.role} account (${target.email})`,
      ipAddress: clientIp(req)
    });
    res.json({ ok: true, deleted: true, id: uid, message: `${target.full_name} (${target.role}) was safely deleted.` });
  });
  router.post("/users/:id/status", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const action = String(req.body?.action || "").toLowerCase();
    const reason = cleanText(req.body?.reason, 300);
    const target = db.prepare("SELECT * FROM users WHERE id = ?").get(uid);
    if (!target) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (target.role === "super_admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Cannot modify a Super Admin account." });
      return;
    }
    let nextStatus = target.verification_status;
    let isActive = Number(target.is_active);
    if (action === "approve") {
      if (target.role === "teacher") {
        const tp = db.prepare("SELECT resume_url, resume_status FROM teacher_profiles WHERE user_id = ?").get(uid);
        if (!tp?.resume_url || !["submitted", "verified"].includes(String(tp.resume_status || ""))) {
          res.status(400).json({
            error: "Cannot approve teacher account until a valid resume has been submitted and is not rejected."
          });
          return;
        }
        if (tp.resume_status === "submitted") {
          db.prepare("UPDATE teacher_profiles SET resume_status = 'verified' WHERE user_id = ?").run(uid);
        }
      }
      nextStatus = "approved";
      isActive = 1;
      if (target.role === "student") {
        db.prepare(
          "UPDATE student_profiles SET enrollment_status = 'active', admission_date = COALESCE(admission_date, ?) WHERE user_id = ?"
        ).run(nowIso().slice(0, 10), uid);
      }
    } else if (action === "activate") {
      isActive = 1;
      if (nextStatus === "suspended") nextStatus = "approved";
    } else if (action === "suspend") {
      nextStatus = "suspended";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else if (action === "reject") {
      nextStatus = "rejected";
      isActive = 0;
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(uid);
    } else {
      res.status(400).json({ error: "Invalid status action." });
      return;
    }
    db.prepare("UPDATE users SET verification_status = ?, is_active = ?, updated_at = ? WHERE id = ?").run(
      nextStatus,
      isActive,
      nowIso(),
      uid
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      uid,
      `Account ${nextStatus}`,
      reason || `Your Yuitor Smart Classes account status is now ${nextStatus}.`,
      nowIso()
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: target.full_name,
      action: `user_${action}`,
      details: reason || `Status updated to ${nextStatus}`,
      ipAddress: clientIp(req)
    });
    if (isSmtpConfigured() && target.email && ["approve", "reject", "suspend", "activate"].includes(action)) {
      const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
      const statusText = action === "approve" ? "approved and activated" : action === "activate" ? "reactivated" : action === "reject" ? "not approved" : "temporarily suspended";
      void sendTransactionalEmail({
        to: target.email,
        recipientName: target.full_name || "Member",
        subject: `Yuitor Portal Account ${nextStatus.toUpperCase()} \u2014 Yuitor Smart Classes`,
        previewText: `Your Yuitor Smart Classes account has been ${statusText}.`,
        htmlBody: `<p>Dear {{name}},</p><p>Your Yuitor Smart Classes ${escapeHtml(target.role)} portal account has been <strong>${escapeHtml(statusText)}</strong>.</p>${reason ? `<p><strong>Note:</strong> ${escapeHtml(reason)}</p>` : ""}`,
        ctaLabel: action === "approve" || action === "activate" ? "Sign In to Portal" : "Contact Yuitor Team",
        ctaUrl: action === "approve" || action === "activate" ? `${siteUrl}/login` : `${siteUrl}/contact`
      });
    }
    res.json({ updated: true, verificationStatus: nextStatus, isActive });
  });
  router.get("/users/:id/resume", (req, res) => {
    const uid = Number(req.params.id);
    const tp = db.prepare("SELECT resume_url, resume_filename, resume_mime FROM teacher_profiles WHERE user_id = ?").get(uid);
    const fileName = path8.basename(String(tp?.resume_url || ""));
    const full = path8.join(RESUMES_DIR, fileName);
    if (!fileName || !full.startsWith(RESUMES_DIR) || !fs10.existsSync(full)) {
      res.status(404).json({ error: "No resume file found for this teacher." });
      return;
    }
    if (tp.resume_mime) res.setHeader("Content-Type", tp.resume_mime);
    const dlName = (tp.resume_filename || fileName).replace(/["\r\n]/g, "");
    res.setHeader("Content-Disposition", `inline; filename="${dlName}"`);
    res.sendFile(full);
  });
  router.post("/users/:id/resume-review", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const status = String(req.body?.status || "").toLowerCase();
    const notes = cleanText(req.body?.notes || "", 500);
    if (!["verified", "rejected"].includes(status)) {
      res.status(400).json({ error: "Resume review status must be verified or rejected." });
      return;
    }
    const target = db.prepare("SELECT id, full_name, role FROM users WHERE id = ?").get(uid);
    if (!target || target.role !== "teacher") {
      res.status(404).json({ error: "Teacher account not found." });
      return;
    }
    const tp = db.prepare("SELECT resume_url FROM teacher_profiles WHERE user_id = ?").get(uid);
    if (!tp?.resume_url) {
      res.status(400).json({ error: "Teacher has not uploaded a resume yet." });
      return;
    }
    db.prepare("UPDATE teacher_profiles SET resume_status = ?, resume_notes = ? WHERE user_id = ?").run(status, notes, uid);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      uid,
      status === "verified" ? "Resume Verified" : "Resume Update Requested",
      status === "verified" ? "Your teacher resume has been verified by the Yuitor Academic Team." : notes || "Kindly upload an updated resume for review in your Teacher Portal.",
      nowIso()
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: target.full_name,
      action: `teacher_resume_${status}`,
      details: notes || `Resume marked as ${status}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true, resumeStatus: status, resumeNotes: notes });
  });
  router.post("/impersonate", (req, res) => {
    const ctx = req.ctx;
    const targetId = Number(req.body?.userId);
    const reason = cleanText(req.body?.reason, 200);
    if (reason.length < 4) {
      res.status(400).json({ error: "Provide a clear troubleshooting reason (min 4 characters)." });
      return;
    }
    const target = db.prepare("SELECT id, role, full_name FROM users WHERE id = ?").get(targetId);
    if (!target || !["student", "teacher"].includes(target.role)) {
      res.status(400).json({ error: "Admins can only impersonate Student or Teacher panels." });
      return;
    }
    const now = nowIso();
    db.prepare("INSERT INTO impersonation_logs (admin_id, target_user_id, reason, started_at) VALUES (?, ?, ?, ?)").run(
      ctx.user.id,
      target.id,
      reason,
      now
    );
    const impSid = createSession(db, target.id, {
      impersonatorId: ctx.user.id,
      reason,
      ttlSeconds: 1800
    });
    setSessionCookie(res, req, impSid, 1800);
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: target.id,
      targetName: target.full_name,
      action: "impersonation_started",
      details: reason,
      ipAddress: clientIp(req)
    });
    res.json({ redirectTo: target.role === "teacher" ? "/teacher/" : "/student/" });
  });
  router.get("/courses", (_req, res) => {
    const courses = db.prepare(
      `SELECT c.*, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status IN ('active', 'completed')) as active_students
         FROM courses c
         LEFT JOIN users u ON u.id = c.teacher_id
         ORDER BY c.id DESC`
    ).all();
    const subjects = db.prepare("SELECT * FROM subjects ORDER BY id DESC").all();
    const teachers = db.prepare("SELECT id, full_name, email FROM users WHERE role = 'teacher' AND verification_status = 'approved' ORDER BY full_name").all();
    res.json({ courses, subjects, teachers });
  });
  router.post("/courses", (req, res) => {
    const title = cleanText(req.body?.title, 160);
    if (title.length < 3) {
      res.status(400).json({ error: "Course title is required." });
      return;
    }
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    const resIns = db.prepare(
      `INSERT INTO courses (title, slug, category, class_range, board, description, duration_months, monthly_fee, yearly_fee, teacher_id, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    ).run(
      title,
      slug,
      cleanText(req.body?.category || "Classes 6-12", 60),
      cleanText(req.body?.classRange || "Classes 9\u201310", 60),
      cleanText(req.body?.board || "CBSE", 60),
      cleanText(req.body?.description || "", 1e3),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths || 12))),
      Math.max(0, Number(req.body?.monthlyFee || 1400)),
      Math.max(0, Number(req.body?.yearlyFee || 14300)),
      req.body?.teacherId ? Number(req.body.teacherId) : null,
      nowIso()
    );
    res.status(201).json({ id: Number(resIns.lastInsertRowid) });
  });
  router.patch("/courses/:id", (req, res) => {
    const cid = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid);
    if (!existing) {
      res.status(404).json({ error: "Course not found." });
      return;
    }
    db.prepare(
      `UPDATE courses SET title = ?, category = ?, class_range = ?, board = ?, description = ?, duration_months = ?, monthly_fee = ?, yearly_fee = ?, teacher_id = ? WHERE id = ?`
    ).run(
      cleanText(req.body?.title ?? existing.title, 160),
      cleanText(req.body?.category ?? existing.category, 60),
      cleanText(req.body?.classRange ?? existing.class_range, 60),
      cleanText(req.body?.board ?? existing.board ?? "CBSE", 60),
      cleanText(req.body?.description ?? existing.description ?? "", 1e3),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths ?? existing.duration_months ?? 12))),
      Math.max(0, Number(req.body?.monthlyFee ?? existing.monthly_fee)),
      Math.max(0, Number(req.body?.yearlyFee ?? existing.yearly_fee)),
      req.body?.teacherId === "" ? null : req.body?.teacherId ? Number(req.body.teacherId) : existing.teacher_id,
      cid
    );
    res.json({ updated: true });
  });
  router.delete("/courses/:id", (req, res) => {
    db.prepare("DELETE FROM courses WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/subjects", (req, res) => {
    const name = cleanText(req.body?.name, 120);
    const code = cleanText(req.body?.code, 30).toUpperCase();
    if (!name || !code) {
      res.status(400).json({ error: "Subject name and code are required." });
      return;
    }
    db.prepare("INSERT INTO subjects (name, code, class_level, description, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      name,
      code,
      cleanText(req.body?.classLevel || "Classes 6\u201312", 80),
      cleanText(req.body?.description || "", 500),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/subjects/:id", (req, res) => {
    db.prepare("DELETE FROM subjects WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/payments", (_req, res) => {
    const payments = db.prepare(
      `SELECT p.*, u.full_name as student_name, u.email as student_email, c.title as course_title
         FROM payments p
         JOIN users u ON u.id = p.student_id
         JOIN courses c ON c.id = p.course_id
         ORDER BY p.id DESC`
    ).all();
    const coupons = db.prepare("SELECT * FROM coupons ORDER BY id DESC").all();
    res.json({ payments, coupons });
  });
  router.post("/coupons", (req, res) => {
    const code = cleanText(req.body?.code, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const discountType = req.body?.discountType === "flat" ? "flat" : "percent";
    const discountValue = Math.max(1, Number(req.body?.discountValue || 10));
    const maxUses = Math.max(1, Number(req.body?.maxUses || 100));
    if (code.length < 3) {
      res.status(400).json({ error: "Coupon code must be at least 3 characters." });
      return;
    }
    db.prepare(
      "INSERT INTO coupons (code, discount_type, discount_value, max_uses, used_count, is_active, created_at) VALUES (?, ?, ?, ?, 0, 1, ?)"
    ).run(code, discountType, discountValue, maxUses, nowIso());
    res.status(201).json({ created: true });
  });
  router.post("/payments/:id/verify", async (req, res) => {
    const ctx = req.ctx;
    const pid = Number(req.params.id);
    const decision = String(req.body?.decision || "verify");
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid);
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }
    if (decision === "verify") {
      if (pay.verification_status === "verified") {
        res.status(409).json({ error: "Payment is already verified." });
        return;
      }
      const receipt = pay.receipt_number || `YTR-RCP-${String(pid).padStart(5, "0")}`;
      const paidAt = nowIso();
      db.prepare("UPDATE payments SET verification_status = 'verified', receipt_number = ?, paid_at = ? WHERE id = ?").run(
        receipt,
        paidAt,
        pid
      );
      if (pay.enrollment_id) {
        db.prepare("UPDATE enrollments SET status = 'active' WHERE id = ?").run(pay.enrollment_id);
      }
      db.prepare("UPDATE fee_records SET paid_amount = total_amount - discount_amount, status = 'paid' WHERE student_id = ? AND course_id = ?").run(
        pay.student_id,
        pay.course_id
      );
      db.prepare("INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)").run(
        pay.student_id,
        "Payment Verified",
        `Your fee payment of \u20B9${pay.amount} (Receipt ${receipt}) is verified. Course access is now active.`,
        paidAt
      );
      const stu = db.prepare("SELECT full_name, email FROM users WHERE id = ?").get(pay.student_id);
      const crs = db.prepare("SELECT title FROM courses WHERE id = ?").get(pay.course_id);
      if (isSmtpConfigured() && stu?.email) {
        const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
        void sendTransactionalEmail({
          to: stu.email,
          recipientName: stu.full_name || "Student",
          subject: `Fee Receipt ${receipt} Verified \u2014 Yuitor Smart Classes`,
          previewText: `Your payment of \u20B9${pay.amount} is verified.`,
          htmlBody: `<p>Dear {{name}},</p><p>Your payment of <strong>\u20B9${escapeHtml(pay.amount)}</strong> for <strong>${escapeHtml(crs?.title || "Course")}</strong> has been verified.</p><p><strong>Official Receipt No.:</strong> ${escapeHtml(receipt)}</p>`,
          ctaLabel: "View Fee Receipt",
          ctaUrl: `${siteUrl}/student/`,
          department: "fee"
        });
      }
      await recomputeReferralForStudent(
        db,
        pay.student_id,
        { eventType: "payment_verified", paymentId: pid, actorId: ctx.user.id, note: `Admin verified payment #${pid}` },
        { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
      );
    } else {
      db.prepare("UPDATE payments SET verification_status = 'failed' WHERE id = ?").run(pid);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: `payment_${decision}`,
      details: `Amount \u20B9${pay.amount}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true });
  });
  router.post("/payments/:id/refund", async (req, res) => {
    const ctx = req.ctx;
    const pid = Number(req.params.id);
    const pay = db.prepare("SELECT * FROM payments WHERE id = ?").get(pid);
    if (!pay) {
      res.status(404).json({ error: "Payment record not found." });
      return;
    }
    if (pay.verification_status === "refunded" || pay.refund_status === "processed") {
      res.status(409).json({ error: "This payment has already been refunded." });
      return;
    }
    db.prepare("UPDATE payments SET verification_status = 'refunded', refund_status = 'processed' WHERE id = ?").run(pid);
    if (pay.enrollment_id) {
      db.prepare("UPDATE enrollments SET status = 'cancelled' WHERE id = ?").run(pay.enrollment_id);
    }
    db.prepare("UPDATE fee_records SET status = 'refunded' WHERE student_id = ? AND course_id = ?").run(
      pay.student_id,
      pay.course_id
    );
    await recomputeReferralForStudent(
      db,
      pay.student_id,
      { eventType: "payment_refunded", paymentId: pid, actorId: ctx.user.id, note: `Admin refunded payment #${pid}` },
      { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: pay.student_id,
      targetName: `Payment #${pid}`,
      action: "payment_refunded",
      details: `Refunded \u20B9${pay.amount}`,
      ipAddress: clientIp(req)
    });
    res.json({ refunded: true });
  });
  router.get("/inquiries", (_req, res) => {
    const inquiries = db.prepare(
      `SELECT i.*, br.name as branch_name
         FROM inquiries i
         LEFT JOIN branches br ON br.id = i.branch_id
         ORDER BY i.id DESC`
    ).all();
    res.json({ inquiries });
  });
  router.patch("/inquiries/:id", (req, res) => {
    const existing = db.prepare("SELECT * FROM inquiries WHERE id = ?").get(Number(req.params.id));
    if (!existing) {
      res.status(404).json({ error: "Inquiry not found." });
      return;
    }
    const status = String(req.body?.status ?? existing.status ?? "new");
    if (!["new", "contacted", "admitted", "closed"].includes(status)) {
      res.status(400).json({ error: "Invalid inquiry status." });
      return;
    }
    db.prepare(
      `UPDATE inquiries
       SET status = ?, follow_up_date = ?, follow_up_notes = ?, assigned_staff = ?,
           demo_date = ?, demo_time_slot = ?, branch_id = ?
       WHERE id = ?`
    ).run(
      status,
      cleanText(req.body?.followUpDate ?? existing.follow_up_date ?? "", 20),
      cleanText(req.body?.followUpNotes ?? existing.follow_up_notes ?? "", 500),
      cleanText(req.body?.assignedStaff ?? existing.assigned_staff ?? "", 80),
      cleanText(req.body?.demoDate ?? existing.demo_date ?? "", 20),
      cleanText(req.body?.demoTimeSlot ?? existing.demo_time_slot ?? "", 60),
      req.body?.branchId !== void 0 ? req.body.branchId ? Number(req.body.branchId) : null : existing.branch_id,
      Number(req.params.id)
    );
    res.json({ updated: true });
  });
  router.delete("/inquiries/:id", (req, res) => {
    db.prepare("DELETE FROM inquiries WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/cms", (_req, res) => {
    res.json({
      announcements: db.prepare("SELECT * FROM announcements ORDER BY id DESC").all(),
      banners: db.prepare("SELECT * FROM banners ORDER BY id DESC").all(),
      blogPosts: db.prepare("SELECT * FROM blog_posts ORDER BY id DESC").all(),
      faqs: db.prepare("SELECT * FROM faqs ORDER BY sort_order ASC, id DESC").all(),
      testimonials: db.prepare("SELECT * FROM testimonials ORDER BY id DESC").all()
    });
  });
  router.post("/cms/announcements", (req, res) => {
    const ctx = req.ctx;
    db.prepare("INSERT INTO announcements (title, body, audience, created_by, created_at) VALUES (?, ?, ?, ?, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.body, 2e3),
      ["all", "students", "teachers", "public"].includes(req.body?.audience) ? req.body.audience : "all",
      ctx.user.id,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/announcements/:id", (req, res) => {
    db.prepare("DELETE FROM announcements WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/banners", (req, res) => {
    const safeHref = sanitizeHttpOrUploadUrl(req.body?.ctaHref, 200) || "/admission";
    db.prepare("INSERT INTO banners (title, subtitle, cta_label, cta_href, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.title, 180),
      cleanText(req.body?.subtitle, 300),
      cleanText(req.body?.ctaLabel || "Apply for Admission", 60),
      safeHref,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/banners/:id", (req, res) => {
    db.prepare("DELETE FROM banners WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/blog", (req, res) => {
    const title = cleanText(req.body?.title, 200);
    const slug = `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    db.prepare("INSERT INTO blog_posts (title, slug, category, excerpt, content, is_published, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)").run(
      title,
      slug,
      cleanText(req.body?.category || "Study Tips", 60),
      cleanText(req.body?.excerpt, 400),
      cleanText(req.body?.content, 1e4),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/blog/:id", (req, res) => {
    db.prepare("DELETE FROM blog_posts WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/faqs", (req, res) => {
    db.prepare("INSERT INTO faqs (question, answer, sort_order, is_active, created_at) VALUES (?, ?, 99, 1, ?)").run(
      cleanText(req.body?.question, 300),
      cleanText(req.body?.answer, 2e3),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/faqs/:id", (req, res) => {
    db.prepare("DELETE FROM faqs WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.post("/cms/testimonials", (req, res) => {
    db.prepare("INSERT INTO testimonials (author_name, author_role, outcome_metric, quote, is_approved, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(
      cleanText(req.body?.authorName, 120),
      cleanText(req.body?.authorRole || "Student", 120),
      cleanText(req.body?.outcomeMetric, 120),
      cleanText(req.body?.quote, 1e3),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.delete("/cms/testimonials/:id", (req, res) => {
    db.prepare("DELETE FROM testimonials WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/chatbot", (req, res) => {
    const status = String(req.query.status || "all");
    const search = cleanText(req.query.search, 120).toLowerCase();
    const minRating = Number(req.query.minRating || 0);
    const where = [];
    const params = [];
    if (status !== "all") {
      where.push("status = ?");
      params.push(status);
    }
    if (minRating > 0) {
      where.push("rating >= ?");
      params.push(minRating);
    }
    if (search) {
      where.push(
        "(LOWER(visitor_name) LIKE ? OR visitor_phone LIKE ? OR LOWER(visitor_email) LIKE ? OR LOWER(last_message) LIKE ? OR id IN (SELECT conversation_id FROM chatbot_messages WHERE LOWER(message) LIKE ?))"
      );
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }
    const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const conversations = db.prepare(`SELECT * FROM chatbot_conversations ${whereSql} ORDER BY updated_at DESC LIMIT 100`).all(...params);
    res.json({ conversations });
  });
  router.get("/chatbot/:id", (req, res) => {
    const conversation = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(req.params.id);
    if (!conversation) {
      res.status(404).json({ error: "Conversation not found." });
      return;
    }
    const messages = db.prepare("SELECT * FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(req.params.id);
    res.json({ conversation, messages });
  });
  router.patch("/chatbot/:id", (req, res) => {
    const status = String(req.body?.status || "resolved");
    if (!["active", "unresolved", "escalated", "resolved"].includes(status)) {
      res.status(400).json({ error: "Invalid conversation status." });
      return;
    }
    db.prepare("UPDATE chatbot_conversations SET status = ?, updated_at = ? WHERE id = ?").run(
      status,
      nowIso(),
      req.params.id
    );
    res.json({ updated: true });
  });
  router.get("/knowledge-docs", (_req, res) => {
    const docs = db.prepare(
      `SELECT id, title, filename, mime_type, size_bytes, length(extracted_text) as char_count, is_active, created_at
         FROM knowledge_documents ORDER BY id DESC LIMIT 100`
    ).all();
    res.json({ docs });
  });
  router.post("/knowledge-docs", (req, res) => {
    const ctx = req.ctx;
    knowledgeUpload(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err?.message || "Document upload failed." });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "Please upload a PDF, TXT, or MD knowledge document." });
        return;
      }
      const ext = path8.extname(req.file.originalname || req.file.filename).toLowerCase();
      if (!validateUploadMagicBytes(req.file.path, ext)) {
        try {
          fs10.unlinkSync(req.file.path);
        } catch {
        }
        res.status(400).json({ error: "Uploaded document failed file format verification." });
        return;
      }
      const extracted = extractTextFromDocumentFile(req.file.path, ext);
      if (!extracted) {
        try {
          fs10.unlinkSync(req.file.path);
        } catch {
        }
        res.status(400).json({
          error: "No readable text could be extracted from that document. Scanned image-only PDFs require OCR or a text-based PDF/TXT file."
        });
        return;
      }
      const title = cleanText(req.body?.title || path8.basename(req.file.originalname, ext), 160) || "Yuitor Knowledge Document";
      const now = nowIso();
      const ins = db.prepare(
        `INSERT INTO knowledge_documents (title, filename, mime_type, size_bytes, file_path, extracted_text, is_active, uploaded_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`
      ).run(
        title,
        cleanText(req.file.originalname || req.file.filename, 180),
        cleanText(req.file.mimetype || "application/pdf", 120),
        Number(req.file.size || 0),
        `knowledge/${req.file.filename}`,
        extracted,
        ctx.user.id,
        now
      );
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: Number(ins.lastInsertRowid),
        targetName: title,
        action: "knowledge_doc_uploaded",
        details: `${req.file.originalname} (${extracted.length} chars indexed)`,
        ipAddress: clientIp(req)
      });
      res.status(201).json({
        created: true,
        doc: {
          id: Number(ins.lastInsertRowid),
          title,
          filename: req.file.originalname,
          char_count: extracted.length,
          created_at: now
        }
      });
    });
  });
  router.delete("/knowledge-docs/:id", (req, res) => {
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT id, file_path FROM knowledge_documents WHERE id = ?").get(id);
    if (existing?.file_path) {
      const full = path8.join(KNOWLEDGE_DIR, path8.basename(existing.file_path));
      if (full.startsWith(KNOWLEDGE_DIR) && fs10.existsSync(full)) {
        try {
          fs10.unlinkSync(full);
        } catch {
        }
      }
    }
    db.prepare("DELETE FROM knowledge_documents WHERE id = ?").run(id);
    res.json({ deleted: true });
  });
  router.get("/notifications", (_req, res) => {
    const notifications = db.prepare("SELECT * FROM notifications WHERE role_target = 'admin' OR role_target = 'all' ORDER BY id DESC LIMIT 30").all();
    res.json({ notifications });
  });
  router.post("/notifications/read-all", (_req, res) => {
    db.prepare("UPDATE notifications SET is_read = 1 WHERE role_target = 'admin'").run();
    res.json({ updated: true });
  });
  router.get("/backups", (_req, res) => {
    fs10.mkdirSync(BACKUPS_DIR, { recursive: true });
    const files = fs10.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith(".db")).map((f) => {
      const full = path8.join(BACKUPS_DIR, f);
      const st = fs10.statSync(full);
      const integrity = verifyBackupIntegrity(full);
      return { filename: f, sizeBytes: st.size, createdAt: st.mtime.toISOString(), integrityOk: integrity.ok };
    }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json({ backups: files });
  });
  router.post("/backups", (req, res) => {
    const ctx = req.ctx;
    const backup = createDatabaseBackup(db, "admin");
    try {
      const fullPath = path8.join(BACKUPS_DIR, path8.basename(backup.filename));
      if (fs10.existsSync(fullPath)) fs10.chmodSync(fullPath, 0o600);
    } catch {
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      action: "database_backup_created",
      details: `${backup.filename} (integrity: ${backup.integrityOk ? "ok" : "warning"})`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ backup });
  });
  router.get("/backups/:filename", (req, res) => {
    const safeName = path8.basename(req.params.filename);
    if (!/^[a-zA-Z0-9._-]+\.db$/.test(safeName)) {
      res.status(400).json({ error: "Invalid backup filename." });
      return;
    }
    const full = path8.resolve(BACKUPS_DIR, safeName);
    const root = path8.resolve(BACKUPS_DIR) + path8.sep;
    if (!full.startsWith(root) || !fs10.existsSync(full)) {
      res.status(404).json({ error: "Backup file not found." });
      return;
    }
    res.setHeader("Cache-Control", "private, no-store");
    res.download(full, safeName);
  });
  router.get("/project-zip", (req, res) => {
    const isSource = String(req.query.type || "").toLowerCase() === "source";
    if (isSource) {
      const sourceZip = path8.join(APP_ROOT, "dist-shared", "yuitor-complete-source-code.zip");
      if (!fs10.existsSync(sourceZip)) {
        res.status(404).json({ error: "Complete source code ZIP archive not found." });
        return;
      }
      res.download(sourceZip, "yuitor-complete-source-code.zip");
      return;
    }
    const v3Zip = path8.join(APP_ROOT, "yuitor-smart-classes-v3.0.zip");
    const sharedZip = path8.join(APP_ROOT, "dist-shared", "deploy-shared-hosting.zip");
    const legacyZip = path8.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    const zipPath = fs10.existsSync(v3Zip) ? v3Zip : fs10.existsSync(sharedZip) ? sharedZip : legacyZip;
    if (!fs10.existsSync(zipPath)) {
      res.status(404).json({ error: "Final project ZIP archive not found." });
      return;
    }
    res.download(zipPath, fs10.existsSync(v3Zip) ? "yuitor-smart-classes-v3.0.zip" : "yuitor-deploy-shared-hosting.zip");
  });
  router.get("/settings", (_req, res) => {
    res.json(getAdminSettingsView(db));
  });
  router.put("/settings", (req, res) => {
    const ctx = req.ctx;
    try {
      const values = req.body?.values && typeof req.body.values === "object" ? req.body.values : {};
      const clearKeys = Array.isArray(req.body?.clearKeys) ? req.body.clearKeys.map((k) => String(k)) : [];
      const result = updateAdminSettings(db, values, clearKeys, ctx.user.id);
      if (result.sessionSecretRotated) {
        setSessionCookie(res, req, ctx.sessionId);
      }
      const changedSummary = [
        result.updatedKeys.length ? `updated: ${result.updatedKeys.join(", ")}` : "",
        result.clearedKeys.length ? `cleared: ${result.clearedKeys.join(", ")}` : ""
      ].filter(Boolean).join("; ");
      if (changedSummary) {
        writeAuditLog(db, {
          actorId: ctx.user.id,
          actorName: ctx.user.full_name,
          action: "admin_settings_updated",
          details: changedSummary,
          ipAddress: clientIp(req)
        });
      }
      res.json({
        saved: true,
        ...result,
        ...getAdminSettingsView(db)
      });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Invalid setting value." });
    }
  });
  router.post("/settings/save-tested", async (req, res) => {
    const ctx = req.ctx;
    const category = cleanText(req.body?.category || "", 32).toLowerCase();
    const validCategories = ["general", "ai", "email", "sms", "payments"];
    if (!validCategories.includes(category)) {
      res.status(400).json({
        saved: false,
        ok: false,
        error: `Unknown settings category "${category}".`,
        rootCause: "The submitted settings tab identifier is invalid.",
        howToFix: ["Reload the Settings page and submit from one of the 5 configuration tabs."]
      });
      return;
    }
    const rawValues = req.body?.values && typeof req.body.values === "object" ? req.body.values : {};
    const rawClearKeys = Array.isArray(req.body?.clearKeys) ? req.body.clearKeys.map((k) => String(k)) : [];
    const testRecipient = cleanText(req.body?.testRecipient || "", 254);
    const testPhone = cleanText(req.body?.testPhone || "", 20);
    const allowedKeys = new Set(SETTING_DEFINITIONS.filter((d) => d.category === category).map((d) => d.key));
    const values = {};
    for (const [k, v] of Object.entries(rawValues)) {
      if (allowedKeys.has(k)) values[k] = cleanText(v, 1000);
    }
    const clearKeys = rawClearKeys.filter((k) => allowedKeys.has(k));
    const effective = (key) => {
      if (clearKeys.includes(key)) return "";
      const def = SETTING_MAP.get(key);
      const submitted = values[key];
      if (def?.isSecret) {
        if (submitted && submitted.trim() !== "") return submitted.trim();
        return String(process.env[key] || "").trim();
      }
      if (submitted !== undefined) return String(submitted).trim();
      return String(process.env[key] || def?.defaultValue || "").trim();
    };
    const failDiag = (error, rootCause, howToFix) => {
      const intMap = { ai: "gemini", email: "smtp", sms: "fast2sms", payments: "razorpay" };
      const integrationStatuses = intMap[category]
        ? recordIntegrationTestStatus(db, intMap[category], false, error)
        : getIntegrationTestStatuses(db);
      res.status(400).json({
        saved: false,
        ok: false,
        error,
        rootCause,
        howToFix: Array.isArray(howToFix) ? howToFix : [howToFix],
        integrationStatuses
      });
    };

    let testMessage = "Configuration validated successfully.";
    try {
      if (category === "general") {
        const appUrl = effective("APP_URL");
        const sessionSecret = effective("SESSION_SECRET");
        const ipAllow = effective("ADMIN_IP_ALLOWLIST");
        const setupKey = effective("YU_ADMIN_SETUP_KEY");
        if (!appUrl) {
          return failDiag(
            "Website Public URL (APP_URL) is required.",
            "The Website Domain (APP_URL) field was left empty or cleared.",
            [
              "Enter your full website URL starting with https:// (for example: https://yuitor.com).",
              "Click Test & Save again to verify and persist."
            ]
          );
        }
        let parsed;
        try {
          parsed = new URL(appUrl);
        } catch {
          return failDiag(
            `Invalid APP_URL format: "${appUrl}".`,
            "The entered domain is not a valid absolute URL with protocol and hostname.",
            [
              "Include https:// or http:// before the domain name (e.g., https://yuitor.com).",
              "Remove any spaces or invalid characters from the URL."
            ]
          );
        }
        if (!["http:", "https:"].includes(parsed.protocol) || (!parsed.hostname.includes(".") && parsed.hostname !== "localhost")) {
          return failDiag(
            `Invalid domain hostname "${parsed.hostname}" in APP_URL.`,
            "APP_URL must use http:// or https:// with a valid public domain or localhost.",
            [
              "Use a real domain like https://yuitor.com (or http://localhost:3000 for local testing).",
              "Verify there are no typos in the domain extension."
            ]
          );
        }
        if (sessionSecret && sessionSecret.length < 16) {
          return failDiag(
            "SESSION_SECRET is too short (minimum 16 characters required).",
            "Weak session signing secrets compromise login cookie security and are blocked.",
            [
              "Click 'Generate 64-Char Secret' or enter a random string of at least 32 characters.",
              "Click Test & Save again."
            ]
          );
        }
        if (setupKey && setupKey.length < 8) {
          return failDiag(
            "YU_ADMIN_SETUP_KEY must be at least 8 characters long.",
            "Short setup keys do not meet security requirements.",
            ["Enter an 8+ character installer setup key, or leave it blank if not needed."]
          );
        }
        if (ipAllow) {
          const badIp = ipAllow.split(",").map((s) => s.trim()).filter(Boolean).find((tok) => !/^[0-9a-fA-F.:/]+$/.test(tok));
          if (badIp) {
            return failDiag(
              `Invalid IP allow-list entry: "${badIp}".`,
              "ADMIN_IP_ALLOWLIST only accepts comma-separated IPv4/IPv6 addresses or CIDR blocks.",
              ["Use comma-separated IPs like 127.0.0.1, 203.0.113.10 or leave blank to allow all IPs."]
            );
          }
        }
        testMessage = `Domain (${parsed.origin}) & security keys validated cleanly.`;
      } else if (category === "ai") {
        const apiKey = effective("GEMINI_API_KEY");
        const modelName = effective("GEMINI_MODEL") || "gemini-2.5-flash";
        if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
          return failDiag(
            "GEMINI_API_KEY is missing or placeholder.",
            "No valid Google Gemini API key was supplied for live verification.",
            [
              "Open Google AI Studio (aistudio.google.com/apikey) and create/copy an active Gemini API key.",
              "Paste the key into GEMINI_API_KEY and click Test & Save."
            ]
          );
        }
        if (!/^gemini-[A-Za-z0-9._-]+$/i.test(modelName)) {
          return failDiag(
            `Invalid GEMINI_MODEL "${modelName}".`,
            "The model identifier does not match a valid Gemini model name.",
            ["Select a supported model such as gemini-2.5-flash or gemini-2.5-pro."]
          );
        }
        try {
          const ai = new GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
          const cfg = /^gemini-[34]/i.test(modelName) ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {};
          const response = await Promise.race([
            ai.models.generateContent({ model: modelName, contents: "Reply with exactly: OK", config: cfg }),
            new Promise((_, reject) => setTimeout(() => reject(new Error("Gemini API connection timed out after 8 seconds")), 8000))
          ]);
          const txt = (response?.text || "").trim();
          if (!txt) throw new Error("Gemini API returned an empty response.");
          testMessage = `Live Gemini API verified (${modelName}): "${txt.slice(0, 60)}"`;
        } catch (err) {
          const exactErr = classifyGeminiError(err, modelName);
          return failDiag(
            exactErr,
            "Google Gemini API rejected the provided API key, model ID, or network request.",
            [
              "Verify your GEMINI_API_KEY is active and copied without extra spaces.",
              "Confirm your Google Cloud / AI Studio project has quota enabled for " + modelName + ".",
              "Try switching GEMINI_MODEL to gemini-2.5-flash and click Test & Save again."
            ]
          );
        }
      } else if (category === "email") {
        const host = effective("SMTP_HOST");
        const port = Number(effective("SMTP_PORT") || 465);
        const secure = effective("SMTP_SECURE") || (port === 465 ? "true" : "false");
        const user = effective("SMTP_USER");
        const pass = effective("SMTP_PASS");
        const fromEmail = effective("SMTP_FROM_EMAIL") || user;
        if (!host || !user || !pass) {
          return failDiag(
            "SMTP_HOST, SMTP_USER, and SMTP_PASS are required before saving.",
            "Incomplete SMTP credentials cannot authenticate with a mail server.",
            [
              "Enter your mail server hostname (e.g., smtp.hostinger.com or smtp.gmail.com).",
              "Enter your full SMTP username email and app password / mailbox password.",
              "Match SMTP_PORT (465 for SSL/TLS true, or 587 for STARTTLS false) and click Test & Save."
            ]
          );
        }
        if (!Number.isInteger(port) || port < 1 || port > 65535) {
          return failDiag(
            `Invalid SMTP_PORT "${effective("SMTP_PORT")}".`,
            "Port number must be between 1 and 65535 (typically 465 or 587).",
            ["Use 465 with SMTP_SECURE=true (SSL/TLS) or 587 with SMTP_SECURE=false (STARTTLS)."]
          );
        }
        try {
          const transporter = getTransporter({ host, port, secure, user, pass });
          await transporter.verify();
          if (testRecipient && isValidEmail(testRecipient)) {
            await transporter.sendMail({
              from: `"${effective("SMTP_FROM_NAME") || "Yuitor Smart Classes"}" <${fromEmail}>`,
              to: testRecipient,
              subject: "Yuitor Smart Classes v3.0 — SMTP Verified",
              text: "Your SMTP configuration passed live verification and was saved cleanly."
            });
            testMessage = `SMTP connection verified on ${host}:${port} & test mail sent to ${testRecipient}.`;
          } else {
            testMessage = `SMTP connection & authentication verified on ${host}:${port}.`;
          }
        } catch (err) {
          const exactErr = err?.message || "SMTP handshake/authentication failed.";
          const isAuth = /535|auth|login|credentials|password|username/i.test(exactErr);
          const isTls = /ssl|tls|wrong version|certificate|greeting/i.test(exactErr);
          const isDns = /ENOTFOUND|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN/i.test(exactErr);
          return failDiag(
            exactErr,
            isAuth
              ? "The SMTP server rejected the username or password."
              : isTls
                ? "TLS/SSL encryption mode does not match the selected SMTP port."
                : isDns
                  ? "Could not reach the SMTP server hostname or port from this server."
                  : "Live SMTP verification failed with the supplied server settings.",
            isAuth
              ? [
                  "Double-check SMTP_USER (full email address) and SMTP_PASS.",
                  "For Gmail/Google Workspace, generate and use a 16-character App Password instead of your login password.",
                  "Verify SMTP login is enabled in your email hosting panel (Hostinger/cPanel/Zoho)."
                ]
              : isTls
                ? [
                    "If using port 465, set SMTP_SECURE to true (SSL/TLS).",
                    "If using port 587, set SMTP_SECURE to false (STARTTLS)."
                  ]
                : [
                    "Confirm SMTP_HOST spelling (e.g., smtp.hostinger.com, smtp.gmail.com).",
                    "Check that outbound port 465 or 587 is open and reachable."
                  ]
          );
        }
      } else if (category === "sms") {
        const apiKey = effective("FAST2SMS_API_KEY");
        const route = (effective("FAST2SMS_ROUTE") || "q").toLowerCase();
        if (!apiKey) {
          return failDiag(
            "FAST2SMS_API_KEY is required.",
            "No Fast2SMS authorization key was provided for live verification.",
            [
              "Log in to fast2sms.com -> Dev API and copy your API Authorization Key.",
              "Paste it into FAST2SMS_API_KEY and click Test & Save."
            ]
          );
        }
        if (!["q", "otp", "dlt"].includes(route)) {
          return failDiag(
            `Unsupported FAST2SMS_ROUTE "${route}".`,
            "Fast2SMS route must be q, otp, or dlt.",
            ["Select q (Quick SMS), otp (OTP Route), or dlt (TRAI DLT Route)."]
          );
        }
        try {
          const resp = await fetch("https://www.fast2sms.com/dev/wallet", {
            method: "POST",
            headers: { authorization: apiKey },
            signal: AbortSignal.timeout(10000)
          });
          const data = await resp.json().catch(() => ({}));
          if (!resp.ok || data?.return !== true) {
            return failDiag(
              data?.message || `Fast2SMS API returned HTTP ${resp.status}.`,
              "Fast2SMS rejected the supplied API key or account status.",
              [
                "Verify your FAST2SMS_API_KEY in your Fast2SMS Dashboard -> Dev API.",
                "Ensure your Fast2SMS account is verified and has active API access enabled.",
                "Paste the exact key without leading or trailing spaces and retry."
              ]
            );
          }
          const bal = data?.wallet !== undefined ? ` (Wallet: ₹${data.wallet})` : "";
          testMessage = `Fast2SMS API key verified cleanly${bal}.`;
        } catch (err) {
          return failDiag(
            err?.message || "Unable to reach Fast2SMS API.",
            "Network or timeout error while connecting to https://www.fast2sms.com/dev/wallet.",
            [
              "Check server outbound internet access to fast2sms.com.",
              "Retry clicking Test & Save in a few seconds."
            ]
          );
        }
      } else if (category === "payments") {
        const keyId = effective("RAZORPAY_KEY_ID");
        const keySecret = effective("RAZORPAY_KEY_SECRET");
        if (!keyId || !keySecret) {
          return failDiag(
            "Both RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET are required.",
            "Razorpay live/sandbox authentication requires both the Key ID and Key Secret.",
            [
              "Open Razorpay Dashboard -> Settings -> API Keys and generate/copy both Key ID and Key Secret.",
              "Enter both fields and click Test & Save."
            ]
          );
        }
        if (!/^rzp_(test|live)_[A-Za-z0-9]{4,}$/.test(keyId)) {
          return failDiag(
            `Invalid RAZORPAY_KEY_ID format: "${keyId}".`,
            "Razorpay Key IDs must begin with rzp_test_ (Sandbox) or rzp_live_ (Live).",
            [
              "Copy the full Key ID starting with rzp_test_ or rzp_live_ from Razorpay Dashboard.",
              "Ensure Key ID and Key Secret were not swapped."
            ]
          );
        }
        try {
          const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
          const resp = await fetch("https://api.razorpay.com/v1/orders?count=1", {
            method: "GET",
            headers: { Authorization: `Basic ${auth}` },
            signal: AbortSignal.timeout(12000)
          });
          const data = await resp.json().catch(() => ({}));
          if (!resp.ok) {
            return failDiag(
              data?.error?.description || `Razorpay API returned HTTP ${resp.status}.`,
              "Razorpay rejected the Key ID / Key Secret pair (unauthorized credentials).",
              [
                "Confirm RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET belong to the same mode (both Test or both Live).",
                "Regenerate the API key pair in Razorpay Dashboard if the secret was lost, then re-enter and click Test & Save."
              ]
            );
          }
          const mode = keyId.startsWith("rzp_live_") ? "LIVE" : "SANDBOX / TEST";
          testMessage = `Razorpay ${mode} credentials verified live with Razorpay API.`;
        } catch (err) {
          return failDiag(
            err?.message || "Unable to reach Razorpay API.",
            "Network or timeout error while connecting to https://api.razorpay.com.",
            ["Check server outbound HTTPS access to api.razorpay.com and retry."]
          );
        }
      }

      // Live validation PASSED — now persist safely to DB
      const result = updateAdminSettings(db, values, clearKeys, ctx.user.id);
      if (result.sessionSecretRotated) {
        setSessionCookie(res, req, ctx.sessionId);
      }
      const intMap = { ai: "gemini", email: "smtp", sms: "fast2sms", payments: "razorpay" };
      if (intMap[category]) {
        recordIntegrationTestStatus(db, intMap[category], true, testMessage);
      }
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        action: "admin_settings_tested_and_saved",
        details: `[${category}] ${testMessage}`,
        ipAddress: clientIp(req)
      });
      res.json({
        saved: true,
        ok: true,
        testMessage,
        ...result,
        ...getAdminSettingsView(db)
      });
    } catch (err) {
      failDiag(
        err?.message || "Settings validation failed.",
        "An unexpected validation error prevented saving.",
        ["Review the fields in this tab, fix any invalid values, and try again."]
      );
    }
  });
  router.post("/settings/test-smtp", async (req, res) => {
    const recipient = cleanText(req.body?.testRecipient || "", 254);
    const result = await testSmtpConnection(recipient);
    const integrationStatuses = recordIntegrationTestStatus(db, "smtp", result.ok, result.ok ? result.message : result.error);
    if (!result.ok) {
      res.status(400).json({ error: result.error, integrationStatuses });
      return;
    }
    res.json({ ok: true, message: result.message, integrationStatuses });
  });
  router.post("/settings/test-gemini", async (_req, res) => {
    const result = await testGeminiConnection();
    const integrationStatuses = recordIntegrationTestStatus(db, "gemini", result.ok, result.ok ? result.message : result.error);
    if (!result.ok) {
      res.status(400).json({ error: result.error, integrationStatuses });
      return;
    }
    res.json({ ok: true, message: result.message, integrationStatuses });
  });
  router.post("/settings/test-sms", async (req, res) => {
    const phone = cleanText(req.body?.testPhone || "", 20);
    const result = await testFast2SmsConnection(phone);
    const integrationStatuses = recordIntegrationTestStatus(db, "fast2sms", result.ok, result.ok ? result.message : result.error);
    if (!result.ok) {
      res.status(400).json({ error: result.error, integrationStatuses });
      return;
    }
    res.json({ ok: true, message: result.message, integrationStatuses });
  });
  router.get("/admin-url", (_req, res) => {
    const slug = getAdminPath(db);
    const appUrl = (process.env.APP_URL || "").trim().replace(/\/+$/, "");
    res.json({
      adminPath: slug,
      adminGatePath: `/${slug}/`,
      fullAdminGateUrl: appUrl && !appUrl.includes("MY_APP_URL") ? `${appUrl}/${slug}/` : `/${slug}/`,
      ipAllowlist: (process.env.ADMIN_IP_ALLOWLIST || "").trim()
    });
  });
  router.post("/settings/admin-path", (req, res) => {
    const ctx = req.ctx;
    const currentPassword = String(req.body?.currentPassword || "");
    const newSlugRaw = String(req.body?.adminPath || "");
    const adminRow = db.prepare("SELECT id, password_hash, full_name FROM users WHERE id = ?").get(ctx.user.id);
    if (!adminRow || !verifyPassword(currentPassword, adminRow.password_hash)) {
      res.status(401).json({ error: "Current admin password verification failed." });
      return;
    }
    const updated = setAdminPathSlug(db, newSlugRaw, ctx.user.id);
    if (!updated.ok) {
      res.status(400).json({ error: updated.error });
      return;
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: adminRow.full_name,
      action: "admin_gate_slug_changed",
      details: `Updated admin gate slug (envUpdated=${updated.envUpdated})`,
      ipAddress: clientIp(req)
    });
    const appUrl = (process.env.APP_URL || "").trim().replace(/\/+$/, "");
    res.json({
      updated: true,
      adminPath: updated.slug,
      adminGatePath: `/${updated.slug}/`,
      fullAdminGateUrl: appUrl && !appUrl.includes("MY_APP_URL") ? `${appUrl}/${updated.slug}/` : `/${updated.slug}/`,
      redirectTo: `/${updated.slug}/`,
      envUpdated: updated.envUpdated
    });
  });
  router.get("/login-attempts", (_req, res) => {
    const attempts = db.prepare("SELECT id, identifier, ip_address, user_agent, outcome, reason, created_at FROM admin_login_attempts ORDER BY id DESC LIMIT 100").all();
    res.json({ attempts });
  });
  router.post("/settings/test-razorpay", async (_req, res) => {
    const result = await testRazorpayConnection();
    const integrationStatuses = recordIntegrationTestStatus(db, "razorpay", result.ok, result.ok ? result.message : result.error);
    if (!result.ok) {
      res.status(400).json({ error: result.error, integrationStatuses });
      return;
    }
    res.json({ ok: true, message: result.message, integrationStatuses });
  });
  router.get("/system-update", (_req, res) => {
    const info = getAppVersionInfo(APP_ROOT);
    const upgradeHistory = db.prepare(
      `SELECT id, actor_name, target_name, details, ip_address, created_at
         FROM audit_logs WHERE action = 'system_zip_upgraded' ORDER BY id DESC LIMIT 20`
    ).all();
    res.json({
      currentVersion: info.version,
      nodeVersion: process.version,
      maxUploadMb: 80,
      protectedPaths: ["data/yuitor.db", "uploads/", "backups/", "logs/", ".env", "Active Stealth Admin URL"],
      upgradeHistory
    });
  });
  router.post("/system-update", (req, res) => {
    const ctx = req.ctx;
    releaseZipUpload(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err?.message || "Release ZIP upload failed." });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "Please choose a Yuitor release .zip file to upload." });
        return;
      }
      const uploadedPath = req.file.path;
      try {
        const zipBuf = fs10.readFileSync(uploadedPath);
        if (zipBuf.length < 22 || zipBuf[0] !== 80 || zipBuf[1] !== 75) {
          res.status(400).json({ error: "Uploaded file is not a valid ZIP archive." });
          return;
        }
        const backup = createDatabaseBackup(db, "pre-upgrade");
        const upgrade = applyReleaseZipUpdate(zipBuf, APP_ROOT);
        writeAuditLog(db, {
          actorId: ctx.user.id,
          actorName: ctx.user.full_name,
          targetName: `v${upgrade.newVersion}`,
          action: "system_zip_upgraded",
          details: `v${upgrade.previousVersion} -> v${upgrade.newVersion} (${upgrade.updatedFiles} files updated, layout=${upgrade.detectedLayout}, backup=${backup.filename})`,
          ipAddress: clientIp(req)
        });
        res.json({
          upgraded: true,
          previousVersion: upgrade.previousVersion,
          newVersion: upgrade.newVersion,
          updatedFiles: upgrade.updatedFiles,
          skippedProtected: upgrade.skippedProtected,
          detectedLayout: upgrade.detectedLayout,
          restartFileWritten: upgrade.restartFileWritten,
          backupFilename: backup.filename,
          message: `Upgraded cleanly from v${upgrade.previousVersion} to v${upgrade.newVersion} (${upgrade.updatedFiles} files updated). Live database, uploads, .env & secret admin gate were preserved.`
        });
      } catch (upErr) {
        res.status(400).json({ error: upErr?.message || "Unable to apply release ZIP update." });
      } finally {
        try {
          if (fs10.existsSync(uploadedPath)) fs10.unlinkSync(uploadedPath);
        } catch {
        }
      }
    });
  });
  return router;
}

// server/routes/marketing.ts
import { Router as Router5 } from "express";
function createMarketingRouter(db) {
  const router = Router5();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/overview", (_req, res) => {
    const campaigns = db.prepare("SELECT * FROM email_campaigns ORDER BY id DESC").all();
    const totalCampaigns = campaigns.length;
    const totalEligible = campaigns.reduce((acc, c) => acc + Number(c.total_recipients || 0), 0);
    const totalSent = campaigns.reduce((acc, c) => acc + Number(c.sent_count || 0), 0);
    const totalFailed = campaigns.reduce((acc, c) => acc + Number(c.failed_count || 0), 0);
    const templates = db.prepare("SELECT * FROM email_templates ORDER BY id ASC").all();
    const courses = db.prepare("SELECT id, title FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const students = db.prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'student' ORDER BY full_name").all();
    const teachers = db.prepare("SELECT id, full_name, email, verification_status, marketing_opt_in FROM users WHERE role = 'teacher' ORDER BY full_name").all();
    const suppressions = db.prepare("SELECT * FROM email_suppressions ORDER BY id DESC LIMIT 100").all();
    res.json({
      summary: {
        totalCampaigns,
        totalEligible,
        totalSent,
        totalFailed,
        openClickTrackingNote: "Opens/clicks reported only when webhook/pixel tracking is enabled on your SMTP provider."
      },
      senderEmail: getSenderEmail(),
      replyToEmail: getReplyToEmail(),
      smtpConfigured: isSmtpConfigured(),
      templates,
      courses,
      students,
      teachers,
      campaigns,
      suppressions
    });
  });
  router.post("/preview-recipients", (req, res) => {
    const filters = req.body?.filters || {};
    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    res.json({
      eligibleCount: eligible.length,
      excludedCount
    });
  });
  router.post("/campaigns", async (req, res) => {
    const ctx = req.ctx;
    const name = cleanText(req.body?.name, 160);
    const subject = cleanText(req.body?.subject, 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "").trim();
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);
    const attachmentUrl = cleanText(req.body?.attachmentUrl, 300);
    const sendMode = ["draft", "immediate", "scheduled"].includes(req.body?.sendMode) ? req.body.sendMode : "draft";
    const scheduledAt = req.body?.scheduledAt ? cleanText(req.body.scheduledAt, 40) : null;
    const templateId = req.body?.templateId ? Number(req.body.templateId) : null;
    const filters = req.body?.filters || {};
    if (!name || !subject || !htmlBody) {
      res.status(400).json({ error: "Campaign name, email subject, and HTML body are required." });
      return;
    }
    const { eligible, excludedCount } = resolveCampaignRecipients(db, filters);
    const initialStatus = sendMode === "draft" ? "draft" : "queued";
    const now = nowIso();
    const ins = db.prepare(
      `INSERT INTO email_campaigns
         (name, template_id, subject, preview_text, html_body, cta_label, cta_url, attachment_url,
          filters_json, send_mode, scheduled_at, status, total_recipients, excluded_count, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      name,
      templateId,
      subject,
      previewText,
      htmlBody,
      ctaLabel,
      ctaUrl,
      attachmentUrl,
      JSON.stringify(filters),
      sendMode,
      scheduledAt,
      initialStatus,
      eligible.length,
      excludedCount,
      ctx.user.id,
      now,
      now
    );
    const campaignId = Number(ins.lastInsertRowid);
    const insDelivery = db.prepare(
      `INSERT OR IGNORE INTO email_deliveries (campaign_id, user_id, recipient_name, recipient_email, status, created_at)
       VALUES (?, ?, ?, ?, 'pending', ?)`
    );
    for (const r of eligible) {
      insDelivery.run(campaignId, r.id, r.full_name, r.email, now);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: campaignId,
      targetName: name,
      action: "email_campaign_created",
      details: `${sendMode} \xB7 ${eligible.length} eligible (${excludedCount} excluded)`,
      ipAddress: clientIp(req)
    });
    if (sendMode === "immediate" && eligible.length > 0) {
      void processCampaignQueue(db, campaignId, 25);
    }
    res.status(201).json({ id: campaignId, eligibleCount: eligible.length, excludedCount });
  });
  router.post("/campaigns/:id/action", async (req, res) => {
    const cid = Number(req.params.id);
    const action = String(req.body?.action || "");
    const camp = db.prepare("SELECT * FROM email_campaigns WHERE id = ?").get(cid);
    if (!camp) {
      res.status(404).json({ error: "Campaign not found." });
      return;
    }
    if (action === "pause") {
      db.prepare("UPDATE email_campaigns SET status = 'paused', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "paused" });
      return;
    }
    if (action === "cancel") {
      db.prepare("UPDATE email_campaigns SET status = 'cancelled', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      res.json({ status: "cancelled" });
      return;
    }
    if (action === "resume" || action === "process_now") {
      db.prepare("UPDATE email_campaigns SET status = 'queued', updated_at = ? WHERE id = ?").run(nowIso(), cid);
      const result = await processCampaignQueue(db, cid, 30);
      res.json({ processed: true, ...result });
      return;
    }
    res.status(400).json({ error: "Unsupported campaign action." });
  });
  router.get("/campaigns/:id/deliveries", (req, res) => {
    const deliveries = db.prepare("SELECT * FROM email_deliveries WHERE campaign_id = ? ORDER BY id ASC LIMIT 500").all(Number(req.params.id));
    res.json({ deliveries });
  });
  router.post("/test-send", async (req, res) => {
    const to = normalizeEmail(req.body?.to);
    const subject = cleanText(req.body?.subject || "Yuitor Smart Classes Test Email", 200).replace(/[\r\n]+/g, " ");
    const previewText = cleanText(req.body?.previewText, 240);
    const htmlBody = String(req.body?.htmlBody || "<p>Test campaign preview from Yuitor Smart Classes.</p>");
    const ctaLabel = cleanText(req.body?.ctaLabel, 80);
    const ctaUrl = cleanText(req.body?.ctaUrl, 300);
    if (!isValidEmail(to)) {
      res.status(400).json({ error: "Enter a valid recipient email address for test delivery." });
      return;
    }
    const html = renderBrandedEmailHtml({
      subject,
      previewText,
      htmlBody,
      recipientName: "Yuitor Team",
      ctaLabel,
      ctaUrl
    });
    const result = await sendEmailDirect({ to, subject: `[TEST] ${subject}`, html });
    if (!result.ok) {
      res.status(503).json({ error: result.error });
      return;
    }
    res.json({ sent: true, messageId: result.messageId });
  });
  router.post("/suppressions", (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const reason = cleanText(req.body?.reason || "unsubscribed", 60);
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Enter a valid email address." });
      return;
    }
    db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, ?, ?)").run(
      email,
      reason,
      nowIso()
    );
    db.prepare("UPDATE users SET marketing_opt_in = 0, updated_at = ? WHERE email = ?").run(nowIso(), email);
    res.status(201).json({ suppressed: true });
  });
  return router;
}

// server/routes/mail.ts
import { Router as Router6 } from "express";
import multer3 from "multer";
var attachmentUpload = multer3({
  storage: multer3.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 3 }
}).array("attachments", 3);
function createMailRouter(db) {
  const router = Router6();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Admin sign-in required." });
      return;
    }
    if (ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  function getFolderCounts(accountIdFilter) {
    const where = accountIdFilter ? "WHERE account_id = ?" : "";
    const params = accountIdFilter ? [accountIdFilter] : [];
    const row = db.prepare(
      `SELECT
           SUM(CASE WHEN folder = 'inbox' THEN 1 ELSE 0 END) as inboxTotal,
           SUM(CASE WHEN folder = 'inbox' AND is_read = 0 THEN 1 ELSE 0 END) as inboxUnread,
           SUM(CASE WHEN folder = 'sent' THEN 1 ELSE 0 END) as sentTotal,
           SUM(CASE WHEN folder = 'trash' THEN 1 ELSE 0 END) as trashTotal
         FROM mail_messages ${where}`
    ).get(...params);
    return {
      inboxTotal: Number(row?.inboxTotal || 0),
      inboxUnread: Number(row?.inboxUnread || 0),
      sentTotal: Number(row?.sentTotal || 0),
      trashTotal: Number(row?.trashTotal || 0)
    };
  }
  router.get("/accounts", (_req, res) => {
    const rows = db.prepare("SELECT * FROM mail_accounts ORDER BY is_default DESC, id ASC").all();
    const accounts = rows.map((r) => toSafeMailAccount(db, r));
    const counts = getFolderCounts(null);
    res.json({ accounts, counts });
  });
  router.post("/accounts", (req, res) => {
    const ctx = req.ctx;
    const email = normalizeEmail(req.body?.email);
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    const displayName = cleanText(req.body?.displayName || "Yuitor Smart Classes", 120) || "Yuitor Smart Classes";
    const smtpHost = cleanText(req.body?.smtpHost || "mail.yuitor.com", 160) || "mail.yuitor.com";
    const smtpPort = Math.min(65535, Math.max(1, Number(req.body?.smtpPort || 465)));
    const smtpSecure = req.body?.smtpSecure === false || String(req.body?.smtpSecure) === "false" ? 0 : 1;
    const smtpUser = cleanText(req.body?.smtpUser || email, 160) || email;
    const imapHost = cleanText(req.body?.imapHost || smtpHost || "mail.yuitor.com", 160) || "mail.yuitor.com";
    const imapPort = Math.min(65535, Math.max(1, Number(req.body?.imapPort || 993)));
    const imapSecure = req.body?.imapSecure === false || String(req.body?.imapSecure) === "false" ? 0 : 1;
    const imapUser = cleanText(req.body?.imapUser || smtpUser || email, 160) || email;
    const plainPass = String(req.body?.password || "");
    const isDefault = req.body?.isDefault === true || String(req.body?.isDefault) === "true" || Number(req.body?.isDefault) === 1 ? 1 : 0;
    const isActive = req.body?.isActive === false || String(req.body?.isActive) === "false" ? 0 : 1;
    const now = nowIso();
    const existing = db.prepare("SELECT * FROM mail_accounts WHERE email = ?").get(email);
    if (isDefault === 1) {
      db.prepare("UPDATE mail_accounts SET is_default = 0").run();
    }
    let accountId;
    if (existing) {
      const nextPassEnc = plainPass ? encryptMailboxPassword(plainPass) : existing.password_enc;
      db.prepare(
        `UPDATE mail_accounts
         SET display_name = ?, smtp_host = ?, smtp_port = ?, smtp_secure = ?, smtp_user = ?,
             imap_host = ?, imap_port = ?, imap_secure = ?, imap_user = ?,
             password_enc = ?, is_default = ?, is_active = ?, last_error = '', updated_at = ?
         WHERE id = ?`
      ).run(
        displayName,
        smtpHost,
        smtpPort,
        smtpSecure,
        smtpUser,
        imapHost,
        imapPort,
        imapSecure,
        imapUser,
        nextPassEnc,
        isDefault || existing.is_default,
        isActive,
        now,
        existing.id
      );
      accountId = Number(existing.id);
    } else {
      if (!plainPass) {
        res.status(400).json({ error: "Password is required when adding a new mailbox." });
        return;
      }
      const enc = encryptMailboxPassword(plainPass);
      const ins = db.prepare(
        `INSERT INTO mail_accounts (
            email, display_name, smtp_host, smtp_port, smtp_secure, smtp_user,
            imap_host, imap_port, imap_secure, imap_user, password_enc,
            is_default, is_active, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        email,
        displayName,
        smtpHost,
        smtpPort,
        smtpSecure,
        smtpUser,
        imapHost,
        imapPort,
        imapSecure,
        imapUser,
        enc,
        isDefault,
        isActive,
        now,
        now
      );
      accountId = Number(ins.lastInsertRowid);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: accountId,
      targetName: email,
      action: existing ? "mail_account_updated" : "mail_account_created",
      details: `SMTP ${smtpHost}:${smtpPort} | IMAP ${imapHost}:${imapPort}`,
      ipAddress: clientIp(req)
    });
    const saved = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(accountId);
    res.json({ ok: true, account: toSafeMailAccount(db, saved) });
  });
  router.patch("/accounts/:id", (req, res) => {
    const ctx = req.ctx;
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(id);
    if (!existing) {
      res.status(404).json({ error: "Mailbox not found." });
      return;
    }
    const email = req.body?.email ? normalizeEmail(req.body.email) : existing.email;
    if (!isValidEmail(email)) {
      res.status(400).json({ error: "Invalid email address." });
      return;
    }
    const displayName = cleanText(req.body?.displayName ?? existing.display_name, 120) || existing.display_name;
    const smtpHost = cleanText(req.body?.smtpHost ?? existing.smtp_host, 160) || existing.smtp_host;
    const smtpPort = Math.min(65535, Math.max(1, Number(req.body?.smtpPort ?? existing.smtp_port)));
    const smtpSecure = req.body?.smtpSecure !== void 0 ? req.body.smtpSecure === true || String(req.body.smtpSecure) === "true" || Number(req.body.smtpSecure) === 1 ? 1 : 0 : existing.smtp_secure;
    const smtpUser = cleanText(req.body?.smtpUser ?? existing.smtp_user, 160) || email;
    const imapHost = cleanText(req.body?.imapHost ?? existing.imap_host, 160) || existing.imap_host;
    const imapPort = Math.min(65535, Math.max(1, Number(req.body?.imapPort ?? existing.imap_port)));
    const imapSecure = req.body?.imapSecure !== void 0 ? req.body.imapSecure === true || String(req.body.imapSecure) === "true" || Number(req.body.imapSecure) === 1 ? 1 : 0 : existing.imap_secure;
    const imapUser = cleanText(req.body?.imapUser ?? existing.imap_user, 160) || email;
    const plainPass = String(req.body?.password || "");
    const nextPassEnc = plainPass ? encryptMailboxPassword(plainPass) : existing.password_enc;
    const isDefault = req.body?.isDefault !== void 0 ? req.body.isDefault === true || String(req.body.isDefault) === "true" || Number(req.body.isDefault) === 1 ? 1 : 0 : existing.is_default;
    const isActive = req.body?.isActive !== void 0 ? req.body.isActive === false || String(req.body.isActive) === "false" || Number(req.body.isActive) === 0 ? 0 : 1 : existing.is_active;
    if (isDefault === 1) {
      db.prepare("UPDATE mail_accounts SET is_default = 0 WHERE id != ?").run(id);
    }
    db.prepare(
      `UPDATE mail_accounts
       SET email = ?, display_name = ?, smtp_host = ?, smtp_port = ?, smtp_secure = ?, smtp_user = ?,
           imap_host = ?, imap_port = ?, imap_secure = ?, imap_user = ?,
           password_enc = ?, is_default = ?, is_active = ?, last_error = '', updated_at = ?
       WHERE id = ?`
    ).run(
      email,
      displayName,
      smtpHost,
      smtpPort,
      smtpSecure,
      smtpUser,
      imapHost,
      imapPort,
      imapSecure,
      imapUser,
      nextPassEnc,
      isDefault,
      isActive,
      nowIso(),
      id
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: id,
      targetName: email,
      action: "mail_account_updated",
      details: plainPass ? "Updated configuration & encrypted password" : "Updated configuration",
      ipAddress: clientIp(req)
    });
    const saved = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(id);
    res.json({ ok: true, account: toSafeMailAccount(db, saved) });
  });
  router.post("/accounts/bulk-password", (req, res) => {
    const ctx = req.ctx;
    const password = String(req.body?.password || "");
    const accountIds = Array.isArray(req.body?.accountIds) ? req.body.accountIds.map(Number).filter((n) => Number.isInteger(n) && n > 0) : [];
    if (!password) {
      res.status(400).json({ error: "Please enter a mailbox password to save." });
      return;
    }
    if (accountIds.length === 0) {
      res.status(400).json({ error: "Please select at least one mailbox." });
      return;
    }
    const enc = encryptMailboxPassword(password);
    const now = nowIso();
    const ph = accountIds.map(() => "?").join(",");
    db.prepare(`UPDATE mail_accounts SET password_enc = ?, last_error = '', updated_at = ? WHERE id IN (${ph})`).run(
      enc,
      now,
      ...accountIds
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetName: `${accountIds.length} mailbox(es)`,
      action: "mail_bulk_password_updated",
      details: `Encrypted mailbox credentials saved for ${accountIds.length} account(s).`,
      ipAddress: clientIp(req)
    });
    res.json({ ok: true, updatedCount: accountIds.length });
  });
  router.delete("/accounts/:id", (req, res) => {
    const ctx = req.ctx;
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM mail_accounts WHERE id = ?").get(id);
    if (!existing) {
      res.status(404).json({ error: "Mailbox not found." });
      return;
    }
    db.prepare("DELETE FROM mail_accounts WHERE id = ?").run(id);
    if (existing.is_default === 1) {
      const next = db.prepare("SELECT id FROM mail_accounts ORDER BY id ASC LIMIT 1").get();
      if (next) db.prepare("UPDATE mail_accounts SET is_default = 1 WHERE id = ?").run(next.id);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: id,
      targetName: existing.email,
      action: "mail_account_deleted",
      ipAddress: clientIp(req)
    });
    res.json({ ok: true });
  });
  router.post("/accounts/:id/test", async (req, res) => {
    const id = Number(req.params.id);
    const result = await testMailboxConnection(db, id);
    res.status(result.ok ? 200 : 400).json(result);
  });
  router.post("/accounts/:id/sync", async (req, res) => {
    const id = Number(req.params.id);
    const result = await syncMailboxInbox(db, id, 40);
    if (!result.ok) {
      res.status(400).json({ error: result.error || "IMAP sync failed.", ...result });
      return;
    }
    res.json(result);
  });
  router.post("/sync-all", async (_req, res) => {
    const results = await syncAllActiveMailboxes(db);
    const totalImported = results.reduce((sum, r) => sum + Number(r.imported || 0), 0);
    res.json({ ok: true, totalImported, results });
  });
  router.get("/messages", (req, res) => {
    const folderRaw = String(req.query.folder || "inbox").toLowerCase();
    const folder = ["inbox", "sent", "trash"].includes(folderRaw) ? folderRaw : "inbox";
    const accountIdRaw = String(req.query.accountId || "").trim();
    const accountIdFilter = accountIdRaw && accountIdRaw !== "all" && Number(accountIdRaw) > 0 ? Number(accountIdRaw) : null;
    const search = cleanText(req.query.search || "", 120).toLowerCase();
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(50, Math.max(5, Number(req.query.pageSize || 25)));
    const where = ["m.folder = ?"];
    const params = [folder];
    if (accountIdFilter) {
      where.push("m.account_id = ?");
      params.push(accountIdFilter);
    }
    if (search) {
      where.push("(LOWER(m.subject) LIKE ? OR LOWER(m.from_email) LIKE ? OR LOWER(m.from_name) LIKE ? OR LOWER(m.to_emails) LIKE ? OR LOWER(m.snippet) LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like, like, like);
    }
    const whereSql = where.join(" AND ");
    const totalRow = db.prepare(`SELECT COUNT(*) as c FROM mail_messages m WHERE ${whereSql}`).get(...params);
    const messages = db.prepare(
      `SELECT m.id, m.account_id, m.folder, m.direction, m.from_name, m.from_email, m.to_emails,
                m.cc_emails, m.subject, m.snippet, m.has_attachments, m.is_read, m.is_starred, m.mail_date,
                a.email as account_email, a.display_name as account_display_name
         FROM mail_messages m
         JOIN mail_accounts a ON a.id = m.account_id
         WHERE ${whereSql}
         ORDER BY m.mail_date DESC, m.id DESC
         LIMIT ? OFFSET ?`
    ).all(...params, pageSize, (page - 1) * pageSize);
    res.json({
      messages,
      total: Number(totalRow?.c || 0),
      page,
      pageSize,
      counts: getFolderCounts(accountIdFilter)
    });
  });
  router.get("/messages/:id", (req, res) => {
    const id = Number(req.params.id);
    const msg = db.prepare(
      `SELECT m.*, a.email as account_email, a.display_name as account_display_name
         FROM mail_messages m
         JOIN mail_accounts a ON a.id = m.account_id
         WHERE m.id = ?`
    ).get(id);
    if (!msg) {
      res.status(404).json({ error: "Email message not found." });
      return;
    }
    if (Number(msg.is_read) === 0) {
      db.prepare("UPDATE mail_messages SET is_read = 1 WHERE id = ?").run(id);
      msg.is_read = 1;
    }
    let attachments = [];
    try {
      attachments = JSON.parse(msg.attachments_json || "[]");
    } catch {
      attachments = [];
    }
    res.json({ message: { ...msg, attachments } });
  });
  router.patch("/messages/:id", (req, res) => {
    const id = Number(req.params.id);
    const msg = db.prepare("SELECT id FROM mail_messages WHERE id = ?").get(id);
    if (!msg) {
      res.status(404).json({ error: "Email message not found." });
      return;
    }
    if (req.body?.isRead !== void 0) {
      db.prepare("UPDATE mail_messages SET is_read = ? WHERE id = ?").run(req.body.isRead ? 1 : 0, id);
    }
    if (req.body?.isStarred !== void 0) {
      db.prepare("UPDATE mail_messages SET is_starred = ? WHERE id = ?").run(req.body.isStarred ? 1 : 0, id);
    }
    if (req.body?.folder && ["inbox", "sent", "trash"].includes(String(req.body.folder))) {
      db.prepare("UPDATE mail_messages SET folder = ? WHERE id = ?").run(String(req.body.folder), id);
    }
    res.json({ ok: true });
  });
  router.delete("/messages/:id", (req, res) => {
    const id = Number(req.params.id);
    const msg = db.prepare("SELECT id, folder FROM mail_messages WHERE id = ?").get(id);
    if (!msg) {
      res.status(404).json({ error: "Email message not found." });
      return;
    }
    if (msg.folder === "trash" || String(req.query.permanent || "") === "1") {
      db.prepare("DELETE FROM mail_messages WHERE id = ?").run(id);
    } else {
      db.prepare("UPDATE mail_messages SET folder = 'trash' WHERE id = ?").run(id);
    }
    res.json({ ok: true });
  });
  router.post("/send", (req, res, next) => {
    const ct = String(req.headers["content-type"] || "");
    if (ct.includes("multipart/form-data")) {
      attachmentUpload(req, res, (err) => {
        if (err) {
          res.status(400).json({ error: err.message || "Attachment upload failed (max 5 MB)." });
          return;
        }
        next();
      });
    } else {
      next();
    }
  }, async (req, res) => {
    const ctx = req.ctx;
    const accountId = req.body?.accountId ? Number(req.body.accountId) : void 0;
    const to = cleanText(req.body?.to || "", 500);
    const cc = cleanText(req.body?.cc || "", 500);
    const subject = cleanText(req.body?.subject || "", 300);
    const html = String(req.body?.html || "");
    const text = String(req.body?.text || "");
    const inReplyTo = cleanText(req.body?.inReplyTo || "", 240);
    if (!to || !to.includes("@")) {
      res.status(400).json({ error: "Please enter a valid recipient email address." });
      return;
    }
    if (!subject) {
      res.status(400).json({ error: "Email subject is required." });
      return;
    }
    if (!html.trim() && !text.trim()) {
      res.status(400).json({ error: "Email message body cannot be empty." });
      return;
    }
    const uploadedFiles = Array.isArray(req.files) ? req.files : [];
    const attachments = uploadedFiles.map((f) => ({
      filename: cleanText(f.originalname || "attachment", 120),
      content: f.buffer,
      contentType: f.mimetype || "application/octet-stream"
    }));
    const result = await sendFromMailbox(db, {
      accountId,
      to,
      cc,
      subject,
      html: html || void 0,
      text: text || void 0,
      inReplyTo: inReplyTo || void 0,
      attachments
    });
    if (!result.ok) {
      res.status(400).json({ error: result.error });
      return;
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: result.savedId,
      targetName: `${result.fromEmail} -> ${to}`,
      action: "mail_sent",
      details: `Subject: ${subject}`,
      ipAddress: clientIp(req)
    });
    res.json(result);
  });
  return router;
}

// server/routes/student.ts
import { Router as Router7 } from "express";
import crypto8 from "node:crypto";

// server/qr.ts
var VERSION_SPECS = [
  { version: 1, size: 21, dataBytes: 19, ecBytes: 7, alignments: [] },
  { version: 2, size: 25, dataBytes: 34, ecBytes: 10, alignments: [6, 18] },
  { version: 3, size: 29, dataBytes: 55, ecBytes: 15, alignments: [6, 22] },
  { version: 4, size: 33, dataBytes: 80, ecBytes: 20, alignments: [6, 26] }
];
var GF_EXP = new Uint8Array(512);
var GF_LOG = new Uint8Array(256);
{
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 256) x ^= 285;
  }
  for (let i = 255; i < 512; i++) {
    GF_EXP[i] = GF_EXP[i - 255];
  }
}
function gfMul(a, b) {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}
function rsGeneratorPoly(degree) {
  let poly = new Uint8Array([1]);
  for (let i = 0; i < degree; i++) {
    const next = new Uint8Array(poly.length + 1);
    const factor = GF_EXP[i];
    for (let j = 0; j < poly.length; j++) {
      next[j] ^= poly[j];
      next[j + 1] ^= gfMul(poly[j], factor);
    }
    poly = next;
  }
  return poly;
}
function rsComputeEc(data, ecCount) {
  const gen = rsGeneratorPoly(ecCount);
  const work = new Uint8Array(data.length + ecCount);
  work.set(data, 0);
  for (let i = 0; i < data.length; i++) {
    const coef = work[i];
    if (coef !== 0) {
      for (let j = 0; j < gen.length; j++) {
        work[i + j] ^= gfMul(gen[j], coef);
      }
    }
  }
  return work.subarray(data.length);
}
function encodeByteData(bytes, capacityBytes) {
  const bits = [];
  const pushBits = (val, len) => {
    for (let i = len - 1; i >= 0; i--) {
      bits.push(val >> i & 1);
    }
  };
  pushBits(4, 4);
  pushBits(bytes.length, 8);
  for (const b of bytes) {
    pushBits(b, 8);
  }
  const maxBits = capacityBytes * 8;
  const termLen = Math.min(4, maxBits - bits.length);
  for (let i = 0; i < termLen; i++) bits.push(0);
  while (bits.length % 8 !== 0) bits.push(0);
  const out = new Uint8Array(capacityBytes);
  let byteIdx = 0;
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0;
    for (let b = 0; b < 8; b++) v = v << 1 | bits[i + b];
    out[byteIdx++] = v;
  }
  const pads = [236, 17];
  let p = 0;
  while (byteIdx < capacityBytes) {
    out[byteIdx++] = pads[p % 2];
    p++;
  }
  return out;
}
function computeFormatBits(mask) {
  const data = 1 << 3 | mask & 7;
  let rem = data << 10;
  for (let i = 4; i >= 0; i--) {
    if (rem >> i + 10 & 1) {
      rem ^= 1335 << i;
    }
  }
  return (data << 10 | rem) ^ 21522;
}
function buildQrMatrix(text) {
  const raw = new TextEncoder().encode(String(text || ""));
  const spec = VERSION_SPECS.find((s) => raw.length + 2 <= s.dataBytes) || VERSION_SPECS[VERSION_SPECS.length - 1];
  const payload = raw.length + 2 <= spec.dataBytes ? raw : raw.subarray(0, spec.dataBytes - 2);
  const dataWords = encodeByteData(payload, spec.dataBytes);
  const ecWords = rsComputeEc(dataWords, spec.ecBytes);
  const codewords = new Uint8Array(dataWords.length + ecWords.length);
  codewords.set(dataWords, 0);
  codewords.set(ecWords, dataWords.length);
  const n = spec.size;
  const modules = Array.from({ length: n }, () => Array(n).fill(null));
  const reserved = Array.from({ length: n }, () => Array(n).fill(false));
  const setFn = (r, c, dark) => {
    if (r >= 0 && r < n && c >= 0 && c < n) {
      modules[r][c] = dark;
      reserved[r][c] = true;
    }
  };
  const drawFinder = (r0, c0) => {
    for (let dr = -1; dr <= 7; dr++) {
      for (let dc = -1; dc <= 7; dc++) {
        const r = r0 + dr;
        const c = c0 + dc;
        if (r < 0 || r >= n || c < 0 || c >= n) continue;
        const inSquare = dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6;
        const dark = inSquare && (dr === 0 || dr === 6 || dc === 0 || dc === 6 || dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4);
        setFn(r, c, dark);
      }
    }
  };
  drawFinder(0, 0);
  drawFinder(0, n - 7);
  drawFinder(n - 7, 0);
  for (let i = 8; i < n - 8; i++) {
    const dark = i % 2 === 0;
    setFn(6, i, dark);
    setFn(i, 6, dark);
  }
  for (const ar of spec.alignments) {
    for (const ac of spec.alignments) {
      if (ar === 6 && ac === 6 || ar === 6 && ac === n - 7 || ar === n - 7 && ac === 6) continue;
      for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const dark = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
          setFn(ar + dr, ac + dc, dark);
        }
      }
    }
  }
  setFn(4 * spec.version + 9, 8, true);
  for (let i = 0; i < 9; i++) {
    if (i !== 6) {
      reserved[8][i] = true;
      reserved[i][8] = true;
    }
  }
  for (let i = 0; i < 8; i++) {
    reserved[8][n - 1 - i] = true;
    reserved[n - 1 - i][8] = true;
  }
  let bitIdx = 0;
  const totalBits = codewords.length * 8;
  let upward = true;
  for (let right = n - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let step = 0; step < n; step++) {
      const r = upward ? n - 1 - step : step;
      for (let offset = 0; offset < 2; offset++) {
        const c = right - offset;
        if (!reserved[r][c]) {
          let bit = false;
          if (bitIdx < totalBits) {
            bit = Boolean(codewords[bitIdx >> 3] >> 7 - (bitIdx & 7) & 1);
            bitIdx++;
          }
          modules[r][c] = (r + c & 1) === 0 ? !bit : bit;
        }
      }
    }
    upward = !upward;
  }
  const fmt = computeFormatBits(0);
  for (let i = 0; i < 15; i++) {
    const bit = Boolean(fmt >> i & 1);
    if (i < 6) modules[i][8] = bit;
    else if (i < 8) modules[i + 1][8] = bit;
    else modules[n - 15 + i][8] = bit;
    if (i < 8) modules[8][n - 1 - i] = bit;
    else if (i < 9) modules[8][7] = bit;
    else modules[8][14 - i] = bit;
  }
  return modules.map((row) => row.map((cell) => Boolean(cell)));
}
function renderQrSvg(text, pxSize = 180, label = "QR Code") {
  const matrix = buildQrMatrix(text);
  const n = matrix.length;
  const quiet = 2;
  const total = n + quiet * 2;
  const rects = [];
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (matrix[r][c]) {
        rects.push(`<rect x="${c + quiet}" y="${r + quiet}" width="1" height="1"/>`);
      }
    }
  }
  const safeLabel = String(label || "QR Code").replace(/[<>&"']/g, "");
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" width="${pxSize}" height="${pxSize}" role="img" aria-label="${safeLabel}" shape-rendering="crispEdges" style="background:#ffffff;border-radius:8px;border:1px solid #cbd5e1;display:block;"><rect width="${total}" height="${total}" fill="#ffffff"/><g fill="#0f172a">${rects.join("")}</g></svg>`;
}

// server/routes/erp-helpers.ts
function recalculateTestRanks(db, testId) {
  const rows = db.prepare(
    `SELECT id, marks_obtained, is_absent
       FROM offline_test_marks
       WHERE test_id = ?
       ORDER BY is_absent ASC, marks_obtained DESC, student_id ASC`
  ).all(testId);
  const upd = db.prepare("UPDATE offline_test_marks SET rank_position = ? WHERE id = ?");
  let rank = 0;
  let seen = 0;
  let prevScore = null;
  for (const r of rows) {
    if (Number(r.is_absent) === 1) {
      upd.run(null, r.id);
      continue;
    }
    seen++;
    const score = Number(r.marks_obtained || 0);
    if (prevScore === null || score < prevScore) {
      rank = seen;
      prevScore = score;
    }
    upd.run(rank, r.id);
  }
}
function getStudentOfflineTestsWithRanks(db, studentId, enrolledCourseIds) {
  if (enrolledCourseIds.length === 0) return [];
  const ph = enrolledCourseIds.map(() => "?").join(",");
  const rows = db.prepare(
    `SELECT ot.*, c.title as course_title, b.name as batch_name,
              otm.marks_obtained, otm.is_absent, otm.remarks, otm.rank_position,
              (SELECT COUNT(*) FROM offline_test_marks m2 WHERE m2.test_id = ot.id AND m2.is_absent = 0) as total_appeared,
              (SELECT MAX(m3.marks_obtained) FROM offline_test_marks m3 WHERE m3.test_id = ot.id AND m3.is_absent = 0) as topper_marks
       FROM offline_tests ot
       JOIN courses c ON c.id = ot.course_id
       LEFT JOIN batches b ON b.id = ot.batch_id
       LEFT JOIN offline_test_marks otm ON otm.test_id = ot.id AND otm.student_id = ?
       WHERE ot.course_id IN (${ph})
       ORDER BY ot.test_date DESC, ot.id DESC`
  ).all(studentId, ...enrolledCourseIds);
  return rows.map((r) => {
    const maxMarks = Math.max(1, Number(r.max_marks || 100));
    const hasMark = r.marks_obtained !== null && r.marks_obtained !== void 0;
    const pct = hasMark && Number(r.is_absent) !== 1 ? Math.round(Number(r.marks_obtained) / maxMarks * 100) : null;
    return {
      ...r,
      percentage: pct
    };
  });
}
function getStudentTimetableSlots(db, enrolledCourseIds, batchIds) {
  if (enrolledCourseIds.length === 0 && batchIds.length === 0) return [];
  const clauses = [];
  const params = [];
  if (batchIds.length > 0) {
    clauses.push(`ts.batch_id IN (${batchIds.map(() => "?").join(",")})`);
    params.push(...batchIds);
  }
  if (enrolledCourseIds.length > 0) {
    clauses.push(`(ts.batch_id IS NULL AND ts.course_id IN (${enrolledCourseIds.map(() => "?").join(",")}))`);
    params.push(...enrolledCourseIds);
  }
  return db.prepare(
    `SELECT ts.*, c.title as course_title, b.name as batch_name, u.full_name as teacher_name, br.name as branch_name
       FROM timetable_slots ts
       LEFT JOIN courses c ON c.id = ts.course_id
       LEFT JOIN batches b ON b.id = ts.batch_id
       LEFT JOIN branches br ON br.id = ts.branch_id
       LEFT JOIN users u ON u.id = ts.teacher_id
       WHERE ${clauses.join(" OR ")}
       ORDER BY CASE ts.day_of_week
         WHEN 'Monday' THEN 1
         WHEN 'Tuesday' THEN 2
         WHEN 'Wednesday' THEN 3
         WHEN 'Thursday' THEN 4
         WHEN 'Friday' THEN 5
         WHEN 'Saturday' THEN 6
         ELSE 7 END, ts.start_time ASC`
  ).all(...params);
}
function getStudentComprehensiveReport(db, studentId) {
  const user = db.prepare(
    `SELECT u.id, u.full_name, u.email, u.phone, u.avatar_url,
              sp.class_level, sp.board, sp.parent_name, sp.parent_phone, sp.roll_number, sp.branch_id, sp.batch_id,
              br.name as branch_name, b.name as batch_name, b.schedule_days, b.start_time, b.end_time, b.room_name
       FROM users u
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       LEFT JOIN branches br ON br.id = sp.branch_id
       LEFT JOIN batches b ON b.id = sp.batch_id
       WHERE u.id = ? AND u.role = 'student'`
  ).get(studentId);
  if (!user) return null;
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const enrollments = db.prepare(
    `SELECT e.*, c.title as course_title, c.teacher_id, u.full_name as teacher_name,
                b.name as batch_name, b.room_name, b.schedule_days, b.start_time, b.end_time
         FROM enrollments e
         JOIN courses c ON c.id = e.course_id
         LEFT JOIN users u ON u.id = COALESCE(b.teacher_id, c.teacher_id)
         LEFT JOIN batches b ON b.id = e.batch_id
         WHERE e.student_id = ?
         ORDER BY e.id DESC`
  ).all(studentId).map((e) => ({
    ...e,
    is_expired: Boolean(e.expires_at && e.expires_at < today)
  }));
  const activeCourseIds = enrollments.filter((e) => ["active", "completed"].includes(e.status) && !e.is_expired).map((e) => Number(e.course_id));
  const batchIds = Array.from(
    /* @__PURE__ */ new Set([
      ...user.batch_id ? [Number(user.batch_id)] : [],
      ...enrollments.filter((e) => e.batch_id).map((e) => Number(e.batch_id))
    ])
  );
  const attendance = db.prepare(
    `SELECT a.*, c.title as course_title
       FROM attendance a
       JOIN courses c ON c.id = a.course_id
       WHERE a.student_id = ?
       ORDER BY a.att_date DESC, a.id DESC LIMIT 90`
  ).all(studentId);
  const presentCount = attendance.filter((a) => a.status === "present" || a.status === "late").length;
  const attendancePct = attendance.length > 0 ? Math.round(presentCount / attendance.length * 100) : 100;
  const offlineTests = getStudentOfflineTestsWithRanks(db, studentId, activeCourseIds);
  const timetable = getStudentTimetableSlots(db, activeCourseIds, batchIds);
  const feeRecords = db.prepare(
    `SELECT f.*, COALESCE(c.title, f.title) as course_title,
              COALESCE(
                (SELECT p.invoice_number FROM payments p WHERE p.student_id = f.student_id AND p.course_id = f.course_id ORDER BY p.id DESC LIMIT 1),
                'YTR-FEE-' || f.id
              ) as invoice_number
       FROM fee_records f
       LEFT JOIN courses c ON c.id = f.course_id
       WHERE f.student_id = ?
       ORDER BY f.id DESC`
  ).all(studentId);
  const installments = db.prepare(
    `SELECT fi.*, fr.title as fee_title
       FROM fee_installments fi
       JOIN fee_records fr ON fr.id = fi.fee_record_id
       WHERE fi.student_id = ?
       ORDER BY fi.due_date ASC, fi.installment_no ASC`
  ).all(studentId);
  const payments = db.prepare(
    `SELECT p.*, c.title as course_title
       FROM payments p
       JOIN courses c ON c.id = p.course_id
       WHERE p.student_id = ?
       ORDER BY p.id DESC`
  ).all(studentId);
  const teachers = activeCourseIds.length > 0 ? db.prepare(
    `SELECT DISTINCT u.id, u.full_name, u.email, c.id as course_id, c.title as course_title
             FROM courses c
             JOIN users u ON u.id = c.teacher_id
             WHERE c.id IN (${activeCourseIds.map(() => "?").join(",")}) AND u.is_active = 1`
  ).all(...activeCourseIds) : [];
  let quizAttempts = [];
  if (activeCourseIds.length > 0) {
    quizAttempts = db.prepare(
      `SELECT qa.*, q.title as quiz_title, c.title as course_title
         FROM quiz_attempts qa
         JOIN quizzes q ON q.id = qa.quiz_id
         JOIN courses c ON c.id = q.course_id
         WHERE qa.student_id = ?
         ORDER BY qa.attempted_at DESC LIMIT 20`
    ).all(studentId);
  }
  return {
    student: user,
    enrollments,
    attendance,
    attendanceSummary: {
      total: attendance.length,
      present: attendance.filter((a) => a.status === "present").length,
      late: attendance.filter((a) => a.status === "late").length,
      absent: attendance.filter((a) => a.status === "absent").length,
      percentage: attendancePct
    },
    offlineTests,
    timetable,
    feeRecords,
    installments,
    payments,
    quizAttempts,
    teachers
  };
}

// server/routes/student.ts
function createStudentRouter(db) {
  const router = Router7();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Student sign-in required." });
      return;
    }
    if (ctx.user.role !== "student") {
      res.status(403).json({ error: "Student portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved" || (Number(ctx.user.mobile_verified) !== 1 && !ctx.impersonation?.active)) {
      res.status(403).json({ error: "OTP verification is required before entering the Student Portal.", code: "OTP_REQUIRED" });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const uid = ctx.user.id;
    const today = nowIso().slice(0, 10);
    const profile = db.prepare("SELECT * FROM student_profiles WHERE user_id = ?").get(uid) || {
      class_level: "Class 10",
      board: "CBSE",
      course_duration_months: 12,
      admission_date: null,
      enrollment_status: "active"
    };
    const rawEnrollments = db.prepare(
      `SELECT e.*, c.title, c.category, c.board, b.name as batch_name, b.room_name, b.schedule_days, b.start_time, b.end_time
         FROM enrollments e
         JOIN courses c ON c.id = e.course_id
         LEFT JOIN batches b ON b.id = e.batch_id
         WHERE e.student_id = ?
         ORDER BY e.id DESC`
    ).all(uid);
    const enrollments = rawEnrollments.map((e) => ({
      ...e,
      is_expired: Boolean(e.expires_at && e.expires_at < today)
    }));
    const enrolledCourseIds = enrollments.filter((e) => ["active", "completed"].includes(e.status) && !e.is_expired).map((e) => Number(e.course_id));
    const batchIds = Array.from(
      /* @__PURE__ */ new Set([
        ...profile.batch_id ? [Number(profile.batch_id)] : [],
        ...enrollments.filter((e) => e.batch_id).map((e) => Number(e.batch_id))
      ])
    );
    let upcomingClasses = [];
    let assignments = [];
    let quizzes = [];
    let teachers = [];
    if (enrolledCourseIds.length > 0) {
      const ph = enrolledCourseIds.map(() => "?").join(",");
      upcomingClasses = db.prepare(
        `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph}) AND cs.scheduled_date >= ?
           ORDER BY cs.scheduled_date ASC, cs.start_time ASC LIMIT 20`
      ).all(...enrolledCourseIds, today);
      assignments = db.prepare(
        `SELECT a.*, c.title as course_title,
                  sub.status as submission_status, sub.marks_obtained, sub.feedback
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           LEFT JOIN assignment_submissions sub ON sub.assignment_id = a.id AND sub.student_id = ?
           WHERE a.course_id IN (${ph})
           ORDER BY a.due_date ASC, a.id DESC`
      ).all(uid, ...enrolledCourseIds);
      quizzes = db.prepare(
        `SELECT q.*, c.title as course_title,
                  (SELECT qa.score FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) as score
           FROM quizzes q
           JOIN courses c ON c.id = q.course_id
           WHERE q.course_id IN (${ph})
           ORDER BY q.id DESC`
      ).all(uid, ...enrolledCourseIds);
      teachers = db.prepare(
        `SELECT DISTINCT u.id, u.full_name, u.email, c.id as course_id, c.title as course_title
           FROM courses c
           JOIN users u ON u.id = c.teacher_id
           WHERE c.id IN (${ph}) AND u.is_active = 1`
      ).all(...enrolledCourseIds);
    }
    const timetable = getStudentTimetableSlots(db, enrolledCourseIds, batchIds);
    const offlineTests = getStudentOfflineTestsWithRanks(db, uid, enrolledCourseIds);
    const announcements = db.prepare(
      `SELECT * FROM announcements
         WHERE audience IN ('all', 'students')
         ORDER BY id DESC LIMIT 15`
    ).all();
    const feeRecords = db.prepare(
      `SELECT f.*, COALESCE(c.title, f.title) as course_title,
                COALESCE(
                  (SELECT p.invoice_number FROM payments p WHERE p.student_id = f.student_id AND p.course_id = f.course_id ORDER BY p.id DESC LIMIT 1),
                  'YTR-FEE-' || f.id
                ) as invoice_number
         FROM fee_records f
         LEFT JOIN courses c ON c.id = f.course_id
         WHERE f.student_id = ?
         ORDER BY f.id DESC`
    ).all(uid);
    const installments = db.prepare(
      `SELECT fi.*, fr.title as fee_title
         FROM fee_installments fi
         JOIN fee_records fr ON fr.id = fi.fee_record_id
         WHERE fi.student_id = ?
         ORDER BY fi.due_date ASC, fi.installment_no ASC`
    ).all(uid);
    const payments = db.prepare(
      `SELECT p.*, c.title as course_title
         FROM payments p
         JOIN courses c ON c.id = p.course_id
         WHERE p.student_id = ?
         ORDER BY p.id DESC`
    ).all(uid);
    const attendance = db.prepare(
      `SELECT a.*, c.title as course_title
         FROM attendance a
         JOIN courses c ON c.id = a.course_id
         WHERE a.student_id = ?
         ORDER BY a.att_date DESC, a.id DESC LIMIT 60`
    ).all(uid);
    const libraryIssues = db.prepare(
      `SELECT li.*, lb.title as book_title, lb.code as book_code, lb.category
         FROM library_issues li
         JOIN library_books lb ON lb.id = li.book_id
         WHERE li.student_id = ?
         ORDER BY li.id DESC LIMIT 30`
    ).all(uid);
    const notifications = db.prepare(
      `SELECT * FROM notifications
         WHERE user_id = ? OR role_target IN ('student', 'all')
         ORDER BY id DESC LIMIT 20`
    ).all(uid);
    const supportMessages = db.prepare(
      `SELECT sm.*, c.title as course_title, u.full_name as teacher_name
         FROM support_messages sm
         LEFT JOIN courses c ON c.id = sm.course_id
         LEFT JOIN users u ON u.id = sm.teacher_id
         WHERE sm.user_id = ? ORDER BY sm.id DESC LIMIT 20`
    ).all(uid);
    const branchRow = profile.branch_id ? db.prepare("SELECT name, code, address, phone FROM branches WHERE id = ?").get(profile.branch_id) : db.prepare("SELECT name, code, address, phone FROM branches ORDER BY id ASC LIMIT 1").get();
    const rollNumber = profile.roll_number || `YTR-STU-${String(uid).padStart(4, "0")}`;
    const primaryBatch = enrollments.find((e) => e.batch_name)?.batch_name || "Regular Batch";
    const idCardQrText = `YTRID|${rollNumber}|${ctx.user.id}|${ctx.user.phone}`;
    const idCard = {
      rollNumber,
      fullName: ctx.user.full_name,
      classLevel: profile.class_level || "Class 10",
      board: profile.board || "CBSE",
      batchName: primaryBatch,
      branchName: branchRow?.name || "Muradnagar Main Centre",
      branchPhone: branchRow?.phone || "+91 78-2728-9292",
      parentPhone: profile.parent_phone || ctx.user.phone,
      avatarUrl: ctx.user.avatar_url || "",
      instituteLogoUrl: "/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png",
      admissionDate: profile.admission_date || today,
      qrSvg: renderQrSvg(idCardQrText, 128)
    };
    res.json({
      profile: { ...profile, roll_number: rollNumber },
      enrollments,
      upcomingClasses,
      timetable,
      offlineTests,
      announcements,
      feeRecords,
      installments,
      payments,
      assignments,
      quizzes,
      attendance,
      libraryIssues,
      teachers,
      idCard,
      notifications,
      supportMessages
    });
  });
  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.params.courseId);
    const today = nowIso().slice(0, 10);
    const enrollment = db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?").get(ctx.user.id, courseId);
    if (!enrollment || !["active", "completed"].includes(enrollment.status)) {
      res.status(403).json({ error: "Active course enrollment is required to access lessons." });
      return;
    }
    if (enrollment.expires_at && enrollment.expires_at < today) {
      res.status(403).json({ error: "This course enrollment has expired. Contact Yuitor Team to renew." });
      return;
    }
    const lessons = db.prepare(
      `SELECT l.*, CASE WHEN lp.completed_at IS NOT NULL THEN 1 ELSE 0 END as completed
         FROM lessons l
         LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.student_id = ?
         WHERE l.course_id = ? AND l.is_visible = 1
         ORDER BY l.sort_order ASC, l.id ASC`
    ).all(ctx.user.id, courseId);
    res.json({ enrollment, lessons });
  });
  router.post("/lessons/:lessonId/complete", (req, res) => {
    const ctx = req.ctx;
    const lessonId = Number(req.params.lessonId);
    const mins = Math.min(240, Math.max(1, Number(req.body?.timeSpentMinutes || 20)));
    const lesson = db.prepare("SELECT * FROM lessons WHERE id = ? AND is_visible = 1").get(lessonId);
    if (!lesson) {
      res.status(404).json({ error: "Lesson not found." });
      return;
    }
    const enrollment = db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, lesson.course_id);
    if (!enrollment) {
      res.status(403).json({ error: "Not enrolled in this course." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `INSERT OR IGNORE INTO lesson_progress (student_id, lesson_id, completed_at, time_spent_minutes)
       VALUES (?, ?, ?, ?)`
    ).run(ctx.user.id, lessonId, now, mins);
    const totalVisible = db.prepare("SELECT COUNT(*) as c FROM lessons WHERE course_id = ? AND is_visible = 1").get(lesson.course_id).c;
    const completedCount = db.prepare(
      `SELECT COUNT(*) as c FROM lesson_progress lp
           JOIN lessons l ON l.id = lp.lesson_id
           WHERE lp.student_id = ? AND l.course_id = ? AND l.is_visible = 1`
    ).get(ctx.user.id, lesson.course_id).c;
    const progress = totalVisible > 0 ? Math.min(100, Math.round(completedCount / totalVisible * 100)) : 100;
    const certCode = progress === 100 ? enrollment.certificate_code || `YTR-CERT-${ctx.user.id}-${lesson.course_id}-${crypto8.randomBytes(2).toString("hex").toUpperCase()}` : enrollment.certificate_code || "";
    const nextStatus = progress === 100 ? "completed" : enrollment.status;
    db.prepare(
      `UPDATE enrollments
       SET progress_percent = ?, learning_minutes = learning_minutes + ?, status = ?, certificate_code = ?
       WHERE id = ?`
    ).run(progress, mins, nextStatus, certCode, enrollment.id);
    res.json({ completed: true, progressPercent: progress, certificateCode: certCode });
  });
  router.post("/assignments/:assignmentId/submit", (req, res) => {
    const ctx = req.ctx;
    const aid = Number(req.params.assignmentId);
    const assignment = db.prepare("SELECT * FROM assignments WHERE id = ?").get(aid);
    if (!assignment) {
      res.status(404).json({ error: "Assignment not found." });
      return;
    }
    const enrolled = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, assignment.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }
    const submissionText = cleanText(req.body?.submissionText, 4e3);
    const fileUrl = sanitizeHttpOrUploadUrl(req.body?.fileUrl, 300);
    if (!submissionText && !fileUrl) {
      res.status(400).json({ error: "Enter answer text or upload a file." });
      return;
    }
    db.prepare(
      `INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, file_url, status, submitted_at)
       VALUES (?, ?, ?, ?, 'submitted', ?)
       ON CONFLICT(assignment_id, student_id) DO UPDATE SET
         submission_text = excluded.submission_text,
         file_url = CASE WHEN excluded.file_url != '' THEN excluded.file_url ELSE assignment_submissions.file_url END,
         status = 'submitted',
         submitted_at = excluded.submitted_at`
    ).run(aid, ctx.user.id, submissionText, fileUrl, nowIso());
    res.status(201).json({ submitted: true });
  });
  router.post("/quizzes/:quizId/attempt", (req, res) => {
    const ctx = req.ctx;
    const qid = Number(req.params.quizId);
    const quiz = db.prepare("SELECT * FROM quizzes WHERE id = ?").get(qid);
    if (!quiz) {
      res.status(404).json({ error: "Quiz not found." });
      return;
    }
    const enrolled = db.prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, quiz.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not enrolled in this course." });
      return;
    }
    let questions = [];
    try {
      questions = JSON.parse(quiz.questions_json || "[]");
    } catch {
      questions = [];
    }
    const answers = Array.isArray(req.body?.answers) ? req.body.answers.map(Number) : [];
    let correct = 0;
    questions.forEach((q, idx) => {
      if (answers[idx] === Number(q.correctIndex)) correct++;
    });
    const maxMarks = Number(quiz.max_marks || 10);
    const score = questions.length > 0 ? Math.round(correct / questions.length * maxMarks) : 0;
    db.prepare(
      "INSERT INTO quiz_attempts (quiz_id, student_id, answers_json, score, max_marks, attempted_at) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(qid, ctx.user.id, JSON.stringify(answers), score, maxMarks, nowIso());
    res.json({ score, maxMarks });
  });
  router.post("/reviews", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const comment = cleanText(req.body?.comment, 1e3);
    if (!courseId || comment.length < 3) {
      res.status(400).json({ error: "Select a course and write a short review." });
      return;
    }
    db.prepare(
      `INSERT INTO course_reviews (student_id, course_id, rating, comment, created_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(student_id, course_id) DO UPDATE SET rating = excluded.rating, comment = excluded.comment`
    ).run(ctx.user.id, courseId, rating, comment, nowIso());
    res.status(201).json({ saved: true });
  });
  router.post("/attendance/qr", (req, res) => {
    const ctx = req.ctx;
    const rawCode = cleanText(req.body?.qrCode || "", 200);
    if (!rawCode) {
      res.status(400).json({ error: "Enter or scan the classroom QR attendance code." });
      return;
    }
    let tokenCode = rawCode;
    try {
      if (rawCode.includes("qr=")) {
        const u = new URL(rawCode.startsWith("http") ? rawCode : `https://yuitor.com${rawCode}`);
        tokenCode = cleanText(u.searchParams.get("qr") || rawCode, 100);
      }
    } catch {
    }
    const session = db.prepare("SELECT * FROM qr_attendance_sessions WHERE UPPER(token_code) = UPPER(?) LIMIT 1").get(tokenCode);
    if (!session) {
      res.status(404).json({ error: "Invalid classroom QR attendance code." });
      return;
    }
    const nowEpoch = Math.floor(Date.now() / 1e3);
    if (Number(session.expires_at) < nowEpoch) {
      res.status(410).json({ error: "This QR attendance session has expired. Ask your teacher for a fresh QR code." });
      return;
    }
    const enrolled = db.prepare("SELECT id, batch_id FROM enrollments WHERE student_id = ? AND course_id = ? AND status IN ('active', 'completed')").get(ctx.user.id, session.course_id);
    if (!enrolled) {
      res.status(403).json({ error: "You are not actively enrolled in the course for this QR session." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `INSERT INTO attendance (course_id, batch_id, student_id, teacher_id, att_date, status, marked_via, remarks, created_at)
       VALUES (?, ?, ?, ?, ?, 'present', 'qr', 'Self check-in via QR', ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET
         status = 'present',
         marked_via = 'qr',
         batch_id = COALESCE(excluded.batch_id, attendance.batch_id),
         remarks = 'Self check-in via QR'`
    ).run(
      session.course_id,
      session.batch_id || enrolled.batch_id || null,
      ctx.user.id,
      session.teacher_id || null,
      session.session_date,
      now
    );
    res.json({ marked: true, sessionDate: session.session_date, status: "present" });
  });
  router.post("/support", (req, res) => {
    const ctx = req.ctx;
    const subject = cleanText(req.body?.subject, 180);
    const body = cleanText(req.body?.body, 2e3);
    const courseId = req.body?.courseId ? Number(req.body.courseId) : null;
    let teacherId = req.body?.teacherId ? Number(req.body.teacherId) : null;
    if (subject.length < 2 || body.length < 5) {
      res.status(400).json({ error: "Enter subject and message." });
      return;
    }
    if (courseId && !teacherId) {
      const crs = db.prepare("SELECT teacher_id FROM courses WHERE id = ?").get(courseId);
      if (crs?.teacher_id) teacherId = Number(crs.teacher_id);
    }
    const now = nowIso();
    db.prepare(
      "INSERT INTO support_messages (user_id, course_id, teacher_id, subject, body, status, created_at) VALUES (?, ?, ?, ?, ?, 'open', ?)"
    ).run(ctx.user.id, courseId || null, teacherId || null, subject, body, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`Student Support: ${subject}`, `${ctx.user.full_name} sent a support message.`, now);
    if (teacherId) {
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
      ).run(teacherId, `Student Doubt: ${subject}`, `${ctx.user.full_name} asked: ${body.slice(0, 140)}`, now);
    }
    res.status(201).json({ sent: true });
  });
  router.post("/notifications/read-all", (req, res) => {
    const ctx = req.ctx;
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(ctx.user.id);
    res.json({ updated: true });
  });
  return router;
}

// server/routes/teacher.ts
import { Router as Router8 } from "express";
import crypto9 from "node:crypto";
import fs11 from "node:fs";
import path9 from "node:path";
function createTeacherRouter(db) {
  const router = Router8();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Teacher sign-in required." });
      return;
    }
    if (ctx.user.role !== "teacher") {
      res.status(403).json({ error: "Teacher portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved" || (Number(ctx.user.mobile_verified) !== 1 && !ctx.impersonation?.active)) {
      res.status(403).json({ error: "OTP verification is required before entering the Teacher Portal.", code: "OTP_REQUIRED" });
      return;
    }
    const tp = db.prepare("SELECT resume_url, resume_filename, resume_mime, resume_status FROM teacher_profiles WHERE user_id = ?").get(ctx.user.id);
    if (!tp?.resume_url || !["submitted", "verified"].includes(String(tp.resume_status || ""))) {
      res.status(403).json({
        error: TEACHER_MISSING_RESUME_MSG,
        code: "RESUME_REQUIRED",
        resumeStatus: tp?.resume_status || "missing"
      });
      return;
    }
    req.ctx = ctx;
    req.teacherResume = tp;
    next();
  });
  router.get("/resume", (req, res) => {
    const tp = req.teacherResume;
    const fileName = path9.basename(String(tp?.resume_url || ""));
    const full = path9.join(RESUMES_DIR, fileName);
    if (!fileName || !full.startsWith(RESUMES_DIR) || !fs11.existsSync(full)) {
      res.status(404).json({ error: "Submitted resume file was not found on server." });
      return;
    }
    if (tp.resume_mime) res.setHeader("Content-Type", tp.resume_mime);
    const dlName = (tp.resume_filename || fileName).replace(/["\r\n]/g, "");
    res.setHeader("Content-Disposition", `inline; filename="${dlName}"`);
    res.sendFile(full);
  });
  function ownsCourse(teacherId, courseId) {
    const row = db.prepare("SELECT id FROM courses WHERE id = ? AND teacher_id = ?").get(courseId, teacherId);
    return Boolean(row);
  }
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const tid = ctx.user.id;
    const profile = db.prepare("SELECT * FROM teacher_profiles WHERE user_id = ?").get(tid) || {
      qualification: "",
      experience_years: 0,
      availability_status: "available",
      vacation_note: "",
      monthly_payout_rate: 0,
      payout_upi: ""
    };
    const courses = db.prepare("SELECT * FROM courses WHERE teacher_id = ? ORDER BY id ASC").all(tid);
    const courseIds = courses.map((c) => Number(c.id));
    let students = [];
    let schedules = [];
    let assignments = [];
    const maskPhones = isTeacherPhoneMaskingEnabled(db);
    if (courseIds.length > 0) {
      const ph = courseIds.map(() => "?").join(",");
      students = db.prepare(
        `SELECT u.id, u.full_name, u.phone, u.email, e.course_id, c.title as course_title, e.progress_percent
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           JOIN courses c ON c.id = e.course_id
           WHERE e.course_id IN (${ph}) AND e.status = 'active' AND u.is_active = 1
           ORDER BY c.title ASC, u.full_name ASC`
      ).all(...courseIds).map((s) => ({
        ...s,
        phone: maskPhones ? maskPhoneForTeacher(s.phone) : s.phone,
        phone_masked: maskPhones
      }));
      schedules = db.prepare(
        `SELECT cs.*, c.title as course_title
           FROM class_schedules cs
           JOIN courses c ON c.id = cs.course_id
           WHERE cs.course_id IN (${ph})
           ORDER BY cs.scheduled_date DESC LIMIT 30`
      ).all(...courseIds);
      assignments = db.prepare(
        `SELECT a.*, c.title as course_title,
                  (SELECT COUNT(*) FROM assignment_submissions s WHERE s.assignment_id = a.id) as submissions_count
           FROM assignments a
           JOIN courses c ON c.id = a.course_id
           WHERE a.course_id IN (${ph})
           ORDER BY a.id DESC`
      ).all(...courseIds);
    }
    const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? OR role_target IN ('teacher', 'all') ORDER BY id DESC LIMIT 20").all(tid);
    const batches = db.prepare(
      `SELECT b.*, c.title as course_title, br.name as branch_name,
                (SELECT COUNT(*) FROM enrollments e JOIN users eu ON eu.id = e.student_id WHERE e.batch_id = b.id AND e.status = 'active' AND eu.is_active = 1) as seats_used
         FROM batches b
         LEFT JOIN courses c ON c.id = b.course_id
         LEFT JOIN branches br ON br.id = b.branch_id
         WHERE b.teacher_id = ? ${courseIds.length ? `OR b.course_id IN (${courseIds.map(() => "?").join(",")})` : ""}
         ORDER BY b.id DESC`
    ).all(tid, ...courseIds);
    const timetableSlots = db.prepare(
      `SELECT ts.*, c.title as course_title, b.name as batch_name, br.name as branch_name
         FROM timetable_slots ts
         LEFT JOIN courses c ON c.id = ts.course_id
         LEFT JOIN batches b ON b.id = ts.batch_id
         LEFT JOIN branches br ON br.id = ts.branch_id
         WHERE ts.teacher_id = ? ${courseIds.length ? `OR ts.course_id IN (${courseIds.map(() => "?").join(",")})` : ""}
         ORDER BY CASE ts.day_of_week
           WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
           WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 ELSE 7 END, ts.start_time ASC`
    ).all(tid, ...courseIds);
    const offlineTests = courseIds.length ? db.prepare(
      `SELECT ot.*, c.title as course_title, b.name as batch_name,
                    (SELECT COUNT(*) FROM offline_test_marks m WHERE m.test_id = ot.id) as marks_entered,
                    (SELECT ROUND(AVG(m.marks_obtained), 1) FROM offline_test_marks m WHERE m.test_id = ot.id AND m.is_absent = 0) as avg_marks
             FROM offline_tests ot
             JOIN courses c ON c.id = ot.course_id
             LEFT JOIN batches b ON b.id = ot.batch_id
             WHERE ot.teacher_id = ? OR ot.course_id IN (${courseIds.map(() => "?").join(",")})
             ORDER BY ot.test_date DESC, ot.id DESC`
    ).all(tid, ...courseIds) : [];
    const leaveRequests = db.prepare("SELECT * FROM teacher_leave_requests WHERE teacher_id = ? ORDER BY id DESC LIMIT 20").all(tid);
    const parentMessages = db.prepare(
      `SELECT m.*, par.full_name as parent_name, par.phone as parent_phone, stu.full_name as student_name
         FROM parent_teacher_messages m
         JOIN users par ON par.id = m.parent_id
         JOIN users stu ON stu.id = m.student_id
         WHERE m.teacher_id = ?
         ORDER BY m.id DESC LIMIT 50`
    ).all(tid).map((m) => ({
      ...m,
      parent_phone: maskPhones ? maskPhoneForTeacher(m.parent_phone) : m.parent_phone,
      phone_masked: maskPhones
    }));
    const studentDoubts = db.prepare(
      `SELECT sm.*, u.full_name as student_name, c.title as course_title
         FROM support_messages sm
         JOIN users u ON u.id = sm.user_id
         LEFT JOIN courses c ON c.id = sm.course_id
         WHERE sm.teacher_id = ? ${courseIds.length ? `OR sm.course_id IN (${courseIds.map(() => "?").join(",")})` : ""}
         ORDER BY sm.id DESC LIMIT 30`
    ).all(tid, ...courseIds);
    const nowEpoch = Math.floor(Date.now() / 1e3);
    const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
    const activeQrSessions = db.prepare(
      `SELECT qs.*, c.title as course_title, b.name as batch_name
           FROM qr_attendance_sessions qs
           JOIN courses c ON c.id = qs.course_id
           LEFT JOIN batches b ON b.id = qs.batch_id
           WHERE qs.teacher_id = ? AND qs.expires_at >= ?
           ORDER BY qs.id DESC LIMIT 5`
    ).all(tid, nowEpoch).map((q) => {
      const checkinUrl = `${siteUrl}/student/?qr=${encodeURIComponent(q.token_code)}`;
      return {
        ...q,
        checkinUrl,
        qrSvg: renderQrSvg(checkinUrl, 176)
      };
    });
    res.json({
      profile,
      courses,
      batches,
      students,
      schedules,
      timetableSlots,
      assignments,
      offlineTests,
      leaveRequests,
      parentMessages,
      studentDoubts,
      activeQrSessions,
      notifications,
      phoneMaskingEnabled: maskPhones,
      earningsSummary: {
        monthlyPayoutRate: Number(profile.monthly_payout_rate || 0),
        activeStudentsCount: students.length,
        payoutUpi: profile.payout_upi || "",
        limitationNote: Number(profile.monthly_payout_rate || 0) === 0 ? "Faculty payout schedules are finalized directly by the Yuitor Finance Team." : ""
      }
    });
  });
  router.patch("/profile", (req, res) => {
    const ctx = req.ctx;
    const tid = ctx.user.id;
    const fullName = cleanText(req.body?.fullName || ctx.user.full_name, 120);
    const qualification = cleanText(req.body?.qualification, 120);
    const availabilityStatus = req.body?.availabilityStatus === "vacation" ? "vacation" : "available";
    const vacationNote = cleanText(req.body?.vacationNote, 300);
    const payoutUpi = cleanText(req.body?.payoutUpi, 100);
    db.prepare("UPDATE users SET full_name = ?, updated_at = ? WHERE id = ?").run(fullName, nowIso(), tid);
    db.prepare(
      `INSERT INTO teacher_profiles (user_id, qualification, availability_status, vacation_note, payout_upi)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         qualification = excluded.qualification,
         availability_status = excluded.availability_status,
         vacation_note = excluded.vacation_note,
         payout_upi = excluded.payout_upi`
    ).run(tid, qualification, availabilityStatus, vacationNote, payoutUpi);
    res.json({ updated: true });
  });
  router.post("/announcements", (req, res) => {
    const ctx = req.ctx;
    const courseId = req.body?.courseId ? Number(req.body.courseId) : null;
    if (courseId && !ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "You can only post announcements to your assigned courses." });
      return;
    }
    db.prepare(
      "INSERT INTO announcements (title, body, audience, course_id, created_by, created_at) VALUES (?, ?, 'students', ?, ?, ?)"
    ).run(cleanText(req.body?.title, 180), cleanText(req.body?.body, 2e3), courseId, ctx.user.id, nowIso());
    res.status(201).json({ created: true });
  });
  router.patch("/courses/:courseId", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const existing = db.prepare("SELECT * FROM courses WHERE id = ?").get(cid);
    const safeThumb = req.body?.thumbnailUrl !== void 0 ? sanitizeHttpOrUploadUrl(req.body.thumbnailUrl, 300) : existing.thumbnail_url;
    db.prepare("UPDATE courses SET description = ?, duration_months = ?, thumbnail_url = ? WHERE id = ?").run(
      cleanText(req.body?.description ?? existing.description, 1e3),
      Math.min(60, Math.max(1, Number(req.body?.durationMonths ?? existing.duration_months))),
      safeThumb || existing.thumbnail_url,
      cid
    );
    res.json({ updated: true });
  });
  router.get("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const lessons = db.prepare("SELECT * FROM lessons WHERE course_id = ? ORDER BY sort_order ASC, id ASC").all(cid);
    res.json({ lessons });
  });
  router.post("/courses/:courseId/lessons", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const title = cleanText(req.body?.title, 200);
    if (title.length < 2) {
      res.status(400).json({ error: "Lesson title is required." });
      return;
    }
    const maxSort = db.prepare("SELECT COALESCE(MAX(sort_order), 0) as m FROM lessons WHERE course_id = ?").get(cid).m;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : "text";
    db.prepare(
      `INSERT INTO lessons (course_id, title, lesson_type, material_url, content, duration_minutes, sort_order, is_visible, created_at)
       VALUES (?, ?, ?, ?, ?, 30, ?, 1, ?)`
    ).run(
      cid,
      title,
      lessonType,
      sanitizeHttpOrUploadUrl(req.body?.materialUrl, 400),
      cleanText(req.body?.content, 5e3),
      maxSort + 1,
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.post("/courses/:courseId/lessons/reorder", (req, res) => {
    const ctx = req.ctx;
    const cid = Number(req.params.courseId);
    if (!ownsCourse(ctx.user.id, cid)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const orderedIds = Array.isArray(req.body?.orderedIds) ? req.body.orderedIds.map(Number) : [];
    const upd = db.prepare("UPDATE lessons SET sort_order = ? WHERE id = ? AND course_id = ?");
    orderedIds.forEach((id, idx) => {
      upd.run(idx + 1, id, cid);
    });
    res.json({ reordered: true });
  });
  router.patch("/lessons/:lessonId", (req, res) => {
    const ctx = req.ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db.prepare("SELECT l.*, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?").get(lid);
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Lesson not found or unauthorized." });
      return;
    }
    const title = req.body?.title !== void 0 ? cleanText(req.body.title, 200) : lesson.title;
    const lessonType = ["text", "video", "pdf"].includes(req.body?.lessonType) ? req.body.lessonType : lesson.lesson_type;
    const materialUrl = req.body?.materialUrl !== void 0 ? sanitizeHttpOrUploadUrl(req.body.materialUrl, 400) : lesson.material_url;
    const content = req.body?.content !== void 0 ? cleanText(req.body.content, 5e3) : lesson.content;
    const isVisible = req.body?.isVisible !== void 0 ? req.body.isVisible ? 1 : 0 : lesson.is_visible;
    db.prepare("UPDATE lessons SET title = ?, lesson_type = ?, material_url = ?, content = ?, is_visible = ? WHERE id = ?").run(
      title,
      lessonType,
      materialUrl,
      content,
      isVisible,
      lid
    );
    res.json({ updated: true });
  });
  router.delete("/lessons/:lessonId", (req, res) => {
    const ctx = req.ctx;
    const lid = Number(req.params.lessonId);
    const lesson = db.prepare("SELECT l.id, c.teacher_id FROM lessons l JOIN courses c ON c.id = l.course_id WHERE l.id = ?").get(lid);
    if (!lesson || Number(lesson.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("DELETE FROM lessons WHERE id = ?").run(lid);
    res.json({ deleted: true });
  });
  router.post("/attendance", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const attDate = cleanText(req.body?.attDate || nowIso().slice(0, 10), 10);
    const records = Array.isArray(req.body?.records) ? req.body.records : [];
    const stmt = db.prepare(
      `INSERT INTO attendance (course_id, student_id, teacher_id, att_date, status, remarks, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = excluded.status, remarks = excluded.remarks`
    );
    for (const r of records) {
      const st = ["present", "absent", "late"].includes(r.status) ? r.status : "present";
      stmt.run(courseId, Number(r.studentId), ctx.user.id, attDate, st, cleanText(r.remarks || "", 200), nowIso());
    }
    res.json({ saved: true });
  });
  router.post("/schedules", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      `INSERT INTO class_schedules (course_id, teacher_id, title, scheduled_date, start_time, end_time, mode, meeting_link, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.scheduledDate, 10),
      cleanText(req.body?.startTime, 10),
      cleanText(req.body?.endTime, 10),
      req.body?.mode === "online" ? "online" : "offline",
      sanitizeHttpOrUploadUrl(req.body?.meetingLink, 300),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.post("/assignments", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    db.prepare(
      "INSERT INTO assignments (course_id, teacher_id, title, description, due_date, max_marks, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      cleanText(req.body?.description, 2e3),
      cleanText(req.body?.dueDate, 10),
      Math.max(1, Number(req.body?.maxMarks || 50)),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.get("/assignments/:assignmentId/submissions", (req, res) => {
    const ctx = req.ctx;
    const aid = Number(req.params.assignmentId);
    const assign = db.prepare("SELECT a.*, c.teacher_id FROM assignments a JOIN courses c ON c.id = a.course_id WHERE a.id = ?").get(aid);
    if (!assign || Number(assign.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    const submissions = db.prepare(
      `SELECT s.*, u.full_name as student_name
         FROM assignment_submissions s
         JOIN users u ON u.id = s.student_id
         WHERE s.assignment_id = ?
         ORDER BY s.submitted_at DESC`
    ).all(aid);
    res.json({ submissions });
  });
  router.post("/submissions/:submissionId/grade", (req, res) => {
    const ctx = req.ctx;
    const sid = Number(req.params.submissionId);
    const sub = db.prepare(
      `SELECT s.id, c.teacher_id
         FROM assignment_submissions s
         JOIN assignments a ON a.id = s.assignment_id
         JOIN courses c ON c.id = a.course_id
         WHERE s.id = ?`
    ).get(sid);
    if (!sub || Number(sub.teacher_id) !== ctx.user.id) {
      res.status(403).json({ error: "Unauthorized." });
      return;
    }
    db.prepare("UPDATE assignment_submissions SET marks_obtained = ?, feedback = ?, status = 'graded', graded_at = ? WHERE id = ?").run(
      Number(req.body?.marksObtained || 0),
      cleanText(req.body?.feedback, 500),
      nowIso(),
      sid
    );
    res.json({ graded: true });
  });
  router.post("/quizzes", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "Unauthorized course." });
      return;
    }
    const questions = Array.isArray(req.body?.questions) ? req.body.questions : [];
    db.prepare(
      "INSERT INTO quizzes (course_id, teacher_id, title, max_marks, duration_minutes, questions_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(
      courseId,
      ctx.user.id,
      cleanText(req.body?.title, 180),
      Math.max(1, Number(req.body?.maxMarks || 10)),
      Math.max(1, Number(req.body?.durationMinutes || 15)),
      JSON.stringify(questions),
      nowIso()
    );
    res.status(201).json({ created: true });
  });
  router.post("/attendance/qr-session", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "You can only start QR attendance for your assigned courses." });
      return;
    }
    const batchId = req.body?.batchId ? Number(req.body.batchId) : null;
    const expiresMinutes = Math.min(180, Math.max(5, Number(req.body?.expiresMinutes || 20)));
    const sessionDate = cleanText(req.body?.sessionDate || nowIso().slice(0, 10), 10);
    const tokenCode = `YTR-QR-${crypto9.randomBytes(3).toString("hex").toUpperCase()}`;
    const expiresAt = Math.floor(Date.now() / 1e3) + expiresMinutes * 60;
    const ins = db.prepare(
      `INSERT INTO qr_attendance_sessions (course_id, batch_id, teacher_id, session_date, token_code, expires_at, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(courseId, batchId, ctx.user.id, sessionDate, tokenCode, expiresAt, nowIso());
    const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");
    const checkinUrl = `${siteUrl}/student/?qr=${encodeURIComponent(tokenCode)}`;
    const qrSvg = renderQrSvg(checkinUrl, 184);
    res.status(201).json({
      id: Number(ins.lastInsertRowid),
      tokenCode,
      checkinUrl,
      qrSvg,
      expiresAt,
      expiresMinutes
    });
  });
  router.post("/offline-tests", (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    if (!ownsCourse(ctx.user.id, courseId)) {
      res.status(403).json({ error: "You are not assigned to this course." });
      return;
    }
    const title = cleanText(req.body?.title, 180);
    if (title.length < 2) {
      res.status(400).json({ error: "Test title is required." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO offline_tests (course_id, batch_id, teacher_id, title, subject_name, test_date, max_marks, passing_marks, room_name, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      courseId,
      req.body?.batchId ? Number(req.body.batchId) : null,
      ctx.user.id,
      title,
      cleanText(req.body?.subjectName || "All Subjects", 100),
      cleanText(req.body?.testDate || nowIso().slice(0, 10), 16),
      Math.max(1, Number(req.body?.maxMarks || 100)),
      Math.max(0, Number(req.body?.passingMarks || 33)),
      cleanText(req.body?.roomName || "Exam Hall 1", 80),
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.get("/offline-tests/:testId/marks", (req, res) => {
    const ctx = req.ctx;
    const tid = Number(req.params.testId);
    const test = db.prepare("SELECT * FROM offline_tests WHERE id = ?").get(tid);
    if (!test || !ownsCourse(ctx.user.id, Number(test.course_id))) {
      res.status(403).json({ error: "Offline test not found or unauthorized." });
      return;
    }
    const students = db.prepare(
      `SELECT u.id as student_id, u.full_name, sp.roll_number,
                m.marks_obtained, m.is_absent, m.remarks, m.rank_position
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN offline_test_marks m ON m.test_id = ? AND m.student_id = u.id
         WHERE e.course_id = ? AND e.status IN ('active', 'completed')
           AND (? IS NULL OR e.batch_id = ?)
         ORDER BY COALESCE(m.rank_position, 999999) ASC, u.full_name ASC`
    ).all(tid, test.course_id, test.batch_id, test.batch_id);
    res.json({ test, students });
  });
  router.post("/offline-tests/:testId/marks", (req, res) => {
    const ctx = req.ctx;
    const tid = Number(req.params.testId);
    const test = db.prepare("SELECT * FROM offline_tests WHERE id = ?").get(tid);
    if (!test || !ownsCourse(ctx.user.id, Number(test.course_id))) {
      res.status(403).json({ error: "Offline test not found or unauthorized." });
      return;
    }
    const entries = Array.isArray(req.body?.marks) ? req.body.marks : [];
    const now = nowIso();
    const stmt = db.prepare(
      `INSERT INTO offline_test_marks (test_id, student_id, marks_obtained, is_absent, remarks, graded_by, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(test_id, student_id) DO UPDATE SET
         marks_obtained = excluded.marks_obtained,
         is_absent = excluded.is_absent,
         remarks = excluded.remarks,
         graded_by = excluded.graded_by,
         updated_at = excluded.updated_at`
    );
    for (const e of entries) {
      const sid = Number(e.studentId);
      if (!sid) continue;
      const isAbsent = e.isAbsent ? 1 : 0;
      const val = isAbsent ? 0 : Math.min(Number(test.max_marks || 100), Math.max(0, Number(e.marksObtained || 0)));
      stmt.run(tid, sid, val, isAbsent, cleanText(e.remarks || "", 200), ctx.user.id, now);
    }
    recalculateTestRanks(db, tid);
    const ranked = db.prepare(
      `SELECT m.*, u.full_name, sp.roll_number
         FROM offline_test_marks m
         JOIN users u ON u.id = m.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE m.test_id = ?
         ORDER BY COALESCE(m.rank_position, 999999) ASC, u.full_name ASC`
    ).all(tid);
    res.json({ saved: true, ranked });
  });
  router.get("/performance-report", (req, res) => {
    const ctx = req.ctx;
    const tid = ctx.user.id;
    const courses = db.prepare("SELECT id, title FROM courses WHERE teacher_id = ?").all(tid);
    if (courses.length === 0) {
      res.json({ report: [] });
      return;
    }
    const ph = courses.map(() => "?").join(",");
    const courseIds = courses.map((c) => Number(c.id));
    const report = db.prepare(
      `SELECT u.id as student_id, u.full_name, sp.roll_number, c.id as course_id, c.title as course_title,
                e.progress_percent,
                (SELECT ROUND(100.0 * SUM(CASE WHEN a.status IN ('present', 'late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1)
                 FROM attendance a WHERE a.student_id = u.id AND a.course_id = c.id) as attendance_pct,
                (SELECT ROUND(AVG(100.0 * m.marks_obtained / NULLIF(ot.max_marks, 0)), 1)
                 FROM offline_test_marks m JOIN offline_tests ot ON ot.id = m.test_id
                 WHERE m.student_id = u.id AND ot.course_id = c.id AND m.is_absent = 0) as offline_avg_pct,
                (SELECT MIN(m.rank_position)
                 FROM offline_test_marks m JOIN offline_tests ot ON ot.id = m.test_id
                 WHERE m.student_id = u.id AND ot.course_id = c.id AND m.rank_position IS NOT NULL) as best_rank,
                (SELECT ROUND(AVG(100.0 * qa.score / NULLIF(qa.max_marks, 0)), 1)
                 FROM quiz_attempts qa JOIN quizzes q ON q.id = qa.quiz_id
                 WHERE qa.student_id = u.id AND q.course_id = c.id) as quiz_avg_pct
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         JOIN courses c ON c.id = e.course_id
         WHERE e.course_id IN (${ph}) AND e.status IN ('active', 'completed')
         ORDER BY c.title ASC, u.full_name ASC`
    ).all(...courseIds);
    res.json({ report });
  });
  router.post("/leave-requests", (req, res) => {
    const ctx = req.ctx;
    const fromDate = cleanText(req.body?.fromDate || "", 16);
    const toDate = cleanText(req.body?.toDate || "", 16);
    const reason = cleanText(req.body?.reason || "", 500);
    if (!fromDate || !toDate || reason.length < 4) {
      res.status(400).json({ error: "Enter from date, to date, and clear leave reason." });
      return;
    }
    const now = nowIso();
    const ins = db.prepare(
      `INSERT INTO teacher_leave_requests (teacher_id, branch_id, from_date, to_date, reason, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'pending', ?)`
    ).run(ctx.user.id, ctx.user.branch_id || null, fromDate, toDate, reason, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`Teacher Leave Request: ${ctx.user.full_name}`, `${fromDate} to ${toDate}: ${reason}`, now);
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.post("/parent-messages/reply", (req, res) => {
    const ctx = req.ctx;
    const parentId = Number(req.body?.parentId);
    const studentId = Number(req.body?.studentId);
    const message = cleanText(req.body?.message, 2e3);
    if (!parentId || !studentId || message.length < 2) {
      res.status(400).json({ error: "Parent, student, and reply message are required." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `INSERT INTO parent_teacher_messages (parent_id, student_id, teacher_id, sender_role, message, is_read, created_at)
       VALUES (?, ?, ?, 'teacher', ?, 0, ?)`
    ).run(parentId, studentId, ctx.user.id, message, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(parentId, `Reply from ${ctx.user.full_name}`, message.slice(0, 180), now);
    res.status(201).json({ sent: true });
  });
  router.post("/support-reply", (req, res) => {
    const ctx = req.ctx;
    const supportId = Number(req.body?.supportId);
    const reply = cleanText(req.body?.reply, 1500);
    const msg = db.prepare("SELECT * FROM support_messages WHERE id = ?").get(supportId);
    if (!msg) {
      res.status(404).json({ error: "Student doubt not found." });
      return;
    }
    if (reply.length < 2) {
      res.status(400).json({ error: "Enter a helpful reply." });
      return;
    }
    db.prepare("UPDATE support_messages SET admin_reply = ?, status = 'resolved' WHERE id = ?").run(
      `${ctx.user.full_name}: ${reply}`,
      supportId
    );
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(msg.user_id, `Doubt Answered: ${msg.subject}`, reply.slice(0, 180), nowIso());
    res.json({ replied: true });
  });
  return router;
}

// server/routes/parent.ts
import { Router as Router9 } from "express";
function createParentRouter(db) {
  const router = Router9();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Parent sign-in required." });
      return;
    }
    if (ctx.user.role !== "parent") {
      res.status(403).json({ error: "Parent portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved" || (Number(ctx.user.mobile_verified) !== 1 && !ctx.impersonation?.active)) {
      res.status(403).json({ error: "OTP verification is required before entering the Parent Portal.", code: "OTP_REQUIRED" });
      return;
    }
    req.ctx = ctx;
    next();
  });
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const links = db.prepare(
      `SELECT pl.student_user_id, pl.relation, pl.created_at
         FROM parent_links pl
         JOIN users u ON u.id = pl.student_user_id
         WHERE pl.parent_user_id = ? AND u.role = 'student'
         ORDER BY pl.id ASC`
    ).all(ctx.user.id);
    const children = links.map((l) => {
      const report = getStudentComprehensiveReport(db, Number(l.student_user_id));
      if (!report) return null;
      return {
        relation: l.relation,
        ...report
      };
    }).filter(Boolean);
    const messages = db.prepare(
      `SELECT m.*, stu.full_name as student_name, tch.full_name as teacher_name
         FROM parent_teacher_messages m
         JOIN users stu ON stu.id = m.student_id
         JOIN users tch ON tch.id = m.teacher_id
         WHERE m.parent_id = ?
         ORDER BY m.id DESC LIMIT 60`
    ).all(ctx.user.id);
    const announcements = db.prepare("SELECT * FROM announcements WHERE audience IN ('all', 'students', 'public') ORDER BY id DESC LIMIT 12").all();
    const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? OR role_target = 'all' ORDER BY id DESC LIMIT 20").all(ctx.user.id);
    res.json({
      parent: ctx.user,
      children,
      messages,
      announcements,
      notifications
    });
  });
  router.post("/link-child/request-otp", async (req, res) => {
    const ctx = req.ctx;
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `parentlinkotp:${ip}:${ctx.user.id}`, 5, 600, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many OTP requests. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `parentlinkotp:${ip}:${ctx.user.id}`, 600);
    if (Number(ctx.user.mobile_verified) !== 1) {
      res.status(403).json({ error: "Your parent mobile number must be verified before linking via OTP. You may submit an Admin approval request instead." });
      return;
    }
    const rollNumber = cleanText(req.body?.rollNumber || "", 40).toUpperCase();
    const studentPhone = normalizePhone(req.body?.studentPhone || "");
    if (!rollNumber && !studentPhone) {
      res.status(400).json({ error: "Enter your child's Roll Number or Student Mobile Number." });
      return;
    }
    let student = null;
    if (rollNumber) {
      student = db.prepare(
        `SELECT u.id, u.full_name, u.phone, sp.parent_phone
           FROM users u
           JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND UPPER(sp.roll_number) = ?
           LIMIT 1`
      ).get(rollNumber);
    }
    if (!student && studentPhone) {
      student = db.prepare(
        `SELECT u.id, u.full_name, u.phone, sp.parent_phone
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND (u.phone = ? OR sp.parent_phone = ?)
           LIMIT 1`
      ).get(studentPhone, studentPhone);
    }
    const parentPhone = normalizePhone(ctx.user.phone);
    if (!student || !parentPhone || normalizePhone(student.parent_phone) !== parentPhone) {
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        action: "parent_link_otp_denied",
        details: "Parent mobile did not match student's registered parent_phone",
        ipAddress: ip
      });
      res.status(403).json({
        error: "Your verified parent mobile number does not match the student's registered guardian mobile. Submit an Admin approval request instead."
      });
      return;
    }
    const { otp } = issueOtp(db, {
      userId: ctx.user.id,
      phone: parentPhone,
      email: ctx.user.email,
      purpose: "parent_link"
    });
    let smsSent = false;
    let emailSent = false;
    if (isValidIndianMobile(parentPhone)) {
      const sms = await dispatchSmsOtp(parentPhone, otp, "parent-student linking");
      smsSent = Boolean(sms.sent);
    }
    if (isSmtpConfigured() && ctx.user.email) {
      const mail = await sendTransactionalEmail({
        to: ctx.user.email,
        recipientName: ctx.user.full_name || "Parent",
        subject: "Yuitor Smart Classes \u2014 Parent Link Verification OTP",
        previewText: "Use this 6-digit OTP within 10 minutes to link your child's student profile.",
        htmlBody: `<p>Hello {{name}},</p><p>Your 6-digit verification OTP to link your child's student record is <strong style="font-size:20px;letter-spacing:3px;color:#7A0F28;">${escapeHtml(otp)}</strong>.</p><p>Valid for 10 minutes.</p>`,
        department: "inquiry"
      });
      emailSent = Boolean(mail?.ok || mail?.sent);
    }
    res.json({
      sent: true,
      smsSent,
      emailSent,
      message: "6-digit parent link verification OTP issued to your verified parent contact."
    });
  });
  router.post("/link-child", (req, res) => {
    const ctx = req.ctx;
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `parentlink:${ip}:${ctx.user.id}`, 10, 600, 600);
    if (!rl.allowed) {
      res.status(429).json({ error: `Too many child-link attempts. Wait ${rl.retryAfterSeconds}s.` });
      return;
    }
    recordRateLimitHit(db, `parentlink:${ip}:${ctx.user.id}`, 600);
    const rollNumber = cleanText(req.body?.rollNumber || "", 40).toUpperCase();
    const studentPhone = normalizePhone(req.body?.studentPhone || "");
    const relation = cleanText(req.body?.relation || "Parent / Guardian", 60) || "Parent / Guardian";
    const otpCode = cleanText(req.body?.otp || "", 10);
    const requestApproval = Boolean(req.body?.requestApproval);
    if (!rollNumber && !studentPhone) {
      res.status(400).json({ error: "Enter Student Roll Number (e.g. YTR-STU-0002) or Student Mobile Number." });
      return;
    }
    let student = null;
    if (rollNumber) {
      student = db.prepare(
        `SELECT u.id, u.full_name, u.phone, sp.parent_phone
           FROM users u
           JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND UPPER(sp.roll_number) = ?
           LIMIT 1`
      ).get(rollNumber);
    }
    if (!student && studentPhone) {
      student = db.prepare(
        `SELECT u.id, u.full_name, u.phone, sp.parent_phone
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND (u.phone = ? OR sp.parent_phone = ?)
           LIMIT 1`
      ).get(studentPhone, studentPhone);
    }
    if (!student) {
      res.status(404).json({ error: "No matching student record found. Check Roll Number or contact Yuitor Desk." });
      return;
    }
    const existingLink = db.prepare("SELECT id FROM parent_links WHERE parent_user_id = ? AND student_user_id = ?").get(ctx.user.id, student.id);
    if (existingLink) {
      res.json({ linked: true, alreadyLinked: true, studentName: student.full_name });
      return;
    }
    const parentPhone = normalizePhone(ctx.user.phone);
    const verifiedMobileMatches = Number(ctx.user.mobile_verified) === 1 && Boolean(parentPhone) && normalizePhone(student.parent_phone) === parentPhone;
    if (otpCode) {
      if (!verifiedMobileMatches) {
        writeAuditLog(db, {
          actorId: ctx.user.id,
          actorName: ctx.user.full_name,
          targetId: student.id,
          action: "parent_link_idor_blocked",
          details: "Attempted OTP parent link without matching verified parent_phone",
          ipAddress: ip
        });
        res.status(403).json({
          error: "Your verified mobile number does not match this student's registered parent mobile. Submit an Admin approval request instead."
        });
        return;
      }
      let check = verifyOtpToken(db, { target: parentPhone, purpose: "parent_link", otp: otpCode });
      if (!check.ok && ctx.user.email) {
        check = verifyOtpToken(db, { target: ctx.user.email, purpose: "parent_link", otp: otpCode });
      }
      if (!check.ok || Number(check.tokenRow.user_id) !== Number(ctx.user.id)) {
        res.status(400).json({ error: check.ok ? "OTP does not belong to this parent account." : check.error });
        return;
      }
      db.prepare(
        "INSERT OR IGNORE INTO parent_links (parent_user_id, student_user_id, relation, created_at) VALUES (?, ?, ?, ?)"
      ).run(ctx.user.id, student.id, relation, nowIso());
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: student.id,
        targetName: student.full_name,
        action: "parent_link_verified_otp",
        details: "Parent linked to student via verified parent mobile + OTP",
        ipAddress: ip
      });
      res.status(201).json({ linked: true, studentName: student.full_name });
      return;
    }
    if (requestApproval) {
      const now = nowIso();
      db.prepare(
        `INSERT INTO parent_link_requests (parent_user_id, student_user_id, relation, status, requested_by_ip, created_at)
         VALUES (?, ?, ?, 'pending', ?, ?)
         ON CONFLICT(parent_user_id, student_user_id) DO UPDATE SET
           relation = excluded.relation,
           status = CASE WHEN parent_link_requests.status = 'approved' THEN 'approved' ELSE 'pending' END,
           requested_by_ip = excluded.requested_by_ip`
      ).run(ctx.user.id, student.id, relation, ip, now);
      const reqRow = db.prepare("SELECT id, status FROM parent_link_requests WHERE parent_user_id = ? AND student_user_id = ?").get(ctx.user.id, student.id);
      writeAuditLog(db, {
        actorId: ctx.user.id,
        actorName: ctx.user.full_name,
        targetId: student.id,
        targetName: `Student #${student.id}`,
        action: "parent_link_approval_requested",
        details: "Parent submitted child-link request for Admin approval",
        ipAddress: ip
      });
      res.status(202).json({
        linked: false,
        pendingApproval: true,
        requestId: reqRow?.id,
        message: "Child link request submitted. A Yuitor Administrator will verify and approve the link."
      });
      return;
    }
    // Roll-number-only linking is strictly blocked!
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: student.id,
      action: "parent_link_idor_blocked",
      details: "Blocked parent link attempt without verified parent mobile OTP or Admin approval",
      ipAddress: ip
    });
    res.status(403).json({
      requiresVerification: true,
      canUseOtp: verifiedMobileMatches,
      error: verifiedMobileMatches
        ? "OTP verification required. Request a 6-digit OTP via /api/parent/link-child/request-otp and submit it to complete linking."
        : "Linking by Roll Number alone is disabled for student privacy. Submit with requestApproval: true for Yuitor Admin approval, or update your verified parent mobile at the coaching desk."
    });
  });
  router.post("/messages", (req, res) => {
    const ctx = req.ctx;
    const studentId = Number(req.body?.studentId);
    const teacherId = Number(req.body?.teacherId);
    const message = cleanText(req.body?.message, 2e3);
    if (!studentId || !teacherId || message.length < 2) {
      res.status(400).json({ error: "Select child, teacher, and enter your message." });
      return;
    }
    const link = db.prepare("SELECT id FROM parent_links WHERE parent_user_id = ? AND student_user_id = ?").get(ctx.user.id, studentId);
    if (!link) {
      res.status(403).json({ error: "You can only message teachers for your linked children." });
      return;
    }
    const teacher = db.prepare("SELECT id, full_name FROM users WHERE id = ? AND role = 'teacher'").get(teacherId);
    if (!teacher) {
      res.status(404).json({ error: "Selected teacher not found." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `INSERT INTO parent_teacher_messages (parent_id, student_id, teacher_id, sender_role, message, is_read, created_at)
       VALUES (?, ?, ?, 'parent', ?, 0, ?)`
    ).run(ctx.user.id, studentId, teacherId, message, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(teacherId, `Parent Message from ${ctx.user.full_name}`, message.slice(0, 180), now);
    res.status(201).json({ sent: true });
  });
  router.post("/notifications/read-all", (req, res) => {
    const ctx = req.ctx;
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(ctx.user.id);
    res.json({ updated: true });
  });
  return router;
}

// server/routes/coaching-erp.ts
import { Router as Router10 } from "express";
function csvCell(v) {
  const s = String(v ?? "").replace(/"/g, '""');
  return `"${s}"`;
}
function csvRows(headers, rows) {
  return [headers.map(csvCell).join(","), ...rows.map((r) => r.map(csvCell).join(","))].join("\r\n");
}
function attachCoachingErpEndpoints(router, db, guard) {
  router.get("/branches", guard("batches"), (_req, res) => {
    const branches = db.prepare(
      `SELECT br.*,
                (SELECT COUNT(*) FROM batches b WHERE b.branch_id = br.id AND b.is_active = 1) as batch_count,
                (SELECT COUNT(*) FROM student_profiles sp WHERE sp.branch_id = br.id) as student_count
         FROM branches br
         ORDER BY br.id ASC`
    ).all();
    res.json({ branches });
  });
  router.post("/branches", guard("branches"), (req, res) => {
    const ctx = req.ctx;
    const name = cleanText(req.body?.name, 120);
    const code = cleanText(req.body?.code || `BR-${Date.now().toString(36)}`, 24).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    if (name.length < 2 || !code) {
      res.status(400).json({ error: "Branch name and code are required." });
      return;
    }
    const existing = db.prepare("SELECT id FROM branches WHERE code = ?").get(code);
    if (existing) {
      res.status(409).json({ error: `Branch code ${code} already exists.` });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO branches (name, code, address, city, phone, email, timing_note, map_url, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    ).run(
      name,
      code,
      cleanText(req.body?.address || "", 300),
      cleanText(req.body?.city || "Muradnagar", 80),
      cleanText(req.body?.phone || "+91 78-2728-9292", 30),
      cleanText(req.body?.email || "inquiry@yuitor.com", 120),
      cleanText(req.body?.timingNote || "Mon\u2013Sat \xB7 7:00 AM \u2013 8:00 PM", 120),
      sanitizeHttpOrUploadUrl(req.body?.mapUrl || "", 400),
      nowIso()
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: Number(ins.lastInsertRowid),
      targetName: name,
      action: "branch_created",
      details: `Code: ${code}`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.delete("/branches/:id", guard("branches"), (req, res) => {
    const bid = Number(req.params.id);
    db.prepare("UPDATE batches SET branch_id = NULL WHERE branch_id = ?").run(bid);
    db.prepare("UPDATE student_profiles SET branch_id = NULL WHERE branch_id = ?").run(bid);
    db.prepare("DELETE FROM branches WHERE id = ?").run(bid);
    res.json({ deleted: true });
  });
  router.get("/batches", guard("batches"), (_req, res) => {
    const rows = db.prepare(
      `SELECT b.*, c.title as course_title, br.name as branch_name, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) as seats_used
         FROM batches b
         LEFT JOIN courses c ON c.id = b.course_id
         LEFT JOIN branches br ON br.id = b.branch_id
         LEFT JOIN users u ON u.id = b.teacher_id
         ORDER BY b.id DESC`
    ).all();
    const batches = rows.map((b) => ({
      ...b,
      seats_used: Number(b.seats_used || 0),
      seats_remaining: Math.max(0, Number(b.seat_limit || 0) - Number(b.seats_used || 0))
    }));
    res.json({ batches });
  });
  router.post("/batches", guard("batches"), (req, res) => {
    const ctx = req.ctx;
    const courseId = Number(req.body?.courseId);
    const name = cleanText(req.body?.name, 140);
    const code = cleanText(req.body?.code || `BAT-${Date.now().toString(36)}`, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const seatLimit = Math.min(500, Math.max(1, Number(req.body?.seatLimit || 40)));
    if (!courseId || name.length < 2) {
      res.status(400).json({ error: "Course and batch name are required." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO batches (course_id, branch_id, teacher_id, name, code, room_name, seat_limit, schedule_days, start_time, end_time, start_date, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    ).run(
      courseId,
      req.body?.branchId ? Number(req.body.branchId) : null,
      req.body?.teacherId ? Number(req.body.teacherId) : null,
      name,
      code,
      cleanText(req.body?.roomName || "Room 101", 80),
      seatLimit,
      cleanText(req.body?.scheduleDays || "Mon\u2013Sat", 60),
      cleanText(req.body?.startTime || "16:00", 16),
      cleanText(req.body?.endTime || "17:30", 16),
      cleanText(req.body?.startDate || nowIso().slice(0, 10), 16),
      nowIso()
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: Number(ins.lastInsertRowid),
      targetName: name,
      action: "batch_created",
      details: `Course #${courseId}, limit ${seatLimit} seats`,
      ipAddress: clientIp(req)
    });
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.patch("/batches/:id", guard("batches"), (req, res) => {
    const id = Number(req.params.id);
    const existing = db.prepare("SELECT * FROM batches WHERE id = ?").get(id);
    if (!existing) {
      res.status(404).json({ error: "Batch not found." });
      return;
    }
    db.prepare(
      `UPDATE batches
       SET branch_id = ?, teacher_id = ?, name = ?, room_name = ?, seat_limit = ?,
           schedule_days = ?, start_time = ?, end_time = ?, is_active = ?
       WHERE id = ?`
    ).run(
      req.body?.branchId !== void 0 ? req.body.branchId ? Number(req.body.branchId) : null : existing.branch_id,
      req.body?.teacherId !== void 0 ? req.body.teacherId ? Number(req.body.teacherId) : null : existing.teacher_id,
      cleanText(req.body?.name ?? existing.name, 140),
      cleanText(req.body?.roomName ?? existing.room_name, 80),
      Math.min(500, Math.max(1, Number(req.body?.seatLimit ?? existing.seat_limit))),
      cleanText(req.body?.scheduleDays ?? existing.schedule_days, 60),
      cleanText(req.body?.startTime ?? existing.start_time, 16),
      cleanText(req.body?.endTime ?? existing.end_time, 16),
      req.body?.isActive !== void 0 ? req.body.isActive ? 1 : 0 : existing.is_active,
      id
    );
    res.json({ updated: true });
  });
  router.delete("/batches/:id", guard("batches"), (req, res) => {
    db.prepare("DELETE FROM batches WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/timetable", guard("timetable"), (_req, res) => {
    const slots = db.prepare(
      `SELECT ts.*, c.title as course_title, b.name as batch_name, br.name as branch_name, u.full_name as teacher_name
         FROM timetable_slots ts
         LEFT JOIN courses c ON c.id = ts.course_id
         LEFT JOIN batches b ON b.id = ts.batch_id
         LEFT JOIN branches br ON br.id = ts.branch_id
         LEFT JOIN users u ON u.id = ts.teacher_id
         ORDER BY CASE ts.day_of_week
           WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
           WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 ELSE 7 END,
           ts.start_time ASC`
    ).all();
    res.json({ slots });
  });
  router.post("/timetable", guard("timetable"), (req, res) => {
    const dayOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].includes(
      req.body?.dayOfWeek
    ) ? req.body.dayOfWeek : "Monday";
    const startTime = cleanText(req.body?.startTime || "16:00", 16);
    const endTime = cleanText(req.body?.endTime || "17:00", 16);
    const subjectName = cleanText(req.body?.subjectName || "", 120);
    if (!subjectName) {
      res.status(400).json({ error: "Subject name is required for timetable slot." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO timetable_slots (branch_id, course_id, batch_id, teacher_id, day_of_week, start_time, end_time, subject_name, room_name, mode, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      req.body?.branchId ? Number(req.body.branchId) : null,
      req.body?.courseId ? Number(req.body.courseId) : null,
      req.body?.batchId ? Number(req.body.batchId) : null,
      req.body?.teacherId ? Number(req.body.teacherId) : null,
      dayOfWeek,
      startTime,
      endTime,
      subjectName,
      cleanText(req.body?.roomName || "Room 101", 80),
      req.body?.mode === "online" ? "online" : "offline",
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.delete("/timetable/:id", guard("timetable"), (req, res) => {
    db.prepare("DELETE FROM timetable_slots WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/reports/attendance", guard("attendance"), (req, res) => {
    const courseId = Number(req.query.courseId || 0);
    const dateFrom = cleanText(req.query.from || "", 10);
    const dateTo = cleanText(req.query.to || "", 10);
    const where = [];
    const params = [];
    if (courseId > 0) {
      where.push("a.course_id = ?");
      params.push(courseId);
    }
    if (dateFrom) {
      where.push("a.att_date >= ?");
      params.push(dateFrom);
    }
    if (dateTo) {
      where.push("a.att_date <= ?");
      params.push(dateTo);
    }
    const wSql = where.length ? "WHERE " + where.join(" AND ") : "";
    const records = db.prepare(
      `SELECT a.*, u.full_name as student_name, u.phone as student_phone, sp.roll_number,
                c.title as course_title, b.name as batch_name
         FROM attendance a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         JOIN courses c ON c.id = a.course_id
         LEFT JOIN batches b ON b.id = a.batch_id
         ${wSql}
         ORDER BY a.att_date DESC, a.id DESC LIMIT 300`
    ).all(...params);
    const summary = db.prepare(
      `SELECT u.id as student_id, u.full_name, sp.roll_number, c.title as course_title,
                COUNT(*) as total_days,
                SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days,
                SUM(CASE WHEN a.status = 'late' THEN 1 ELSE 0 END) as late_days,
                SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_days
         FROM attendance a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         JOIN courses c ON c.id = a.course_id
         ${wSql}
         GROUP BY u.id, a.course_id
         ORDER BY u.full_name ASC`
    ).all(...params);
    const summaryWithPct = summary.map((s) => ({
      ...s,
      percentage: Number(s.total_days || 0) > 0 ? Math.round((Number(s.present_days || 0) + Number(s.late_days || 0)) / Number(s.total_days) * 100) : 0
    }));
    if (String(req.query.format || "") === "csv") {
      const csv = csvRows(
        ["Date", "Roll No", "Student", "Course", "Batch", "Status", "Marked Via", "Remarks"],
        records.map((r) => [
          r.att_date,
          r.roll_number || "",
          r.student_name,
          r.course_title,
          r.batch_name || "",
          r.status,
          r.marked_via || "manual",
          r.remarks || ""
        ])
      );
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", 'attachment; filename="yuitor-attendance-report.csv"');
      res.send(csv);
      return;
    }
    res.json({ records, summary: summaryWithPct });
  });
  router.get("/offline-tests", guard("tests"), (_req, res) => {
    const tests = db.prepare(
      `SELECT ot.*, c.title as course_title, b.name as batch_name, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM offline_test_marks m WHERE m.test_id = ot.id) as marks_entered,
                (SELECT ROUND(AVG(m.marks_obtained), 1) FROM offline_test_marks m WHERE m.test_id = ot.id AND m.is_absent = 0) as avg_marks
         FROM offline_tests ot
         LEFT JOIN courses c ON c.id = ot.course_id
         LEFT JOIN batches b ON b.id = ot.batch_id
         LEFT JOIN users u ON u.id = ot.teacher_id
         ORDER BY ot.test_date DESC, ot.id DESC`
    ).all();
    res.json({ tests });
  });
  router.post("/offline-tests", guard("tests"), (req, res) => {
    const courseId = Number(req.body?.courseId);
    const title = cleanText(req.body?.title, 180);
    if (!courseId || title.length < 2) {
      res.status(400).json({ error: "Course and test title are required." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO offline_tests (branch_id, course_id, batch_id, teacher_id, title, subject_name, test_date, max_marks, passing_marks, room_name, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      req.body?.branchId ? Number(req.body.branchId) : null,
      courseId,
      req.body?.batchId ? Number(req.body.batchId) : null,
      req.body?.teacherId ? Number(req.body.teacherId) : null,
      title,
      cleanText(req.body?.subjectName || "All Subjects", 100),
      cleanText(req.body?.testDate || nowIso().slice(0, 10), 16),
      Math.max(1, Number(req.body?.maxMarks || 100)),
      Math.max(0, Number(req.body?.passingMarks || 33)),
      cleanText(req.body?.roomName || "Exam Hall 1", 80),
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.get("/offline-tests/:testId/marks", guard("tests"), (req, res) => {
    const tid = Number(req.params.testId);
    const test = db.prepare(
      `SELECT ot.*, c.title as course_title, b.name as batch_name
         FROM offline_tests ot
         LEFT JOIN courses c ON c.id = ot.course_id
         LEFT JOIN batches b ON b.id = ot.batch_id
         WHERE ot.id = ?`
    ).get(tid);
    if (!test) {
      res.status(404).json({ error: "Offline test not found." });
      return;
    }
    const students = db.prepare(
      `SELECT u.id as student_id, u.full_name, sp.roll_number,
                m.marks_obtained, m.is_absent, m.remarks, m.rank_position
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN offline_test_marks m ON m.test_id = ? AND m.student_id = u.id
         WHERE e.course_id = ? AND e.status IN ('active', 'completed')
           AND (? IS NULL OR e.batch_id = ?)
         ORDER BY COALESCE(m.rank_position, 999999) ASC, u.full_name ASC`
    ).all(tid, test.course_id, test.batch_id, test.batch_id);
    res.json({ test, students });
  });
  router.post("/offline-tests/:testId/marks", guard("tests"), (req, res) => {
    const ctx = req.ctx;
    const tid = Number(req.params.testId);
    const test = db.prepare("SELECT * FROM offline_tests WHERE id = ?").get(tid);
    if (!test) {
      res.status(404).json({ error: "Offline test not found." });
      return;
    }
    const entries = Array.isArray(req.body?.marks) ? req.body.marks : [];
    const now = nowIso();
    const stmt = db.prepare(
      `INSERT INTO offline_test_marks (test_id, student_id, marks_obtained, is_absent, remarks, graded_by, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(test_id, student_id) DO UPDATE SET
         marks_obtained = excluded.marks_obtained,
         is_absent = excluded.is_absent,
         remarks = excluded.remarks,
         graded_by = excluded.graded_by,
         updated_at = excluded.updated_at`
    );
    for (const e of entries) {
      const sid = Number(e.studentId);
      if (!sid) continue;
      const isAbsent = e.isAbsent ? 1 : 0;
      const val = isAbsent ? 0 : Math.min(Number(test.max_marks || 100), Math.max(0, Number(e.marksObtained || 0)));
      stmt.run(tid, sid, val, isAbsent, cleanText(e.remarks || "", 200), ctx.user.id, now);
    }
    recalculateTestRanks(db, tid);
    const ranked = db.prepare(
      `SELECT m.*, u.full_name, sp.roll_number
         FROM offline_test_marks m
         JOIN users u ON u.id = m.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE m.test_id = ?
         ORDER BY COALESCE(m.rank_position, 999999) ASC, u.full_name ASC`
    ).all(tid);
    res.json({ saved: true, ranked });
  });
  router.get("/fee-installments", guard("fees"), (_req, res) => {
    const feeRecords = db.prepare(
      `SELECT f.*, u.full_name as student_name, u.phone as student_phone, sp.roll_number, COALESCE(c.title, f.title) as course_title
         FROM fee_records f
         JOIN users u ON u.id = f.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN courses c ON c.id = f.course_id
         ORDER BY f.id DESC LIMIT 200`
    ).all();
    const installments = db.prepare(
      `SELECT fi.*, fr.title as fee_title, fr.course_id, u.full_name as student_name, u.phone as student_phone, u.email as student_email,
                sp.roll_number, sp.parent_phone
         FROM fee_installments fi
         JOIN fee_records fr ON fr.id = fi.fee_record_id
         JOIN users u ON u.id = fi.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         ORDER BY CASE fi.status WHEN 'overdue' THEN 1 WHEN 'pending' THEN 2 WHEN 'partial' THEN 3 ELSE 4 END, fi.due_date ASC`
    ).all();
    res.json({ feeRecords, installments });
  });
  router.post("/fee-installments/generate", guard("fees"), (req, res) => {
    const feeRecordId = Number(req.body?.feeRecordId);
    const count = Math.min(12, Math.max(1, Number(req.body?.installmentsCount || 3)));
    const firstDueDate = cleanText(req.body?.firstDueDate || nowIso().slice(0, 10), 10);
    const rec = db.prepare("SELECT * FROM fee_records WHERE id = ?").get(feeRecordId);
    if (!rec) {
      res.status(404).json({ error: "Fee record not found." });
      return;
    }
    const existingCount = db.prepare("SELECT COUNT(*) as c FROM fee_installments WHERE fee_record_id = ?").get(feeRecordId).c;
    if (existingCount > 0) {
      res.status(400).json({ error: "Installments already exist for this fee record." });
      return;
    }
    const netDue = Math.max(0, Number(rec.total_amount || 0) - Number(rec.discount_amount || 0) - Number(rec.paid_amount || 0));
    if (netDue <= 0) {
      res.status(400).json({ error: "No pending balance left on this fee record." });
      return;
    }
    const baseSlice = Math.floor(netDue / count);
    const remainder = netDue - baseSlice * count;
    const baseDate = /* @__PURE__ */ new Date(`${firstDueDate}T00:00:00Z`);
    const ins = db.prepare(
      `INSERT INTO fee_installments (fee_record_id, student_id, installment_no, title, amount, paid_amount, due_date, status, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`
    );
    const today = nowIso().slice(0, 10);
    for (let i = 0; i < count; i++) {
      const d = new Date(baseDate.getTime());
      d.setUTCMonth(d.getUTCMonth() + i);
      const dueStr = d.toISOString().slice(0, 10);
      const amt = baseSlice + (i === count - 1 ? remainder : 0);
      const st = dueStr < today ? "overdue" : "pending";
      ins.run(feeRecordId, rec.student_id, i + 1, `${rec.title} \u2014 Inst ${i + 1}/${count}`, amt, dueStr, st, nowIso());
    }
    res.status(201).json({ generated: count, totalAmount: netDue });
  });
  router.post("/fee-installments/:id/pay", guard("fees"), async (req, res) => {
    const ctx = req.ctx;
    const branchScope = getStaffBranchScope(ctx);
    const instId = Number(req.params.id);
    const inst = db.prepare("SELECT * FROM fee_installments WHERE id = ?").get(instId);
    if (!inst) {
      res.status(404).json({ error: "Installment not found." });
      return;
    }
    const feeRec = db.prepare("SELECT * FROM fee_records WHERE id = ?").get(inst.fee_record_id);
    if (branchScope) {
      const stuProfile = db.prepare("SELECT branch_id FROM student_profiles WHERE user_id = ?").get(inst.student_id);
      const recordBranch = Number(feeRec?.branch_id || stuProfile?.branch_id || 0);
      if (recordBranch !== branchScope) {
        res.status(403).json({ error: "Access denied: fee record belongs to another branch." });
        return;
      }
    }
    const remaining = Math.max(0, Number(inst.amount) - Number(inst.paid_amount || 0));
    const payAmt = Math.min(remaining, Math.max(1, Number(req.body?.amount || remaining)));
    const method = ["upi", "cash", "gateway"].includes(req.body?.paymentMethod) ? req.body.paymentMethod : "cash";
    const utr = cleanText(req.body?.utrReference || "", 80);
    const now = nowIso();
    const receiptNo = `YTR-RCP-I${instId}-${Date.now().toString().slice(-4)}`;
    const invoiceNo = `YTR-INV-I${instId}-${Date.now().toString().slice(-4)}`;
    const payIns = db.prepare(
      `INSERT INTO payments (student_id, course_id, plan, base_amount, discount_amount, amount, payment_method, utr_reference, verification_status, invoice_number, receipt_number, paid_at, created_at)
         VALUES (?, ?, 'monthly', ?, 0, ?, ?, ?, 'verified', ?, ?, ?, ?)`
    ).run(
      inst.student_id,
      feeRec?.course_id || null,
      payAmt,
      payAmt,
      method,
      utr,
      invoiceNo,
      receiptNo,
      now,
      now
    );
    const newInstPaid = Number(inst.paid_amount || 0) + payAmt;
    const instStatus = newInstPaid >= Number(inst.amount) ? "paid" : "partial";
    db.prepare("UPDATE fee_installments SET paid_amount = ?, status = ?, payment_id = ? WHERE id = ?").run(
      newInstPaid,
      instStatus,
      Number(payIns.lastInsertRowid),
      instId
    );
    if (feeRec) {
      const nextRecPaid = Number(feeRec.paid_amount || 0) + payAmt;
      const netTotal = Math.max(0, Number(feeRec.total_amount || 0) - Number(feeRec.discount_amount || 0));
      const recStatus = nextRecPaid >= netTotal ? "paid" : "partial";
      db.prepare("UPDATE fee_records SET paid_amount = ?, status = ? WHERE id = ?").run(nextRecPaid, recStatus, feeRec.id);
    }
    await recomputeReferralForStudent(
      db,
      inst.student_id,
      { eventType: "payment_verified", paymentId: Number(payIns.lastInsertRowid), actorId: ctx.user.id, note: `Installment #${instId} verified paid` },
      { writeAuditLog, sendTransactionalEmail, dispatchSmsMessage, dispatchWhatsAppMessage }
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: inst.student_id,
      targetName: inst.title,
      action: "fee_installment_paid",
      details: `\u20B9${payAmt} (${method.toUpperCase()}) \xB7 Receipt ${receiptNo}`,
      ipAddress: clientIp(req)
    });
    res.json({ paid: true, receiptNumber: receiptNo, installmentStatus: instStatus });
  });
  router.post("/fee-installments/send-reminders", guard("fees"), async (req, res) => {
    const ctx = req.ctx;
    const today = nowIso().slice(0, 10);
    db.prepare("UPDATE fee_installments SET status = 'overdue' WHERE status IN ('pending', 'partial') AND due_date < ?").run(today);
    const dueRows = db.prepare(
      `SELECT fi.*, u.full_name as student_name, u.email as student_email, u.phone as student_phone, sp.parent_phone
         FROM fee_installments fi
         JOIN users u ON u.id = fi.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE fi.status IN ('pending', 'partial', 'overdue')
           AND fi.due_date <= date('now', '+5 days')
         ORDER BY fi.due_date ASC LIMIT 60`
    ).all();
    const now = nowIso();
    let inAppSent = 0;
    let smsSent = 0;
    let waSent = 0;
    const waLinks = [];
    for (const row of dueRows) {
      const dueAmt = Math.max(0, Number(row.amount || 0) - Number(row.paid_amount || 0));
      if (dueAmt <= 0) continue;
      const msgText = `Yuitor Fee Reminder: ${row.student_name}'s installment "${row.title}" of Rs.${dueAmt} is ${row.status} (Due: ${row.due_date}).`;
      db.prepare("INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)").run(
        row.student_id,
        `Fee Due Alert: \u20B9${dueAmt}`,
        msgText,
        now
      );
      inAppSent++;
      const targetPhone = row.parent_phone || row.student_phone || "";
      if (targetPhone) {
        if (req.body?.sendSms) {
          const sms = await dispatchSmsMessage(targetPhone, msgText);
          if (sms.sent) smsSent++;
          db.prepare(
            "INSERT INTO alert_dispatch_logs (channel, recipient_user_id, recipient_name, recipient_contact, category, message, status, provider_response, created_by, created_at) VALUES ('sms', ?, ?, ?, 'fee_due', ?, ?, ?, ?, ?)"
          ).run(row.student_id, row.student_name, targetPhone, msgText, sms.sent ? "sent" : "logged", sms.providerResponse, ctx.user.id, now);
        }
        const wa = req.body?.sendWhatsApp ? await dispatchWhatsAppMessage(targetPhone, msgText) : { sent: false, providerResponse: "Manual link", waLink: buildWhatsAppDirectLink(targetPhone, msgText) };
        if (wa.sent) waSent++;
        if (wa.waLink) {
          waLinks.push({ studentName: row.student_name, phone: targetPhone, dueAmount: dueAmt, waLink: wa.waLink });
        }
      }
      if (isSmtpConfigured() && row.student_email) {
        void sendTransactionalEmail({
          to: row.student_email,
          recipientName: row.student_name || "Student",
          subject: `Fee Due Reminder: \u20B9${dueAmt} \u2014 Yuitor Smart Classes`,
          previewText: msgText,
          htmlBody: `<p>Dear {{name}},</p><p>${escapeHtml(msgText)}</p>`,
          department: "fee"
        });
      }
      db.prepare("UPDATE fee_installments SET reminder_sent_at = ? WHERE id = ?").run(now, row.id);
    }
    res.json({ remindersProcessed: dueRows.length, inAppSent, smsSent, waSent, waLinks });
  });
  router.get("/leave-requests", guard("payouts"), (_req, res) => {
    const requests = db.prepare(
      `SELECT lr.*, u.full_name as teacher_name, u.phone as teacher_phone, br.name as branch_name
         FROM teacher_leave_requests lr
         JOIN users u ON u.id = lr.teacher_id
         LEFT JOIN branches br ON br.id = lr.branch_id
         ORDER BY CASE lr.status WHEN 'pending' THEN 1 ELSE 2 END, lr.id DESC`
    ).all();
    res.json({ requests });
  });
  router.post("/leave-requests/:id/review", guard("payouts"), (req, res) => {
    const ctx = req.ctx;
    const lid = Number(req.params.id);
    const status = req.body?.status === "approved" ? "approved" : req.body?.status === "rejected" ? "rejected" : "";
    if (!status) {
      res.status(400).json({ error: "Leave status must be approved or rejected." });
      return;
    }
    const existing = db.prepare("SELECT * FROM teacher_leave_requests WHERE id = ?").get(lid);
    if (!existing) {
      res.status(404).json({ error: "Leave request not found." });
      return;
    }
    const note = cleanText(req.body?.adminNote || "", 400);
    const now = nowIso();
    db.prepare(
      "UPDATE teacher_leave_requests SET status = ?, admin_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?"
    ).run(status, note, ctx.user.id, now, lid);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      existing.teacher_id,
      `Leave Request ${status.toUpperCase()}`,
      `Your leave (${existing.from_date} to ${existing.to_date}) has been ${status}.${note ? ` Note: ${note}` : ""}`,
      now
    );
    let substitution = null;
    if (status === "approved") {
      try {
        const cfg = getAutomationConfig(db);
        const manualSub = req.body?.substituteTeacherId ? Number(req.body.substituteTeacherId) : null;
        if (manualSub || Number(cfg?.auto_substitute_on_leave ?? 1) === 1) {
          substitution = assignSubstituteOnTeacherLeave(db, {
            leaveRequestId: lid,
            substituteTeacherId: manualSub,
            actorId: ctx.user.id
          });
        }
      } catch {
        // Keep leave decision committed even if substitute auto-assignment hits edge case
      }
    }
    res.json({ updated: true, status, substitution });
  });
  router.get("/teacher-payouts", guard("payouts"), (_req, res) => {
    const payouts = db.prepare(
      `SELECT tp.*, u.full_name as teacher_name, prof.payout_upi, prof.monthly_payout_rate
         FROM teacher_payouts tp
         JOIN users u ON u.id = tp.teacher_id
         LEFT JOIN teacher_profiles prof ON prof.user_id = tp.teacher_id
         ORDER BY tp.salary_month DESC, tp.id DESC`
    ).all();
    const teachers = db.prepare(
      `SELECT u.id, u.full_name, tp.monthly_payout_rate, tp.payout_upi
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.is_active = 1
         ORDER BY u.full_name ASC`
    ).all();
    res.json({ payouts, teachers });
  });
  router.post("/teacher-payouts", guard("payouts"), (req, res) => {
    const teacherId = Number(req.body?.teacherId);
    const salaryMonth = cleanText(req.body?.salaryMonth || nowIso().slice(0, 7), 12);
    const baseAmount = Math.max(0, Number(req.body?.baseAmount || 0));
    const bonusAmount = Math.max(0, Number(req.body?.bonusAmount || 0));
    const deductionAmount = Math.max(0, Number(req.body?.deductionAmount || 0));
    const netAmount = Math.max(0, baseAmount + bonusAmount - deductionAmount);
    if (!teacherId || netAmount <= 0) {
      res.status(400).json({ error: "Select teacher and positive salary amount." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO teacher_payouts (teacher_id, branch_id, salary_month, base_amount, bonus_amount, deduction_amount, net_amount, payment_method, status, notes, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`
    ).run(
      teacherId,
      req.body?.branchId ? Number(req.body.branchId) : null,
      salaryMonth,
      baseAmount,
      bonusAmount,
      deductionAmount,
      netAmount,
      cleanText(req.body?.paymentMethod || "upi", 24),
      cleanText(req.body?.notes || "", 300),
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), netAmount });
  });
  router.post("/teacher-payouts/:id/mark-paid", guard("payouts"), (req, res) => {
    const ctx = req.ctx;
    const pid = Number(req.params.id);
    const payout = db.prepare("SELECT * FROM teacher_payouts WHERE id = ?").get(pid);
    if (!payout) {
      res.status(404).json({ error: "Payout entry not found." });
      return;
    }
    const now = nowIso();
    const refNo = cleanText(req.body?.referenceNo || `PAY-${Date.now().toString().slice(-6)}`, 80);
    const method = cleanText(req.body?.paymentMethod || payout.payment_method || "upi", 24);
    db.prepare(
      "UPDATE teacher_payouts SET status = 'paid', payment_method = ?, reference_no = ?, paid_at = ? WHERE id = ?"
    ).run(method, refNo, now, pid);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
    ).run(
      payout.teacher_id,
      `Salary Paid (${payout.salary_month})`,
      `Your salary payout of \u20B9${payout.net_amount} has been processed (${method.toUpperCase()} Ref: ${refNo}).`,
      now
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: payout.teacher_id,
      targetName: `Payout #${pid}`,
      action: "teacher_salary_paid",
      details: `\u20B9${payout.net_amount} (${refNo})`,
      ipAddress: clientIp(req)
    });
    res.json({ paid: true, referenceNo: refNo });
  });
  router.get("/expenses", guard("expenses"), (_req, res) => {
    const expenses = db.prepare(
      `SELECT ex.*, br.name as branch_name
         FROM expenses ex
         LEFT JOIN branches br ON br.id = ex.branch_id
         ORDER BY ex.expense_date DESC, ex.id DESC LIMIT 200`
    ).all();
    const feeIncome = Number(
      db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE verification_status = 'verified'").get().s || 0
    );
    const salaryPaid = Number(
      db.prepare("SELECT COALESCE(SUM(net_amount), 0) as s FROM teacher_payouts WHERE status = 'paid'").get().s || 0
    );
    const opsExpenses = Number(db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM expenses").get().s || 0);
    const totalOutflow = salaryPaid + opsExpenses;
    res.json({
      expenses,
      financeSummary: {
        feeIncome,
        salaryPaid,
        opsExpenses,
        totalOutflow,
        netSurplus: feeIncome - totalOutflow
      }
    });
  });
  router.post("/expenses", guard("expenses"), (req, res) => {
    const ctx = req.ctx;
    const title = cleanText(req.body?.title, 180);
    const amount = Math.max(1, Number(req.body?.amount || 0));
    if (title.length < 2 || amount <= 0) {
      res.status(400).json({ error: "Expense title and positive amount are required." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO expenses (branch_id, title, category, amount, expense_date, payment_method, notes, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      req.body?.branchId ? Number(req.body.branchId) : null,
      title,
      cleanText(req.body?.category || "Operations", 60),
      amount,
      cleanText(req.body?.expenseDate || nowIso().slice(0, 10), 16),
      cleanText(req.body?.paymentMethod || "upi", 24),
      cleanText(req.body?.notes || "", 400),
      ctx.user.id,
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.delete("/expenses/:id", guard("expenses"), (req, res) => {
    db.prepare("DELETE FROM expenses WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/reports/overview", guard("reports"), (req, res) => {
    const branchScope = getStaffBranchScope(req.ctx);
    const dropouts = branchScope ? db.prepare(
      `SELECT e.id, e.status, e.expires_at, e.enrolled_at,
                u.id as student_id, u.full_name, u.phone, u.email, u.verification_status,
                c.title as course_title, b.name as batch_name
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         JOIN courses c ON c.id = e.course_id
         LEFT JOIN batches b ON b.id = e.batch_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE (e.status IN ('cancelled', 'expired') OR u.verification_status = 'suspended' OR (e.expires_at != '' AND e.expires_at < date('now')))
           AND COALESCE(b.branch_id, sp.branch_id) = ?
         ORDER BY e.id DESC LIMIT 100`
    ).all(branchScope) : db.prepare(
      `SELECT e.id, e.status, e.expires_at, e.enrolled_at,
                u.id as student_id, u.full_name, u.phone, u.email, u.verification_status,
                c.title as course_title, b.name as batch_name
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         JOIN courses c ON c.id = e.course_id
         LEFT JOIN batches b ON b.id = e.batch_id
         WHERE e.status IN ('cancelled', 'expired') OR u.verification_status = 'suspended' OR (e.expires_at != '' AND e.expires_at < date('now'))
         ORDER BY e.id DESC LIMIT 100`
    ).all();
    const batchPerformance = branchScope ? db.prepare(
      `SELECT b.id, b.name, b.code, b.seat_limit, c.title as course_title, br.name as branch_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) as enrolled_count,
                (SELECT ROUND(100.0 * SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1)
                 FROM attendance a WHERE a.batch_id = b.id) as attendance_pct,
                (SELECT ROUND(AVG(100.0 * m.marks_obtained / NULLIF(ot.max_marks, 0)), 1)
                 FROM offline_test_marks m
                 JOIN offline_tests ot ON ot.id = m.test_id
                 WHERE ot.batch_id = b.id AND m.is_absent = 0) as test_avg_pct
         FROM batches b
         LEFT JOIN courses c ON c.id = b.course_id
         LEFT JOIN branches br ON br.id = b.branch_id
         WHERE b.branch_id = ?
         ORDER BY b.id ASC`
    ).all(branchScope) : db.prepare(
      `SELECT b.id, b.name, b.code, b.seat_limit, c.title as course_title, br.name as branch_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) as enrolled_count,
                (SELECT ROUND(100.0 * SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1)
                 FROM attendance a WHERE a.batch_id = b.id) as attendance_pct,
                (SELECT ROUND(AVG(100.0 * m.marks_obtained / NULLIF(ot.max_marks, 0)), 1)
                 FROM offline_test_marks m
                 JOIN offline_tests ot ON ot.id = m.test_id
                 WHERE ot.batch_id = b.id AND m.is_absent = 0) as test_avg_pct
         FROM batches b
         LEFT JOIN courses c ON c.id = b.course_id
         LEFT JOIN branches br ON br.id = b.branch_id
         ORDER BY b.id ASC`
    ).all();
    const monthlyCollection = branchScope ? db.prepare(
      `SELECT substr(COALESCE(p.paid_at, p.created_at), 1, 7) as month,
                COUNT(*) as receipt_count,
                COALESCE(SUM(p.amount), 0) as total_collected
         FROM payments p
         LEFT JOIN student_profiles sp ON sp.user_id = p.student_id
         WHERE p.verification_status = 'verified' AND sp.branch_id = ?
         GROUP BY month
         ORDER BY month DESC
         LIMIT 12`
    ).all(branchScope) : db.prepare(
      `SELECT substr(COALESCE(paid_at, created_at), 1, 7) as month,
                COUNT(*) as receipt_count,
                COALESCE(SUM(amount), 0) as total_collected
         FROM payments
         WHERE verification_status = 'verified'
         GROUP BY month
         ORDER BY month DESC
         LIMIT 12`
    ).all();
    res.json({ dropouts, batchPerformance, monthlyCollection });
  });
  router.get("/library", guard("library"), (req, res) => {
    const ctx = req.ctx;
    const branchScope = getStaffBranchScope(ctx);
    const books = branchScope ? db.prepare(
      `SELECT lb.*, c.title as course_title, br.name as branch_name
         FROM library_books lb
         LEFT JOIN courses c ON c.id = lb.course_id
         LEFT JOIN branches br ON br.id = lb.branch_id
         WHERE lb.branch_id = ? OR lb.branch_id IS NULL
         ORDER BY lb.id DESC`
    ).all(branchScope) : db.prepare(
      `SELECT lb.*, c.title as course_title, br.name as branch_name
         FROM library_books lb
         LEFT JOIN courses c ON c.id = lb.course_id
         LEFT JOIN branches br ON br.id = lb.branch_id
         ORDER BY lb.id DESC`
    ).all();
    const rawIssues = branchScope ? db.prepare(
      `SELECT li.*, lb.title as book_title, lb.code as book_code, u.full_name as student_name, sp.roll_number
         FROM library_issues li
         JOIN library_books lb ON lb.id = li.book_id
         JOIN users u ON u.id = li.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE lb.branch_id = ? OR sp.branch_id = ?
         ORDER BY CASE li.status WHEN 'issued' THEN 1 ELSE 2 END, li.id DESC LIMIT 200`
    ).all(branchScope, branchScope) : db.prepare(
      `SELECT li.*, lb.title as book_title, lb.code as book_code, u.full_name as student_name, sp.roll_number
         FROM library_issues li
         JOIN library_books lb ON lb.id = li.book_id
         JOIN users u ON u.id = li.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         ORDER BY CASE li.status WHEN 'issued' THEN 1 ELSE 2 END, li.id DESC LIMIT 200`
    ).all();
    const issues = isStrictLibrarian(ctx) ? stripLibrarianLibraryIssues(rawIssues) : rawIssues;
    res.json({ books, issues });
  });
  router.post("/library/books", guard("library"), (req, res) => {
    const branchScope = getStaffBranchScope(req.ctx);
    const title = cleanText(req.body?.title, 180);
    const code = cleanText(req.body?.code || `BK-${Date.now().toString(36)}`, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    const totalCopies = Math.min(1e3, Math.max(1, Number(req.body?.totalCopies || 10)));
    if (title.length < 2) {
      res.status(400).json({ error: "Book/material title is required." });
      return;
    }
    const targetBranch = branchScope || (req.body?.branchId ? Number(req.body.branchId) : null);
    const ins = db.prepare(
      `INSERT INTO library_books (branch_id, title, code, category, course_id, total_copies, available_copies, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      targetBranch,
      title,
      code,
      cleanText(req.body?.category || "Study Module", 60),
      req.body?.courseId ? Number(req.body.courseId) : null,
      totalCopies,
      totalCopies,
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.post("/library/issues", guard("library"), (req, res) => {
    const ctx = req.ctx;
    const branchScope = getStaffBranchScope(ctx);
    const bookId = Number(req.body?.bookId);
    const studentId = Number(req.body?.studentId);
    const dueReturnDate = cleanText(req.body?.dueReturnDate || new Date(Date.now() + 14 * 86400 * 1e3).toISOString().slice(0, 10), 16);
    const book = db.prepare("SELECT * FROM library_books WHERE id = ?").get(bookId);
    if (!book) {
      res.status(404).json({ error: "Study material / book not found." });
      return;
    }
    if (branchScope && book.branch_id && Number(book.branch_id) !== branchScope) {
      res.status(403).json({ error: "Access denied: book belongs to another branch." });
      return;
    }
    if (Number(book.available_copies || 0) <= 0) {
      res.status(409).json({ error: `All copies of "${book.title}" are currently issued.` });
      return;
    }
    const student = db.prepare(
      `SELECT u.id, u.full_name, sp.branch_id
         FROM users u LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.id = ? AND u.role = 'student'`
    ).get(studentId);
    if (!student) {
      res.status(404).json({ error: "Student not found." });
      return;
    }
    if (branchScope && student.branch_id && Number(student.branch_id) !== branchScope) {
      res.status(403).json({ error: "Access denied: student belongs to another branch." });
      return;
    }
    const now = nowIso();
    db.exec("BEGIN IMMEDIATE;");
    try {
      db.prepare("UPDATE library_books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0").run(bookId);
      const ins = db.prepare(
        `INSERT INTO library_issues (book_id, student_id, issued_by, issued_at, due_return_date, status, remarks)
           VALUES (?, ?, ?, ?, ?, 'issued', ?)`
      ).run(bookId, studentId, ctx.user.id, now, dueReturnDate, cleanText(req.body?.remarks || "", 200));
      db.exec("COMMIT;");
      res.status(201).json({ id: Number(ins.lastInsertRowid), issued: true });
    } catch (err) {
      try {
        db.exec("ROLLBACK;");
      } catch {
      }
      throw err;
    }
  });
  router.post("/library/issues/:id/return", guard("library"), (req, res) => {
    const issueId = Number(req.params.id);
    const issue = db.prepare("SELECT * FROM library_issues WHERE id = ?").get(issueId);
    if (!issue) {
      res.status(404).json({ error: "Issue record not found." });
      return;
    }
    if (issue.status === "returned") {
      res.json({ returned: true, alreadyReturned: true });
      return;
    }
    db.exec("BEGIN IMMEDIATE;");
    try {
      db.prepare("UPDATE library_issues SET status = 'returned', returned_at = ? WHERE id = ?").run(nowIso(), issueId);
      db.prepare("UPDATE library_books SET available_copies = MIN(total_copies, available_copies + 1) WHERE id = ?").run(issue.book_id);
      db.exec("COMMIT;");
      res.json({ returned: true });
    } catch (err) {
      try {
        db.exec("ROLLBACK;");
      } catch {
      }
      throw err;
    }
  });
  router.get("/cms/toppers", guard("cms"), (_req, res) => {
    const toppers = db.prepare("SELECT * FROM toppers ORDER BY sort_order ASC, id DESC").all();
    res.json({ toppers });
  });
  router.post("/cms/toppers", guard("cms"), (req, res) => {
    const studentName = cleanText(req.body?.studentName, 120);
    const examName = cleanText(req.body?.examName, 120);
    if (!studentName || !examName) {
      res.status(400).json({ error: "Student name and exam name are required." });
      return;
    }
    const ins = db.prepare(
      `INSERT INTO toppers (branch_id, student_name, exam_name, rank_label, score_label, batch_label, photo_url, is_featured, sort_order, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    ).run(
      req.body?.branchId ? Number(req.body.branchId) : null,
      studentName,
      examName,
      cleanText(req.body?.rankLabel || "Top Ranker", 60),
      cleanText(req.body?.scoreLabel || "95%+", 60),
      cleanText(req.body?.batchLabel || "Yuitor Achievers", 80),
      sanitizeHttpOrUploadUrl(req.body?.photoUrl || "", 300) || "/assets/images/student-achievement.webp",
      Number(req.body?.sortOrder || 10),
      nowIso()
    );
    res.status(201).json({ id: Number(ins.lastInsertRowid), created: true });
  });
  router.delete("/cms/toppers/:id", guard("cms"), (req, res) => {
    db.prepare("DELETE FROM toppers WHERE id = ?").run(Number(req.params.id));
    res.json({ deleted: true });
  });
  router.get("/alerts", guard("alerts"), (_req, res) => {
    const logs = db.prepare("SELECT * FROM alert_dispatch_logs ORDER BY id DESC LIMIT 100").all();
    res.json({ logs });
  });
  router.post("/alerts/send", guard("alerts"), async (req, res) => {
    const ctx = req.ctx;
    const channel = ["sms", "whatsapp", "in_app"].includes(req.body?.channel) ? req.body.channel : "whatsapp";
    const audience = String(req.body?.audience || "all_students");
    const category = cleanText(req.body?.category || "announcement", 40);
    const message = cleanText(req.body?.message || "", 1e3);
    if (message.length < 4) {
      res.status(400).json({ error: "Alert message must be at least 4 characters." });
      return;
    }
    let recipients = [];
    if (audience === "all_parents") {
      recipients = db.prepare("SELECT id, full_name, phone FROM users WHERE role = 'parent' AND is_active = 1").all();
    } else if (audience === "fee_due") {
      recipients = db.prepare(
        `SELECT DISTINCT u.id, u.full_name, COALESCE(NULLIF(sp.parent_phone, ''), u.phone) as phone
           FROM fee_records f
           JOIN users u ON u.id = f.student_id
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE f.status IN ('pending', 'partial', 'overdue') AND (f.total_amount - f.discount_amount - f.paid_amount) > 0`
      ).all();
    } else if (audience === "batch" && Number(req.body?.batchId) > 0) {
      recipients = db.prepare(
        `SELECT DISTINCT u.id, u.full_name, u.phone
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           WHERE e.batch_id = ? AND e.status IN ('active', 'completed')`
      ).all(Number(req.body.batchId));
    } else if (audience === "course" && Number(req.body?.courseId) > 0) {
      recipients = db.prepare(
        `SELECT DISTINCT u.id, u.full_name, u.phone
           FROM enrollments e
           JOIN users u ON u.id = e.student_id
           WHERE e.course_id = ? AND e.status IN ('active', 'completed')`
      ).all(Number(req.body.courseId));
    } else {
      recipients = db.prepare("SELECT id, full_name, phone FROM users WHERE role = 'student' AND is_active = 1 AND verification_status = 'approved'").all();
    }
    const now = nowIso();
    let sentCount = 0;
    const waLinks = [];
    const insLog = db.prepare(
      `INSERT INTO alert_dispatch_logs (channel, recipient_user_id, recipient_name, recipient_contact, category, message, status, provider_response, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const r of recipients.slice(0, 150)) {
      db.prepare(
        "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)"
      ).run(r.id, `Alert: ${category.replace(/_/g, " ").toUpperCase()}`, message, now);
      if (channel === "in_app") {
        sentCount++;
        insLog.run("in_app", r.id, r.full_name, r.phone || "", category, message, "sent", "In-app notification delivered", ctx.user.id, now);
      } else if (channel === "sms") {
        const sms = await dispatchSmsMessage(r.phone, message);
        if (sms.sent) sentCount++;
        insLog.run("sms", r.id, r.full_name, r.phone || "", category, message, sms.sent ? "sent" : "logged", sms.providerResponse, ctx.user.id, now);
      } else {
        const wa = await dispatchWhatsAppMessage(r.phone, message);
        if (wa.sent) sentCount++;
        if (wa.waLink) waLinks.push({ name: r.full_name, phone: r.phone, waLink: wa.waLink });
        insLog.run("whatsapp", r.id, r.full_name, r.phone || "", category, message, wa.sent ? "sent" : "logged", wa.providerResponse, ctx.user.id, now);
      }
    }
    res.json({
      totalRecipients: recipients.length,
      sentCount,
      channel,
      waLinks
    });
  });
  router.get("/parents", guard("admissions"), (_req, res) => {
    const parents = db.prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.verification_status,
                (SELECT GROUP_CONCAT(stu.full_name || ' (' || COALESCE(sp.roll_number, '#' || stu.id) || ')', ', ')
                 FROM parent_links pl
                 JOIN users stu ON stu.id = pl.student_user_id
                 LEFT JOIN student_profiles sp ON sp.user_id = stu.id
                 WHERE pl.parent_user_id = u.id) as linked_children
         FROM users u
         WHERE u.role = 'parent'
         ORDER BY u.id DESC`
    ).all();
    res.json({ parents });
  });
  router.post("/parents/link", guard("admissions"), (req, res) => {
    const parentId = Number(req.body?.parentId);
    const studentId = Number(req.body?.studentId);
    const relation = cleanText(req.body?.relation || "Parent / Guardian", 60) || "Parent / Guardian";
    const p = db.prepare("SELECT id FROM users WHERE id = ? AND role = 'parent'").get(parentId);
    const s = db.prepare("SELECT id FROM users WHERE id = ? AND role = 'student'").get(studentId);
    if (!p || !s) {
      res.status(404).json({ error: "Parent or Student account not found." });
      return;
    }
    db.prepare(
      "INSERT OR IGNORE INTO parent_links (parent_user_id, student_user_id, relation, created_at) VALUES (?, ?, ?, ?)"
    ).run(parentId, studentId, relation, nowIso());
    res.status(201).json({ linked: true });
  });
}
function createAdminErpRouter(db) {
  const router = Router10();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || ctx.user.role !== "admin" && ctx.user.role !== "super_admin") {
      res.status(403).json({ error: "Admin authorization required." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  attachCoachingErpEndpoints(router, db, () => (_req, _res, next) => next());
  router.patch("/users/:id/staff-permissions", (req, res) => {
    const ctx = req.ctx;
    const uid = Number(req.params.id);
    const target = db.prepare("SELECT id, role, full_name FROM users WHERE id = ?").get(uid);
    if (!target || target.role !== "staff") {
      res.status(404).json({ error: "Staff account not found." });
      return;
    }
    const staffRole = cleanText(req.body?.staffRole || "coordinator", 40).toLowerCase();
    const perms = parseStaffPermissions(req.body?.permissions || []);
    const branchId = req.body?.branchId ? Number(req.body.branchId) : null;
    db.prepare("UPDATE users SET staff_role = ?, staff_permissions_json = ?, branch_id = ?, updated_at = ? WHERE id = ?").run(
      staffRole,
      JSON.stringify(perms),
      branchId,
      nowIso(),
      uid
    );
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: uid,
      targetName: target.full_name,
      action: "staff_permissions_updated",
      details: `role=${staffRole}, branchId=${branchId || "all"}, perms=${perms.join(",")}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true, staffRole, permissions: perms });
  });
  router.get("/parents/link-requests", (_req, res) => {
    const requests = db.prepare(
      `SELECT plr.*,
                p.full_name as parent_name, p.phone as parent_phone, p.email as parent_email,
                s.full_name as student_name, sp.roll_number, sp.class_level
         FROM parent_link_requests plr
         JOIN users p ON p.id = plr.parent_user_id
         JOIN users s ON s.id = plr.student_user_id
         LEFT JOIN student_profiles sp ON sp.user_id = s.id
         ORDER BY CASE plr.status WHEN 'pending' THEN 1 ELSE 2 END, plr.id DESC
         LIMIT 200`
    ).all();
    res.json({ requests });
  });
  router.post("/parents/link-requests/:id/review", (req, res) => {
    const ctx = req.ctx;
    const reqId = Number(req.params.id);
    const decision = req.body?.decision === "approve" || req.body?.status === "approved" ? "approved" : req.body?.decision === "reject" || req.body?.status === "rejected" ? "rejected" : "";
    if (!decision) {
      res.status(400).json({ error: "Decision must be approve or reject." });
      return;
    }
    const row = db.prepare("SELECT * FROM parent_link_requests WHERE id = ?").get(reqId);
    if (!row) {
      res.status(404).json({ error: "Parent link request not found." });
      return;
    }
    const now = nowIso();
    const note = cleanText(req.body?.note || "", 300);
    db.prepare("UPDATE parent_link_requests SET status = ?, reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ?").run(
      decision,
      ctx.user.id,
      note,
      now,
      reqId
    );
    if (decision === "approved") {
      db.prepare(
        "INSERT OR IGNORE INTO parent_links (parent_user_id, student_user_id, relation, created_at) VALUES (?, ?, ?, ?)"
      ).run(row.parent_user_id, row.student_user_id, row.relation || "Parent / Guardian", now);
    }
    writeAuditLog(db, {
      actorId: ctx.user.id,
      actorName: ctx.user.full_name,
      targetId: row.student_user_id,
      targetName: `Parent #${row.parent_user_id} -> Student #${row.student_user_id}`,
      action: `parent_link_${decision}`,
      details: note || `Admin ${decision} parent-student link request #${reqId}`,
      ipAddress: clientIp(req)
    });
    res.json({ updated: true, status: decision });
  });
  return router;
}
function createStaffRouter(db) {
  const router = Router10();
  router.use((req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Staff sign-in required." });
      return;
    }
    if (ctx.user.role !== "staff") {
      res.status(403).json({ error: "Staff portal access only." });
      return;
    }
    if (ctx.user.verification_status !== "approved") {
      res.status(403).json({ error: "Your staff account is awaiting Yuitor Admin approval." });
      return;
    }
    req.ctx = ctx;
    next();
  });
  const staffGuard = (perm) => (req, res, next) => {
    const ctx = req.ctx;
    if (!hasStaffPermission(ctx, perm)) {
      res.status(403).json({ error: `Permission "${perm}" is not enabled for your staff role.` });
      return;
    }
    next();
  };
  router.get("/dashboard", (req, res) => {
    const ctx = req.ctx;
    const branchScope = getStaffBranchScope(ctx);
    const librarianOnly = isStrictLibrarian(ctx);
    const branch = branchScope ? db.prepare("SELECT * FROM branches WHERE id = ?").get(branchScope) : null;
    const courses = branchScope ? db.prepare("SELECT id, title FROM courses WHERE is_active = 1 AND (branch_id = ? OR branch_id IS NULL) ORDER BY id ASC").all(branchScope) : db.prepare("SELECT id, title FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const rawStudents = branchScope ? db.prepare(
      `SELECT u.id, u.full_name, u.phone, sp.roll_number, sp.class_level
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.role = 'student' AND u.is_active = 1 AND sp.branch_id = ?
         ORDER BY u.full_name ASC`
    ).all(branchScope) : db.prepare(
      `SELECT u.id, u.full_name, u.phone, sp.roll_number, sp.class_level
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.role = 'student' AND u.is_active = 1
         ORDER BY u.full_name ASC`
    ).all();
    // Security: Librarian MUST NOT receive student mobile, roll number, or academic class data!
    const students = librarianOnly ? stripLibrarianStudentPii(rawStudents) : rawStudents;
    const inquiries = !librarianOnly && hasStaffPermission(ctx, "inquiries")
      ? (branchScope
        ? db.prepare("SELECT * FROM inquiries WHERE branch_id = ? ORDER BY id DESC LIMIT 60").all(branchScope)
        : db.prepare("SELECT * FROM inquiries ORDER BY id DESC LIMIT 60").all())
      : [];
    res.json({
      staff: {
        id: ctx.user.id,
        fullName: ctx.user.full_name,
        email: ctx.user.email,
        staffRole: ctx.user.staff_role,
        permissions: ctx.user.staff_permissions,
        branch
      },
      courses,
      students,
      inquiries
    });
  });
  router.patch("/inquiries/:id", staffGuard("inquiries"), (req, res) => {
    const ctx = req.ctx;
    const branchScope = getStaffBranchScope(ctx);
    const inqId = Number(req.params.id);
    if (branchScope) {
      const row = db.prepare("SELECT branch_id FROM inquiries WHERE id = ?").get(inqId);
      if (!row || Number(row.branch_id || 0) !== branchScope) {
        res.status(403).json({ error: "Access denied: inquiry belongs to another branch." });
        return;
      }
    }
    const status = String(req.body?.status || "new");
    if (!["new", "contacted", "admitted", "closed"].includes(status)) {
      res.status(400).json({ error: "Invalid inquiry status." });
      return;
    }
    db.prepare(
      `UPDATE inquiries
       SET status = ?, follow_up_date = COALESCE(?, follow_up_date), follow_up_notes = COALESCE(?, follow_up_notes), assigned_staff = COALESCE(?, assigned_staff)
       WHERE id = ?`
    ).run(
      status,
      req.body?.followUpDate !== void 0 ? cleanText(req.body.followUpDate, 20) : null,
      req.body?.followUpNotes !== void 0 ? cleanText(req.body.followUpNotes, 400) : null,
      req.body?.assignedStaff !== void 0 ? cleanText(req.body.assignedStaff, 80) : null,
      inqId
    );
    res.json({ updated: true });
  });
  attachCoachingErpEndpoints(router, db, staffGuard);
  return router;
}

// server/routes/public.ts
import { Router as Router11 } from "express";
import crypto10 from "node:crypto";
import fs12 from "node:fs";
import path10 from "node:path";
import multer4 from "multer";
var ALLOWED_EXTENSIONS = /* @__PURE__ */ new Set([".pdf", ".png", ".jpg", ".jpeg", ".webp"]);
var upload = multer4({
  storage: multer4.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const ext = path10.extname(file.originalname || "").toLowerCase();
      const safeExt = ALLOWED_EXTENSIONS.has(ext) ? ext : ".bin";
      cb(null, `yu-${Date.now()}-${crypto10.randomBytes(6).toString("hex")}${safeExt}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path10.extname(file.originalname || "").toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      cb(new Error("Only PDF, PNG, JPG, and WebP files up to 5 MB are allowed."));
      return;
    }
    cb(null, true);
  }
});
function createPublicRouter(db) {
  const router = Router11();
  router.get("/public/fee-plans", (_req, res) => {
    res.json({
      version: getAppVersionInfo(APP_ROOT).version,
      classes: CLASS_FEE_PLANS,
      cycles: BILLING_CYCLES
    });
  });
  router.get("/public/bootstrap", (_req, res) => {
    const courses = db.prepare("SELECT * FROM courses WHERE is_active = 1 ORDER BY id ASC").all();
    const subjects = db.prepare("SELECT * FROM subjects WHERE is_active = 1 ORDER BY id ASC").all();
    const teachers = db.prepare(
      `SELECT u.id, u.full_name, u.avatar_url, tp.qualification, tp.experience_years, tp.bio
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.verification_status = 'approved' AND u.is_active = 1
         ORDER BY u.id ASC`
    ).all();
    const faqs = db.prepare("SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC, id ASC").all();
    const testimonials = db.prepare("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY id DESC").all();
    const banners = db.prepare("SELECT * FROM banners WHERE is_active = 1 ORDER BY id DESC").all();
    const announcements = db.prepare("SELECT * FROM announcements WHERE audience IN ('all', 'public') ORDER BY id DESC LIMIT 10").all();
    const branches = db.prepare("SELECT * FROM branches WHERE is_active = 1 ORDER BY id ASC").all();
    const rawBatches = db.prepare(
      `SELECT b.*, c.title as course_title, br.name as branch_name, u.full_name as teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id AND e.status IN ('active', 'completed')) as seats_used
         FROM batches b
         LEFT JOIN courses c ON c.id = b.course_id
         LEFT JOIN branches br ON br.id = b.branch_id
         LEFT JOIN users u ON u.id = b.teacher_id
         WHERE b.is_active = 1
         ORDER BY b.id ASC`
    ).all();
    const batches = rawBatches.map((b) => ({
      ...b,
      seats_used: Number(b.seats_used || 0),
      seats_remaining: Math.max(0, Number(b.seat_limit || 0) - Number(b.seats_used || 0))
    }));
    const toppers = db.prepare("SELECT * FROM toppers WHERE is_featured = 1 ORDER BY sort_order ASC, id DESC LIMIT 24").all();
    const timetable = db.prepare(
      `SELECT ts.*, c.title as course_title, b.name as batch_name, br.name as branch_name, u.full_name as teacher_name
         FROM timetable_slots ts
         LEFT JOIN courses c ON c.id = ts.course_id
         LEFT JOIN batches b ON b.id = ts.batch_id
         LEFT JOIN branches br ON br.id = ts.branch_id
         LEFT JOIN users u ON u.id = ts.teacher_id
         ORDER BY ts.id ASC`
    ).all();
    res.json({
      courses,
      subjects,
      teachers,
      faqs,
      testimonials,
      banners,
      announcements,
      branches,
      batches,
      toppers,
      timetable,
      departmentEmails: getDepartmentEmails()
    });
  });
  const handleInquirySubmit = (req, res) => {
    if (String(req.body?.website || "").trim() !== "" || String(req.body?.website_url || "").trim() !== "") {
      res.status(201).json({ accepted: true, success: true, message: "Thank you. Your enquiry has been received." });
      return;
    }
    const ip = clientIp(req);
    const rl = checkRateLimit(db, `inq:${ip}`, 6, 300, 120);
    if (!rl.allowed) {
      res.status(429).json({ error: "Please wait a few seconds before sending another enquiry." });
      return;
    }
    const name = cleanText(req.body?.name, 120);
    const phone = cleanText(req.body?.phone, 24);
    const email = cleanText(req.body?.email, 254);
    const classOrCourse = cleanText(req.body?.class_or_course || req.body?.course || "General Inquiry", 120);
    const message = cleanText(req.body?.message, 2e3);
    const source = cleanText(req.body?.source || "website", 40);
    const branchId = req.body?.branchId ? Number(req.body.branchId) : null;
    const demoDate = cleanText(req.body?.demoDate || "", 20);
    const demoTimeSlot = cleanText(req.body?.demoTimeSlot || "", 60);
    if (name.length < 2) {
      res.status(400).json({ error: "Please enter your name." });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: "Please enter a valid mobile or phone number." });
      return;
    }
    if (email && !isValidEmail(email)) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    recordRateLimitHit(db, `inq:${ip}`, 300);
    const now = nowIso();
    db.prepare(
      `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, branch_id, demo_date, demo_time_slot, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?)`
    ).run(name, phone, email, classOrCourse, message, source, branchId || null, demoDate, demoTimeSlot, now);
    db.prepare(
      "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
    ).run(`New Inquiry: ${classOrCourse}`, `${name} (${phone})${demoDate ? ` \xB7 Demo ${demoDate}` : ""} submitted an inquiry.`, now);
    const notifyEmail = getAdminNotifyEmail();
    if (isSmtpConfigured() && notifyEmail) {
      void sendTransactionalEmail({
        to: notifyEmail,
        recipientName: "Yuitor Admissions Team",
        subject: `New Yuitor Inquiry (${classOrCourse}) \u2014 ${name}`,
        previewText: `New inquiry from ${name} (${phone}) for ${classOrCourse}.`,
        htmlBody: `<p>A new enquiry was submitted on the Yuitor website:</p><p><strong>Name:</strong> ${escapeHtml(name)}<br><strong>Phone:</strong> ${escapeHtml(phone)}<br><strong>Email:</strong> ${escapeHtml(email || "N/A")}<br><strong>Course:</strong> ${escapeHtml(classOrCourse)}<br><strong>Message:</strong> ${escapeHtml(message || "N/A")}</p>`,
        department: "admission"
      });
    }
    res.status(201).json({
      accepted: true,
      success: true,
      message: "Thank you! Your enquiry has been saved. Our Muradnagar team will contact you shortly."
    });
  };
  router.post("/public/inquiries", handleInquirySubmit);
  router.post("/inquiries", handleInquirySubmit);
  router.get("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const user = db.prepare("SELECT email, marketing_opt_in FROM users WHERE unsubscribe_token = ?").get(token);
    if (!user) {
      res.status(404).json({ error: "Invalid or expired unsubscribe token." });
      return;
    }
    res.json({
      email: user.email,
      reason: user.marketing_opt_in ? "Subscribed to Yuitor updates" : "Unsubscribed from marketing emails"
    });
  });
  router.post("/public/unsubscribe/:token", (req, res) => {
    const token = cleanText(req.params.token, 100);
    const optIn = Boolean(req.body?.marketingOptIn);
    const user = db.prepare("SELECT id, email FROM users WHERE unsubscribe_token = ?").get(token);
    if (!user) {
      res.status(404).json({ error: "Invalid unsubscribe token." });
      return;
    }
    db.prepare("UPDATE users SET marketing_opt_in = ?, updated_at = ? WHERE id = ?").run(optIn ? 1 : 0, nowIso(), user.id);
    if (optIn) {
      db.prepare("DELETE FROM email_suppressions WHERE email = ?").run(user.email);
    } else {
      db.prepare("INSERT OR REPLACE INTO email_suppressions (email, reason, created_at) VALUES (?, 'unsubscribed', ?)").run(
        user.email,
        nowIso()
      );
    }
    res.json({ updated: true, marketingOptIn: optIn });
  });
  router.post("/public/chatbot/session", (req, res) => {
    try {
      const existingId = cleanText(req.body?.conversationId, 80);
      const visitorId = cleanText(req.body?.visitorId || `v-${crypto10.randomBytes(4).toString("hex")}`, 80);
      if (existingId) {
        const conv2 = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(existingId);
        if (conv2) {
          const messages2 = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(existingId);
          res.json({ conversation: conv2, messages: messages2 });
          return;
        }
      }
      const newId = `chat-${crypto10.randomUUID()}`;
      const now = nowIso();
      db.prepare(
        `INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at)
         VALUES (?, ?, 'active', ?, ?, ?)`
      ).run(newId, visitorId, SHREYA_INTRO, now, now);
      db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
        newId,
        SHREYA_INTRO,
        now
      );
      const conv = db.prepare("SELECT * FROM chatbot_conversations WHERE id = ?").get(newId);
      const messages = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(newId);
      res.json({ conversation: conv, messages });
    } catch (err) {
      res.status(500).json({ error: err?.message || "Unable to initialize chat session." });
    }
  });
  router.post("/public/chatbot/message", async (req, res) => {
    try {
      const ip = clientIp(req);
      const rl = checkRateLimit(db, `chat:${ip}`, 30, 300, 120);
      if (!rl.allowed) {
        res.status(429).json({ error: "Too many messages. Please wait a moment." });
        return;
      }
      recordRateLimitHit(db, `chat:${ip}`, 300);
      let conversationId = cleanText(req.body?.conversationId, 80);
      const message = cleanText(req.body?.message, 500);
      if (!message) {
        res.status(400).json({ error: "Message is required." });
        return;
      }
      const now = nowIso();
      if (!conversationId || !db.prepare("SELECT id FROM chatbot_conversations WHERE id = ?").get(conversationId)) {
        conversationId = `chat-${crypto10.randomUUID()}`;
        db.prepare(
          "INSERT INTO chatbot_conversations (id, visitor_id, status, last_message, created_at, updated_at) VALUES (?, 'visitor', 'active', ?, ?, ?)"
        ).run(conversationId, SHREYA_INTRO, now, now);
        db.prepare("INSERT INTO chatbot_messages (conversation_id, sender, message, created_at) VALUES (?, 'assistant', ?, ?)").run(
          conversationId,
          SHREYA_INTRO,
          now
        );
      }
      const vName = cleanText(req.body?.visitorName, 120);
      const vPhone = cleanText(req.body?.visitorPhone, 24);
      const vEmail = cleanText(req.body?.visitorEmail, 254);
      if (vName || vPhone || vEmail) {
        db.prepare(
          `UPDATE chatbot_conversations
           SET visitor_name = COALESCE(NULLIF(?, ''), visitor_name),
               visitor_phone = COALESCE(NULLIF(?, ''), visitor_phone),
               visitor_email = COALESCE(NULLIF(?, ''), visitor_email),
               updated_at = ?
           WHERE id = ?`
        ).run(vName, vPhone, vEmail, now, conversationId);
      }
      const { reply, escalate } = await generateShreyaReply(db, conversationId, message);
      saveChatTurn(db, conversationId, message, reply, escalate);
      if (escalate) {
        db.prepare(
          "INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (NULL, 'admin', ?, ?, 0, ?)"
        ).run("Shreya Escalation", `Visitor query requires Yuitor Team follow-up: "${message.slice(0, 120)}"`, now);
      }
      const messages = db.prepare("SELECT sender, message, created_at FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC").all(conversationId);
      res.json({ conversationId, reply, escalated: escalate, messages });
    } catch (err) {
      res.status(500).json({ error: err?.message || "Chatbot request failed." });
    }
  });
  router.post("/public/chatbot/feedback", (req, res) => {
    const conversationId = cleanText(req.body?.conversationId, 80);
    const rating = Math.min(5, Math.max(1, Number(req.body?.rating || 5)));
    const feedback = cleanText(req.body?.feedback, 500);
    const resolved = Boolean(req.body?.resolved);
    if (!conversationId) {
      res.status(400).json({ error: "Conversation ID required." });
      return;
    }
    const status = resolved ? "resolved" : "unresolved";
    db.prepare(
      "UPDATE chatbot_conversations SET rating = ?, feedback = ?, status = ?, updated_at = ? WHERE id = ?"
    ).run(rating, feedback, status, nowIso(), conversationId);
    res.json({ saved: true });
  });
  const formatFestivalConfig = (row) => {
    let overrides = {};
    try {
      overrides = row?.overrides_json ? JSON.parse(row.overrides_json) : {};
    } catch {
      overrides = {};
    }
    const mode = row?.mode || "automatic";
    const manualFestivalId = row?.manual_festival_id || null;
    const simulatedDateIST = row?.simulated_date_ist || null;
    return {
      mode,
      manualFestivalId,
      simulatedDateIST,
      overrides,
      manual_festival_id: manualFestivalId,
      simulated_date_ist: simulatedDateIST,
      overrides_json: JSON.stringify(overrides)
    };
  };
  router.get("/festival", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    res.json({ config: formatFestivalConfig(row) });
  });
  router.get("/festival.php", (_req, res) => {
    const row = db.prepare("SELECT * FROM festival_settings WHERE id = 1").get();
    res.json({ config: formatFestivalConfig(row) });
  });
  router.post("/uploads", (req, res) => {
    const ctx = getSessionContext(db, req);
    if (!ctx) {
      res.status(401).json({ error: "Authentication required to upload files." });
      return;
    }
    upload.single("file")(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err.message || "Upload failed." });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: "No file uploaded." });
        return;
      }
      const check = validateUploadMagicAndMime(
        req.file.path,
        req.file.originalname || req.file.filename,
        req.file.mimetype || "",
        ALLOWED_EXTENSIONS
      );
      if (!check.ok) {
        try {
          fs12.unlinkSync(req.file.path);
        } catch {
        }
        res.status(400).json({ error: check.error || "File contents do not match an allowed PDF, PNG, JPG, or WebP file." });
        return;
      }
      const av = scanUploadedFileWithClamAv(req.file.path);
      if (!av.clean) {
        try {
          fs12.unlinkSync(req.file.path);
        } catch {
        }
        writeAuditLog(db, {
          actorId: ctx.user.id,
          actorName: ctx.user.full_name,
          action: "upload_malware_blocked",
          details: av.reason || "ClamAV rejected uploaded file",
          ipAddress: clientIp(req)
        });
        res.status(400).json({ error: "Uploaded file failed antivirus inspection." });
        return;
      }
      try {
        fs12.chmodSync(req.file.path, 0o600);
      } catch {
      }
      res.status(201).json({
        url: `/uploads/${req.file.filename}`,
        filename: req.file.filename,
        avScanStatus: av.status
      });
    });
  });
  router.get("/download-release", (req, res) => {
    const variant = String(req.query.type || "deploy").toLowerCase() === "source" ? "source" : "deploy";
    if (!verifyReleaseDownload(req.query.expires, req.query.sig, variant)) {
      res.status(403).json({ error: "Invalid or expired download signature." });
      return;
    }
    if (variant === "source") {
      const sourceZip = path10.join(APP_ROOT, "dist-shared", "yuitor-complete-source-code.zip");
      if (!fs12.existsSync(sourceZip)) {
        res.status(404).json({ error: "Complete source code ZIP archive not found." });
        return;
      }
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.download(sourceZip, "yuitor-complete-source-code.zip");
      return;
    }
    const v3Zip = path10.join(APP_ROOT, "yuitor-smart-classes-v3.0.zip");
    const sharedZip = path10.join(APP_ROOT, "dist-shared", "deploy-shared-hosting.zip");
    const legacyZip = path10.join(APP_ROOT, "yuitor-smart-classes-final.zip");
    const zipPath = fs12.existsSync(v3Zip) ? v3Zip : fs12.existsSync(sharedZip) ? sharedZip : legacyZip;
    if (!fs12.existsSync(zipPath)) {
      res.status(404).json({ error: "Release ZIP archive not found." });
      return;
    }
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    res.download(zipPath, fs12.existsSync(v3Zip) ? "yuitor-smart-classes-v3.0.zip" : "yuitor-deploy-shared-hosting.zip");
  });
  return router;
}

// server.ts
var PORT = Number(process.env.PORT || 3e3);
var HOST = "0.0.0.0";
var STATIC_EXT_RE = /\.(?:js|mjs|ts|tsx|css|map|png|jpe?g|webp|gif|svg|ico|woff2?|ttf|eot|json|xml|txt|md|yml|yaml|lock|pdf|sqlite|db|zip|tar|gz|bak|sql|env|log)$/i;
var PRIVATE_ROUTE_RE = /^\/(?:student|teacher|parent|staff|teacher-apply\.php|login|register|unsubscribe|erp)(?:\/|$|\.)/i;
var COMPRESSIBLE_CT_RE = /^(?:text\/|application\/(?:javascript|ecmascript|json|xml|xhtml\+xml)|image\/svg\+xml)/i;
var HASHED_ASSET_RE = /\/assets\/.*-[A-Za-z0-9_-]{8}\.(?:js|css)$/i;
var SENSITIVE_EXT_RE = /\.(?:sql|log|db|sqlite|sqlite3|env|bak|sh)$/i;
var BLOCKED_ROOT_SEGMENTS = /* @__PURE__ */ new Set([
  "backup_original",
  "backups",
  "data",
  "database",
  "logs",
  "scripts",
  "dist-shared",
  "storage",
  "tmp",
  "vendor",
  "node_modules",
  "server",
  "server.ts",
  "server.js",
  "app.cjs",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "htaccess.example",
  "security_report.md",
  "deploy.md",
  ".htaccess",
  "readme.md",
  "deploy-shared-hosting.md"
]);
function applyStaticCacheHeaders(res, filePath) {
  if (/\.html$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
  } else if (
    filePath.includes(`${path11.sep}assets${path11.sep}images${path11.sep}`) ||
    filePath.includes(`${path11.sep}assets${path11.sep}aistudio${path11.sep}`) ||
    HASHED_ASSET_RE.test(filePath)
  ) {
    res.setHeader("Cache-Control", "public, max-age=604800, immutable");
  } else if (/\.(?:js|css|json)$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=86400");
  } else if (/\.(?:svg|png|jpe?g|webp|ico|woff2?)$/i.test(filePath)) {
    res.setHeader("Cache-Control", "public, max-age=86400, stale-while-revalidate=604800");
  }
}
var routeMetaCache = { mtimeMs: -1, data: {} };
function loadRouteMetadataMap() {
  try {
    const metaFile = path11.join(PUBLIC_DIR, "assets", "route-metadata.json");
    const stat = fs13.statSync(metaFile);
    if (stat.mtimeMs !== routeMetaCache.mtimeMs) {
      routeMetaCache = {
        mtimeMs: stat.mtimeMs,
        data: JSON.parse(fs13.readFileSync(metaFile, "utf8"))
      };
    }
  } catch {
  }
  return routeMetaCache.data || {};
}
function resolveRequestOrigin(req) {
  const protoHeader = String(req?.headers?.["x-forwarded-proto"] || "").split(",")[0].trim().toLowerCase();
  const proto = protoHeader === "https" || protoHeader === "http" ? protoHeader : req?.protocol === "https" ? "https" : "http";
  const host = String(req?.headers?.["x-forwarded-host"] || req?.get?.("host") || "").split(",")[0].trim();
  if (host && /^[a-z0-9.-]+(?::\d+)?$/i.test(host)) {
    return `${proto}://${host}`;
  }
  return getPublicSiteUrl();
}
function resolveRouteSeoMeta(rawPath, opts = {}) {
  const cleanPath = String(rawPath || "/").split("?")[0].replace(/\/+$/, "") || "/";
  const routes = opts.routes || loadRouteMetadataMap();
  if (opts.isAdminGate) {
    return {
      title: "Yuitor Console | Yuitor Smart Classes",
      description: "Authorized administration console for Yuitor Smart Classes.",
      canonicalPath: cleanPath,
      isPrivate: true,
      ogType: "website"
    };
  }
  let meta = routes[cleanPath];
  let isNotFound = false;
  if (!meta) {
    if (cleanPath.startsWith("/unsubscribe/") || cleanPath === "/unsubscribe") {
      meta = routes["/unsubscribe"] || {
        title: "Email Subscription Preferences | Yuitor Smart Classes",
        description: "Manage your email communication preferences with Yuitor Smart Classes."
      };
    } else if (/^\/teacher(?:\/|$)/.test(cleanPath)) {
      meta = routes["/teacher"] || routes["/"];
    } else if (/^\/student(?:\/|$)/.test(cleanPath)) {
      meta = routes["/student"] || routes["/"];
    } else if (/^\/parent(?:\/|$)/.test(cleanPath)) {
      meta = routes["/parent"] || routes["/"];
    } else if (/^\/staff(?:\/|$)/.test(cleanPath)) {
      meta = routes["/staff"] || routes["/"];
    } else if (/^\/register(?:\/|$)/.test(cleanPath)) {
      meta = routes["/register"] || routes["/"];
    } else if (/^\/erp(?:\/|$)/.test(cleanPath)) {
      meta = routes["/erp"] || routes["/"];
    } else {
      isNotFound = true;
      meta = {
        title: "404 Page Not Found | Yuitor Smart Classes",
        description: "The requested page could not be found. Explore Yuitor Smart Classes courses, admissions, or return home."
      };
    }
  }
  const isPrivate = Boolean(isNotFound || PRIVATE_ROUTE_RE.test(cleanPath));
  return {
    title: meta?.title || "Yuitor Smart Classes | AI-Assisted Coaching in Muradnagar",
    description: meta?.description || "AI-assisted learning and expert-led coaching for Classes 6\u201312, board exams, JEE, NEET and CUET at Yuitor Smart Classes in Muradnagar.",
    canonicalPath: cleanPath === "/" ? "/" : cleanPath,
    isPrivate,
    ogType: cleanPath.startsWith("/blog/") ? "article" : "website"
  };
}
function upsertMetaTagInHead(html, attrName, attrVal, content) {
  const escapedContent = escapeHtml(content);
  const tag = `<meta ${attrName}="${escapeHtml(attrVal)}" content="${escapedContent}" />`;
  const re = new RegExp(`<meta[^>]+${attrName}=["']${attrVal.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["'][^>]*>`, "i");
  if (re.test(html)) {
    return html.replace(re, tag);
  }
  return html.replace(/<\/head>/i, `    ${tag}\n  </head>`);
}
function injectSeoTagsIntoHtml(rawHtml, opts = {}) {
  const origin = String(opts.origin || getPublicSiteUrl()).replace(/\/+$/, "");
  const seo = resolveRouteSeoMeta(opts.reqPath || "/", {
    routes: opts.routes,
    isAdminGate: Boolean(opts.isAdminGate)
  });
  const canonical = `${origin}${seo.canonicalPath === "/" ? "/" : seo.canonicalPath}`;
  const ogImage = `${origin}/opengraph-yuitor.jpg`;
  let html = String(rawHtml || "");
  if (/<title>[\s\S]*?<\/title>/i.test(html)) {
    html = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeHtml(seo.title)}</title>`);
  } else {
    html = html.replace(/<head([^>]*)>/i, `<head$1>\n    <title>${escapeHtml(seo.title)}</title>`);
  }
  html = upsertMetaTagInHead(html, "name", "description", seo.description);
  html = upsertMetaTagInHead(html, "name", "robots", seo.isPrivate ? "noindex, nofollow" : "index, follow, max-image-preview:large");
  html = upsertMetaTagInHead(html, "property", "og:type", seo.ogType);
  html = upsertMetaTagInHead(html, "property", "og:url", canonical);
  html = upsertMetaTagInHead(html, "property", "og:title", seo.title);
  html = upsertMetaTagInHead(html, "property", "og:description", seo.description);
  html = upsertMetaTagInHead(html, "property", "og:image", ogImage);
  html = upsertMetaTagInHead(html, "property", "og:site_name", "Yuitor Smart Classes");
  html = upsertMetaTagInHead(html, "property", "og:locale", "en_IN");
  html = upsertMetaTagInHead(html, "name", "twitter:card", "summary_large_image");
  html = upsertMetaTagInHead(html, "name", "twitter:title", seo.title);
  html = upsertMetaTagInHead(html, "name", "twitter:description", seo.description);
  html = upsertMetaTagInHead(html, "name", "twitter:image", ogImage);
  const canonicalTag = `<link rel="canonical" href="${escapeHtml(canonical)}" />`;
  if (/<link[^>]+rel=["']canonical["'][^>]*>/i.test(html)) {
    html = html.replace(/<link[^>]+rel=["']canonical["'][^>]*>/i, canonicalTag);
  } else {
    html = html.replace(/<\/head>/i, `    ${canonicalTag}\n  </head>`);
  }
  if (!/href=["']\/assets\/route-metadata\.json["']/i.test(html)) {
    html = html.replace(/<script\s+(?:defer\s+)?src=["']\/assets\/route-seo\.js["']/i, `<link rel="preload" as="fetch" href="/assets/route-metadata.json" crossorigin />\n    <script defer src="/assets/route-seo.js"`);
  }
  html = html.replace(/<script\s+src=(["']\/assets\/(?:site-customizations|festival-engine|festival-system|addons-portal|portals|chatbot-widget)\.js["'])/gi, "<script defer src=$1");
  if (!/href=["']\/assets\/addons\.css/i.test(html)) {
    html = html.replace(/(<link[^>]+href=["']\/assets\/portals\.css(?:\?[^"']*)?["'][^>]*>)/i, `$1\n    <link rel="stylesheet" href="/assets/addons.css">`);
  }
  if (!/href=["']\/assets\/crm-v25\.css/i.test(html)) {
    html = html.replace(/(<link[^>]+href=["']\/assets\/addons\.css(?:\?[^"']*)?["'][^>]*>)/i, `$1\n    <link rel="stylesheet" href="/assets/crm-v25.css?v=250" />`);
  }
  if (!/src=["']\/assets\/addons-portal\.js/i.test(html)) {
    html = html.replace(/(<script[^>]+src=["']\/assets\/portals\.js(?:\?[^"']*)?["'][^>]*><\/script>)/i, `<script defer src="/assets/addons-portal.js"></script>\n    $1`);
  }
  if (!/src=["']\/assets\/crm-v25\.js/i.test(html)) {
    html = html.replace(/(<script[^>]+src=["']\/assets\/portals\.js(?:\?[^"']*)?["'][^>]*><\/script>)/i, `<script defer src="/assets/crm-v25.js?v=250"></script>\n    $1`);
  }
  return html;
}
function sendSeoHtmlFile(res, filePath, req, opts = {}) {
  const rawHtml = fs13.readFileSync(filePath, "utf8");
  const html = injectSeoTagsIntoHtml(rawHtml, {
    origin: resolveRequestOrigin(req),
    reqPath: opts.reqPath ?? req.path ?? "/",
    isAdminGate: Boolean(opts.isAdminGate)
  });
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(html);
}
function renderAdminGateShellHtml(adminSlug, req) {
  const indexFile = path11.join(PUBLIC_DIR, "index.html");
  let html = injectSeoTagsIntoHtml(fs13.readFileSync(indexFile, "utf8"), {
    origin: resolveRequestOrigin(req),
    reqPath: req?.path || `/${adminSlug}/`,
    isAdminGate: true
  });
  const gateBootstrap = `<script>window.__YU_ADMIN_GATE__=${JSON.stringify({
    basePath: `/${adminSlug}`,
    apiBase: `/api/${adminSlug}`
  })};document.documentElement.setAttribute("data-yu-portal-active","1");</script>`;
  html = html.replace(/<\/head>/i, `  ${gateBootstrap}
</head>`);
  return html;
}
function gzipResponseMiddleware(req, res, next) {
  if (process.env.DISABLE_APP_GZIP === "1") {
    next();
    return;
  }
  const acceptEncoding = String(req.headers["accept-encoding"] || "");
  if (!/\bgzip\b/i.test(acceptEncoding) || req.method === "HEAD") {
    next();
    return;
  }
  let gzipStream = null;
  let bypass = false;
  const origWrite = res.write.bind(res);
  const origEnd = res.end.bind(res);
  const origWriteHead = res.writeHead.bind(res);
  function decide() {
    if (gzipStream || bypass) return;
    if (res.getHeader("Content-Encoding") || res.getHeader("Content-Range") || res.statusCode === 204 || res.statusCode === 206 || res.statusCode === 304 || (res.statusCode >= 300 && res.statusCode < 400)) {
      bypass = true;
      return;
    }
    const ct = String(res.getHeader("Content-Type") || "");
    if (!COMPRESSIBLE_CT_RE.test(ct)) {
      bypass = true;
      return;
    }
    const len = Number(res.getHeader("Content-Length") || 0);
    if (len > 0 && len < 1024) {
      bypass = true;
      return;
    }
    res.removeHeader("Content-Length");
    res.setHeader("Content-Encoding", "gzip");
    res.setHeader("Vary", "Accept-Encoding");
    gzipStream = zlib3.createGzip({ level: 6 });
    gzipStream.on("data", (chunk) => origWrite(chunk));
    gzipStream.on("drain", () => res.emit("drain"));
    gzipStream.on("error", () => origEnd());
    gzipStream.on("end", () => origEnd());
  }
  res.writeHead = ((statusCode, reasonOrHeaders, maybeHeaders) => {
    const hdrObj = typeof reasonOrHeaders === "object" && reasonOrHeaders !== null ? reasonOrHeaders : maybeHeaders;
    if (hdrObj && typeof hdrObj === "object") {
      for (const [k, v] of Object.entries(hdrObj)) {
        if (v !== void 0) res.setHeader(k, v);
      }
    }
    res.statusCode = statusCode;
    decide();
    if (typeof reasonOrHeaders === "string") {
      return origWriteHead(statusCode, reasonOrHeaders);
    }
    return origWriteHead(statusCode);
  });
  res.write = ((chunk, encoding, cb) => {
    decide();
    if (gzipStream) {
      if (typeof encoding === "function") return gzipStream.write(chunk, encoding);
      return gzipStream.write(chunk, encoding, cb);
    }
    return origWrite(chunk, encoding, cb);
  });
  res.end = ((chunk, encoding, cb) => {
    decide();
    if (gzipStream) {
      if (typeof chunk === "function") {
        gzipStream.end(chunk);
      } else if (typeof encoding === "function") {
        gzipStream.end(chunk, encoding);
      } else if (chunk !== void 0) {
        gzipStream.end(chunk, encoding, cb);
      } else {
        gzipStream.end();
      }
      return res;
    }
    return origEnd(chunk, encoding, cb);
  });
  next();
}
function createApp() {
  const db = getDb();
  hardenRuntimePermissions({
    dirs: [DATA_DIR, BACKUPS_DIR, LOGS_DIR, RESUMES_DIR, KNOWLEDGE_DIR],
    files: [DB_PATH, path11.join(APP_ROOT, ".env")]
  });
  getAdminPath(db);
  registerMailerDb(db);
  startEmailScheduler(db);
  startMailSyncScheduler(db);
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", resolveTrustProxySetting(process.env.TRUST_PROXY));
  const cspHeader = buildCspHeader();
  app.use((req, res, next) => {
    const httpsReq = isRequestHttps(req);
    const hostHdr = String(req.headers.host || "").toLowerCase();
    const isLocalHost = hostHdr.startsWith("localhost") || hostHdr.startsWith("127.0.0.1");
    res.setHeader("Content-Security-Policy", cspHeader);
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    // Send COOP only on trustworthy origins (HTTPS / localhost) to avoid browser/WebView warnings on plain HTTP
    if (httpsReq || isLocalHost) {
      res.setHeader("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
    }
    // Send HSTS ONLY when the actual connection is HTTPS (never lock plain-HTTP or unencrypted subdomains)
    if (httpsReq) {
      const hstsVal = process.env.HSTS_INCLUDE_SUBDOMAINS === "1"
        ? "max-age=31536000; includeSubDomains"
        : "max-age=31536000";
      res.setHeader("Strict-Transport-Security", hstsVal);
    }
    next();
  });
  app.use(gzipResponseMiddleware);
  app.use(
    express.json({
      limit: "1mb",
      verify: (req, _res, buf) => {
        if (req.originalUrl?.startsWith("/api/payments/webhook")) {
          req.rawBody = buf.toString("utf8");
        }
      }
    })
  );
  app.use(express.urlencoded({ extended: true, limit: "1mb" }));
  app.use(cookieParser());
  app.use((req, res, next) => {
    if (req.method === "GET") {
      issueCsrfCookieIfMissing(req, res);
    }
    next();
  });
  app.use("/api", (_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  app.use("/api", sameOriginGuard);
  app.get("/api/health", (_req, res) => {
    const info = getAppVersionInfo(APP_ROOT);
    res.json({
      ok: true,
      service: "yuitor-smart-classes",
      version: info.version,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app.use(["/api/admin", "/api/marketing"], (_req, res) => {
    res.status(404).json({ error: "API endpoint not found." });
  });
  app.use("/api/auth", createAuthRouter(db));
  app.use("/api/student", createStudentRouter(db));
  app.use("/api/teacher", createTeacherRouter(db));
  app.use("/api/parent", createParentRouter(db));
  app.use("/api/staff", createStaffRouter(db));
  app.use("/api/payments", createPaymentsRouter(db));
  const adminGateRouter = Router12();
  adminGateRouter.use(createAdminGateAuthRouter(db));
  adminGateRouter.use((req, res, next) => {
    if (!isIpAllowedForAdmin(clientIp(req))) {
      res.status(403).json({ error: "Access denied from your current IP address." });
      return;
    }
    next();
  });
  const addonDeps = {
    getSessionContext,
    writeAuditLog,
    clientIp,
    validateBatchCapacity,
    verifyRazorpaySignature,
    sendTransactionalEmail,
    dispatchSmsMessage,
    dispatchWhatsAppMessage,
    SETTING_DEFINITIONS,
    backupsDir: BACKUPS_DIR
  };
  startCentralCrmScheduler(db, addonDeps);
  adminGateRouter.use("/marketing", createMarketingRouter(db));
  adminGateRouter.use("/mail", createMailRouter(db));
  adminGateRouter.use("/", createAddonsAdminRouter(db, addonDeps));
  adminGateRouter.use("/", createCrmAdminRouter(db, addonDeps));
  adminGateRouter.use("/", createAdminErpRouter(db));
  adminGateRouter.use("/", createAdminRouter(db));
  app.use("/api/:gateSegment", (req, res, next) => {
    if (req.params.gateSegment === getAdminPath(db)) {
      adminGateRouter(req, res, next);
      return;
    }
    next();
  });
  app.use("/api", createAddonsUserRouter(db, addonDeps));
  app.use("/api", createCrmUserRouter(db, addonDeps));
  app.use("/api", createPublicRouter(db));
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "API endpoint not found." });
  });
  app.use((req, res, next) => {
    if (isLegacyAdminProbePath(req.path)) {
      res.status(404).setHeader("Cache-Control", "no-store");
      sendSeoHtmlFile(res, path11.join(PUBLIC_DIR, "index.html"), req, { reqPath: "/404" });
      return;
    }
    next();
  });
  app.get(["/erp", "/erp/index.php"], (req, res) => {
    const role = String(req.query.role || "").toLowerCase();
    res.redirect(302, role === "teacher" ? "/teacher/" : "/student/");
  });
  app.get("/login.php", (_req, res) => res.redirect(302, "/student/login"));
  app.get("/register.php", (_req, res) => res.redirect(302, "/student/register"));
  app.get("/student-login", (_req, res) => res.redirect(302, "/student/login"));
  app.get("/teacher-login", (_req, res) => res.redirect(302, "/teacher/login"));
  app.get("/parent-login", (_req, res) => res.redirect(302, "/parent/login"));
  app.get("/student-register", (_req, res) => res.redirect(302, "/student/register"));
  app.get("/teacher-register", (_req, res) => res.redirect(302, "/teacher/register"));
  app.get("/parent-register", (_req, res) => res.redirect(302, "/parent/register"));
  app.get("/student/index.php", (_req, res) => res.redirect(302, "/student/"));
  app.get("/teacher/index.php", (_req, res) => res.redirect(302, "/teacher/"));
  app.get("/ref/:code", (req, res) => {
    const code = String(req.params.code || "").replace(/[^A-Za-z0-9_-]/g, "").toUpperCase();
    res.redirect(302, code ? `/register/student?ref=${encodeURIComponent(code)}` : "/register/student");
  });
  app.get("/cart", (_req, res) => res.redirect(302, "/courses?openCart=1"));
  app.use((req, res, next) => {
    const segments = req.path.split("/").filter(Boolean);
    if (segments.some((seg) => seg.startsWith(".") && seg !== ".well-known")) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }
    const first = (segments[0] || "").toLowerCase();
    if (BLOCKED_ROOT_SEGMENTS.has(first) || SENSITIVE_EXT_RE.test(req.path)) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }
    next();
  });
  app.use(["/uploads/resumes", "/uploads/knowledge"], (_req, res) => {
    res.status(403).json({ error: "Private documents require authorized portal access." });
  });
  app.get("/uploads/:filename", (req, res) => {
    const rawName = String(req.params.filename || "");
    const safeName = path11.basename(rawName);
    if (!safeName || safeName !== rawName || safeName.startsWith(".") || safeName.includes("..")) {
      res.status(400).type("text/plain").send("Invalid filename");
      return;
    }
    const ext = path11.extname(safeName).toLowerCase();
    // Private document uploads (PDFs) MUST require an authenticated session!
    if (ext === ".pdf") {
      const ctx = getSessionContext(db, req);
      if (!ctx) {
        res.status(401).json({ error: "Authentication required to download uploaded documents." });
        return;
      }
      res.setHeader("Cache-Control", "private, no-store");
      res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
    } else if (![".png", ".jpg", ".jpeg", ".webp"].includes(ext)) {
      res.status(403).type("text/plain").send("Forbidden");
      return;
    }
    const targetPath = path11.resolve(UPLOADS_DIR, safeName);
    const uploadsRoot = path11.resolve(UPLOADS_DIR) + path11.sep;
    if (!targetPath.startsWith(uploadsRoot) || !fs13.existsSync(targetPath)) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.sendFile(targetPath);
  });
  app.use("/uploads", (_req, res) => {
    res.status(403).json({ error: "Direct directory access forbidden." });
  });
  app.get("*", (req, res, next) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      next();
      return;
    }
    const adminSlug = getAdminPath(db);
    if (reqPath === `/${adminSlug}` || reqPath.startsWith(`/${adminSlug}/`)) {
      if (!isIpAllowedForAdmin(clientIp(req))) {
        res.status(403).type("text/plain").send("Access restricted.");
        return;
      }
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
      res.type("html").send(renderAdminGateShellHtml(adminSlug, req));
      return;
    }
    next();
  });
  app.get("*", (req, res, next) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      next();
      return;
    }
    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
    } else {
      res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    }
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (!safeRel) {
      sendSeoHtmlFile(res, path11.join(PUBLIC_DIR, "index.html"), req, { reqPath: "/" });
      return;
    }
    if (!safeRel.includes("..")) {
      const candidate = path11.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs13.existsSync(candidate)) {
        sendSeoHtmlFile(res, candidate, req);
        return;
      }
    }
    next();
  });
  app.get("/.well-known/security.txt", (_req, res) => {
    const secTxt = path11.join(PUBLIC_DIR, ".well-known", "security.txt");
    if (fs13.existsSync(secTxt)) {
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.sendFile(secTxt);
      return;
    }
    res.status(404).type("text/plain").send("Not Found");
  });
  app.get(["/yuitor-smart-classes-v3.0.zip", "/download/yuitor-smart-classes-v3.0.zip"], (_req, res) => {
    const candidates = [
      path11.join(APP_ROOT, "yuitor-smart-classes-v3.0.zip"),
      path11.join(PUBLIC_DIR, "yuitor-smart-classes-v3.0.zip")
    ];
    const target = candidates.find((p) => fs13.existsSync(p));
    if (!target) {
      res.status(404).type("text/plain").send("Archive not found");
      return;
    }
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="yuitor-smart-classes-v3.0.zip"');
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    res.download(target, "yuitor-smart-classes-v3.0.zip");
  });
  app.use(
    express.static(PUBLIC_DIR, {
      dotfiles: "deny",
      index: "index.html",
      extensions: ["html"],
      redirect: false,
      setHeaders: applyStaticCacheHeaders
    })
  );
  app.get("*", (req, res) => {
    const reqPath = req.path || "/";
    if (STATIC_EXT_RE.test(reqPath) && !reqPath.endsWith(".php")) {
      res.status(404).type("text/plain").send("Not Found");
      return;
    }
    if (PRIVATE_ROUTE_RE.test(reqPath)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.setHeader("Cache-Control", "no-store");
      sendSeoHtmlFile(res, path11.join(PUBLIC_DIR, "index.html"), req);
      return;
    }
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    const safeRel = reqPath.replace(/^\/+|\/+$/g, "");
    if (safeRel && !safeRel.includes("..")) {
      const candidate = path11.join(PUBLIC_DIR, safeRel, "index.html");
      if (candidate.startsWith(PUBLIC_DIR) && fs13.existsSync(candidate)) {
        sendSeoHtmlFile(res, candidate, req);
        return;
      }
    }
    sendSeoHtmlFile(res, path11.join(PUBLIC_DIR, "index.html"), req);
  });
  app.use((err, req, res, _next) => {
    const status = Number(err?.status || 500);
    console.error("[Yuitor Server Error]", status, redactSecretsForLog(err?.message || "Unexpected error"));
    if (req.path.startsWith("/api")) {
      const safeError = status >= 500 ? "Internal server error." : redactSecretsForLog(err?.message || "Request failed.");
      res.status(status >= 400 ? status : 500).json({ error: safeError });
      return;
    }
    res.status(status >= 400 ? status : 500).type("text/plain").send("Server error");
  });
  return { app, db };
}
var shouldAutoListen = process.env.YUITOR_NO_LISTEN !== "1" && process.env.NODE_ENV !== "test" && !process.env.VITEST;
var serverApp = shouldAutoListen ? createApp().app : null;
if (serverApp) {
  serverApp.listen(PORT, HOST, () => {
    console.log(`Yuitor Smart Classes unified server listening on http://${HOST}:${PORT} (public: ${PUBLIC_DIR})`);
  });
}
export {
  createApp,
  getPublicSiteUrl,
  injectSeoTagsIntoHtml,
  renderBrandedEmailHtml,
  resolveRouteSeoMeta,
  serverApp
};
