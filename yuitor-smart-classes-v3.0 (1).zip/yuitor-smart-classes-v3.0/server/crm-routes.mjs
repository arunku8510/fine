import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { Router } from "express";
import { nowIso, runInImmediateTx } from "./addons-db.mjs";
import { rowsToCsv } from "./referral-math.mjs";
import {
  getAutomationConfig,
  STAFF_ROLE_TEMPLATES,
  updateAutomationConfig
} from "./crm-db.mjs";
import {
  assignSubstituteOnTeacherLeave,
  buildBirthdayEmailTemplate,
  buildWhatsAppClickToChatUrl,
  calculateCbtResult,
  computeCostPerAdmission,
  computeLeadScore,
  computeRankAndPercentile,
  createExceptionItem,
  detectTimetableClash,
  emitSystemEvent,
  executeMemberExit,
  generateMonthlyFeeInvoices,
  getIstDateParts,
  getStudentDefaulterLockState,
  getUpcomingBirthdays,
  isBirthdayTodayIst,
  isTeacherPhoneMaskingEnabled,
  maskPhoneForTeacher,
  normalizeIndianPhone,
  parseCsvRows,
  pickBestSubstituteTeacher,
  processJobQueueBatch,
  redactFeedbackForTeacher,
  rejoinExitedMember,
  renderStandardMessage,
  sendBirthdayWishesForToday,
  sendRoleWelcomeKit
} from "./crm-engine.mjs";
import {
  buildSimplePdfBuffer,
  renderAdmitCardHtml,
  renderFeeReceiptHtml,
  renderProgressReportHtml,
  renderStudentIdCardHtml
} from "./crm-pdf.mjs";
import {
  computeFounderDailyMetrics,
  generateTeacherPayrollDrafts,
  runCentralSchedulerTick,
  runStudentRiskCalculation,
  saveDailyReport
} from "./crm-scheduler.mjs";

function requireAdminRole(db, getSessionContext) {
  return (req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || !["super_admin", "admin"].includes(ctx.user?.role)) {
      res.status(401).json({ error: "Administrator authentication required." });
      return;
    }
    req.adminCtx = ctx;
    next();
  };
}

function requireAnyPortalRole(db, getSessionContext, allowedRoles = []) {
  return (req, res, next) => {
    const ctx = getSessionContext(db, req);
    if (!ctx || !allowedRoles.includes(ctx.user?.role)) {
      res.status(401).json({ error: "Authorized portal session required." });
      return;
    }
    req.portalCtx = ctx;
    next();
  };
}

function getStudentFullRecord(db, studentId) {
  return db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.verification_status, u.created_at,
              sp.roll_number, sp.class_level, sp.board, sp.parent_name, sp.parent_phone,
              sp.batch_id, sp.branch_id, sp.fee_lock_exempt,
              b.name AS batch_name, b.code AS batch_code, b.delivery_mode,
              br.name AS branch_name
       FROM users u
       LEFT JOIN student_profiles sp ON sp.user_id = u.id
       LEFT JOIN batches b ON b.id = sp.batch_id
       LEFT JOIN branches br ON br.id = sp.branch_id
       WHERE u.id = ? AND u.role = 'student'`
    )
    .get(Number(studentId));
}

function getStudentProgressReportData(db, studentId) {
  const student = getStudentFullRecord(db, studentId);
  if (!student) return null;
  const att = db
    .prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END) AS present_cnt FROM attendance WHERE student_id = ?`)
    .get(student.id);
  const attendancePercent = Number(att?.total || 0) > 0 ? Math.round((Number(att.present_cnt || 0) / Number(att.total)) * 100) : 100;
  const tests = db
    .prepare(
      `SELECT t.title, t.subject_name, t.test_date, t.max_marks, m.marks_obtained, m.is_absent, m.rank_position, m.remarks
       FROM offline_test_marks m
       JOIN offline_tests t ON t.id = m.test_id
       WHERE m.student_id = ?
       ORDER BY t.test_date DESC LIMIT 20`
    )
    .all(student.id);
  const scored = tests.filter((t) => !t.is_absent && Number(t.max_marks) > 0);
  const avgPercent = scored.length
    ? Math.round(scored.reduce((acc, t) => acc + (Number(t.marks_obtained) / Number(t.max_marks)) * 100, 0) / scored.length)
    : 0;
  const bestRank = scored.map((t) => Number(t.rank_position || 0)).filter(Boolean).sort((a, b) => a - b)[0] || null;
  const performanceGrade = avgPercent >= 85 ? "Outstanding" : avgPercent >= 70 ? "Very Good" : avgPercent >= 50 ? "Steady Progress" : "Needs Extra Practice";
  const summaryText = `Attendance stands at ${attendancePercent}% with ${tests.length} offline test(s) evaluated${scored.length ? ` and an average score of ${avgPercent}% (${performanceGrade})` : ""}. ${
    attendancePercent < 75 ? "Immediate improvement in class attendance is recommended." : "Maintain consistent revision and DPP completion."
  }`;
  return {
    student,
    monthLabel: getIstDateParts().monthStr,
    attendancePercent,
    avgPercent,
    performanceGrade,
    batchRankLabel: bestRank ? `#${bestRank}` : "Pending",
    tests,
    summaryText
  };
}

// ==================== ADMIN CRM ROUTER (MOUNTED UNDER HIDDEN ADMIN GATE) ====================
export function createCrmAdminRouter(db, deps) {
  const router = Router();
  const { getSessionContext, writeAuditLog, clientIp } = deps;
  const guard = requireAdminRole(db, getSessionContext);

  // 1. Smart Admin Dashboard Overview (Live KPI Alerts + Today's Desk + Founder Report)
  router.get("/crm/dashboard", guard, (_req, res) => {
    const ist = getIstDateParts();
    const kpi = computeFounderDailyMetrics(db, ist.dateStr);
    const latestReport = db
      .prepare(`SELECT * FROM crm_daily_reports ORDER BY created_at DESC LIMIT 1`)
      .get();
    const config = getAutomationConfig(db);
    const recentExceptions = db
      .prepare(`SELECT * FROM crm_exception_inbox WHERE status = 'open' ORDER BY created_at DESC LIMIT 6`)
      .all();
    res.json({
      ist,
      kpi,
      config,
      latestReport: latestReport
        ? { ...latestReport, metrics: JSON.parse(latestReport.metrics_json || "{}") }
        : null,
      recentExceptions
    });
  });

  // Founder's Daily Report (view + manual generate/refresh)
  router.get("/crm/founder-report", guard, (req, res) => {
    const dateStr = String(req.query.date || getIstDateParts().dateStr);
    const metrics = computeFounderDailyMetrics(db, dateStr);
    const history = db
      .prepare(`SELECT * FROM crm_daily_reports ORDER BY created_at DESC LIMIT 14`)
      .all()
      .map((r) => ({ ...r, metrics: JSON.parse(r.metrics_json || "{}") }));
    res.json({ dateStr, metrics, history });
  });

  router.post("/crm/founder-report/generate", guard, (req, res) => {
    const type = ["founder_8pm", "owner_930pm", "weekly_monday"].includes(req.body?.reportType)
      ? req.body.reportType
      : "founder_8pm";
    const out = saveDailyReport(db, type, getIstDateParts().dateStr);
    writeAuditLog(db, req.adminCtx.user, "crm_founder_report_generated", null, type, "Generated daily owner report", clientIp(req));
    res.json({ ok: true, ...out });
  });

  // 2. Ctrl + K Quick Command Bar Search (Students by Name / Roll / Phone + Batches)
  router.get("/crm/command-search", guard, (req, res) => {
    const q = String(req.query.q || "").trim();
    const like = `%${q}%`;
    const students = q
      ? db
          .prepare(
            `SELECT u.id, u.full_name, u.phone, u.email, sp.roll_number, sp.class_level, sp.parent_phone, sp.batch_id,
                    b.name AS batch_name,
                    COALESCE((SELECT SUM(MAX(0, fr.total_amount - fr.discount_amount - fr.paid_amount))
                              FROM fee_records fr WHERE fr.student_id = u.id AND fr.status IN ('pending','partial','overdue')), 0) AS pending_fee,
                    (SELECT p.id FROM payments p WHERE p.student_id = u.id AND p.verification_status = 'verified' ORDER BY p.id DESC LIMIT 1) AS last_payment_id
             FROM users u
             LEFT JOIN student_profiles sp ON sp.user_id = u.id
             LEFT JOIN batches b ON b.id = sp.batch_id
             WHERE u.role = 'student' AND (
               u.full_name LIKE ? OR u.phone LIKE ? OR COALESCE(sp.roll_number, '') LIKE ? OR COALESCE(b.name, '') LIKE ?
             )
             ORDER BY u.id DESC LIMIT 12`
          )
          .all(like, like, like, like)
      : db
          .prepare(
            `SELECT u.id, u.full_name, u.phone, u.email, sp.roll_number, sp.class_level, sp.parent_phone, sp.batch_id,
                    b.name AS batch_name,
                    COALESCE((SELECT SUM(MAX(0, fr.total_amount - fr.discount_amount - fr.paid_amount))
                              FROM fee_records fr WHERE fr.student_id = u.id AND fr.status IN ('pending','partial','overdue')), 0) AS pending_fee,
                    (SELECT p.id FROM payments p WHERE p.student_id = u.id AND p.verification_status = 'verified' ORDER BY p.id DESC LIMIT 1) AS last_payment_id
             FROM users u
             LEFT JOIN student_profiles sp ON sp.user_id = u.id
             LEFT JOIN batches b ON b.id = sp.batch_id
             WHERE u.role = 'student'
             ORDER BY u.id DESC LIMIT 8`
          )
          .all();

    const batches = db
      .prepare(`SELECT id, name, code, delivery_mode, seat_limit FROM batches WHERE is_active = 1 AND (? = '' OR name LIKE ? OR code LIKE ?) ORDER BY id DESC LIMIT 10`)
      .all(q, like, like);

    const enriched = students.map((s) => {
      const targetPhone = s.parent_phone || s.phone;
      const feeMsg = renderStandardMessage("fee_reminder", { studentName: s.full_name, amount: s.pending_fee || 0 });
      return {
        ...s,
        whatsappFeeUrl: buildWhatsAppClickToChatUrl(targetPhone, feeMsg)
      };
    });

    res.json({ query: q, students: enriched, batches });
  });

  // Quick Command Bar Actions: Quick Present/Absent & Quick Batch Change
  router.post("/crm/quick-attendance", guard, (req, res) => {
    const studentId = Number(req.body?.studentId || 0);
    const status = ["present", "absent", "late"].includes(req.body?.status) ? req.body.status : "present";
    const attDate = String(req.body?.date || getIstDateParts().dateStr);
    const stu = getStudentFullRecord(db, studentId);
    if (!stu) {
      res.status(404).json({ error: "Student not found." });
      return;
    }
    const enr = db.prepare(`SELECT course_id, batch_id FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1`).get(studentId);
    const courseId = Number(req.body?.courseId || enr?.course_id || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);
    const now = nowIso();
    db.prepare(
      `INSERT INTO attendance (course_id, batch_id, student_id, teacher_id, att_date, status, remarks, marked_via, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'Quick Desk', 'admin_quick', ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = excluded.status, marked_via = 'admin_quick'`
    ).run(courseId, stu.batch_id || enr?.batch_id || null, studentId, req.adminCtx.user.id, attDate, status, now);

    let waAbsentUrl = "";
    if (status === "absent") {
      const msg = renderStandardMessage("absence_alert", { studentName: stu.full_name, batchName: stu.batch_name, date: attDate });
      waAbsentUrl = buildWhatsAppClickToChatUrl(stu.parent_phone || stu.phone, msg);
      emitSystemEvent(
        db,
        "attendance.absent",
        {
          studentId,
          studentName: stu.full_name,
          phone: stu.parent_phone || stu.phone,
          email: stu.email,
          batchName: stu.batch_name,
          date: attDate,
          template: "absence_alert"
        },
        { idempotencyKey: `absent:${studentId}:${attDate}`, entityType: "student", entityId: String(studentId) }
      );
    }
    res.json({ ok: true, studentId, status, attDate, waAbsentUrl });
  });

  router.post("/crm/quick-batch-change", guard, (req, res) => {
    const studentId = Number(req.body?.studentId || 0);
    const batchId = Number(req.body?.batchId || 0);
    const batch = db.prepare("SELECT id, name, course_id FROM batches WHERE id = ?").get(batchId);
    if (!batch) {
      res.status(404).json({ error: "Target batch not found." });
      return;
    }
    db.prepare("UPDATE student_profiles SET batch_id = ? WHERE user_id = ?").run(batchId, studentId);
    db.prepare("UPDATE enrollments SET batch_id = ? WHERE student_id = ?").run(batchId, studentId);
    writeAuditLog(db, req.adminCtx.user, "crm_batch_changed", studentId, batch.name, `Moved student to batch ${batch.name}`, clientIp(req));
    res.json({ ok: true, studentId, batchId, batchName: batch.name });
  });

  // 3. Quick Fee Collection Desk (Cash / UPI / Cheque / Online + Idempotency + Receipt + WhatsApp)
  router.get("/crm/fee-desk/lookup", guard, (req, res) => {
    const q = String(req.query.q || "").trim();
    if (!q) {
      res.json({ matches: [] });
      return;
    }
    const like = `%${q}%`;
    const matches = db
      .prepare(
        `SELECT u.id, u.full_name, u.phone, u.email, sp.roll_number, sp.class_level, sp.parent_name, sp.parent_phone, sp.batch_id, b.name AS batch_name
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN batches b ON b.id = sp.batch_id
         WHERE u.role = 'student' AND (u.phone LIKE ? OR COALESCE(sp.roll_number,'') LIKE ? OR u.full_name LIKE ?)
         ORDER BY u.id DESC LIMIT 10`
      )
      .all(like, like, like)
      .map((s) => {
        const feeRecords = db
          .prepare(
            `SELECT id, course_id, title, total_amount, discount_amount, paid_amount, due_date, status, billing_month
             FROM fee_records WHERE student_id = ? ORDER BY id DESC LIMIT 12`
          )
          .all(s.id);
        const outstanding = feeRecords.reduce(
          (acc, f) => acc + Math.max(0, Number(f.total_amount || 0) - Number(f.discount_amount || 0) - Number(f.paid_amount || 0)),
          0
        );
        const recentPayments = db
          .prepare(`SELECT id, amount, payment_method, receipt_number, utr_reference, paid_at, created_at FROM payments WHERE student_id = ? AND verification_status = 'verified' ORDER BY id DESC LIMIT 5`)
          .all(s.id);
        const reminderUrl = buildWhatsAppClickToChatUrl(
          s.parent_phone || s.phone,
          renderStandardMessage("fee_reminder", { studentName: s.full_name, amount: outstanding })
        );
        return { ...s, feeRecords, outstanding, recentPayments, whatsappReminderUrl: reminderUrl };
      });

    res.json({ matches });
  });

  router.post("/crm/fee-desk/collect", guard, (req, res) => {
    const studentId = Number(req.body?.studentId || 0);
    const amount = Math.round(Number(req.body?.amount || 0));
    const rawMethod = String(req.body?.paymentMethod || "cash").toLowerCase();
    const mappedMethod = rawMethod === "cash" ? "cash" : rawMethod === "online" || rawMethod === "gateway" ? "gateway" : "upi";
    const utrRef = String(req.body?.utrReference || "").trim().slice(0, 80);
    const feeRecordId = Number(req.body?.feeRecordId || 0) || null;
    const notes = String(req.body?.notes || (rawMethod === "cheque" ? "Cheque payment" : "")).trim().slice(0, 200);
    const idempotencyKey = String(req.body?.idempotencyKey || "").trim().slice(0, 120);

    if (!studentId || amount <= 0) {
      res.status(400).json({ error: "Valid student and positive payment amount are required." });
      return;
    }
    if (mappedMethod === "gateway" && !utrRef) {
      res.status(400).json({ error: "Verified gateway payment reference is required before confirming online payment." });
      return;
    }

    const stu = getStudentFullRecord(db, studentId);
    if (!stu) {
      res.status(404).json({ error: "Student not found." });
      return;
    }

    if (idempotencyKey) {
      const dup = db.prepare(`SELECT id, receipt_number, amount FROM payments WHERE idempotency_key = ?`).get(idempotencyKey);
      if (dup) {
        res.status(409).json({
          error: "Duplicate payment prevented by idempotency check.",
          duplicate: true,
          paymentId: dup.id,
          receiptNumber: dup.receipt_number
        });
        return;
      }
    }

    const now = nowIso();
    const receiptNumber = `YSC-${getIstDateParts().dateStr.replace(/-/g, "")}-${crypto.randomInt(1000, 9999)}`;
    const invoiceNumber = `INV-${receiptNumber}`;

    const out = runInImmediateTx(db, () => {
      let targetFee = feeRecordId
        ? db.prepare(`SELECT * FROM fee_records WHERE id = ? AND student_id = ?`).get(feeRecordId, studentId)
        : db
            .prepare(
              `SELECT * FROM fee_records WHERE student_id = ? AND status IN ('pending','partial','overdue') ORDER BY id ASC LIMIT 1`
            )
            .get(studentId);

      const enr = db.prepare(`SELECT id, course_id FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1`).get(studentId);
      const courseId = Number(targetFee?.course_id || enr?.course_id || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);

      const payRes = db
        .prepare(
          `INSERT INTO payments (
            student_id, course_id, enrollment_id, plan, base_amount, discount_amount, amount,
            payment_method, utr_reference, verification_status, invoice_number, receipt_number,
            paid_at, created_at, idempotency_key, collected_by, notes
          ) VALUES (?, ?, ?, 'monthly', ?, 0, ?, ?, ?, 'verified', ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          studentId,
          courseId,
          enr?.id || null,
          amount,
          amount,
          mappedMethod,
          utrRef || (rawMethod === "cheque" ? "CHEQUE" : ""),
          invoiceNumber,
          receiptNumber,
          now,
          now,
          idempotencyKey || `desk:${studentId}:${receiptNumber}`,
          req.adminCtx.user.id,
          notes
        );
      const paymentId = Number(payRes.lastInsertRowid);

      if (targetFee) {
        const newPaid = Number(targetFee.paid_amount || 0) + amount;
        const netDue = Math.max(0, Number(targetFee.total_amount || 0) - Number(targetFee.discount_amount || 0));
        const nextStatus = newPaid >= netDue ? "paid" : "partial";
        db.prepare(`UPDATE fee_records SET paid_amount = ?, status = ? WHERE id = ?`).run(newPaid, nextStatus, targetFee.id);
        db.prepare(`UPDATE fee_installments SET paid_amount = MIN(amount, paid_amount + ?), payment_id = ?, status = CASE WHEN paid_amount + ? >= amount THEN 'paid' ELSE status END WHERE fee_record_id = ?`).run(
          amount,
          paymentId,
          amount,
          targetFee.id
        );
      } else {
        db.prepare(
          `INSERT INTO fee_records (student_id, course_id, branch_id, title, total_amount, discount_amount, paid_amount, due_date, status, created_at)
           VALUES (?, ?, ?, 'Counter Fee Collection', ?, 0, ?, ?, 'paid', ?)`
        ).run(studentId, courseId, stu.branch_id || null, amount, amount, getIstDateParts().dateStr, now);
      }

      const remaining = Number(
        db
          .prepare(
            `SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) AS bal
             FROM fee_records WHERE student_id = ? AND status IN ('pending','partial','overdue')`
          )
          .get(studentId)?.bal || 0
      );
      return { paymentId, remaining };
    });

    const msg = renderStandardMessage("payment_receipt", { studentName: stu.full_name, amount, receiptNo: receiptNumber });
    const whatsappReceiptUrl = buildWhatsAppClickToChatUrl(stu.parent_phone || stu.phone, msg);

    emitSystemEvent(
      db,
      "payment.received",
      {
        studentId,
        studentName: stu.full_name,
        phone: stu.parent_phone || stu.phone,
        email: stu.email,
        amount,
        receiptNo: receiptNumber,
        template: "payment_receipt"
      },
      { idempotencyKey: `pay_rcpt:${out.paymentId}`, entityType: "payment", entityId: String(out.paymentId) }
    );
    writeAuditLog(db, req.adminCtx.user, "crm_fee_collected", studentId, stu.full_name, `Collected ₹${amount} via ${rawMethod} (${receiptNumber})`, clientIp(req));

    res.status(201).json({
      ok: true,
      paymentId: out.paymentId,
      receiptNumber,
      amount,
      outstandingBalance: out.remaining,
      whatsappReceiptUrl
    });
  });

  router.post("/crm/fee-desk/generate-monthly", guard, (req, res) => {
    const billingMonth = String(req.body?.billingMonth || getIstDateParts().monthStr);
    const dueDay = Number(req.body?.dueDay || getAutomationConfig(db).monthly_fee_due_day || 10);
    const batchId = req.body?.batchId ? Number(req.body.batchId) : null;
    const studentIds = Array.isArray(req.body?.studentIds) ? req.body.studentIds : null;
    const summary = generateMonthlyFeeInvoices(db, { billingMonth, dueDay, batchId, studentIds });
    writeAuditLog(db, req.adminCtx.user, "crm_monthly_fees_generated", null, billingMonth, `Created ${summary.created}, skipped ${summary.skipped}`, clientIp(req));
    res.json({ ok: true, ...summary });
  });

  // Financial Approval Controls (Discount / Waiver / Refund / Adjustment)
  router.get("/crm/financial-approvals", guard, (_req, res) => {
    const rows = db
      .prepare(
        `SELECT fa.*, u.full_name AS student_name, u.phone AS student_phone, rq.full_name AS requested_by_name
         FROM crm_financial_approvals fa
         LEFT JOIN users u ON u.id = fa.student_id
         LEFT JOIN users rq ON rq.id = fa.requested_by
         ORDER BY fa.created_at DESC LIMIT 100`
      )
      .all();
    res.json({ approvals: rows });
  });

  router.post("/crm/financial-approvals", guard, (req, res) => {
    const requestType = ["discount", "waiver", "refund", "fee_adjustment"].includes(req.body?.requestType)
      ? req.body.requestType
      : "discount";
    const studentId = Number(req.body?.studentId || 0);
    const amount = Math.max(1, Math.round(Number(req.body?.amount || 0)));
    const reason = String(req.body?.reason || "").trim();
    if (!studentId || !reason) {
      res.status(400).json({ error: "Student and reason are required." });
      return;
    }
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO crm_financial_approvals (request_type, student_id, fee_record_id, payment_id, amount, reason, requested_by, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)`
      )
      .run(requestType, studentId, req.body?.feeRecordId || null, req.body?.paymentId || null, amount, reason, req.adminCtx.user.id, now);
    const id = Number(ins.lastInsertRowid);
    createExceptionItem(db, {
      category: "fee_adjustment",
      severity: "high",
      title: `Financial Approval Needed: ${requestType.toUpperCase()} ₹${amount}`,
      summary: reason,
      entityType: "crm_financial_approvals",
      entityId: String(id),
      escalationLevel: "owner"
    });
    res.status(201).json({ ok: true, id });
  });

  router.post("/crm/financial-approvals/:id/decide", guard, (req, res) => {
    const id = Number(req.params.id);
    const decision = req.body?.decision === "approved" ? "approved" : "rejected";
    const note = String(req.body?.note || "").trim();
    const row = db.prepare(`SELECT * FROM crm_financial_approvals WHERE id = ?`).get(id);
    if (!row) {
      res.status(404).json({ error: "Approval request not found." });
      return;
    }
    const now = nowIso();
    runInImmediateTx(db, () => {
      db.prepare(`UPDATE crm_financial_approvals SET status = ?, reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ?`).run(
        decision,
        req.adminCtx.user.id,
        note,
        now,
        id
      );
      if (decision === "approved" && row.fee_record_id && ["discount", "waiver", "fee_adjustment"].includes(row.request_type)) {
        db.prepare(`UPDATE fee_records SET discount_amount = discount_amount + ? WHERE id = ?`).run(row.amount, row.fee_record_id);
      }
      db.prepare(`UPDATE crm_exception_inbox SET status = ?, resolved_by = ?, resolution_note = ?, updated_at = ? WHERE entity_type = 'crm_financial_approvals' AND entity_id = ?`).run(
        decision === "approved" ? "approved" : "resolved",
        req.adminCtx.user.id,
        note,
        now,
        String(id)
      );
    });
    writeAuditLog(db, req.adminCtx.user, `crm_financial_${decision}`, row.student_id, `Request #${id}`, `${row.request_type} ₹${row.amount} ${decision}: ${note}`, clientIp(req));
    res.json({ ok: true, id, decision });
  });

  // 4. Inquiry & Admission CRM Pipeline + 1-Click Convert to Student
  router.get("/crm/leads", guard, (req, res) => {
    const filter = String(req.query.filter || "all");
    const today = getIstDateParts().dateStr;
    let where = "1=1";
    const params = [];
    if (filter === "today_followups") {
      where = "status NOT IN ('admitted','closed','cold') AND follow_up_date != '' AND follow_up_date <= ?";
      params.push(today);
    } else if (filter === "demo") {
      where = "demo_date != '' AND status NOT IN ('admitted','closed')";
    } else if (filter === "hot") {
      where = "lead_score >= 70 AND status NOT IN ('admitted','closed')";
    }
    const leads = db
      .prepare(`SELECT * FROM inquiries WHERE ${where} ORDER BY lead_score DESC, id DESC LIMIT 150`)
      .all(...params)
      .map((l) => ({
        ...l,
        whatsappUrl: buildWhatsAppClickToChatUrl(
          l.phone,
          renderStandardMessage("lead_welcome", { name: l.name, courseTitle: l.class_or_course || "Coaching" })
        )
      }));
    const tasks = db
      .prepare(`SELECT * FROM crm_counsellor_tasks WHERE status IN ('open','in_progress') ORDER BY due_date ASC, id DESC LIMIT 50`)
      .all();
    res.json({ leads, tasks, today });
  });

  router.post("/crm/leads", guard, (req, res) => {
    const name = String(req.body?.name || "").trim();
    const phone = normalizeIndianPhone(req.body?.phone || "");
    const email = String(req.body?.email || "").trim().toLowerCase();
    const classOrCourse = String(req.body?.classOrCourse || req.body?.course || "Class 10").trim();
    const source = String(req.body?.source || "walk_in").trim();
    const message = String(req.body?.message || "").trim();
    const demoDate = String(req.body?.demoDate || "").trim();
    const demoSlot = String(req.body?.demoTimeSlot || "").trim();
    const followUpDate = String(req.body?.followUpDate || getIstDateParts().dateStr).trim();
    const assignedStaff = String(req.body?.assignedStaff || "").trim();

    if (!name || phone.length < 10) {
      res.status(400).json({ error: "Name and valid 10-digit phone number are required." });
      return;
    }
    const existing = db.prepare(`SELECT id, name, status FROM inquiries WHERE phone LIKE ? ORDER BY id DESC LIMIT 1`).get(`%${phone}`);
    if (existing) {
      res.status(409).json({ error: `Duplicate lead detected for phone ${phone} (Inquiry #${existing.id} - ${existing.name}).`, duplicate: true, existing });
      return;
    }

    const score = computeLeadScore({ phone, email, source, class_or_course: classOrCourse, demo_date: demoDate, message });
    const priority = score >= 75 ? "high" : score >= 50 ? "medium" : "low";
    const now = nowIso();
    const slaDue = new Date(Date.now() + 15 * 60000).toISOString();

    const ins = db
      .prepare(
        `INSERT INTO inquiries (
          name, phone, email, class_or_course, message, source, status, follow_up_date,
          assigned_staff, demo_date, demo_time_slot, lead_score, priority,
          utm_source, utm_medium, utm_campaign, sla_due_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        name,
        phone,
        email,
        classOrCourse,
        message,
        source,
        followUpDate,
        assignedStaff,
        demoDate,
        demoSlot,
        score,
        priority,
        String(req.body?.utmSource || source),
        String(req.body?.utmMedium || ""),
        String(req.body?.utmCampaign || ""),
        slaDue,
        now
      );
    const id = Number(ins.lastInsertRowid);
    db.prepare(
      `INSERT INTO crm_lead_activities (inquiry_id, actor_id, actor_name, activity_type, summary, next_followup_at, created_at)
       VALUES (?, ?, ?, 'created', ?, ?, ?)`
    ).run(id, req.adminCtx.user.id, req.adminCtx.user.full_name, `Lead created (Score ${score}/100, Source: ${source})`, followUpDate, now);

    emitSystemEvent(db, "lead.created", { inquiryId: id, name, phone, email, courseTitle: classOrCourse, leadScore: score }, { idempotencyKey: `lead_new:${id}`, entityType: "inquiry", entityId: String(id) });
    res.status(201).json({ ok: true, id, leadScore: score, priority });
  });

  router.patch("/crm/leads/:id", guard, (req, res) => {
    const id = Number(req.params.id);
    const cur = db.prepare(`SELECT * FROM inquiries WHERE id = ?`).get(id);
    if (!cur) {
      res.status(404).json({ error: "Inquiry not found." });
      return;
    }
    const nextStatus = String(req.body?.status || cur.status);
    const followUpDate = req.body?.followUpDate !== undefined ? String(req.body.followUpDate) : cur.follow_up_date;
    const followUpNotes = req.body?.followUpNotes !== undefined ? String(req.body.followUpNotes) : cur.follow_up_notes;
    const assignedStaff = req.body?.assignedStaff !== undefined ? String(req.body.assignedStaff) : cur.assigned_staff;
    const demoDate = req.body?.demoDate !== undefined ? String(req.body.demoDate) : cur.demo_date;
    const demoSlot = req.body?.demoTimeSlot !== undefined ? String(req.body.demoTimeSlot) : cur.demo_time_slot;
    const score = computeLeadScore({ ...cur, demo_date: demoDate });
    const now = nowIso();

    db.prepare(
      `UPDATE inquiries SET status = ?, follow_up_date = ?, follow_up_notes = ?, assigned_staff = ?,
       demo_date = ?, demo_time_slot = ?, lead_score = ?, last_contacted_at = ? WHERE id = ?`
    ).run(nextStatus, followUpDate, followUpNotes, assignedStaff, demoDate, demoSlot, score, now, id);

    if (req.body?.activityNote || req.body?.followUpNotes) {
      db.prepare(
        `INSERT INTO crm_lead_activities (inquiry_id, actor_id, actor_name, activity_type, summary, next_followup_at, created_at)
         VALUES (?, ?, ?, 'followup', ?, ?, ?)`
      ).run(id, req.adminCtx.user.id, req.adminCtx.user.full_name, String(req.body?.activityNote || followUpNotes || `Status -> ${nextStatus}`), followUpDate, now);
    }
    res.json({ ok: true, id, leadScore: score });
  });

  // 1-Click Convert Inquiry -> Student Admission (Reuses existing info, checks seat limit/waitlist, creates ID card roll & checklist)
  router.post("/crm/leads/:id/convert", guard, (req, res) => {
    const id = Number(req.params.id);
    const lead = db.prepare(`SELECT * FROM inquiries WHERE id = ?`).get(id);
    if (!lead) {
      res.status(404).json({ error: "Inquiry not found." });
      return;
    }
    if (lead.converted_student_id) {
      res.json({ ok: true, alreadyConverted: true, studentId: lead.converted_student_id });
      return;
    }

    const courseId = Number(req.body?.courseId || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);
    const batchId = req.body?.batchId ? Number(req.body.batchId) : db.prepare("SELECT id FROM batches WHERE is_active = 1 ORDER BY id ASC LIMIT 1").get()?.id || null;
    const phone = normalizeIndianPhone(lead.phone || req.body?.phone || "");
    const email = (lead.email || `stu.${phone || id}.${Date.now().toString(36)}@yuitor.local`).toLowerCase();
    const tempPassword = String(req.body?.password || `Ysc@${(phone || "1234").slice(-4)}99`);
    const now = nowIso();

    // Check batch capacity -> waitlist if full
    let waitlisted = false;
    if (batchId) {
      const b = db.prepare("SELECT id, seat_limit, waitlist_enabled FROM batches WHERE id = ?").get(batchId);
      const enrolledCount = Number(db.prepare("SELECT COUNT(*) AS c FROM student_profiles WHERE batch_id = ?").get(batchId)?.c || 0);
      if (b && enrolledCount >= Number(b.seat_limit || 40)) {
        waitlisted = true;
      }
    }

    const out = runInImmediateTx(db, () => {
      const existingUser = db.prepare(`SELECT id FROM users WHERE email = ? OR (phone = ? AND role = 'student') LIMIT 1`).get(email, phone);
      let studentId = existingUser?.id || null;
      const rollNumber = `YSC${new Date().getFullYear().toString().slice(-2)}${String(crypto.randomInt(1000, 9999))}`;

      if (!studentId) {
        const hash = bcrypt.hashSync(tempPassword, 10);
        const uRes = db
          .prepare(
            `INSERT INTO users (
              role, branch_id, full_name, email, phone, password_hash, mobile_verified,
              verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at
            ) VALUES ('student', ?, ?, ?, ?, ?, 1, 'approved', 1, 1, ?, ?, ?)`
          )
          .run(lead.branch_id || null, lead.name, email, phone, hash, crypto.randomBytes(16).toString("hex"), now, now);
        studentId = Number(uRes.lastInsertRowid);
        db.prepare(
          `INSERT INTO student_profiles (user_id, roll_number, class_level, board, admission_date, enrollment_status, parent_name, parent_phone, batch_id, branch_id)
           VALUES (?, ?, ?, 'CBSE', ?, 'active', ?, ?, ?, ?)`
        ).run(
          studentId,
          rollNumber,
          lead.class_or_course || "Class 10",
          getIstDateParts().dateStr,
          String(req.body?.parentName || ""),
          String(req.body?.parentPhone || phone),
          waitlisted ? null : batchId,
          lead.branch_id || null
        );
      }

      db.prepare(
        `INSERT OR IGNORE INTO enrollments (student_id, course_id, batch_id, plan, status, enrolled_at)
         VALUES (?, ?, ?, 'monthly', 'active', ?)`
      ).run(studentId, courseId, waitlisted ? null : batchId, now);

      db.prepare(`INSERT OR IGNORE INTO crm_document_checklists (student_id, updated_at) VALUES (?, ?)`).run(studentId, now);

      if (waitlisted && batchId) {
        db.prepare(
          `INSERT INTO crm_batch_waitlist (batch_id, inquiry_id, student_id, student_name, phone, status, created_at)
           VALUES (?, ?, ?, ?, ?, 'waiting', ?)`
        ).run(batchId, id, studentId, lead.name, phone, now);
      }

      db.prepare(`UPDATE inquiries SET status = 'admitted', converted_student_id = ?, last_contacted_at = ? WHERE id = ?`).run(studentId, now, id);
      db.prepare(
        `INSERT INTO crm_lead_activities (inquiry_id, actor_id, actor_name, activity_type, summary, created_at)
         VALUES (?, ?, ?, 'converted', ?, ?)`
      ).run(id, req.adminCtx.user.id, req.adminCtx.user.full_name, `Converted to Student #${studentId} (${rollNumber})${waitlisted ? " [Waitlisted - Batch Full]" : ""}`, now);

      return { studentId, rollNumber, email, tempPassword, waitlisted };
    });

    emitSystemEvent(
      db,
      "admission.completed",
      { studentId: out.studentId, studentName: lead.name, phone, email: out.email, rollNumber: out.rollNumber },
      { idempotencyKey: `admit:${out.studentId}`, entityType: "student", entityId: String(out.studentId) }
    );
    const cfgWelcome = getAutomationConfig(db);
    if (Number(cfgWelcome?.welcome_emails_enabled ?? 1) === 1) {
      void sendRoleWelcomeKit(db, deps.sendTransactionalEmail || null, {
        userId: out.studentId,
        actorId: req.adminCtx.user.id
      }).catch(() => {});
    }
    writeAuditLog(db, req.adminCtx.user, "crm_lead_converted", out.studentId, lead.name, `Converted Inquiry #${id} -> Roll ${out.rollNumber}`, clientIp(req));

    res.status(201).json({ ok: true, ...out });
  });

  // 5. Smart Batch Attendance + Auto-Absent Detection + 1-Click Teacher WhatsApp List + QR ID Scan
  router.post("/crm/attendance/batch-submit", guard, (req, res) => {
    const courseId = Number(req.body?.courseId || 0);
    const batchId = req.body?.batchId ? Number(req.body.batchId) : null;
    const attDate = String(req.body?.date || getIstDateParts().dateStr);
    const entries = Array.isArray(req.body?.entries) ? req.body.entries : [];
    if (!courseId || !entries.length) {
      res.status(400).json({ error: "Course and attendance entries are required." });
      return;
    }

    const cfg = getAutomationConfig(db);
    const threshold = Number(cfg.low_attendance_threshold || 75);
    const now = nowIso();
    const absentees = [];
    const lowAttendanceAlerts = [];
    const batch = batchId ? db.prepare("SELECT name FROM batches WHERE id = ?").get(batchId) : null;

    runInImmediateTx(db, () => {
      const stmt = db.prepare(
        `INSERT INTO attendance (course_id, batch_id, student_id, teacher_id, att_date, status, remarks, marked_via, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'batch_crm', ?)
         ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = excluded.status, remarks = excluded.remarks`
      );
      for (const e of entries) {
        const sid = Number(e.studentId || 0);
        const st = ["present", "absent", "late"].includes(e.status) ? e.status : "present";
        if (!sid) continue;
        stmt.run(courseId, batchId, sid, req.adminCtx.user.id, attDate, st, String(e.remarks || ""), now);
      }
    });

    for (const e of entries) {
      const sid = Number(e.studentId || 0);
      const stu = getStudentFullRecord(db, sid);
      if (!stu) continue;
      const att = db
        .prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END) AS p FROM attendance WHERE student_id = ?`)
        .get(sid);
      const pct = Number(att?.total || 0) > 0 ? Math.round((Number(att.p || 0) / Number(att.total)) * 100) : 100;

      if (e.status === "absent") {
        const msg = renderStandardMessage("absence_alert", { studentName: stu.full_name, batchName: batch?.name || stu.batch_name, date: attDate });
        const waUrl = buildWhatsAppClickToChatUrl(stu.parent_phone || stu.phone, msg);
        absentees.push({
          studentId: sid,
          studentName: stu.full_name,
          rollNumber: stu.roll_number || `YSC-${sid}`,
          parentPhone: stu.parent_phone || stu.phone,
          attendancePercent: pct,
          whatsappUrl: waUrl
        });
        emitSystemEvent(
          db,
          "attendance.absent",
          {
            studentId: sid,
            studentName: stu.full_name,
            phone: stu.parent_phone || stu.phone,
            email: stu.email,
            batchName: batch?.name || stu.batch_name,
            date: attDate,
            template: "absence_alert"
          },
          { idempotencyKey: `absent:${sid}:${attDate}`, entityType: "student", entityId: String(sid) }
        );
      }
      if (pct < threshold && Number(att?.total || 0) >= 3) {
        lowAttendanceAlerts.push({ studentId: sid, studentName: stu.full_name, attendancePercent: pct });
        emitSystemEvent(
          db,
          "attendance.submitted",
          {
            studentId: sid,
            studentName: stu.full_name,
            phone: stu.parent_phone || stu.phone,
            email: stu.email,
            attendancePercent: pct,
            threshold,
            belowThreshold: true,
            template: "low_attendance_warning"
          },
          { idempotencyKey: `low_att:${sid}:${attDate}`, entityType: "student", entityId: String(sid) }
        );
      }
    }

    res.json({ ok: true, attDate, totalMarked: entries.length, absentCount: absentees.length, absentees, lowAttendanceAlerts });
  });

  // Scan Student ID Card QR Code to Mark Attendance Instantly
  router.post("/crm/attendance/qr-scan", guard, (req, res) => {
    const code = String(req.body?.qrCode || "").trim();
    const attDate = String(req.body?.date || getIstDateParts().dateStr);
    const match = code.match(/YUITOR:STU:(\d+)/i);
    let student = match ? getStudentFullRecord(db, Number(match[1])) : null;
    if (!student && code) {
      const row = db.prepare(`SELECT user_id FROM student_profiles WHERE UPPER(roll_number) = UPPER(?) LIMIT 1`).get(code);
      if (row) student = getStudentFullRecord(db, row.user_id);
    }
    if (!student) {
      res.status(404).json({ error: "No student matched this ID Card QR / Roll Number." });
      return;
    }
    const enr = db.prepare(`SELECT course_id FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1`).get(student.id);
    const courseId = Number(req.body?.courseId || enr?.course_id || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);
    db.prepare(
      `INSERT INTO attendance (course_id, batch_id, student_id, teacher_id, att_date, status, remarks, marked_via, created_at)
       VALUES (?, ?, ?, ?, ?, 'present', 'QR ID Card Scan', 'id_qr_scan', ?)
       ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = 'present', marked_via = 'id_qr_scan'`
    ).run(courseId, student.batch_id || null, student.id, req.adminCtx.user.id, attDate, nowIso());
    res.json({ ok: true, student, attDate, status: "present" });
  });

  // 6. Printable Branded PDFs (ID Card with QR, Fee Receipt, Admit Card, Monthly Progress Report)
  router.get("/crm/pdf/id-card/:studentId", guard, (req, res) => {
    const stu = getStudentFullRecord(db, req.params.studentId);
    if (!stu) {
      res.status(404).json({ error: "Student not found." });
      return;
    }
    const qrPayload = `YUITOR:STU:${stu.id}:${stu.roll_number || `YSC-${stu.id}`}`;
    if (req.query.format === "pdf") {
      const buf = buildSimplePdfBuffer({
        title: "OFFICIAL STUDENT IDENTITY CARD",
        subtitle: `QR Verification Token: ${qrPayload}`,
        rows: [
          { section: "STUDENT DETAILS" },
          { label: "Full Name", value: stu.full_name },
          { label: "Roll Number", value: stu.roll_number || `YSC-${stu.id}` },
          { label: "Class / Board", value: `${stu.class_level || "Class 10"} / ${stu.board || "CBSE"}` },
          { label: "Batch", value: stu.batch_name || "Assigned Batch" },
          { label: "Mobile Number", value: stu.phone || "-" },
          { label: "Parent / Guardian", value: `${stu.parent_name || "-"} (${stu.parent_phone || "-"})` },
          { label: "QR Scan Token", value: qrPayload }
        ]
      });
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="yuitor-id-card-${stu.id}.pdf"`);
      res.send(buf);
      return;
    }
    res.type("html").send(renderStudentIdCardHtml(stu, { qrPayload, pdfDownloadUrl: `${req.baseUrl}${req.path}?format=pdf` }));
  });

  router.get("/crm/pdf/receipt/:paymentId", guard, (req, res) => {
    const pay = db
      .prepare(
        `SELECT p.*, u.full_name AS student_name, u.phone, sp.roll_number, c.title AS course_title
         FROM payments p
         JOIN users u ON u.id = p.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN courses c ON c.id = p.course_id
         WHERE p.id = ?`
      )
      .get(Number(req.params.paymentId));
    if (!pay) {
      res.status(404).json({ error: "Payment receipt not found." });
      return;
    }
    const bal = Number(
      db
        .prepare(`SELECT COALESCE(SUM(MAX(0, total_amount - discount_amount - paid_amount)), 0) AS b FROM fee_records WHERE student_id = ? AND status IN ('pending','partial','overdue')`)
        .get(pay.student_id)?.b || 0
    );
    pay.outstanding_balance = bal;

    if (req.query.format === "pdf") {
      const buf = buildSimplePdfBuffer({
        title: "OFFICIAL FEE RECEIPT / INVOICE",
        subtitle: `Receipt No: ${pay.receipt_number || `RCPT-${pay.id}`} | Date: ${(pay.paid_at || pay.created_at || "").slice(0, 10)}`,
        rows: [
          { section: "STUDENT & COURSE" },
          { label: "Student Name", value: pay.student_name },
          { label: "Roll No / Phone", value: `${pay.roll_number || `YSC-${pay.student_id}`} / ${pay.phone}` },
          { label: "Course", value: pay.course_title || "Coaching Fee" },
          { section: "PAYMENT BREAKDOWN (VERIFIED)" },
          { label: "Payment Method", value: `${String(pay.payment_method || "cash").toUpperCase()} ${pay.utr_reference ? `(${pay.utr_reference})` : ""}` },
          { label: "Base Amount", value: `INR ${Number(pay.base_amount || pay.amount).toLocaleString("en-IN")}` },
          { label: "Discount", value: `INR ${Number(pay.discount_amount || 0).toLocaleString("en-IN")}` },
          { label: "Paid Amount", value: `INR ${Number(pay.amount || 0).toLocaleString("en-IN")}` },
          { label: "Outstanding Balance", value: `INR ${bal.toLocaleString("en-IN")}` }
        ]
      });
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="yuitor-receipt-${pay.id}.pdf"`);
      res.send(buf);
      return;
    }
    res.type("html").send(renderFeeReceiptHtml(pay, { pdfDownloadUrl: `${req.baseUrl}${req.path}?format=pdf` }));
  });

  router.get("/crm/pdf/admit-card/:studentId", guard, (req, res) => {
    const stu = getStudentFullRecord(db, req.params.studentId);
    if (!stu) {
      res.status(404).json({ error: "Student not found." });
      return;
    }
    const tests = db.prepare(`SELECT * FROM offline_tests ORDER BY test_date DESC LIMIT 10`).all();
    if (req.query.format === "pdf") {
      const buf = buildSimplePdfBuffer({
        title: "EXAMINATION ADMIT CARD",
        subtitle: `${stu.full_name} | Roll No: ${stu.roll_number || `YSC-${stu.id}`}`,
        rows: [
          { section: "CANDIDATE DETAILS" },
          { label: "Student Name", value: stu.full_name },
          { label: "Roll Number", value: stu.roll_number || `YSC-${stu.id}` },
          { label: "Class / Batch", value: `${stu.class_level || ""} / ${stu.batch_name || "Main Batch"}` },
          { section: "SCHEDULED EXAMS" },
          ...(tests.length
            ? tests.map((t) => ({ label: t.test_date, value: `${t.title} (${t.subject_name}) - ${t.room_name}` }))
            : [{ label: "Schedule", value: "As notified in batch timetable." }])
        ]
      });
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="yuitor-admit-card-${stu.id}.pdf"`);
      res.send(buf);
      return;
    }
    res.type("html").send(renderAdmitCardHtml(stu, tests, { pdfDownloadUrl: `${req.baseUrl}${req.path}?format=pdf` }));
  });

  router.get("/crm/pdf/report-card/:studentId", guard, (req, res) => {
    const report = getStudentProgressReportData(db, req.params.studentId);
    if (!report) {
      res.status(404).json({ error: "Student not found." });
      return;
    }
    if (req.query.format === "pdf") {
      const buf = buildSimplePdfBuffer({
        title: `MONTHLY PROGRESS REPORT CARD (${report.monthLabel})`,
        subtitle: `${report.student.full_name} | Attendance: ${report.attendancePercent}% | Rank: ${report.batchRankLabel}`,
        rows: [
          { section: "STUDENT OVERVIEW" },
          { label: "Student Name", value: report.student.full_name },
          { label: "Roll Number", value: report.student.roll_number || `YSC-${report.student.id}` },
          { label: "Attendance %", value: `${report.attendancePercent}%` },
          { label: "Batch Rank / Grade", value: `${report.batchRankLabel} (${report.performanceGrade})` },
          { section: "OFFLINE TEST PERFORMANCE" },
          ...(report.tests.length
            ? report.tests.map((t) => ({
                label: `${t.test_date} ${t.subject_name}`,
                value: t.is_absent ? "Absent" : `${t.marks_obtained}/${t.max_marks} (Rank #${t.rank_position || "-"})`
              }))
            : [{ label: "Tests", value: "No offline test marks recorded yet." }]),
          { section: "SUMMARY" },
          { label: "Remarks", value: report.summaryText }
        ]
      });
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="yuitor-report-card-${report.student.id}.pdf"`);
      res.send(buf);
      return;
    }
    res.type("html").send(renderProgressReportHtml(report, { pdfDownloadUrl: `${req.baseUrl}${req.path}?format=pdf` }));
  });

  // 7. Bulk Import (Preview + Validation + Duplicate Detection + Commit) & Accounting/ERP Exports
  router.post("/crm/bulk/import-preview", guard, (req, res) => {
    const entity = String(req.body?.entity || "students");
    const { headers, rows } = parseCsvRows(req.body?.csvText || "");
    const errors = [];
    const duplicates = [];
    const validRows = [];

    if (!rows.length) {
      res.status(400).json({ error: "CSV contains no data rows." });
      return;
    }

    if (entity === "students") {
      const existingPhones = new Set(db.prepare("SELECT phone FROM users WHERE role = 'student'").all().map((r) => normalizeIndianPhone(r.phone)));
      const existingEmails = new Set(db.prepare("SELECT LOWER(email) AS e FROM users").all().map((r) => r.e));
      const seenPhones = new Set();

      for (const r of rows) {
        const name = String(r.full_name || r.name || "").trim();
        const phone = normalizeIndianPhone(r.phone || r.mobile || "");
        const email = String(r.email || `stu.${phone}@yuitor.local`).trim().toLowerCase();
        if (!name || phone.length < 10) {
          errors.push({ row: r._rowNumber, reason: "Missing full_name or valid 10-digit phone." });
          continue;
        }
        if (existingPhones.has(phone) || existingEmails.has(email) || seenPhones.has(phone)) {
          duplicates.push({ row: r._rowNumber, name, phone, email, reason: "Duplicate phone or email" });
          continue;
        }
        seenPhones.add(phone);
        validRows.push({
          row: r._rowNumber,
          full_name: name,
          phone,
          email,
          class_level: r.class_level || r.class || "Class 10",
          board: r.board || "CBSE",
          roll_number: r.roll_number || "",
          parent_name: r.parent_name || "",
          parent_phone: normalizeIndianPhone(r.parent_phone || phone)
        });
      }
    } else if (entity === "offline_marks") {
      for (const r of rows) {
        const roll = String(r.roll_number || "").trim();
        const marks = Number(r.marks_obtained ?? r.marks);
        if (!roll || !Number.isFinite(marks)) {
          errors.push({ row: r._rowNumber, reason: "Missing roll_number or numeric marks." });
          continue;
        }
        validRows.push({ row: r._rowNumber, roll_number: roll, marks_obtained: marks, remarks: r.remarks || "" });
      }
    } else if (entity === "cbt_questions") {
      for (const r of rows) {
        const qText = String(r.question || r.prompt || "").trim();
        const opts = [r.option_a || r.a, r.option_b || r.b, r.option_c || r.c, r.option_d || r.d].filter((x) => x !== undefined && x !== "");
        const ans = String(r.correct_answer || r.answer || "").trim();
        if (!qText || opts.length < 2 || !ans) {
          errors.push({ row: r._rowNumber, reason: "Need question, at least 2 options (option_a..option_d), and correct_answer." });
          continue;
        }
        validRows.push({ row: r._rowNumber, question: qText, options: opts, correctAnswer: ans, topic: r.topic || r.chapter || "General" });
      }
    }

    res.json({ entity, headers, totalRows: rows.length, validCount: validRows.length, duplicateCount: duplicates.length, errorCount: errors.length, validRows: validRows.slice(0, 50), duplicates, errors });
  });

  router.post("/crm/bulk/import-commit", guard, (req, res) => {
    const entity = String(req.body?.entity || "students");
    const { rows } = parseCsvRows(req.body?.csvText || "");
    const now = nowIso();
    let inserted = 0;
    let skipped = 0;

    if (entity === "students") {
      const batchId = req.body?.batchId ? Number(req.body.batchId) : null;
      const courseId = req.body?.courseId ? Number(req.body.courseId) : null;
      runInImmediateTx(db, () => {
        for (const r of rows) {
          const name = String(r.full_name || r.name || "").trim();
          const phone = normalizeIndianPhone(r.phone || r.mobile || "");
          const email = String(r.email || `stu.${phone}@yuitor.local`).trim().toLowerCase();
          if (!name || phone.length < 10) {
            skipped += 1;
            continue;
          }
          const dup = db.prepare(`SELECT id FROM users WHERE email = ? OR (phone = ? AND role = 'student') LIMIT 1`).get(email, phone);
          if (dup) {
            skipped += 1;
            continue;
          }
          const hash = bcrypt.hashSync(`Ysc@${phone.slice(-4)}99`, 8);
          const uRes = db
            .prepare(
              `INSERT INTO users (role, full_name, email, phone, password_hash, mobile_verified, verification_status, is_active, marketing_opt_in, unsubscribe_token, created_at, updated_at)
               VALUES ('student', ?, ?, ?, ?, 1, 'approved', 1, 1, ?, ?, ?)`
            )
            .run(name, email, phone, hash, crypto.randomBytes(14).toString("hex"), now, now);
          const sid = Number(uRes.lastInsertRowid);
          db.prepare(
            `INSERT INTO student_profiles (user_id, roll_number, class_level, board, admission_date, enrollment_status, parent_name, parent_phone, batch_id)
             VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)`
          ).run(sid, r.roll_number || `YSC-${sid}`, r.class_level || r.class || "Class 10", r.board || "CBSE", getIstDateParts().dateStr, r.parent_name || "", normalizeIndianPhone(r.parent_phone || phone), batchId);
          if (courseId) {
            db.prepare(`INSERT OR IGNORE INTO enrollments (student_id, course_id, batch_id, plan, status, enrolled_at) VALUES (?, ?, ?, 'monthly', 'active', ?)`).run(sid, courseId, batchId, now);
          }
          inserted += 1;
        }
      });
    } else if (entity === "offline_marks") {
      const testId = Number(req.body?.testId || 0);
      if (!testId) {
        res.status(400).json({ error: "Select target offline test before committing marks." });
        return;
      }
      runInImmediateTx(db, () => {
        for (const r of rows) {
          const sp = db.prepare(`SELECT user_id FROM student_profiles WHERE UPPER(roll_number) = UPPER(?) LIMIT 1`).get(String(r.roll_number || "").trim());
          if (!sp) {
            skipped += 1;
            continue;
          }
          const marks = Number(r.marks_obtained ?? r.marks ?? 0);
          db.prepare(
            `INSERT INTO offline_test_marks (test_id, student_id, marks_obtained, is_absent, remarks, graded_by, updated_at)
             VALUES (?, ?, ?, 0, ?, ?, ?)
             ON CONFLICT(test_id, student_id) DO UPDATE SET marks_obtained = excluded.marks_obtained, remarks = excluded.remarks, updated_at = excluded.updated_at`
          ).run(testId, sp.user_id, marks, String(r.remarks || ""), req.adminCtx.user.id, now);
          inserted += 1;
        }
      });
    }

    writeAuditLog(db, req.adminCtx.user, "crm_bulk_import", null, entity, `Inserted ${inserted}, skipped ${skipped}`, clientIp(req));
    res.json({ ok: true, entity, inserted, skipped });
  });

  // Bulk Exports (CSV accounting-ready downloads)
  router.get("/crm/bulk/export/:type", guard, (req, res) => {
    const type = String(req.params.type || "collections");
    const today = getIstDateParts().dateStr;
    let rows = [];
    let filename = `yuitor-${type}-${today}.csv`;

    if (type === "fee_register") {
      rows = db
        .prepare(
          `SELECT fr.id, u.full_name AS student, sp.roll_number, u.phone, fr.title, fr.billing_month,
                  fr.total_amount, fr.discount_amount, fr.paid_amount,
                  MAX(0, fr.total_amount - fr.discount_amount - fr.paid_amount) AS balance_due,
                  fr.due_date, fr.status
           FROM fee_records fr JOIN users u ON u.id = fr.student_id LEFT JOIN student_profiles sp ON sp.user_id = u.id
           ORDER BY fr.id DESC`
        )
        .all();
    } else if (type === "defaulters") {
      rows = db
        .prepare(
          `SELECT u.id AS student_id, u.full_name AS student, sp.roll_number, u.phone, sp.parent_phone,
                  fr.title, fr.due_date, MAX(0, fr.total_amount - fr.discount_amount - fr.paid_amount) AS overdue_amount
           FROM fee_records fr JOIN users u ON u.id = fr.student_id LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE fr.status IN ('pending','partial','overdue') AND fr.due_date < ?
           ORDER BY fr.due_date ASC`
        )
        .all(today);
    } else if (type === "attendance") {
      rows = db
        .prepare(
          `SELECT a.att_date, u.full_name AS student, sp.roll_number, c.title AS course, a.status, a.marked_via, a.remarks
           FROM attendance a JOIN users u ON u.id = a.student_id LEFT JOIN student_profiles sp ON sp.user_id = u.id LEFT JOIN courses c ON c.id = a.course_id
           ORDER BY a.att_date DESC LIMIT 2000`
        )
        .all();
    } else if (type === "income_expense" || type === "accounting") {
      const inc = db
        .prepare(`SELECT substr(COALESCE(paid_at,created_at),1,10) AS txn_date, 'INCOME' AS ledger_type, receipt_number AS ref_no, payment_method, amount, 'Student Fee' AS category FROM payments WHERE verification_status = 'verified'`)
        .all();
      const exp = db
        .prepare(`SELECT expense_date AS txn_date, 'EXPENSE' AS ledger_type, CAST(id AS TEXT) AS ref_no, payment_method, -amount AS amount, category FROM expenses`)
        .all();
      rows = [...inc, ...exp].sort((a, b) => String(b.txn_date).localeCompare(String(a.txn_date)));
    } else if (type === "students") {
      rows = db
        .prepare(
          `SELECT u.id, u.full_name, sp.roll_number, u.phone, u.email, sp.class_level, sp.board, b.name AS batch_name, sp.parent_name, sp.parent_phone, u.verification_status
           FROM users u LEFT JOIN student_profiles sp ON sp.user_id = u.id LEFT JOIN batches b ON b.id = sp.batch_id
           WHERE u.role = 'student' ORDER BY u.id DESC`
        )
        .all();
    } else {
      // Today's / all collections
      const dateFilter = req.query.today === "1" ? today : "";
      rows = db
        .prepare(
          `SELECT p.id, substr(COALESCE(p.paid_at,p.created_at),1,10) AS paid_date, p.receipt_number,
                  u.full_name AS student, sp.roll_number, p.payment_method, p.utr_reference, p.amount, p.verification_status
           FROM payments p JOIN users u ON u.id = p.student_id LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE p.verification_status = 'verified' AND (? = '' OR substr(COALESCE(p.paid_at,p.created_at),1,10) = ?)
           ORDER BY p.id DESC`
        )
        .all(dateFilter, dateFilter);
    }

    writeAuditLog(db, req.adminCtx.user, "crm_data_exported", null, type, `Exported ${rows.length} rows (${filename})`, clientIp(req));
    const dataset = rows.length ? rows : [{ message: "No records found", date: today }];
    const headers = Object.keys(dataset[0]);
    const matrix = dataset.map((row) => headers.map((h) => row[h] ?? ""));
    const csv = rowsToCsv(headers, matrix);
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  });

  // Bulk Batch Actions (Promote Batch, Generate Monthly Fees, Send Batch Notice, Export Selected)
  router.post("/crm/students/bulk-action", guard, (req, res) => {
    const action = String(req.body?.action || "");
    const studentIds = Array.isArray(req.body?.studentIds) ? req.body.studentIds.map(Number).filter(Boolean) : [];
    if (!studentIds.length) {
      res.status(400).json({ error: "Select at least one student." });
      return;
    }
    const now = nowIso();
    if (action === "promote_batch") {
      const targetBatchId = Number(req.body?.targetBatchId || 0);
      if (!targetBatchId) {
        res.status(400).json({ error: "Target batch ID is required." });
        return;
      }
      runInImmediateTx(db, () => {
        for (const sid of studentIds) {
          db.prepare("UPDATE student_profiles SET batch_id = ? WHERE user_id = ?").run(targetBatchId, sid);
          db.prepare("UPDATE enrollments SET batch_id = ? WHERE student_id = ?").run(targetBatchId, sid);
        }
      });
      writeAuditLog(db, req.adminCtx.user, "crm_bulk_promote", null, `Batch #${targetBatchId}`, `Promoted ${studentIds.length} students`, clientIp(req));
      res.json({ ok: true, action, affected: studentIds.length });
      return;
    }
    if (action === "generate_monthly_fees") {
      const summary = generateMonthlyFeeInvoices(db, {
        billingMonth: String(req.body?.billingMonth || getIstDateParts().monthStr),
        dueDay: Number(req.body?.dueDay || 10),
        studentIds
      });
      res.json({ ok: true, action, ...summary });
      return;
    }
    if (action === "send_notice") {
      const title = String(req.body?.title || "Batch Announcement").trim();
      const message = String(req.body?.message || "").trim();
      if (!message) {
        res.status(400).json({ error: "Notice message is required." });
        return;
      }
      const ins = db.prepare(`INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`);
      for (const sid of studentIds) ins.run(sid, title, message, now);
      res.json({ ok: true, action, notified: studentIds.length });
      return;
    }
    res.status(400).json({ error: "Unsupported bulk action." });
  });

  // 8. Hybrid Batches, Live Class Launcher, Timetable Clash Detection & Teacher Substitution
  router.patch("/crm/batches/:id/mode", guard, (req, res) => {
    const id = Number(req.params.id);
    const mode = ["offline", "online", "hybrid"].includes(String(req.body?.deliveryMode || "").toLowerCase())
      ? String(req.body.deliveryMode).toLowerCase()
      : "hybrid";
    db.prepare(`UPDATE batches SET delivery_mode = ? WHERE id = ?`).run(mode, id);
    res.json({ ok: true, id, deliveryMode: mode });
  });

  router.get("/crm/live-classes", guard, (_req, res) => {
    const slots = db
      .prepare(
        `SELECT ts.*, COALESCE(NULLIF(ts.delivery_mode, ''), ts.mode) AS mode,
                b.name AS batch_name, COALESCE(NULLIF(ts.delivery_mode, ''), b.delivery_mode, ts.mode) AS delivery_mode,
                c.title AS course_title, u.full_name AS teacher_name, sub.full_name AS substitute_name
         FROM timetable_slots ts
         LEFT JOIN batches b ON b.id = ts.batch_id
         LEFT JOIN courses c ON c.id = ts.course_id
         LEFT JOIN users u ON u.id = ts.teacher_id
         LEFT JOIN users sub ON sub.id = ts.substitute_teacher_id
         ORDER BY ts.id DESC LIMIT 100`
      )
      .all();
    const teachers = db.prepare(`SELECT id, full_name FROM users WHERE role = 'teacher' AND is_active = 1 ORDER BY full_name ASC`).all();
    res.json({ slots, teachers });
  });

  router.post("/crm/live-classes", guard, (req, res) => {
    const deliveryMode = ["offline", "online", "hybrid"].includes(req.body?.mode) ? req.body.mode : "hybrid";
    const legacyMode = deliveryMode === "offline" ? "offline" : "online";
    const candidate = {
      id: req.body?.id ? Number(req.body.id) : null,
      branch_id: req.body?.branchId ? Number(req.body.branchId) : null,
      course_id: req.body?.courseId ? Number(req.body.courseId) : null,
      batch_id: req.body?.batchId ? Number(req.body.batchId) : null,
      teacher_id: req.body?.teacherId ? Number(req.body.teacherId) : null,
      day_of_week: String(req.body?.dayOfWeek || "Monday"),
      start_time: String(req.body?.startTime || "16:00"),
      end_time: String(req.body?.endTime || "17:00"),
      subject_name: String(req.body?.subjectName || "Mathematics"),
      room_name: String(req.body?.roomName || "Online"),
      mode: deliveryMode,
      meeting_url: String(req.body?.meetingUrl || "").trim(),
      meeting_platform: ["google_meet", "zoom", "youtube_unlisted"].includes(req.body?.meetingPlatform) ? req.body.meetingPlatform : "google_meet"
    };
    const existing = db.prepare("SELECT * FROM timetable_slots").all();
    const clash = detectTimetableClash(existing, candidate);
    if (clash.clash) {
      res.status(409).json({ error: `Timetable Clash Detected: ${clash.reason}`, clash });
      return;
    }
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO timetable_slots (branch_id, course_id, batch_id, teacher_id, day_of_week, start_time, end_time, subject_name, room_name, mode, delivery_mode, meeting_url, meeting_platform, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        candidate.branch_id,
        candidate.course_id,
        candidate.batch_id,
        candidate.teacher_id,
        candidate.day_of_week,
        candidate.start_time,
        candidate.end_time,
        candidate.subject_name,
        candidate.room_name,
        legacyMode,
        deliveryMode,
        candidate.meeting_url,
        candidate.meeting_platform,
        now
      );
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid), mode: deliveryMode });
  });

  router.patch("/crm/live-classes/:id/substitute", guard, (req, res) => {
    const id = Number(req.params.id);
    const substituteTeacherId = req.body?.substituteTeacherId ? Number(req.body.substituteTeacherId) : null;
    db.prepare(`UPDATE timetable_slots SET substitute_teacher_id = ? WHERE id = ?`).run(substituteTeacherId, id);
    writeAuditLog(db, req.adminCtx.user, "crm_substitute_assigned", substituteTeacherId, `Slot #${id}`, "Assigned substitute teacher", clientIp(req));
    res.json({ ok: true, id, substituteTeacherId });
  });

  // 9. Competitive CBT Examination Engine (Create Exam + CSV Bulk Upload + Results/Ranking)
  router.get("/crm/cbt/exams", guard, (_req, res) => {
    const exams = db
      .prepare(
        `SELECT q.*, c.title AS course_title, b.name AS batch_name,
                (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id = q.id) AS attempt_count
         FROM quizzes q
         LEFT JOIN courses c ON c.id = q.course_id
         LEFT JOIN batches b ON b.id = q.batch_id
         ORDER BY q.id DESC LIMIT 60`
      )
      .all();
    res.json({ exams });
  });

  router.post("/crm/cbt/exams", guard, (req, res) => {
    const courseId = Number(req.body?.courseId || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);
    const batchId = req.body?.batchId ? Number(req.body.batchId) : null;
    const title = String(req.body?.title || "").trim();
    if (!title) {
      res.status(400).json({ error: "Exam title is required." });
      return;
    }
    const positiveMarks = Number(req.body?.positiveMarks ?? 4);
    const negativeMarks = Number(req.body?.negativeMarks ?? 1);
    const durationMinutes = Math.max(5, Number(req.body?.durationMinutes || 30));
    const examPattern = String(req.body?.examPattern || "JEE/NEET (+4/-1)");
    const subjectName = String(req.body?.subjectName || "All Subjects");

    let questions = Array.isArray(req.body?.questions) ? req.body.questions : [];
    if (!questions.length && req.body?.questionsCsv) {
      const parsed = parseCsvRows(req.body.questionsCsv);
      questions = parsed.rows
        .filter((r) => r.question || r.prompt)
        .map((r, i) => ({
          id: i + 1,
          question: r.question || r.prompt,
          options: [r.option_a || r.a, r.option_b || r.b, r.option_c || r.c, r.option_d || r.d].filter((x) => x !== undefined && x !== ""),
          correctAnswer: String(r.correct_answer || r.answer || "").trim(),
          topic: r.topic || r.chapter || subjectName
        }));
    }
    const maxMarks = Math.max(1, questions.length * positiveMarks);
    const ins = db
      .prepare(
        `INSERT INTO quizzes (course_id, teacher_id, title, max_marks, questions_json, positive_marks, negative_marks, duration_minutes, exam_pattern, batch_id, subject_name, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        courseId,
        req.adminCtx.user.id,
        title,
        maxMarks,
        JSON.stringify(questions),
        positiveMarks,
        negativeMarks,
        durationMinutes,
        examPattern,
        batchId,
        subjectName,
        nowIso()
      );
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid), questionCount: questions.length, maxMarks });
  });

  // 10. DPP & Study Material Locker (Batch-Locked)
  router.get("/crm/materials", guard, (_req, res) => {
    const materials = db
      .prepare(
        `SELECT m.*, c.title AS course_title, b.name AS batch_name
         FROM crm_study_materials m
         LEFT JOIN courses c ON c.id = m.course_id
         LEFT JOIN batches b ON b.id = m.batch_id
         WHERE m.is_active = 1
         ORDER BY m.created_at DESC LIMIT 120`
      )
      .all();
    res.json({ materials });
  });

  router.post("/crm/materials", guard, (req, res) => {
    const courseId = Number(req.body?.courseId || db.prepare("SELECT id FROM courses ORDER BY id ASC LIMIT 1").get()?.id || 1);
    const title = String(req.body?.title || "").trim();
    if (!title) {
      res.status(400).json({ error: "Material title is required." });
      return;
    }
    const materialType = ["notes", "dpp", "pyq", "assignment", "homework", "practice_set"].includes(req.body?.materialType)
      ? req.body.materialType
      : "notes";
    const ins = db
      .prepare(
        `INSERT INTO crm_study_materials (course_id, batch_id, subject_name, chapter_name, material_type, title, description, file_url, file_name, uploaded_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        courseId,
        req.body?.batchId ? Number(req.body.batchId) : null,
        String(req.body?.subjectName || "General"),
        String(req.body?.chapterName || "Chapter 1"),
        materialType,
        title,
        String(req.body?.description || ""),
        String(req.body?.fileUrl || ""),
        String(req.body?.fileName || ""),
        req.adminCtx.user.id,
        nowIso()
      );
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  router.delete("/crm/materials/:id", guard, (req, res) => {
    db.prepare(`UPDATE crm_study_materials SET is_active = 0 WHERE id = ?`).run(Number(req.params.id));
    res.json({ ok: true });
  });

  // 11. Doubt Counter Monitor (Admin view + reply)
  router.get("/crm/doubts", guard, (_req, res) => {
    const doubts = db
      .prepare(
        `SELECT d.*, s.full_name AS student_name, t.full_name AS teacher_name
         FROM crm_doubts d
         JOIN users s ON s.id = d.student_id
         LEFT JOIN users t ON t.id = d.assigned_teacher_id
         ORDER BY d.status = 'escalated' DESC, d.status = 'open' DESC, d.created_at DESC LIMIT 100`
      )
      .all();
    res.json({ doubts });
  });

  router.post("/crm/doubts/:id/reply", guard, (req, res) => {
    const id = Number(req.params.id);
    const replyText = String(req.body?.replyText || "").trim();
    if (!replyText) {
      res.status(400).json({ error: "Reply solution text is required." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `UPDATE crm_doubts SET reply_text = ?, reply_attachment_url = ?, replied_by = ?, replied_at = ?, status = 'answered', updated_at = ? WHERE id = ?`
    ).run(replyText, String(req.body?.replyAttachmentUrl || ""), req.adminCtx.user.id, now, now, id);
    res.json({ ok: true, id });
  });

  // 12. Teacher Salary Calculator, Staff Role Templates & Teacher Exit Revocation
  router.post("/crm/payroll/generate-draft", guard, (req, res) => {
    const salaryMonth = String(req.body?.salaryMonth || getIstDateParts().monthStr);
    const summary = generateTeacherPayrollDrafts(db, salaryMonth);
    writeAuditLog(db, req.adminCtx.user, "crm_payroll_draft_generated", null, salaryMonth, `Drafted ${summary.created} payouts`, clientIp(req));
    res.json({ ok: true, ...summary });
  });

  router.get("/crm/staff-templates", guard, (_req, res) => {
    const staff = db
      .prepare(`SELECT id, full_name, email, phone, staff_role, staff_permissions_json, is_active FROM users WHERE role = 'staff' ORDER BY id DESC`)
      .all();
    res.json({ templates: Object.values(STAFF_ROLE_TEMPLATES), staff });
  });

  router.post("/crm/staff/:id/apply-template", guard, (req, res) => {
    const id = Number(req.params.id);
    const tpl = STAFF_ROLE_TEMPLATES[String(req.body?.templateKey || "")];
    if (!tpl) {
      res.status(400).json({ error: "Invalid staff role template." });
      return;
    }
    const customPerms = Array.isArray(req.body?.permissions) ? req.body.permissions : tpl.permissions;
    db.prepare(`UPDATE users SET staff_role = ?, staff_permissions_json = ?, updated_at = ? WHERE id = ? AND role = 'staff'`).run(
      tpl.label,
      JSON.stringify(customPerms),
      nowIso(),
      id
    );
    writeAuditLog(db, req.adminCtx.user, "crm_staff_template_applied", id, tpl.label, `Permissions: ${customPerms.join(",")}`, clientIp(req));
    res.json({ ok: true, id, roleLabel: tpl.label, permissions: customPerms });
  });

  router.post("/crm/teachers/:id/revoke-exit", guard, (req, res) => {
    const id = Number(req.params.id);
    try {
      const result = executeMemberExit(db, {
        userId: id,
        role: "teacher",
        exitCategory: req.body?.exitCategory || "resigned",
        exitDate: req.body?.exitDate || getIstDateParts().dateStr,
        exitReason: req.body?.exitReason || "Relieved / exit access revoked",
        duesAction: req.body?.duesAction || "salary_settled",
        settlementNote: req.body?.settlementNote || "",
        handoverTeacherId: req.body?.handoverTeacherId || null,
        actorId: req.adminCtx.user.id
      });
      writeAuditLog(db, req.adminCtx.user, "crm_teacher_exit_revoked", id, `Teacher #${id}`, `Exit #${result.exitId}`, clientIp(req));
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to process teacher exit." });
    }
  });

  // 12B. Role-Separated 1-Click Exit Settlement & Alumni/Former Rejoin (Student vs Teacher vs Staff)
  router.get("/crm/exits", guard, (req, res) => {
    const role = String(req.query.role || "student").toLowerCase();
    if (!["student", "teacher", "staff"].includes(role)) {
      res.status(400).json({ error: "role must be student, teacher, or staff." });
      return;
    }

    let activeMembers = [];
    if (role === "student") {
      activeMembers = db
        .prepare(
          `SELECT u.id, u.full_name, u.email, u.phone, sp.roll_number, sp.class_level AS academic_class,
                  (SELECT GROUP_CONCAT(b.name, ', ')
                   FROM enrollments e LEFT JOIN batches b ON b.id = e.batch_id
                   WHERE e.student_id = u.id AND e.status = 'active') AS active_batches,
                  COALESCE((SELECT SUM(MAX(0, total_amount - discount_amount - paid_amount))
                   FROM fee_records fr WHERE fr.student_id = u.id AND fr.status IN ('pending', 'partial', 'overdue')), 0) AS pending_dues
           FROM users u
           LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND u.is_active = 1
           ORDER BY u.id DESC LIMIT 200`
        )
        .all();
    } else if (role === "teacher") {
      activeMembers = db
        .prepare(
          `SELECT u.id, u.full_name, u.email, u.phone, tp.qualification, tp.subjects_json,
                  (SELECT COUNT(*) FROM timetable_slots ts WHERE ts.teacher_id = u.id) AS active_slots,
                  (SELECT COUNT(*) FROM batches b WHERE b.teacher_id = u.id AND b.is_active = 1) AS active_batches,
                  COALESCE((SELECT SUM(net_amount) FROM teacher_payouts p WHERE p.teacher_id = u.id AND p.status != 'paid'), 0) AS pending_payout
           FROM users u
           LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
           WHERE u.role = 'teacher' AND u.is_active = 1
           ORDER BY u.id DESC LIMIT 120`
        )
        .all();
    } else {
      activeMembers = db
        .prepare(
          `SELECT u.id, u.full_name, u.email, u.phone, u.staff_role, u.created_at
           FROM users u
           WHERE u.role = 'staff' AND u.is_active = 1
           ORDER BY u.id DESC LIMIT 120`
        )
        .all();
    }

    const exitedMembers = db
      .prepare(
        `SELECT ex.*, u.full_name, u.email, u.phone, u.staff_role,
                sp.roll_number, sp.class_level AS academic_class,
                ht.full_name AS handover_teacher_name
         FROM crm_member_exits ex
         JOIN users u ON u.id = ex.user_id
         LEFT JOIN student_profiles sp ON sp.user_id = ex.user_id
         LEFT JOIN users ht ON ht.id = ex.handover_teacher_id
         WHERE ex.role = ?
         ORDER BY ex.status = 'left' DESC, ex.id DESC LIMIT 150`
      )
      .all(role);

    res.json({ role, activeMembers, exitedMembers });
  });

  router.post("/crm/exits/:exitId/rejoin", guard, (req, res) => {
    const exitId = Number(req.params.exitId);
    try {
      const result = rejoinExitedMember(db, {
        exitId,
        actorId: req.adminCtx.user.id,
        rejoinNote: req.body?.rejoinNote || "Rejoined via Admin CRM",
        restoreBatch: req.body?.restoreBatch !== false
      });
      writeAuditLog(
        db,
        req.adminCtx.user,
        `crm_${result.role}_rejoin`,
        result.userId,
        `Exit #${exitId}`,
        `BatchesRestored=${result.batchesRestored || 0}`,
        clientIp(req)
      );
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to rejoin member." });
    }
  });

  router.post("/crm/exits/:role/:userId", guard, (req, res) => {
    const role = String(req.params.role || "").toLowerCase();
    const userId = Number(req.params.userId);
    try {
      const result = executeMemberExit(db, {
        userId,
        role,
        exitCategory: req.body?.exitCategory,
        exitDate: req.body?.exitDate,
        exitReason: req.body?.exitReason,
        duesAction: req.body?.duesAction,
        settlementNote: req.body?.settlementNote,
        handoverTeacherId: req.body?.handoverTeacherId ? Number(req.body.handoverTeacherId) : null,
        actorId: req.adminCtx.user.id
      });
      writeAuditLog(
        db,
        req.adminCtx.user,
        `crm_${role}_exit`,
        userId,
        result.fullName,
        `Category=${result.exitCategory}, DuesAction=${result.duesAction}, SeatsFreed=${result.seatsFreed}`,
        clientIp(req)
      );
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to process exit." });
    }
  });

  // 12C. Teacher Leave -> Auto Substitute Assignment & Batch Notification
  router.get("/crm/leaves/overview", guard, (_req, res) => {
    const leaves = db
      .prepare(
        `SELECT lr.*, u.full_name AS teacher_name, sub.full_name AS substitute_teacher_name
         FROM teacher_leave_requests lr
         JOIN users u ON u.id = lr.teacher_id
         LEFT JOIN users sub ON sub.id = lr.substitute_teacher_id
         ORDER BY CASE lr.status WHEN 'pending' THEN 1 ELSE 2 END, lr.id DESC LIMIT 60`
      )
      .all();
    const activeTeachers = db
      .prepare(
        `SELECT u.id, u.full_name, u.is_active, tp.subjects_json
         FROM users u LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.is_active = 1 ORDER BY u.full_name ASC`
      )
      .all();
    const allSlots = db.prepare(`SELECT * FROM timetable_slots`).all();
    const leavesWithSuggestions = leaves.map((l) => {
      const affected = allSlots.filter((s) => Number(s.teacher_id) === Number(l.teacher_id));
      const pick = pickBestSubstituteTeacher(l.teacher_id, affected, activeTeachers, allSlots, []);
      return {
        ...l,
        affected_slots_count: affected.length,
        suggested_substitute_id: pick.substitute?.id || null,
        suggested_substitute_name: pick.substitute?.full_name || ""
      };
    });
    const substitutions = db
      .prepare(
        `SELECT cs.*, a.full_name AS absent_teacher_name, s.full_name AS substitute_teacher_name,
                b.name AS batch_name, ts.day_of_week, ts.start_time, ts.end_time, ts.subject_name
         FROM crm_leave_substitutions cs
         JOIN users a ON a.id = cs.absent_teacher_id
         JOIN users s ON s.id = cs.substitute_teacher_id
         LEFT JOIN batches b ON b.id = cs.batch_id
         LEFT JOIN timetable_slots ts ON ts.id = cs.timetable_slot_id
         ORDER BY cs.id DESC LIMIT 50`
      )
      .all();
    res.json({ leaves: leavesWithSuggestions, activeTeachers, substitutions });
  });

  router.post("/crm/leaves/:id/approve-substitute", guard, (req, res) => {
    const lid = Number(req.params.id);
    const leave = db.prepare(`SELECT * FROM teacher_leave_requests WHERE id = ?`).get(lid);
    if (!leave) {
      res.status(404).json({ error: "Leave request not found." });
      return;
    }
    const now = nowIso();
    const note = String(req.body?.adminNote || "").trim().slice(0, 400);
    db.prepare(
      `UPDATE teacher_leave_requests SET status = 'approved', admin_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?`
    ).run(note || "Approved with substitute assigned", req.adminCtx.user.id, now, lid);

    try {
      const substitution = assignSubstituteOnTeacherLeave(db, {
        leaveRequestId: lid,
        substituteTeacherId: req.body?.substituteTeacherId ? Number(req.body.substituteTeacherId) : null,
        actorId: req.adminCtx.user.id
      });
      writeAuditLog(
        db,
        req.adminCtx.user,
        "crm_leave_substitute_assigned",
        lid,
        `Leave #${lid}`,
        substitution.assigned ? `Sub=${substitution.substituteTeacherName}, Notified=${substitution.studentsNotified}` : "No free substitute",
        clientIp(req)
      );
      res.json({ ok: true, leaveId: lid, status: "approved", substitution });
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to assign substitute." });
    }
  });

  // 12D. Admin Teacher Ratings & Anonymous Student Feedback Overview
  router.get("/crm/feedback/overview", guard, (_req, res) => {
    const teacherRatings = db
      .prepare(
        `SELECT u.id AS teacher_id, u.full_name AS teacher_name,
                COUNT(f.id) AS feedback_count,
                ROUND(AVG(f.rating), 2) AS avg_rating,
                ROUND(AVG(f.clarity_rating), 2) AS avg_clarity,
                SUM(CASE WHEN f.pace_tag = 'too_fast' THEN 1 ELSE 0 END) AS too_fast_count,
                SUM(CASE WHEN f.topic_unclear != '' THEN 1 ELSE 0 END) AS unclear_topics_count
         FROM users u
         LEFT JOIN crm_student_feedback f ON f.teacher_id = u.id
         WHERE u.role = 'teacher' AND u.is_active = 1
         GROUP BY u.id
         ORDER BY feedback_count DESC, avg_rating DESC`
      )
      .all();

    const entries = db
      .prepare(
        `SELECT f.*, t.full_name AS teacher_name, b.name AS batch_name,
                CASE WHEN f.is_anonymous = 1 THEN 'Anonymous Student' ELSE s.full_name END AS student_display
         FROM crm_student_feedback f
         JOIN users t ON t.id = f.teacher_id
         JOIN users s ON s.id = f.student_id
         LEFT JOIN batches b ON b.id = f.batch_id
         ORDER BY f.admin_reviewed ASC, f.id DESC LIMIT 80`
      )
      .all();

    res.json({ teacherRatings, entries });
  });

  router.patch("/crm/feedback/:id/review", guard, (req, res) => {
    const id = Number(req.params.id);
    const note = String(req.body?.adminActionNote || "Reviewed by Admin").trim().slice(0, 300);
    db.prepare(`UPDATE crm_student_feedback SET admin_reviewed = 1, admin_action_note = ? WHERE id = ?`).run(note, id);
    res.json({ ok: true, id });
  });

  // 12E. Birthdays & Role-Wise New Joining Welcome Mails (Student + Teacher + Staff)
  router.get("/crm/celebrations/overview", guard, (req, res) => {
    const roleFilter = String(req.query.role || "all").toLowerCase();
    const ist = getIstDateParts();
    const yearKey = String(ist.year);
    const siteUrl = (process.env.APP_URL || "https://yuitor.com").replace(/\/+$/, "");

    const members = db
      .prepare(
        `SELECT u.id, u.role, u.full_name, u.email, u.phone, u.created_at,
                CASE WHEN u.dob != '' THEN u.dob ELSE COALESCE(sp.dob, '') END AS dob,
                sp.roll_number,
                (SELECT COUNT(*) FROM crm_celebration_logs cl WHERE cl.user_id = u.id AND cl.event_type = 'birthday' AND cl.year_key = ?) AS wished_this_year,
                (SELECT MAX(cl.created_at) FROM crm_celebration_logs cl WHERE cl.user_id = u.id AND cl.event_type = 'welcome_joining') AS last_welcome_at
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.is_active = 1 AND u.role IN ('student', 'teacher', 'staff', 'parent')
         ORDER BY u.id DESC LIMIT 250`
      )
      .all(yearKey);

    const { today, upcoming } = getUpcomingBirthdays(members, ist, 14);
    const enrich = (m) => {
      const tpl = buildBirthdayEmailTemplate({ fullName: m.full_name, role: m.role, siteUrl });
      return {
        ...m,
        whatsapp_wish_url: m.phone ? buildWhatsAppClickToChatUrl(m.phone, tpl.whatsappText) : ""
      };
    };

    const filteredMembers =
      roleFilter && roleFilter !== "all" ? members.filter((m) => m.role === roleFilter) : members;

    const logs = db
      .prepare(
        `SELECT cl.*, u.full_name
         FROM crm_celebration_logs cl
         JOIN users u ON u.id = cl.user_id
         ORDER BY cl.id DESC LIMIT 60`
      )
      .all();

    res.json({
      ist,
      todayBirthdays: today.map(enrich),
      upcomingBirthdays: upcoming.map(enrich),
      members: filteredMembers,
      logs
    });
  });

  router.post("/crm/celebrations/dob/:userId", guard, (req, res) => {
    const uid = Number(req.params.userId);
    const dob = String(req.body?.dob || "").trim().slice(0, 10);
    if (dob && !/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
      res.status(400).json({ error: "Date of Birth must be in YYYY-MM-DD format." });
      return;
    }
    const user = db.prepare(`SELECT id, role, full_name FROM users WHERE id = ?`).get(uid);
    if (!user) {
      res.status(404).json({ error: "Member not found." });
      return;
    }
    const now = nowIso();
    db.prepare(`UPDATE users SET dob = ?, updated_at = ? WHERE id = ?`).run(dob, now, uid);
    if (user.role === "student") {
      try {
        db.prepare(`UPDATE student_profiles SET dob = ? WHERE user_id = ?`).run(dob, uid);
      } catch {}
    }
    writeAuditLog(db, req.adminCtx.user, "crm_member_dob_updated", uid, user.full_name, `DOB=${dob || "cleared"}`, clientIp(req));
    res.json({ ok: true, userId: uid, dob });
  });

  router.post("/crm/celebrations/birthday-wish/:userId", guard, async (req, res) => {
    const uid = Number(req.params.userId);
    try {
      const out = await sendBirthdayWishesForToday(db, deps.sendTransactionalEmail || null, {
        actorId: req.adminCtx.user.id,
        forceUserId: uid
      });
      writeAuditLog(db, req.adminCtx.user, "crm_birthday_wish_sent", uid, `Member #${uid}`, `wished=${out.wished}`, clientIp(req));
      res.json(out);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to send birthday wish." });
    }
  });

  router.post("/crm/celebrations/birthday-run-today", guard, async (req, res) => {
    try {
      const out = await sendBirthdayWishesForToday(db, deps.sendTransactionalEmail || null, {
        actorId: req.adminCtx.user.id
      });
      writeAuditLog(db, req.adminCtx.user, "crm_birthday_batch_run", null, "Daily Birthdays", `matched=${out.matched}, wished=${out.wished}`, clientIp(req));
      res.json(out);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to run birthday wishes." });
    }
  });

  router.post("/crm/celebrations/welcome-mail/:userId", guard, async (req, res) => {
    const uid = Number(req.params.userId);
    try {
      const out = await sendRoleWelcomeKit(db, deps.sendTransactionalEmail || null, {
        userId: uid,
        actorId: req.adminCtx.user.id
      });
      writeAuditLog(db, req.adminCtx.user, "crm_welcome_mail_sent", uid, out.fullName, `role=${out.role}, status=${out.emailStatus}`, clientIp(req));
      res.json(out);
    } catch (err) {
      res.status(400).json({ error: err?.message || "Failed to send welcome email." });
    }
  });

  // 13. Automation Control Panel, Rules, Dry-Run, Job Queue, Scheduler & Exception Inbox
  router.get("/crm/automation/overview", guard, (_req, res) => {
    const config = getAutomationConfig(db);
    const rules = db.prepare(`SELECT * FROM crm_automation_rules ORDER BY priority ASC, id ASC`).all();
    const jobs = db.prepare(`SELECT * FROM crm_job_queue ORDER BY id DESC LIMIT 40`).all();
    const schedulerRuns = db.prepare(`SELECT * FROM crm_scheduler_runs ORDER BY id DESC LIMIT 30`).all();
    const exceptions = db.prepare(`SELECT * FROM crm_exception_inbox ORDER BY status = 'open' DESC, id DESC LIMIT 60`).all();
    const deliveryLogs = db.prepare(`SELECT * FROM alert_dispatch_logs ORDER BY id DESC LIMIT 30`).all();
    res.json({ config, rules, jobs, schedulerRuns, exceptions, deliveryLogs });
  });

  router.patch("/crm/automation/config", guard, (req, res) => {
    const updated = updateAutomationConfig(db, req.body || {}, req.adminCtx.user.id);
    writeAuditLog(db, req.adminCtx.user, "crm_automation_config_updated", null, "Automation Config", `KillSwitch=${updated.global_kill_switch}, SoftLock=${updated.defaulter_soft_lock_enabled}`, clientIp(req));
    res.json({ ok: true, config: updated });
  });

  router.patch("/crm/automation/rules/:id", guard, (req, res) => {
    const id = Number(req.params.id);
    const cur = db.prepare(`SELECT * FROM crm_automation_rules WHERE id = ?`).get(id);
    if (!cur) {
      res.status(404).json({ error: "Automation rule not found." });
      return;
    }
    const isEnabled = req.body?.isEnabled !== undefined ? (Number(req.body.isEnabled) ? 1 : 0) : cur.is_enabled;
    const priority = req.body?.priority !== undefined ? Number(req.body.priority) : cur.priority;
    db.prepare(`UPDATE crm_automation_rules SET is_enabled = ?, priority = ?, version = version + 1, updated_at = ? WHERE id = ?`).run(
      isEnabled,
      priority,
      nowIso(),
      id
    );
    writeAuditLog(db, req.adminCtx.user, "crm_rule_toggled", id, cur.rule_key, `enabled=${isEnabled}`, clientIp(req));
    res.json({ ok: true, rule: db.prepare(`SELECT * FROM crm_automation_rules WHERE id = ?`).get(id) });
  });

  router.post("/crm/automation/rules/:id/dry-run", guard, (req, res) => {
    const rule = db.prepare(`SELECT * FROM crm_automation_rules WHERE id = ?`).get(Number(req.params.id));
    if (!rule) {
      res.status(404).json({ error: "Rule not found." });
      return;
    }
    const sim = emitSystemEvent(db, rule.event_name, req.body?.samplePayload || { studentName: "Demo Student", percentage: 32, belowThreshold: true }, { dryRun: true });
    res.json({ ok: true, dryRun: true, ruleKey: rule.rule_key, simulation: sim });
  });

  router.post("/crm/automation/jobs/:id/retry", guard, async (req, res) => {
    const id = Number(req.params.id);
    db.prepare(`UPDATE crm_job_queue SET status = 'pending', attempts = 0, next_run_at = ?, updated_at = ? WHERE id = ?`).run(nowIso(), nowIso(), id);
    const processed = await processJobQueueBatch(db, deps, { limit: 10 });
    res.json({ ok: true, id, processed });
  });

  router.post("/crm/automation/scheduler/run", guard, async (req, res) => {
    const forceJob = String(req.body?.jobName || "queue_and_sla");
    const out = await runCentralSchedulerTick(db, deps, { forceJob });
    res.json({ ok: true, ...out });
  });

  router.post("/crm/exceptions/:id/action", guard, async (req, res) => {
    const id = Number(req.params.id);
    const action = String(req.body?.action || "resolved");
    const note = String(req.body?.note || "").trim();
    const item = db.prepare(`SELECT * FROM crm_exception_inbox WHERE id = ?`).get(id);
    if (!item) {
      res.status(404).json({ error: "Exception item not found." });
      return;
    }
    const statusMap = { approve: "approved", retry: "retried", ignore: "ignored", resolve: "resolved" };
    const nextStatus = statusMap[action] || "resolved";

    if (action === "retry" && item.entity_type === "crm_job_queue" && item.entity_id) {
      db.prepare(`UPDATE crm_job_queue SET status = 'pending', attempts = 0, next_run_at = ?, updated_at = ? WHERE id = ?`).run(nowIso(), nowIso(), Number(item.entity_id));
      await processJobQueueBatch(db, deps, { limit: 5 });
    }
    db.prepare(`UPDATE crm_exception_inbox SET status = ?, assigned_to = COALESCE(?, assigned_to), resolved_by = ?, resolution_note = ?, updated_at = ? WHERE id = ?`).run(
      nextStatus,
      req.body?.assignedTo ? Number(req.body.assignedTo) : null,
      req.adminCtx.user.id,
      note,
      nowIso(),
      id
    );
    res.json({ ok: true, id, status: nextStatus });
  });

  // 14. Retention Risk Scores & Marketing CPA Analytics
  router.get("/crm/retention/risks", guard, (_req, res) => {
    const risks = db
      .prepare(
        `SELECT r.*, u.full_name, u.phone, sp.roll_number, sp.parent_phone, b.name AS batch_name
         FROM crm_student_risk_scores r
         JOIN users u ON u.id = r.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN batches b ON b.id = sp.batch_id
         ORDER BY r.risk_score DESC, r.calculated_date DESC LIMIT 80`
      )
      .all();
    res.json({ risks });
  });

  router.post("/crm/retention/recalculate", guard, (_req, res) => {
    const out = runStudentRiskCalculation(db);
    res.json({ ok: true, ...out });
  });

  router.get("/crm/marketing/campaigns", guard, (_req, res) => {
    const campaigns = db.prepare(`SELECT * FROM crm_marketing_campaigns ORDER BY id DESC`).all();
    const enriched = campaigns.map((c) => {
      const leadsCount = Number(
        db.prepare(`SELECT COUNT(*) AS cnt FROM inquiries WHERE utm_source = ? OR source = ?`).get(c.utm_source, c.utm_source)?.cnt || 0
      );
      const admCount = Number(
        db.prepare(`SELECT COUNT(*) AS cnt FROM inquiries WHERE (utm_source = ? OR source = ?) AND status = 'admitted'`).get(c.utm_source, c.utm_source)?.cnt || 0
      );
      const cpa = computeCostPerAdmission(c.spend_amount, admCount);
      return { ...c, leadsCount, admissionsCount: admCount, cpa, pauseAlert: cpa > Number(c.target_cpa || 1500) && c.spend_amount > 0 };
    });
    res.json({ campaigns: enriched });
  });

  router.post("/crm/marketing/campaigns", guard, (req, res) => {
    const name = String(req.body?.name || "").trim();
    if (!name) {
      res.status(400).json({ error: "Campaign name is required." });
      return;
    }
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO crm_marketing_campaigns (name, utm_source, utm_medium, utm_campaign, budget_amount, spend_amount, impressions, clicks, target_cpa, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`
      )
      .run(
        name,
        String(req.body?.utmSource || "facebook_ads"),
        String(req.body?.utmMedium || "cpc"),
        String(req.body?.utmCampaign || ""),
        Number(req.body?.budgetAmount || 5000),
        Number(req.body?.spendAmount || 0),
        Number(req.body?.impressions || 0),
        Number(req.body?.clicks || 0),
        Number(req.body?.targetCpa || 1500),
        now,
        now
      );
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid) });
  });

  return router;
}

// ==================== STUDENT, TEACHER, STAFF & PUBLIC CRM ROUTER ====================
export function createCrmUserRouter(db, deps) {
  const router = Router();
  const { getSessionContext } = deps;
  const studentGuard = requireAnyPortalRole(db, getSessionContext, ["student"]);
  const teacherGuard = requireAnyPortalRole(db, getSessionContext, ["teacher", "admin", "super_admin"]);

  // Public multi-channel Lead Capture (Website / FB Ads / Google Ads / WhatsApp / Walk-in QR / Missed Call)
  router.post("/public/crm/lead-capture", (req, res) => {
    const name = String(req.body?.name || "Prospective Student").trim();
    const phone = normalizeIndianPhone(req.body?.phone || "");
    if (phone.length < 10) {
      res.status(400).json({ error: "Valid 10-digit mobile number is required." });
      return;
    }
    const existing = db.prepare(`SELECT id FROM inquiries WHERE phone LIKE ? ORDER BY id DESC LIMIT 1`).get(`%${phone}`);
    if (existing) {
      res.json({ ok: true, duplicate: true, inquiryId: existing.id, message: "Your inquiry is already registered. Our counsellor will call you shortly." });
      return;
    }
    const source = String(req.body?.source || req.body?.utmSource || "website").trim();
    const classOrCourse = String(req.body?.classOrCourse || req.body?.course || "General Inquiry").trim();
    const score = computeLeadScore({ phone, email: req.body?.email, source, class_or_course: classOrCourse, message: req.body?.message });
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO inquiries (name, phone, email, class_or_course, message, source, status, follow_up_date, lead_score, priority, utm_source, utm_medium, utm_campaign, sla_due_at, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        name,
        phone,
        String(req.body?.email || "").trim().toLowerCase(),
        classOrCourse,
        String(req.body?.message || "").trim(),
        source,
        getIstDateParts().dateStr,
        score,
        score >= 75 ? "high" : "medium",
        String(req.body?.utmSource || source),
        String(req.body?.utmMedium || ""),
        String(req.body?.utmCampaign || ""),
        new Date(Date.now() + 15 * 60000).toISOString(),
        now
      );
    const id = Number(ins.lastInsertRowid);
    emitSystemEvent(db, "lead.created", { inquiryId: id, name, phone, courseTitle: classOrCourse }, { idempotencyKey: `pub_lead:${id}`, entityType: "inquiry", entityId: String(id) });
    res.status(201).json({ ok: true, inquiryId: id, leadScore: score });
  });

  // Public Opt-Out / STOP Consent Compliance (DPDP + WhatsApp/SMS Compliance)
  router.post("/public/crm/consent", (req, res) => {
    const phone = normalizeIndianPhone(req.body?.phone || "");
    if (phone.length < 10) {
      res.status(400).json({ error: "Valid phone number required." });
      return;
    }
    const optedOutAll = req.body?.stop === true || Number(req.body?.optedOutAll) === 1 ? 1 : 0;
    const now = nowIso();
    db.prepare(
      `INSERT INTO crm_message_consent (phone, whatsapp_opt_in, sms_opt_in, email_opt_in, parent_consent_under18, opted_out_all, opt_out_reason, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(phone) DO UPDATE SET
         whatsapp_opt_in = excluded.whatsapp_opt_in, sms_opt_in = excluded.sms_opt_in,
         email_opt_in = excluded.email_opt_in, parent_consent_under18 = excluded.parent_consent_under18,
         opted_out_all = excluded.opted_out_all, opt_out_reason = excluded.opt_out_reason, updated_at = excluded.updated_at`
    ).run(
      phone,
      optedOutAll ? 0 : Number(req.body?.whatsappOptIn ?? 1),
      optedOutAll ? 0 : Number(req.body?.smsOptIn ?? 1),
      optedOutAll ? 0 : Number(req.body?.emailOptIn ?? 1),
      Number(req.body?.parentConsentUnder18 ?? 0),
      optedOutAll,
      String(req.body?.reason || (optedOutAll ? "STOP requested" : "")),
      now
    );
    res.json({ ok: true, phone, optedOutAll: Boolean(optedOutAll) });
  });

  // Student Portal CRM Hub: Live Classes, CBT Exams, Batch-Locked DPP/Notes, Doubts, Soft-Lock Status
  router.get("/student/crm/hub", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const stu = getStudentFullRecord(db, studentId);
    const lockState = getStudentDefaulterLockState(db, studentId);

    const enrolledCourseIds = db
      .prepare(`SELECT course_id FROM enrollments WHERE student_id = ? AND status IN ('active','completed')`)
      .all(studentId)
      .map((r) => Number(r.course_id));

    const liveClasses = db
      .prepare(
        `SELECT ts.*, c.title AS course_title, b.name AS batch_name, u.full_name AS teacher_name
         FROM timetable_slots ts
         LEFT JOIN courses c ON c.id = ts.course_id
         LEFT JOIN batches b ON b.id = ts.batch_id
         LEFT JOIN users u ON u.id = COALESCE(ts.substitute_teacher_id, ts.teacher_id)
         WHERE ts.meeting_url != '' AND (? IS NULL OR ts.batch_id IS NULL OR ts.batch_id = ?)
         ORDER BY ts.id DESC LIMIT 20`
      )
      .all(stu?.batch_id || null, stu?.batch_id || null);

    const cbtExams = lockState.locked
      ? []
      : db
          .prepare(
            `SELECT q.id, q.course_id, q.batch_id, q.title, '' AS description, q.subject_name, q.exam_pattern,
                    q.positive_marks, q.negative_marks, q.duration_minutes, q.max_marks, q.questions_json,
                    (SELECT qa.score FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) AS last_score,
                    (SELECT qa.batch_rank FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) AS last_rank,
                    (SELECT qa.percentile FROM quiz_attempts qa WHERE qa.quiz_id = q.id AND qa.student_id = ? ORDER BY qa.id DESC LIMIT 1) AS last_percentile
             FROM quizzes q
             WHERE (? IS NULL OR q.batch_id IS NULL OR q.batch_id = ?)
             ORDER BY q.id DESC LIMIT 30`
          )
          .all(studentId, studentId, studentId, stu?.batch_id || null, stu?.batch_id || null);

    // Strictly batch/course-locked study materials
    let materials = [];
    if (!lockState.locked && enrolledCourseIds.length > 0) {
      materials = db
        .prepare(
          `SELECT m.*, c.title AS course_title
           FROM crm_study_materials m
           LEFT JOIN courses c ON c.id = m.course_id
           WHERE m.is_active = 1
             AND m.course_id IN (${enrolledCourseIds.map(() => "?").join(",")})
             AND (m.batch_id IS NULL OR m.batch_id = ?)
           ORDER BY m.created_at DESC LIMIT 80`
        )
        .all(...enrolledCourseIds, stu?.batch_id || -1);
    }

    const doubts = db
      .prepare(
        `SELECT d.*, t.full_name AS teacher_name
         FROM crm_doubts d LEFT JOIN users t ON t.id = d.assigned_teacher_id
         WHERE d.student_id = ? ORDER BY d.created_at DESC LIMIT 30`
      )
      .all(studentId);

    res.json({ student: stu, lockState, liveClasses, cbtExams, materials, doubts });
  });

  // Student Printable ID Card & Progress Report (Self-access only!)
  router.get("/student/crm/pdf/id-card", studentGuard, (req, res) => {
    const stu = getStudentFullRecord(db, req.portalCtx.user.id);
    const qrPayload = `YUITOR:STU:${stu.id}:${stu.roll_number || `YSC-${stu.id}`}`;
    res.type("html").send(renderStudentIdCardHtml(stu, { qrPayload }));
  });

  router.get("/student/crm/pdf/report-card", studentGuard, (req, res) => {
    const report = getStudentProgressReportData(db, req.portalCtx.user.id);
    res.type("html").send(renderProgressReportHtml(report));
  });

  // Live Class Join + Heartbeat Verified Attendance (Click alone != attendance!)
  router.post("/student/crm/live-classes/:slotId/join", studentGuard, (req, res) => {
    const slotId = Number(req.params.slotId);
    const slot = db.prepare(`SELECT * FROM timetable_slots WHERE id = ?`).get(slotId);
    if (!slot) {
      res.status(404).json({ error: "Live class session not found." });
      return;
    }
    const now = nowIso();
    const today = getIstDateParts().dateStr;
    db.prepare(
      `INSERT INTO crm_live_class_joins (timetable_slot_id, session_date, user_id, user_role, joined_at, last_heartbeat_at, duration_seconds, platform_verified, attendance_marked)
       VALUES (?, ?, ?, 'student', ?, ?, 0, 0, 0)
       ON CONFLICT(timetable_slot_id, session_date, user_id) DO UPDATE SET last_heartbeat_at = excluded.last_heartbeat_at`
    ).run(slotId, today, req.portalCtx.user.id, now, now);
    res.json({
      ok: true,
      meetingUrl: slot.meeting_url,
      platform: slot.meeting_platform,
      attendanceNote: "Join logged. Online attendance is marked only after verified active session duration (>= 15 mins) or platform join-log verification."
    });
  });

  router.post("/student/crm/live-classes/:slotId/heartbeat", studentGuard, (req, res) => {
    const slotId = Number(req.params.slotId);
    const addedSeconds = Math.min(300, Math.max(10, Number(req.body?.elapsedSeconds || 60)));
    const today = getIstDateParts().dateStr;
    const row = db
      .prepare(`SELECT * FROM crm_live_class_joins WHERE timetable_slot_id = ? AND session_date = ? AND user_id = ?`)
      .get(slotId, today, req.portalCtx.user.id);
    if (!row) {
      res.status(404).json({ error: "Join session not started." });
      return;
    }
    const nextDuration = Number(row.duration_seconds || 0) + addedSeconds;
    const verified = nextDuration >= 900 || Boolean(req.body?.platformJoinLogVerified) ? 1 : 0;
    db.prepare(
      `UPDATE crm_live_class_joins SET duration_seconds = ?, last_heartbeat_at = ?, platform_verified = MAX(platform_verified, ?) WHERE id = ?`
    ).run(nextDuration, nowIso(), verified, row.id);

    let attendanceMarked = Boolean(row.attendance_marked);
    if (verified && !attendanceMarked) {
      const slot = db.prepare(`SELECT course_id, batch_id, teacher_id FROM timetable_slots WHERE id = ?`).get(slotId);
      if (slot?.course_id) {
        db.prepare(
          `INSERT INTO attendance (course_id, batch_id, student_id, teacher_id, att_date, status, remarks, marked_via, created_at)
           VALUES (?, ?, ?, ?, ?, 'present', 'Verified Online Live Session', 'live_verified', ?)
           ON CONFLICT(course_id, student_id, att_date) DO UPDATE SET status = 'present', marked_via = 'live_verified'`
        ).run(slot.course_id, slot.batch_id || null, req.portalCtx.user.id, slot.teacher_id || null, today, nowIso());
        db.prepare(`UPDATE crm_live_class_joins SET attendance_marked = 1 WHERE id = ?`).run(row.id);
        attendanceMarked = true;
      }
    }
    res.json({ ok: true, durationSeconds: nextDuration, verified: Boolean(verified), attendanceMarked });
  });

  // Competitive CBT Submission (+4/-1, Rank, Percentile, Weak Topics <40%, Auto Remediation)
  router.post("/student/crm/cbt/:quizId/submit", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const lockState = getStudentDefaulterLockState(db, studentId);
    if (lockState.locked) {
      res.status(403).json({ error: lockState.message, feeSoftLocked: true });
      return;
    }
    const quiz = db.prepare(`SELECT * FROM quizzes WHERE id = ?`).get(Number(req.params.quizId));
    if (!quiz) {
      res.status(404).json({ error: "CBT Exam not found." });
      return;
    }
    let questions = [];
    try {
      questions = JSON.parse(quiz.questions_json || "[]");
    } catch {
      questions = [];
    }
    const answers = req.body?.answers && typeof req.body.answers === "object" ? req.body.answers : {};
    const statusMap = req.body?.statusMap && typeof req.body.statusMap === "object" ? req.body.statusMap : {};
    const result = calculateCbtResult(questions, answers, {
      positiveMarks: Number(quiz.positive_marks ?? 4),
      negativeMarks: Number(quiz.negative_marks ?? 1)
    });

    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO quiz_attempts (
          quiz_id, student_id, answers_json, score, max_marks, attempted_at,
          weak_topics_json, status_map_json, positive_count, negative_count, unanswered_count
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        quiz.id,
        studentId,
        JSON.stringify(answers),
        result.score,
        result.maxMarks,
        now,
        JSON.stringify(result.weakTopics),
        JSON.stringify(statusMap),
        result.correct,
        result.wrong,
        result.unanswered
      );
    const attemptId = Number(ins.lastInsertRowid);

    // Recompute rank & percentile across all attempts of this CBT
    const allScores = db.prepare(`SELECT score FROM quiz_attempts WHERE quiz_id = ?`).all(quiz.id).map((r) => Number(r.score));
    const { rank, percentile } = computeRankAndPercentile(allScores, result.score);
    db.prepare(`UPDATE quiz_attempts SET batch_rank = ?, percentile = ? WHERE id = ?`).run(rank, percentile, attemptId);

    if (result.needsRemediation) {
      emitSystemEvent(
        db,
        "test.completed",
        {
          studentId,
          studentName: req.portalCtx.user.full_name,
          courseId: quiz.course_id,
          batchId: quiz.batch_id,
          subjectName: quiz.subject_name,
          percentage: result.percentage,
          weakTopics: result.weakTopics
        },
        { idempotencyKey: `cbt_rem:${attemptId}`, entityType: "quiz_attempt", entityId: String(attemptId) }
      );
    }

    res.status(201).json({ ok: true, attemptId, ...result, rank, percentile });
  });

  // Student Doubt Counter (Auto-assigns to Subject Teacher + 12h SLA)
  router.post("/student/crm/doubts", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const subjectName = String(req.body?.subjectName || "Mathematics").trim();
    const chapterName = String(req.body?.chapterName || "").trim();
    const questionText = String(req.body?.questionText || "").trim();
    const questionImageUrl = String(req.body?.questionImageUrl || "").trim();
    if (!questionText && !questionImageUrl) {
      res.status(400).json({ error: "Provide question text or upload a question screenshot." });
      return;
    }
    const stu = getStudentFullRecord(db, studentId);
    // Find subject teacher automatically
    const teachers = db
      .prepare(`SELECT u.id, tp.subjects_json FROM users u LEFT JOIN teacher_profiles tp ON tp.user_id = u.id WHERE u.role = 'teacher' AND u.is_active = 1`)
      .all();
    const matchedTeacher =
      teachers.find((t) => String(t.subjects_json || "").toLowerCase().includes(subjectName.toLowerCase())) || teachers[0] || null;
    const slaHours = Number(getAutomationConfig(db).doubt_sla_hours || 12);
    const slaDueAt = new Date(Date.now() + slaHours * 3600000).toISOString();
    const now = nowIso();

    const ins = db
      .prepare(
        `INSERT INTO crm_doubts (student_id, course_id, batch_id, subject_name, chapter_name, question_text, question_image_url, assigned_teacher_id, status, sla_due_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?)`
      )
      .run(
        studentId,
        req.body?.courseId || null,
        stu?.batch_id || null,
        subjectName,
        chapterName,
        questionText,
        questionImageUrl,
        matchedTeacher?.id || null,
        slaDueAt,
        now,
        now
      );
    if (matchedTeacher?.id) {
      db.prepare(`INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`).run(
        matchedTeacher.id,
        `New ${subjectName} Doubt Assigned`,
        `${stu?.full_name || "Student"} asked a doubt in ${chapterName || subjectName}. Respond within ${slaHours}h.`,
        now
      );
    }
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid), assignedTeacherId: matchedTeacher?.id || null, slaDueAt });
  });

  // Recorded Lecture Watch Progress (YouTube Unlisted / Vimeo / MP4 real tracking + resume position)
  router.post("/student/crm/lessons/:lessonId/watch-progress", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const lessonId = Number(req.params.lessonId);
    const watchSeconds = Math.max(0, Math.round(Number(req.body?.watchSeconds || 0)));
    const durationSeconds = Math.max(1, Math.round(Number(req.body?.durationSeconds || 1800)));
    const lastPositionSeconds = Math.max(0, Math.round(Number(req.body?.lastPositionSeconds || watchSeconds)));
    const watchPercent = Math.min(100, Math.round((watchSeconds / durationSeconds) * 100));
    const now = nowIso();

    db.prepare(
      `INSERT INTO lesson_progress (student_id, lesson_id, completed_at, time_spent_minutes, watch_seconds, watch_percent, last_position_seconds)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(student_id, lesson_id) DO UPDATE SET
         watch_seconds = MAX(watch_seconds, excluded.watch_seconds),
         watch_percent = MAX(watch_percent, excluded.watch_percent),
         last_position_seconds = excluded.last_position_seconds,
         time_spent_minutes = MAX(time_spent_minutes, excluded.time_spent_minutes)`
    ).run(studentId, lessonId, now, Math.max(1, Math.round(watchSeconds / 60)), watchSeconds, watchPercent, lastPositionSeconds);

    res.json({ ok: true, lessonId, watchSeconds, watchPercent, lastPositionSeconds, completed: watchPercent >= 85 });
  });

  // Student Private / Anonymous Feedback & Teacher Rating
  router.get("/student/crm/feedback", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const teachers = db
      .prepare(
        `SELECT DISTINCT u.id, u.full_name, tp.subjects_json
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher' AND u.is_active = 1
         ORDER BY u.full_name ASC`
      )
      .all();
    const myFeedback = db
      .prepare(
        `SELECT f.*, t.full_name AS teacher_name
         FROM crm_student_feedback f
         JOIN users t ON t.id = f.teacher_id
         WHERE f.student_id = ?
         ORDER BY f.id DESC LIMIT 30`
      )
      .all(studentId);
    res.json({ teachers, myFeedback });
  });

  router.post("/student/crm/feedback", studentGuard, (req, res) => {
    const studentId = req.portalCtx.user.id;
    const teacherId = Number(req.body?.teacherId);
    const rating = Math.max(1, Math.min(5, Math.round(Number(req.body?.rating || 5))));
    const clarityRating = Math.max(1, Math.min(5, Math.round(Number(req.body?.clarityRating || rating))));
    const paceTag = ["too_fast", "just_right", "too_slow"].includes(req.body?.paceTag) ? req.body.paceTag : "just_right";
    const subjectName = String(req.body?.subjectName || "").trim().slice(0, 80);
    const topicUnclear = String(req.body?.topicUnclear || "").trim().slice(0, 180);
    const feedbackText = String(req.body?.feedbackText || "").trim().slice(0, 600);
    const isAnonymous = req.body?.isAnonymous === false || req.body?.isAnonymous === 0 || req.body?.isAnonymous === "0" ? 0 : 1;

    const teacher = db.prepare(`SELECT id, full_name FROM users WHERE id = ? AND role = 'teacher' AND is_active = 1`).get(teacherId);
    if (!teacher) {
      res.status(400).json({ error: "Please select an active teacher." });
      return;
    }
    if (!topicUnclear && !feedbackText) {
      res.status(400).json({ error: "Please mention an unclear topic or short feedback." });
      return;
    }
    const enr = db
      .prepare(`SELECT batch_id, course_id FROM enrollments WHERE student_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1`)
      .get(studentId);
    const now = nowIso();
    const ins = db
      .prepare(
        `INSERT INTO crm_student_feedback (
           student_id, teacher_id, batch_id, course_id, subject_name, topic_unclear,
           rating, clarity_rating, pace_tag, feedback_text, is_anonymous, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        studentId,
        teacherId,
        enr?.batch_id || null,
        enr?.course_id || null,
        subjectName,
        topicUnclear,
        rating,
        clarityRating,
        paceTag,
        feedbackText,
        isAnonymous,
        now
      );
    res.status(201).json({ ok: true, id: Number(ins.lastInsertRowid), isAnonymous: Boolean(isAnonymous) });
  });

  // Teacher CRM Hub: Doubts + Live Classes + Masked Active Roster + Substitutions + Strictly Anonymized Feedback
  router.get("/teacher/crm/hub", teacherGuard, (req, res) => {
    const uid = req.portalCtx.user.id;
    const maskPhones = isTeacherPhoneMaskingEnabled(db);
    const doubts = db
      .prepare(
        `SELECT d.*, s.full_name AS student_name
         FROM crm_doubts d JOIN users s ON s.id = d.student_id
         WHERE (d.assigned_teacher_id = ? OR d.assigned_teacher_id IS NULL) AND s.is_active = 1
         ORDER BY d.status = 'open' DESC, d.sla_due_at ASC LIMIT 60`
      )
      .all(uid);
    const liveClasses = db
      .prepare(`SELECT ts.*, b.name AS batch_name FROM timetable_slots ts LEFT JOIN batches b ON b.id = ts.batch_id WHERE ts.teacher_id = ? OR ts.substitute_teacher_id = ? ORDER BY ts.id DESC`)
      .all(uid, uid);

    // Active students only (left/dropped students automatically excluded) with privacy phone masking
    const rawRoster = db
      .prepare(
        `SELECT DISTINCT u.id, u.full_name, u.phone AS student_phone, sp.roll_number, sp.parent_phone,
                b.name AS batch_name, c.title AS course_title
         FROM enrollments e
         JOIN users u ON u.id = e.student_id
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         LEFT JOIN batches b ON b.id = e.batch_id
         LEFT JOIN courses c ON c.id = e.course_id
         WHERE e.status = 'active' AND u.is_active = 1
           AND (b.teacher_id = ? OR c.teacher_id = ? OR EXISTS (
             SELECT 1 FROM timetable_slots ts WHERE ts.batch_id = e.batch_id AND (ts.teacher_id = ? OR ts.substitute_teacher_id = ?)
           ))
         ORDER BY b.name ASC, u.full_name ASC LIMIT 120`
      )
      .all(uid, uid, uid, uid);
    const maskedRoster = rawRoster.map((r) => ({
      id: r.id,
      full_name: r.full_name,
      roll_number: r.roll_number || "",
      batch_name: r.batch_name || "",
      course_title: r.course_title || "",
      student_phone: maskPhones ? maskPhoneForTeacher(r.student_phone) : r.student_phone || "",
      parent_phone: maskPhones ? maskPhoneForTeacher(r.parent_phone || r.student_phone) : r.parent_phone || r.student_phone || "",
      phone_masked: maskPhones
    }));

    const substitutions = db
      .prepare(
        `SELECT cs.*, a.full_name AS absent_teacher_name, b.name AS batch_name,
                ts.day_of_week, ts.start_time, ts.end_time, ts.subject_name
         FROM crm_leave_substitutions cs
         JOIN users a ON a.id = cs.absent_teacher_id
         LEFT JOIN batches b ON b.id = cs.batch_id
         LEFT JOIN timetable_slots ts ON ts.id = cs.timetable_slot_id
         WHERE cs.substitute_teacher_id = ? AND cs.status = 'assigned'
         ORDER BY cs.id DESC LIMIT 20`
      )
      .all(uid);

    const rawFeedback = db
      .prepare(
        `SELECT f.*, s.full_name AS student_name, b.name AS batch_name, c.title AS course_title
         FROM crm_student_feedback f
         JOIN users s ON s.id = f.student_id
         LEFT JOIN batches b ON b.id = f.batch_id
         LEFT JOIN courses c ON c.id = f.course_id
         WHERE f.teacher_id = ?
         ORDER BY f.id DESC LIMIT 40`
      )
      .all(uid);
    const feedbackItems = redactFeedbackForTeacher(rawFeedback);
    const avgRating = feedbackItems.length
      ? Number((feedbackItems.reduce((a, b) => a + Number(b.rating || 0), 0) / feedbackItems.length).toFixed(2))
      : 0;
    const topicsToRevise = [...new Set(feedbackItems.map((f) => f.topic_unclear).filter(Boolean))].slice(0, 12);

    res.json({
      doubts,
      liveClasses,
      phoneMaskingEnabled: maskPhones,
      maskedRoster,
      substitutions,
      feedbackSummary: {
        count: feedbackItems.length,
        avgRating,
        topicsToRevise,
        items: feedbackItems
      }
    });
  });

  // Teacher -> Official Institute-Logged Parent Alert (works even when parent mobile numbers are masked!)
  router.post("/teacher/crm/notify-parent", teacherGuard, (req, res) => {
    const tid = req.portalCtx.user.id;
    const studentId = Number(req.body?.studentId);
    const message = String(req.body?.message || "").trim().slice(0, 500);
    if (!studentId || !message) {
      res.status(400).json({ error: "Student and message are required." });
      return;
    }
    const stu = db.prepare(`SELECT id, full_name, is_active FROM users WHERE id = ? AND role = 'student' AND is_active = 1`).get(studentId);
    if (!stu) {
      res.status(404).json({ error: "Active student not found." });
      return;
    }
    const now = nowIso();
    // Send in-app notification to linked parent(s) + student without exposing raw mobile numbers to teacher
    const parents = db
      .prepare(`SELECT parent_id FROM parent_student_links WHERE student_id = ?`)
      .all(studentId);
    const insNotif = db.prepare(
      `INSERT INTO notifications (user_id, role_target, title, message, is_read, created_at) VALUES (?, '', ?, ?, 0, ?)`
    );
    const title = `Faculty Update from ${req.portalCtx.user.full_name} (re: ${stu.full_name})`;
    for (const p of parents) {
      insNotif.run(p.parent_id, title, message, now);
    }
    insNotif.run(studentId, title, message, now);
    writeAuditLog(db, req.portalCtx.user, "teacher_safe_parent_alert", studentId, stu.full_name, `ParentsNotified=${parents.length}`, clientIp(req));
    res.status(201).json({ ok: true, studentId, parentsNotified: parents.length, maskedChannel: true });
  });

  router.post("/teacher/crm/doubts/:id/reply", teacherGuard, (req, res) => {
    const id = Number(req.params.id);
    const replyText = String(req.body?.replyText || "").trim();
    if (!replyText) {
      res.status(400).json({ error: "Reply text is required." });
      return;
    }
    const now = nowIso();
    db.prepare(
      `UPDATE crm_doubts SET reply_text = ?, reply_attachment_url = ?, replied_by = ?, replied_at = ?, status = 'answered', updated_at = ? WHERE id = ?`
    ).run(replyText, String(req.body?.replyAttachmentUrl || ""), req.portalCtx.user.id, now, now, id);
    res.json({ ok: true, id });
  });

  // Self-Service Celebration Status & Date of Birth Saver (Student, Teacher, Parent & Staff)
  const anyMemberGuard = requireAnyPortalRole(db, getSessionContext, ["student", "teacher", "parent", "staff", "admin", "super_admin"]);

  router.get("/portal/crm/celebration-status", anyMemberGuard, (req, res) => {
    const uid = req.portalCtx.user.id;
    const row = db
      .prepare(
        `SELECT u.id, u.role, u.full_name,
                CASE WHEN u.dob != '' THEN u.dob ELSE COALESCE(sp.dob, '') END AS dob
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.id = ?`
      )
      .get(uid);
    const dob = row?.dob || "";
    const ist = getIstDateParts();
    const isBday = isBirthdayTodayIst(dob, ist);
    const tpl = isBday ? buildBirthdayEmailTemplate({ fullName: row.full_name, role: row.role }) : null;
    res.json({
      dob,
      isBirthdayToday: isBday,
      bannerTitle: tpl?.portalTitle || "",
      bannerMessage: tpl?.portalMessage || ""
    });
  });

  router.post("/portal/crm/save-dob", anyMemberGuard, (req, res) => {
    const uid = req.portalCtx.user.id;
    const dob = String(req.body?.dob || "").trim().slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
      res.status(400).json({ error: "Please pick a valid Date of Birth (YYYY-MM-DD)." });
      return;
    }
    const now = nowIso();
    db.prepare(`UPDATE users SET dob = ?, updated_at = ? WHERE id = ?`).run(dob, now, uid);
    if (req.portalCtx.user.role === "student") {
      try {
        db.prepare(`UPDATE student_profiles SET dob = ? WHERE user_id = ?`).run(dob, uid);
      } catch {}
    }
    const isBday = isBirthdayTodayIst(dob, getIstDateParts());
    const tpl = isBday ? buildBirthdayEmailTemplate({ fullName: req.portalCtx.user.full_name, role: req.portalCtx.user.role }) : null;
    res.json({
      ok: true,
      dob,
      isBirthdayToday: isBday,
      bannerTitle: tpl?.portalTitle || "",
      bannerMessage: tpl?.portalMessage || ""
    });
  });

  return router;
}
