// Pure, deterministic calculation & formatting helpers for Referrals, Wallets, Withdrawals & Exports

export const DEFAULT_MILESTONES = [
  { qualified_count: 1, cumulative_reward: 200, title: "Starter Referrer", badge_label: "1 Referral" },
  { qualified_count: 2, cumulative_reward: 500, title: "Rising Ambassador", badge_label: "2 Referrals" },
  { qualified_count: 3, cumulative_reward: 1000, title: "Gold Advocate", badge_label: "3 Referrals" },
  { qualified_count: 4, cumulative_reward: 1500, title: "Elite Mentor", badge_label: "4 Referrals" },
  { qualified_count: 5, cumulative_reward: 2500, title: "Yuitor Champion", badge_label: "5 Referrals" }
];

export const WITHDRAWAL_STATUSES = ["pending", "under_review", "approved", "processing", "paid", "rejected"];

export const VALID_WITHDRAWAL_TRANSITIONS = {
  pending: ["under_review", "approved", "processing", "paid", "rejected"],
  under_review: ["approved", "processing", "paid", "rejected"],
  approved: ["processing", "paid", "rejected"],
  processing: ["paid", "rejected"],
  paid: [],
  rejected: []
};

export function normalizeReferralCode(raw) {
  return String(raw || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "")
    .slice(0, 24);
}

export function generateReferralCode(fullName, userId) {
  const letters = String(fullName || "YTR")
    .toUpperCase()
    .replace(/[^A-Z]/g, "")
    .slice(0, 4)
    .padEnd(3, "Y");
  const suffix = String(Number(userId || 1)).padStart(4, "0");
  return `YTR-${letters}${suffix}`;
}

export function sortActiveMilestones(milestones) {
  const source = Array.isArray(milestones) && milestones.length > 0 ? milestones : DEFAULT_MILESTONES;
  return source
    .filter((m) => m && (m.is_active === undefined || Number(m.is_active) === 1))
    .map((m) => ({
      id: m.id ?? null,
      qualified_count: Math.max(1, Math.floor(Number(m.qualified_count || 1))),
      cumulative_reward: Math.max(0, Math.round(Number(m.cumulative_reward || 0))),
      title: String(m.title || `Milestone ${m.qualified_count}`),
      badge_label: String(m.badge_label || `${m.qualified_count} Referrals`)
    }))
    .sort((a, b) => a.qualified_count - b.qualified_count);
}

/**
 * Cumulative milestone payout calculator.
 * Credits ONLY the additional difference when reaching a higher milestone.
 */
export function computeMilestoneDelta({ qualifiedCount, alreadyCreditedTotal, milestones }) {
  const qCount = Math.max(0, Math.floor(Number(qualifiedCount || 0)));
  const credited = Math.max(0, Math.round(Number(alreadyCreditedTotal || 0)));
  const sorted = sortActiveMilestones(milestones);

  let unlockedMilestone = null;
  for (const m of sorted) {
    if (qCount >= m.qualified_count) {
      unlockedMilestone = m;
    }
  }

  const targetCumulative = unlockedMilestone ? unlockedMilestone.cumulative_reward : 0;
  const deltaAmount = Math.max(0, targetCumulative - credited);

  return {
    qualifiedCount: qCount,
    targetCumulative,
    alreadyCredited: credited,
    deltaAmount,
    unlockedMilestone
  };
}

/**
 * Computes next milestone target, remaining referrals, progress percent, and clear offer headline.
 * Example: "You have unlocked ₹500. Complete 1 more qualified referral to unlock ₹1,000."
 */
export function computeNextMilestoneOffer({ qualifiedCount, alreadyCreditedTotal, milestones }) {
  const qCount = Math.max(0, Math.floor(Number(qualifiedCount || 0)));
  const credited = Math.max(0, Math.round(Number(alreadyCreditedTotal || 0)));
  const sorted = sortActiveMilestones(milestones);

  let currentMilestone = null;
  let nextMilestone = null;
  for (const m of sorted) {
    if (qCount >= m.qualified_count) {
      currentMilestone = m;
    } else if (!nextMilestone) {
      nextMilestone = m;
    }
  }

  const unlockedAmount = Math.max(credited, currentMilestone ? currentMilestone.cumulative_reward : 0);
  const topMilestone = sorted[sorted.length - 1] || null;

  if (!nextMilestone) {
    return {
      qualifiedCount: qCount,
      unlockedAmount,
      nextTargetAmount: unlockedAmount,
      nextAdditionalGain: 0,
      remainingReferrals: 0,
      progressPercent: 100,
      headline:
        unlockedAmount > 0
          ? `Congratulations! You have unlocked ₹${unlockedAmount.toLocaleString("en-IN")} across all referral milestones.`
          : "Share your referral link to start unlocking milestone rewards.",
      currentMilestone,
      nextMilestone: null,
      milestones: sorted
    };
  }

  const remainingReferrals = Math.max(1, nextMilestone.qualified_count - qCount);
  const nextAdditionalGain = Math.max(0, nextMilestone.cumulative_reward - unlockedAmount);
  const maxRefTarget = topMilestone ? topMilestone.qualified_count : nextMilestone.qualified_count;
  const progressPercent = Math.min(100, Math.round((qCount / Math.max(1, maxRefTarget)) * 100));

  const headline =
    unlockedAmount > 0
      ? `You have unlocked ₹${unlockedAmount.toLocaleString("en-IN")}. Complete ${remainingReferrals} more qualified referral${remainingReferrals === 1 ? "" : "s"} to unlock ₹${nextMilestone.cumulative_reward.toLocaleString("en-IN")}.`
      : `Complete ${remainingReferrals} qualified referral${remainingReferrals === 1 ? "" : "s"} (3 months verified fee paid) to unlock ₹${nextMilestone.cumulative_reward.toLocaleString("en-IN")}.`;

  return {
    qualifiedCount: qCount,
    unlockedAmount,
    nextTargetAmount: nextMilestone.cumulative_reward,
    nextAdditionalGain,
    remainingReferrals,
    progressPercent,
    headline,
    currentMilestone,
    nextMilestone,
    milestones: sorted
  };
}

/**
 * Evaluates 1-month, 2-month, and 3-month progress for a referred student.
 */
export function evaluateThreeMonthProgress({ paidMonthsCount, requiredMonths = 3 }) {
  const req = Math.max(1, Math.floor(Number(requiredMonths || 3)));
  const count = Math.max(0, Math.floor(Number(paidMonthsCount || 0)));
  const clamped = Math.min(req, count);
  return {
    paidMonthsCount: count,
    requiredMonths: req,
    month1Paid: count >= 1 ? 1 : 0,
    month2Paid: count >= 2 ? 1 : 0,
    month3Paid: count >= 3 ? 1 : 0,
    progressPercent: Math.min(100, Math.round((clamped / req) * 100)),
    isEligible: count >= req
  };
}

/**
 * Computes total verified paid months for a student from verified payment records.
 * Monthly verified payment -> 1 month.
 * Yearly verified payment -> configurable credit (default 12 months, minimum 1).
 * Refunded / failed / pending payments do not count.
 */
export function computeVerifiedPaidMonths(verifiedPayments = [], yearlyPlanMonthsCredit = 12) {
  const yearlyCredits = Math.max(1, Math.min(12, Math.floor(Number(yearlyPlanMonthsCredit || 12))));
  let totalMonths = 0;
  let verifiedFeesTotal = 0;
  const milestonesTimestamps = [];

  const ordered = [...(verifiedPayments || [])]
    .filter((p) => p && String(p.verification_status) === "verified")
    .sort((a, b) => String(a.paid_at || a.created_at || "").localeCompare(String(b.paid_at || b.created_at || "")));

  for (const p of ordered) {
    const monthsCovered = String(p.plan || "monthly") === "yearly" ? yearlyCredits : 1;
    verifiedFeesTotal += Math.max(0, Number(p.amount || 0));
    const ts = String(p.paid_at || p.created_at || "");
    for (let i = 0; i < monthsCovered; i++) {
      totalMonths += 1;
      milestonesTimestamps.push(ts);
    }
  }

  return {
    paidMonthsCount: totalMonths,
    verifiedFeesTotal,
    month1PaidAt: milestonesTimestamps[0] || null,
    month2PaidAt: milestonesTimestamps[1] || null,
    month3PaidAt: milestonesTimestamps[2] || null
  };
}

export function validateUpiId(upi) {
  const clean = String(upi || "").trim();
  return /^[a-zA-Z0-9.\-_]{2,64}@[a-zA-Z0-9]{2,32}$/.test(clean);
}

export function validateIfscCode(ifsc) {
  const clean = String(ifsc || "").trim().toUpperCase();
  return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(clean);
}

export function escapeCsvCell(val) {
  const str = String(val ?? "");
  const safe = /^[=+\-@\t\r]/.test(str) ? `'${str}` : str;
  return `"${safe.replace(/"/g, '""')}"`;
}

export function rowsToCsv(headers, rows) {
  const headerLine = headers.map((h) => escapeCsvCell(h)).join(",");
  const bodyLines = (rows || []).map((row) => row.map((cell) => escapeCsvCell(cell)).join(","));
  return "\uFEFF" + [headerLine, ...bodyLines].join("\r\n");
}

function escapeXml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Generates Excel-compatible SpreadsheetML 2003 (.xls) supporting multiple clean worksheets without binary bloat.
 */
export function buildSpreadsheetXml(sheets = []) {
  const worksheetXml = sheets
    .map((sheet) => {
      const name = escapeXml(String(sheet.name || "Sheet").slice(0, 31));
      const headerRow = `<Row>${(sheet.headers || [])
        .map((h) => `<Cell ss:StyleID="hdr"><Data ss:Type="String">${escapeXml(h)}</Data></Cell>`)
        .join("")}</Row>`;
      const dataRows = (sheet.rows || [])
        .map(
          (row) =>
            `<Row>${row
              .map((cell) => {
                const isNum = typeof cell === "number" && Number.isFinite(cell);
                const raw = String(cell ?? "");
                const safeStr = /^[=+\-@\t\r]/.test(raw) ? `'${raw}` : raw;
                return isNum
                  ? `<Cell><Data ss:Type="Number">${cell}</Data></Cell>`
                  : `<Cell><Data ss:Type="String">${escapeXml(safeStr)}</Data></Cell>`;
              })
              .join("")}</Row>`
        )
        .join("");
      return `<Worksheet ss:Name="${name}"><Table>${headerRow}${dataRows}</Table></Worksheet>`;
    })
    .join("");

  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles>
    <Style ss:ID="hdr">
      <Font ss:Bold="1" ss:Color="#FFFFFF"/>
      <Interior ss:Color="#1D63ED" ss:Pattern="Solid"/>
    </Style>
  </Styles>
  ${worksheetXml}
</Workbook>`;
}

const SECRET_KEY_RE = /(password|secret|token|pass|api_key|apikey|webhook_secret|otp_hash|private)/i;

export function redactSensitiveFields(record) {
  if (!record || typeof record !== "object") return record;
  const out = {};
  for (const [k, v] of Object.entries(record)) {
    if (SECRET_KEY_RE.test(k)) continue;
    out[k] = v;
  }
  return out;
}
