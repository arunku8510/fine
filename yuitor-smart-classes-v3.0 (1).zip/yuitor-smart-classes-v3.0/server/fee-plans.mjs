// Canonical Class-Wise Fee Structure & Billing Cycles — Yuitor Smart Classes v3.0
// Pure, zero-dependency module shared across backend routes, invoices, and unit tests.

export const BILLING_CYCLES = [
  { id: "1m", label: "1 Month", shortLabel: "1m", months: 1, discountPercent: 0 },
  { id: "3m", label: "3 Months", shortLabel: "3m", months: 3, discountPercent: 0 },
  { id: "6m", label: "6 Months", shortLabel: "6m", months: 6, discountPercent: 0 },
  { id: "9m", label: "9 Months", shortLabel: "9m", months: 9, discountPercent: 0 },
  { id: "yearly", label: "Yearly (10% OFF)", shortLabel: "Yearly", months: 12, discountPercent: 10 },
];

export const CLASS_FEE_PLANS = [
  { classNumber: 6, classLabel: "Class 6th", monthly: 600, m1: 600, m3: 1800, m6: 3600, m9: 5400, yearlyGross: 7200, yearlySavings: 720, yearlyTotal: 6480 },
  { classNumber: 7, classLabel: "Class 7th", monthly: 650, m1: 650, m3: 1950, m6: 3900, m9: 5850, yearlyGross: 7800, yearlySavings: 780, yearlyTotal: 7020 },
  { classNumber: 8, classLabel: "Class 8th", monthly: 700, m1: 700, m3: 2100, m6: 4200, m9: 6300, yearlyGross: 8400, yearlySavings: 840, yearlyTotal: 7560 },
  { classNumber: 9, classLabel: "Class 9th", monthly: 750, m1: 750, m3: 2250, m6: 4500, m9: 6750, yearlyGross: 9000, yearlySavings: 900, yearlyTotal: 8100 },
  { classNumber: 10, classLabel: "Class 10th", monthly: 800, m1: 800, m3: 2400, m6: 4800, m9: 7200, yearlyGross: 9600, yearlySavings: 960, yearlyTotal: 8640 },
  { classNumber: 11, classLabel: "Class 11th", monthly: 850, m1: 850, m3: 2550, m6: 5100, m9: 7650, yearlyGross: 10200, yearlySavings: 1020, yearlyTotal: 9180 },
  { classNumber: 12, classLabel: "Class 12th", monthly: 900, m1: 900, m3: 2700, m6: 5400, m9: 8100, yearlyGross: 10800, yearlySavings: 1080, yearlyTotal: 9720 },
];

export function parseClassNumberFromLabel(raw) {
  if (typeof raw === "number" && Number.isFinite(raw)) {
    const n = Math.round(raw);
    return n >= 6 && n <= 12 ? n : null;
  }
  const s = String(raw || "").trim();
  if (!s) return null;
  const match = s.match(/\b(1[0-2]|[6-9])(?:th)?\b/i);
  if (match) {
    const n = Number(match[1]);
    if (n >= 6 && n <= 12) return n;
  }
  return null;
}

export function normalizeBillingCycle(raw) {
  const s = String(raw || "1m").trim().toLowerCase();
  if (s === "1m" || s === "1" || s === "monthly" || s === "1 month") return "1m";
  if (s === "3m" || s === "3" || s === "quarterly" || s === "3 months") return "3m";
  if (s === "6m" || s === "6" || s === "half-yearly" || s === "6 months") return "6m";
  if (s === "9m" || s === "9" || s === "9 months") return "9m";
  if (s === "yearly" || s === "12m" || s === "12" || s === "annual" || s === "lump-sum") return "yearly";
  return "1m";
}

export function calculateClassFeePlan(classInput, cycleInput = "1m") {
  const parsed = parseClassNumberFromLabel(classInput);
  const classNumber = parsed ?? 10;
  const plan = CLASS_FEE_PLANS.find((p) => p.classNumber === classNumber) || CLASS_FEE_PLANS[4];
  const cycleId = normalizeBillingCycle(cycleInput);
  const cycleMeta = BILLING_CYCLES.find((c) => c.id === cycleId) || BILLING_CYCLES[0];

  const subtotal = plan.monthly * cycleMeta.months;
  const discountAmount = cycleMeta.discountPercent > 0 ? Math.round((subtotal * cycleMeta.discountPercent) / 100) : 0;
  const totalPayable = subtotal - discountAmount;

  return {
    classNumber: plan.classNumber,
    classLabel: plan.classLabel,
    cycle: cycleMeta.id,
    cycleLabel: cycleMeta.label,
    months: cycleMeta.months,
    monthlyRate: plan.monthly,
    subtotal,
    discountPercent: cycleMeta.discountPercent,
    discountAmount,
    savings: discountAmount,
    totalPayable,
  };
}
