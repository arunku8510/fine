import { nowIso } from "./addons-db.mjs";
import { redactSensitiveFields } from "./referral-math.mjs";

export const ADMIN_FEATURE_REGISTRY = [
  { id: "dashboard-overview", title: "Dashboard Overview", category: "Pages", subtitle: "KPIs, counts & daily summary", navKey: "dashboard-overview", tab: "dashboard", keywords: "home overview stats metrics dashboard" },
  { id: "marketing-referrals", title: "Referrals, Milestones & Offers", category: "Referrals", subtitle: "Cumulative milestones, 3-month progress, campaigns & rules", navKey: "marketing-referrals", tab: "referrals", keywords: "referral reward milestone 3 month campaign offer code link" },
  { id: "finance-wallets", title: "Student & Teacher Wallets", category: "Wallets", subtitle: "Balances, ledgers, freeze/unfreeze & manual credit/debit", navKey: "finance-wallets", tab: "wallets", keywords: "wallet balance ledger transaction student teacher freeze credit debit" },
  { id: "finance-withdrawals", title: "Withdrawal Requests Queue", category: "Withdrawals", subtitle: "Approve, review, process & pay UPI/Bank payouts", navKey: "finance-withdrawals", tab: "withdrawals", keywords: "withdrawal payout upi bank ifsc approve reject paid pending" },
  { id: "reports-referrals", title: "Referral & Wallet Analytics", category: "Reports", subtitle: "Date/month/year analytics, CSV, Excel & PDF exports", navKey: "reports-referrals", tab: "referral_reports", keywords: "analytics report export csv excel pdf monthly yearly payout" },
  { id: "finance-fees", title: "Fees, Payments & Cart Orders", category: "Payments", subtitle: "Verify payments, invoices, receipts & refunds", navKey: "finance-fees", tab: "payments", keywords: "fee payment invoice receipt refund utr razorpay order" },
  { id: "finance-emi", title: "EMI & Fee Installments", category: "Payments", subtitle: "Student installment schedule & due reminders", navKey: "finance-emi", tab: "payments", scrollMatch: "Fee Installments", keywords: "emi installment overdue reminder" },
  { id: "users-students", title: "Students Directory", category: "Users", subtitle: "Manage student accounts, approvals & profiles", navKey: "users-students", tab: "users", role: "student", keywords: "student enrollment roll id card" },
  { id: "users-teachers", title: "Teachers Directory", category: "Users", subtitle: "Manage teacher accounts, resumes, mail & payouts", navKey: "users-teachers", tab: "users", role: "teacher", keywords: "teacher faculty mentor resume" },
  { id: "users-parents", title: "Parents Directory", category: "Users", subtitle: "Manage parent links & accounts", navKey: "users-parents", tab: "users", role: "parent", keywords: "parent guardian link" },
  { id: "users-staff", title: "Staff Directory", category: "Users", subtitle: "Manage staff roles & desk permissions", navKey: "users-staff", tab: "users", role: "staff", keywords: "staff permission coordinator counselor" },
  { id: "academics-courses", title: "Courses & Fee Directory", category: "Academics", subtitle: "Create/edit courses, pricing & categories", navKey: "academics-courses", tab: "courses", keywords: "course fee price category monthly yearly" },
  { id: "academics-batches", title: "Batches, Branches & Timetable", category: "Academics", subtitle: "Manage classrooms, batches, centers & weekly timetable", navKey: "academics-batches", tab: "academics", keywords: "batch room seat branch timetable" },
  { id: "academics-exams", title: "Exams, Offline Tests & Attendance", category: "Academics", subtitle: "Marks entry, rank cards & QR attendance", navKey: "academics-tests", tab: "tests", keywords: "exam test attendance qr marks rank" },
  { id: "comm-mail", title: "Webmail & Communication", category: "Communication", subtitle: "Multi-mailbox inbox, SMS, WhatsApp & Email marketing", navKey: "comm-mail", tab: "mail", keywords: "email mail sms whatsapp marketing campaign" },
  { id: "reports-inquiries", title: "Inquiries & Demo Bookings", category: "Inquiries", subtitle: "Leads, demo requests & follow-ups", navKey: "reports-inquiries", tab: "cms", scrollMatch: "Website Inquiries", keywords: "inquiry lead demo callback admission" },
  { id: "marketing-cms", title: "Website CMS & Toppers", category: "Marketing", subtitle: "Toppers, banners, FAQs, blog & testimonials", navKey: "marketing-cms", tab: "cms", keywords: "cms banner topper faq blog testimonial" },
  { id: "marketing-chatbot", title: "Shreya AI Chatbot", category: "Marketing", subtitle: "Knowledge base & student chat transcripts", navKey: "marketing-chatbot", tab: "chatbot", keywords: "chatbot shreya ai transcript" },
  { id: "system-settings", title: "Settings & Security", category: "Settings", subtitle: "Admin gate URL, readiness, login attempts & CRM modules", navKey: "system-settings", tab: "settings", settingsTab: "gate", keywords: "setting config threshold minimum approval gate slug readiness" },
  { id: "system-api", title: "API & Integration Settings", category: "Settings", subtitle: "Domain, Gemini AI, SMTP, Fast2SMS & Razorpay (Test-Before-Save)", navKey: "system-api", tab: "settings", settingsTab: "cfg_general", keywords: "api integration razorpay smtp sms gemini" },
  { id: "system-backup", title: "Database Backup & Restore", category: "System", subtitle: "Backups, snapshots & recovery", navKey: "system-backup", tab: "backups", keywords: "backup restore sql download" },
  { id: "crm-fee-desk", title: "Quick Fee Desk (Settings)", category: "Settings", subtitle: "Fast Cash/UPI collection, class-wise fee plans, receipts & WhatsApp reminders", navKey: "system-settings", tab: "settings", settingsTab: "crm_fee_desk", keywords: "quick fee cash upi receipt pdf whatsapp monthly invoice waiver" },
  { id: "crm-leads", title: "Leads & Admission CRM (Settings)", category: "Settings", subtitle: "Lead scoring, today's follow-ups, demo booking & 1-click convert", navKey: "system-settings", tab: "settings", settingsTab: "crm_leads", keywords: "lead inquiry crm followup demo convert admission counsellor" },
  { id: "crm-academics", title: "Live, CBT, DPP & Doubts (Settings)", category: "Settings", subtitle: "Live classes, JEE/NEET CBT tests, DPP notes, doubts & printable PDFs", navKey: "system-settings", tab: "settings", settingsTab: "crm_hub", keywords: "live class zoom meet cbt exam dpp notes doubt id card admit report card" },
  { id: "crm-student-exits", title: "Student Exits & Alumni (Settings)", category: "Settings", subtitle: "Student exits, TC & alumni management", navKey: "system-settings", tab: "settings", settingsTab: "crm_student_exits", keywords: "student exit alumni tc dropout" },
  { id: "crm-teacher-ops", title: "Teachers: Exits, Subs & Ratings (Settings)", category: "Settings", subtitle: "Teacher exits, substitutes & student ratings", navKey: "system-settings", tab: "settings", settingsTab: "crm_teacher_ops", keywords: "teacher exit substitute rating" },
  { id: "crm-staff-exits", title: "Staff Exits & Rejoin (Settings)", category: "Settings", subtitle: "Staff exit workflow & rejoining", navKey: "system-settings", tab: "settings", settingsTab: "crm_staff_exits", keywords: "staff exit rejoin hr" },
  { id: "crm-celebrations", title: "Birthdays & Welcome Mails (Settings)", category: "Settings", subtitle: "Birthday wishes & new joining welcome emails", navKey: "system-settings", tab: "settings", settingsTab: "crm_celebrations", keywords: "birthday welcome mail wishing" },
  { id: "crm-bulk", title: "Bulk CSV & Batch Actions (Settings)", category: "Settings", subtitle: "CSV preview, duplicate detection, accounting exports & bulk promote", navKey: "system-settings", tab: "settings", settingsTab: "crm_bulk", keywords: "csv excel import export accounting defaulters bulk promote" },
  { id: "crm-automation", title: "Automation & Exceptions (Settings)", category: "Settings", subtitle: "Kill switch, rules ON/OFF, exception inbox, IST scheduler, salary & risk", navKey: "system-settings", tab: "settings", settingsTab: "crm_automation", keywords: "automation kill switch rules scheduler exception inbox payroll salary risk cpa" }
];

const STATIC_SAFE_SETTINGS = [
  { key: "required_fee_months", label: "3-Month Fee Eligibility Threshold", category: "Referral Rules", tab: "referrals" },
  { key: "min_withdrawal_amount", label: "Minimum Withdrawal Limit (INR)", category: "Wallet & Withdrawal Rules", tab: "referrals" },
  { key: "max_withdrawal_amount", label: "Maximum Withdrawal Limit (INR)", category: "Wallet & Withdrawal Rules", tab: "referrals" },
  { key: "require_admin_approval", label: "Admin Approval for Withdrawals", category: "Wallet & Withdrawal Rules", tab: "referrals" },
  { key: "allow_student_referrals", label: "Allow Student Referrals", category: "Referral Rules", tab: "referrals" },
  { key: "allow_teacher_referrals", label: "Allow Teacher Referrals", category: "Referral Rules", tab: "referrals" },
  { key: "allow_self_referral", label: "Block Self Referrals", category: "Referral Rules", tab: "referrals" },
  { key: "notify_in_app", label: "In-App Referral & Wallet Notifications", category: "Notification Preferences", tab: "referrals" },
  { key: "notify_email", label: "Email Referral & Wallet Notifications", category: "Notification Preferences", tab: "referrals" },
  { key: "APP_URL", label: "Public Website URL", category: "System Settings", tab: "settings" },
  { key: "ADMIN_OTP_EMAIL", label: "Admin 2FA OTP Email", category: "System Settings", tab: "settings" },
  { key: "GEMINI_MODEL", label: "Shreya AI Model Name", category: "AI Settings", tab: "settings" }
];

export function getAdminSearchPreferences(db, userId) {
  const row = db.prepare("SELECT * FROM admin_search_preferences WHERE user_id = ?").get(userId);
  const safeParse = (s) => {
    try {
      const p = JSON.parse(s || "[]");
      return Array.isArray(p) ? p : [];
    } catch {
      return [];
    }
  };
  return {
    recentSearches: safeParse(row?.recent_searches_json),
    recentPages: safeParse(row?.recent_pages_json),
    pinnedPages: safeParse(row?.pinned_pages_json),
    frequentSettings: safeParse(row?.frequent_settings_json)
  };
}

export function updateAdminSearchPreferences(db, userId, patch = {}) {
  const cur = getAdminSearchPreferences(db, userId);
  const now = nowIso();

  if (patch.addSearch) {
    const q = String(patch.addSearch).trim().slice(0, 80);
    if (q) {
      cur.recentSearches = [q, ...cur.recentSearches.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 8);
    }
  }
  if (patch.recordPage && patch.recordPage.title) {
    const p = {
      id: String(patch.recordPage.id || patch.recordPage.tab || ""),
      title: String(patch.recordPage.title).slice(0, 80),
      tab: String(patch.recordPage.tab || "dashboard"),
      navKey: String(patch.recordPage.navKey || ""),
      role: patch.recordPage.role || null
    };
    cur.recentPages = [p, ...cur.recentPages.filter((x) => x.id !== p.id)].slice(0, 8);
  }
  if (patch.togglePin && patch.togglePin.id) {
    const exists = cur.pinnedPages.some((x) => x.id === patch.togglePin.id);
    if (exists) {
      cur.pinnedPages = cur.pinnedPages.filter((x) => x.id !== patch.togglePin.id);
    } else {
      cur.pinnedPages = [
        {
          id: String(patch.togglePin.id),
          title: String(patch.togglePin.title || ""),
          tab: String(patch.togglePin.tab || "dashboard"),
          navKey: String(patch.togglePin.navKey || "")
        },
        ...cur.pinnedPages
      ].slice(0, 8);
    }
  }
  if (patch.recordSetting && patch.recordSetting.key) {
    const k = String(patch.recordSetting.key);
    const prev = cur.frequentSettings.find((x) => x.key === k);
    if (prev) {
      prev.count = Number(prev.count || 1) + 1;
    } else {
      cur.frequentSettings.push({
        key: k,
        label: String(patch.recordSetting.label || k),
        tab: String(patch.recordSetting.tab || "settings"),
        count: 1
      });
    }
    cur.frequentSettings = cur.frequentSettings.sort((a, b) => Number(b.count || 0) - Number(a.count || 0)).slice(0, 6);
  }

  db.prepare(
    `INSERT INTO admin_search_preferences (
       user_id, recent_searches_json, recent_pages_json, pinned_pages_json, frequent_settings_json, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       recent_searches_json = excluded.recent_searches_json,
       recent_pages_json = excluded.recent_pages_json,
       pinned_pages_json = excluded.pinned_pages_json,
       frequent_settings_json = excluded.frequent_settings_json,
       updated_at = excluded.updated_at`
  ).run(
    userId,
    JSON.stringify(cur.recentSearches),
    JSON.stringify(cur.recentPages),
    JSON.stringify(cur.pinnedPages),
    JSON.stringify(cur.frequentSettings),
    now
  );

  return cur;
}

/**
 * Parameterized, secret-free Admin Global Search across registered pages, safe settings, and live DB records.
 */
export function searchAdminWorkspace(db, {
  query = "",
  category = "all",
  limit = 8,
  offset = 0,
  settingDefinitions = []
} = {}) {
  const qRaw = String(query || "").trim();
  const qLower = qRaw.toLowerCase();
  const like = `%${qRaw}%`;
  const perGroup = Math.min(25, Math.max(3, Number(limit || 8)));
  const off = Math.max(0, Number(offset || 0));

  const groups = {};
  const addGroup = (name, items, total = items.length) => {
    if (items.length > 0) {
      groups[name] = { total, items: items.map((it) => redactSensitiveFields(it)) };
    }
  };

  if (!qRaw) {
    return {
      query: "",
      totalHits: 0,
      groups: {},
      suggestions: ADMIN_FEATURE_REGISTRY.slice(0, 8),
      noResultHint: ""
    };
  }

  const want = (cat) => category === "all" || category.toLowerCase() === cat.toLowerCase();

  // 1. Registered Features / Pages
  if (want("Pages")) {
    const matchedPages = ADMIN_FEATURE_REGISTRY.filter((p) => {
      const hay = `${p.title} ${p.category} ${p.subtitle} ${p.keywords}`.toLowerCase();
      return hay.includes(qLower);
    });
    addGroup(
      "Pages",
      matchedPages.slice(off, off + perGroup).map((p) => ({
        id: p.id,
        title: p.title,
        subtitle: p.subtitle,
        meta: p.category,
        nav: { tab: p.tab, navKey: p.navKey, role: p.role || null, settingsTab: p.settingsTab || null, scrollMatch: p.scrollMatch || null }
      })),
      matchedPages.length
    );
  }

  // 2. Non-Secret Settings
  if (want("Settings")) {
    const safeDefs = (settingDefinitions || [])
      .filter((s) => !s.isSecret)
      .map((s) => ({
        key: s.key,
        label: s.label,
        category: `System (${s.category})`,
        tab: "settings",
        settingsTab: s.category === "general" ? "general" : "api"
      }));
    const allSafe = [...STATIC_SAFE_SETTINGS, ...safeDefs];
    const seen = new Set();
    const matchedSettings = allSafe.filter((s) => {
      if (seen.has(s.key)) return false;
      seen.add(s.key);
      return `${s.key} ${s.label} ${s.category}`.toLowerCase().includes(qLower);
    });
    addGroup(
      "Settings",
      matchedSettings.slice(off, off + perGroup).map((s) => ({
        id: `set:${s.key}`,
        title: s.label,
        subtitle: `${s.category} · Key: ${s.key}`,
        meta: "Config",
        nav: { tab: s.tab, settingsTab: s.settingsTab || "general" }
      })),
      matchedSettings.length
    );
  }

  // 3. Students & Teachers (explicitly select safe columns — NEVER password_hash or unsubscribe_token)
  if (want("Students")) {
    const hasRollNo = db
      .prepare("PRAGMA table_info(student_profiles)")
      .all()
      .some((c) => c.name === "roll_number");
    const rollSelect = hasRollNo ? "sp.roll_number" : "'' AS roll_number";
    const rollCond = hasRollNo ? "OR COALESCE(sp.roll_number, '') LIKE ?" : "";
    const stuParams = hasRollNo ? [like, like, like, like] : [like, like, like];
    const rows = db
      .prepare(
        `SELECT u.id, u.full_name, u.email, u.phone, u.verification_status, ${rollSelect}, sp.class_level
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.role = 'student'
           AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? ${rollCond})
         ORDER BY u.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(...stuParams, perGroup, off);
    const total = Number(
      db
        .prepare(
          `SELECT COUNT(*) AS c FROM users u LEFT JOIN student_profiles sp ON sp.user_id = u.id
           WHERE u.role = 'student' AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? ${rollCond})`
        )
        .get(...stuParams)?.c || 0
    );
    addGroup(
      "Students",
      rows.map((r) => ({
        id: `stu:${r.id}`,
        title: r.full_name,
        subtitle: `${r.roll_number || `User #${r.id}`} · ${r.class_level || "Student"} · ${r.phone}`,
        meta: r.verification_status,
        nav: { tab: "users", role: "student", userId: r.id }
      })),
      total
    );
  }

  if (want("Teachers")) {
    const rows = db
      .prepare(
        `SELECT u.id, u.full_name, u.email, u.phone, u.verification_status, tp.qualification
         FROM users u
         LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
         WHERE u.role = 'teacher'
           AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR COALESCE(tp.qualification, '') LIKE ?)
         ORDER BY u.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, perGroup, off);
    addGroup(
      "Teachers",
      rows.map((r) => ({
        id: `tch:${r.id}`,
        title: r.full_name,
        subtitle: `${r.qualification || "Faculty"} · ${r.phone} · ${r.email}`,
        meta: r.verification_status,
        nav: { tab: "users", role: "teacher", userId: r.id }
      })),
      rows.length
    );
  }

  // 4. Referrals & Referral Codes
  if (want("Referrals")) {
    const rows = db
      .prepare(
        `SELECT r.id, r.referral_code_used, r.status, r.paid_months_count, r.required_months, r.reward_amount_credited,
                u1.full_name AS referrer_name, u2.full_name AS referred_name
         FROM referrals r
         JOIN users u1 ON u1.id = r.referrer_user_id
         JOIN users u2 ON u2.id = r.referred_user_id
         WHERE r.referral_code_used LIKE ? OR u1.full_name LIKE ? OR u2.full_name LIKE ? OR r.status LIKE ?
         ORDER BY r.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, perGroup, off);
    addGroup(
      "Referrals",
      rows.map((r) => ({
        id: `ref:${r.id}`,
        title: `${r.referrer_name} -> ${r.referred_name}`,
        subtitle: `Code ${r.referral_code_used} · ${r.paid_months_count}/${r.required_months} mo · Reward ₹${r.reward_amount_credited}`,
        meta: r.status,
        nav: { tab: "referrals", search: r.referral_code_used }
      })),
      rows.length
    );
  }

  // 5. Wallets & Transactions
  if (want("Wallets")) {
    const rows = db
      .prepare(
        `SELECT wt.id, wt.tx_code, wt.tx_type, wt.amount, wt.status, wt.description, u.full_name, w.wallet_type
         FROM wallet_transactions wt
         JOIN wallets w ON w.id = wt.wallet_id
         JOIN users u ON u.id = wt.user_id
         WHERE wt.tx_code LIKE ? OR wt.description LIKE ? OR u.full_name LIKE ? OR u.phone LIKE ?
         ORDER BY wt.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, perGroup, off);
    addGroup(
      "Wallets & Transactions",
      rows.map((r) => ({
        id: `wtx:${r.id}`,
        title: `${r.tx_code} · ${r.full_name} (${r.wallet_type})`,
        subtitle: `${r.tx_type === "credit" ? "+" : "-"}₹${r.amount} · ${r.description}`,
        meta: r.status,
        nav: { tab: "wallets", userId: r.id }
      })),
      rows.length
    );
  }

  // 6. Withdrawals
  if (want("Withdrawals")) {
    const rows = db
      .prepare(
        `SELECT wr.id, wr.request_code, wr.amount, wr.payout_method, wr.upi_id, wr.bank_name, wr.status, u.full_name
         FROM withdrawal_requests wr
         JOIN users u ON u.id = wr.user_id
         WHERE wr.request_code LIKE ? OR u.full_name LIKE ? OR wr.upi_id LIKE ? OR wr.status LIKE ? OR wr.payout_reference LIKE ?
         ORDER BY wr.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, like, perGroup, off);
    addGroup(
      "Withdrawals",
      rows.map((r) => ({
        id: `wdr:${r.id}`,
        title: `${r.request_code} · ${r.full_name} (₹${r.amount})`,
        subtitle: `${r.payout_method.toUpperCase()} ${r.upi_id || r.bank_name || ""}`,
        meta: r.status,
        nav: { tab: "withdrawals" }
      })),
      rows.length
    );
  }

  // 7. Payments, Invoices & Cart Orders
  if (want("Payments")) {
    const rows = db
      .prepare(
        `SELECT p.id, p.invoice_number, p.receipt_number, p.amount, p.verification_status, u.full_name, c.title AS course_title
         FROM payments p
         JOIN users u ON u.id = p.student_id
         LEFT JOIN courses c ON c.id = p.course_id
         WHERE p.invoice_number LIKE ? OR p.receipt_number LIKE ? OR p.utr_reference LIKE ? OR u.full_name LIKE ?
         ORDER BY p.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, perGroup, off);
    addGroup(
      "Payments & Invoices",
      rows.map((r) => ({
        id: `pay:${r.id}`,
        title: `${r.invoice_number || `Payment #${r.id}`} · ${r.full_name}`,
        subtitle: `${r.course_title || "Course"} · ₹${r.amount} ${r.receipt_number ? `· Receipt ${r.receipt_number}` : ""}`,
        meta: r.verification_status,
        nav: { tab: "payments" }
      })),
      rows.length
    );
  }

  // 8. Courses & Batches
  if (want("Courses")) {
    const rows = db
      .prepare(
        `SELECT id, title, category, board, monthly_fee
         FROM courses
         WHERE title LIKE ? OR category LIKE ? OR board LIKE ?
         ORDER BY id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, perGroup, off);
    addGroup(
      "Courses & Batches",
      rows.map((r) => ({
        id: `crs:${r.id}`,
        title: r.title,
        subtitle: `${r.category} · ${r.board} · ₹${r.monthly_fee}/mo`,
        meta: "Course",
        nav: { tab: "courses" }
      })),
      rows.length
    );
  }

  // 9. Inquiries
  if (want("Inquiries")) {
    const rows = db
      .prepare(
        `SELECT id, name, phone, class_or_course, status
         FROM inquiries
         WHERE name LIKE ? OR phone LIKE ? OR class_or_course LIKE ? OR message LIKE ?
         ORDER BY id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, like, like, perGroup, off);
    addGroup(
      "Inquiries",
      rows.map((r) => ({
        id: `inq:${r.id}`,
        title: `${r.name} (${r.phone})`,
        subtitle: `Interest: ${r.class_or_course || "General Inquiry"}`,
        meta: r.status,
        nav: { tab: "cms", scrollMatch: "Website Inquiries" }
      })),
      rows.length
    );
  }

  // 10. Notifications
  if (want("Notifications")) {
    const rows = db
      .prepare(
        `SELECT id, title, message, created_at
         FROM notifications
         WHERE title LIKE ? OR message LIKE ?
         ORDER BY id DESC
         LIMIT ? OFFSET ?`
      )
      .all(like, like, perGroup, off);
    addGroup(
      "Notifications",
      rows.map((r) => ({
        id: `ntf:${r.id}`,
        title: r.title,
        subtitle: r.message,
        meta: String(r.created_at || "").slice(0, 10),
        nav: { tab: "dashboard" }
      })),
      rows.length
    );
  }

  const totalHits = Object.values(groups).reduce((sum, g) => sum + (g.items?.length || 0), 0);
  return {
    query: qRaw,
    totalHits,
    groups,
    suggestions: totalHits === 0 ? ADMIN_FEATURE_REGISTRY.slice(0, 6) : [],
    noResultHint:
      totalHits === 0
        ? `No matching pages, records, or settings found for "${qRaw}". Try searching a student name, referral code (YTR-...), invoice number, or withdrawal status.`
        : ""
  };
}
