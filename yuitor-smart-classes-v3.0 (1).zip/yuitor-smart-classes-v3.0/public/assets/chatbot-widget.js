(() => {
  "use strict";
  if (document.getElementById("yu-ai-guide-root")) return;

  const SHREYA_INTRO =
    "Hello! My name is Shreya, and I am Yuitor Smart Classes’ Smart AI Assistant. How can I help you with courses, fees, admissions, referrals, payouts, OTP login, or Class 6–12 study doubts?";

  let conversationId = sessionStorage.getItem("yuitor_shreya_conv_id") || "";
  let visitorId = sessionStorage.getItem("yuitor_visitor_id") || "";
  if (!visitorId) {
    visitorId = "v-" + Math.random().toString(36).slice(2, 10);
    sessionStorage.setItem("yuitor_visitor_id", visitorId);
  }

  let busy = false;
  let currentRating = 5;

  const isCompactViewport = typeof window !== "undefined" && window.innerWidth <= 480;
  const root = document.createElement("div");
  root.id = "yu-ai-guide-root";
  root.className = "yu-ai-guide-root";
  root.style.cssText = isCompactViewport
    ? "position:fixed;bottom:14px;right:14px;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;font-family:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;"
    : "position:fixed;bottom:22px;right:20px;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;font-family:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.id = "yu-smart-ai-toggle";
  toggle.textContent = "Ask Shreya";
  toggle.setAttribute("aria-label", "Open Ask Shreya AI Assistant");
  toggle.style.cssText = isCompactViewport
    ? "background:#7A0F28;color:#fff;border:2px solid #E6B450;padding:9px 15px;border-radius:999px;font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 10px 24px rgba(45,5,14,.32);"
    : "background:#7A0F28;color:#fff;border:2px solid #E6B450;padding:11px 18px;border-radius:999px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 12px 28px rgba(45,5,14,.32);";

  const box = document.createElement("div");
  box.id = "yu-shreya-box";
  box.hidden = true;
  box.style.cssText =
    "width:360px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 104px);display:flex;flex-direction:column;background:#fff;border:1px solid #EADFE2;border-radius:16px;box-shadow:0 18px 40px rgba(45,5,14,.28);overflow:hidden;margin-bottom:10px;";
  box.style.display = "none";

  box.innerHTML = `
    <div style="background:linear-gradient(135deg,#3A0714,#7A0F28);color:#fff;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-shrink:0;">
      <div>
        <div style="font-weight:700;font-size:14.5px;font-family:'Playfair Display',Georgia,serif;">Shreya · Yuitor AI Assistant</div>
        <div style="font-size:11px;color:#F3CF7A;">Courses, Fees, Referrals, Payouts, OTP &amp; Doubts</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <button type="button" id="yu-chat-new-btn" title="Start new chat" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">New</button>
        <button type="button" id="yu-chat-info-btn" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Info</button>
        <button type="button" id="yu-chat-rate-btn" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer;">Rate</button>
        <button type="button" id="yu-chat-close" aria-label="Close Shreya AI Chat" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
      </div>
    </div>
    <div id="yu-chat-contact" hidden style="padding:10px;background:#FAF7F5;border-bottom:1px solid #EADFE2;display:none;gap:6px;font-size:12px;flex-shrink:0;">
      <input id="yu-v-name" type="text" placeholder="Your name (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
        <input id="yu-v-phone" type="tel" placeholder="Mobile (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
        <input id="yu-v-email" type="email" placeholder="Email (optional)" style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      </div>
    </div>
    <form id="yu-chat-rate" hidden style="padding:10px;background:#FFF9EB;border-bottom:1px solid #F0DBA8;display:none;gap:6px;font-size:12px;flex-shrink:0;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <strong style="color:#1D1014;">Rate Shreya</strong>
        <div id="yu-stars" style="display:flex;gap:4px;"></div>
      </div>
      <input id="yu-fb-text" type="text" placeholder="Optional feedback..." style="padding:6px 8px;border:1px solid #EADFE2;border-radius:8px;font-size:12px;background:#ffffff;color:#1D1014;">
      <button type="submit" style="background:#7A0F28;color:#fff;border:0;padding:6px 10px;border-radius:8px;font-weight:600;cursor:pointer;">Save Feedback</button>
    </form>
    <div id="yu-chat-msgs" style="height:280px;max-height:52dvh;overflow-y:auto;padding:12px;background:#FAF7F5;display:flex;flex-direction:column;gap:8px;font-size:13px;line-height:1.48;"></div>
    <form id="yu-chat-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #EADFE2;background:#fff;flex-shrink:0;">
      <input id="yu-chat-in" type="text" maxlength="600" required placeholder="Ask in English, Hindi or Hinglish..." style="flex:1;padding:8px 10px;border:1px solid #EADFE2;border-radius:10px;font-size:13px;min-width:0;background:#ffffff;color:#1D1014;">
      <button type="submit" id="yu-chat-submit" style="background:#7A0F28;color:#fff;border:0;padding:8px 14px;border-radius:10px;font-weight:700;cursor:pointer;white-space:nowrap;">Send</button>
    </form>
  `;

  root.append(box, toggle);
  document.body.appendChild(root);

  const msgsEl = box.querySelector("#yu-chat-msgs");
  const form = box.querySelector("#yu-chat-form");
  const input = box.querySelector("#yu-chat-in");
  const submitBtn = box.querySelector("#yu-chat-submit");
  const closeBtn = box.querySelector("#yu-chat-close");
  const newBtn = box.querySelector("#yu-chat-new-btn");
  const infoBtn = box.querySelector("#yu-chat-info-btn");
  const rateBtn = box.querySelector("#yu-chat-rate-btn");
  const contactPanel = box.querySelector("#yu-chat-contact");
  const rateForm = box.querySelector("#yu-chat-rate");
  const starsWrap = box.querySelector("#yu-stars");

  const localMessages = [{ sender: "assistant", message: SHREYA_INTRO }];
  let isEscalated = false;

  const STARTER_CHIPS = [
    "Class 10 & NEET fees?",
    "Referral & payout rules?",
    "OTP email ya mobile par?",
    "Book a free demo class",
  ];

  const LINK_TOKEN_RE =
    /(\+91[\s-]?\d{2,5}[\s-]?\d{4,6}(?:[\s-]?\d{4})?|[a-zA-Z0-9._%+-]+@yuitor\.com|\/(?:register\/teacher|register\/student|register\/parent|course\/[a-z0-9-]+|class-(?:6|7|8|9|10|11|12)|fee-calculator|admission|scholarship|teachers|courses|contact|register|refund|login|student\/|teacher\/|parent\/))/g;

  function appendRichMessageText(container, text) {
    container.textContent = "";
    const str = String(text || "");
    let lastIndex = 0;
    LINK_TOKEN_RE.lastIndex = 0;
    let match;
    while ((match = LINK_TOKEN_RE.exec(str)) !== null) {
      if (match.index > lastIndex) {
        container.appendChild(document.createTextNode(str.slice(lastIndex, match.index)));
      }
      const token = match[0];
      const a = document.createElement("a");
      a.textContent = token;
      if (token.startsWith("+91")) {
        a.href = `tel:${token.replace(/[^+\d]/g, "")}`;
      } else if (token.includes("@")) {
        a.href = `mailto:${token}`;
      } else {
        a.href = token;
      }
      a.style.cssText = "color:#7A0F28;font-weight:700;text-decoration:underline;text-underline-offset:2px;";
      container.appendChild(a);
      lastIndex = LINK_TOKEN_RE.lastIndex;
    }
    if (lastIndex < str.length) {
      container.appendChild(document.createTextNode(str.slice(lastIndex)));
    }
  }

  function renderMessages(list) {
    msgsEl.innerHTML = "";
    const items = Array.isArray(list) && list.length ? list : [{ sender: "assistant", message: SHREYA_INTRO }];
    for (const m of items) {
      const div = document.createElement("div");
      const isUser = m.sender === "user";
      div.style.cssText = isUser
        ? "align-self:flex-end;background:#7A0F28;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;word-break:break-word;"
        : "align-self:flex-start;background:#fff;border:1px solid #EADFE2;color:#1D1014;padding:9px 11px;border-radius:12px;max-width:90%;white-space:pre-line;word-break:break-word;";
      if (isUser) {
        div.textContent = m.message;
      } else {
        appendRichMessageText(div, m.message);
      }
      msgsEl.appendChild(div);
    }
    if (isEscalated) {
      const escBanner = document.createElement("div");
      escBanner.style.cssText =
        "align-self:stretch;background:#fef3c7;border:1px solid #fcd34d;color:#92400e;padding:7px 10px;border-radius:10px;font-size:11.5px;font-weight:600;";
      appendRichMessageText(
        escBanner,
        "Flagged for Yuitor Team follow-up. For urgent counselling, call +91 78-2728-9292 or add your number in Info."
      );
      msgsEl.appendChild(escBanner);
    }
    if (items.length <= 1) {
      const chipWrap = document.createElement("div");
      chipWrap.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin-top:4px;";
      for (const label of STARTER_CHIPS) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.textContent = label;
        chip.style.cssText =
          "background:#FFF7F8;color:#7A0F28;border:1px solid #E5C8D0;border-radius:999px;padding:5px 10px;font-size:11.5px;font-weight:600;cursor:pointer;text-align:left;";
        chip.addEventListener("click", () => sendMessage(label));
        chipWrap.appendChild(chip);
      }
      msgsEl.appendChild(chipWrap);
    }
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function renderStars() {
    starsWrap.innerHTML = "";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = i <= currentRating ? "★" : "☆";
      b.style.cssText = `background:none;border:0;font-size:16px;cursor:pointer;color:${i <= currentRating ? "#d97706" : "#94a3b8"};padding:0 2px;`;
      b.addEventListener("click", () => {
        currentRating = i;
        renderStars();
      });
      starsWrap.appendChild(b);
    }
  }
  renderStars();
  renderMessages(localMessages);

  function localFallbackReply(text) {
    const q = String(text || "").trim().toLowerCase();
    const isHindi =
      /[\u0900-\u097F]|\b(kya|kaise|kitni|fees|batayein|batao|chahiye|karna|nahi|ho raha|madad|admission lena|namaste|milta|milega|paisa|nikalna)\b/i.test(
        text
      );
    if (/\b(admin\s*(url|link|path|slug|password|credentials?|otp)|\.env|api_key|secret_key|select\s+\*\s+from|dump\s+database|yt-ctrl|ignore\s+previous|system\s*prompt)\b/i.test(q)) {
      return isHindi
        ? "Suraksha aur privacy rules ke karan main Admin panel URL, passwords, OTP, API keys, database details, ya kisi dusre user ka personal data share nahi kar sakti."
        : "For security and privacy protection, I cannot share admin URLs, credentials, passwords, OTPs, API keys, database internals, or other users' private data.";
    }
    if (/^(hi|hello|hey|namaste|hlo)[!.\s]*$/i.test(q)) return SHREYA_INTRO;
    if (/\b(who are you|your name|kaun ho|aap kaun)\b/i.test(q)) return SHREYA_INTRO;
    if (/\b(referral|refer|payout|withdraw|withdrawal|wallet|milestone|reward)\b/i.test(q)) {
      return isHindi
        ? "Yuitor Refer & Earn Program: Approved Students & Teachers ko apne portal mein unique referral code milta hai. Referred student ke 3 months verified fee complete hone par reward Available Balance mein credit hota hai. Teachers ₹500+ balance par UPI/Bank payout withdraw kar sakte hain aur Students course fees mein use kar sakte hain."
        : "Yuitor Refer & Earn: Approved Students and Teachers get a unique referral code in their portal. Referrals qualify after 3 verified paid months of coaching fees, unlocking cumulative rewards. Teachers can withdraw (min ₹500) via UPI/Bank Transfer, and Students can apply wallet balance to course fees.";
    }
    if (/\b(otp|login|sign in|password)\b/i.test(q)) {
      return isHindi
        ? "Student, Teacher aur Parent teeno ke liye Registration (/register) aur Login (/login) par Email (Mail) ya Mobile Number (SMS) OTP ka option available hai!"
        : "Students, Teachers, and Parents can choose to receive 6-digit OTP via Email (Mail) or Mobile Number (SMS) during both Registration (/register) and Login (/login).";
    }
    if (/\b(resume|teacher register|teacher registration|apply as teacher)\b/i.test(q)) {
      return isHindi
        ? "Teacher Registration ke liye /register/teacher par apna updated PDF/DOC/DOCX resume upload karein aur Email ya Mobile OTP verify karein."
        : "To apply as a teacher, visit /register/teacher, upload a valid PDF/DOC/DOCX resume, and verify your Email or Mobile OTP.";
    }
    if (/\b(class\s*6|class\s*7|class\s*8|6th|7th|8th)\b/i.test(q)) {
      return "Classes 6–8 Coaching fees: Class 6 & 7 ₹1,000/month and Class 8 ₹1,100/month. Visit /fee-calculator or apply on /admission.";
    }
    if (/\b(class\s*9|class\s*10|9th|10th)\b/i.test(q)) {
      return "Class 9 Coaching is ₹1,300/month and Class 10 Coaching is ₹1,400/month (UP Board, ICSE & State Board). Visit /admission or /fee-calculator.";
    }
    if (/\b(class\s*11|class\s*12|11th|12th)\b/i.test(q)) {
      return "Class 11 Coaching is ₹1,600/month and Class 12 Coaching is ₹1,700/month. Apply on /admission.";
    }
    if (/\b(neet|jee)\b/i.test(q)) {
      return "NEET & JEE Coaching fees: ₹2,400/month (₹24,500/year). Book a free demo on /admission or call +91 78-2728-9292.";
    }
    if (/\b(cuet|nda|ssc|banking)\b/i.test(q)) {
      return "Competitive Exam Coaching: CUET ₹1,800/month, NDA ₹2,000/month, SSC ₹1,600/month, Banking ₹1,600/month at Yuitor Muradnagar.";
    }
    if (/\b(computer|dca|tally|ccc|coding|python)\b/i.test(q)) {
      return "Computer Classes (DCA/Tally/CCC) are ₹1,000/month (/course/computer-classes) and Coding Classes (Python/Web Dev) are ₹1,500/month (/course/coding-classes).";
    }
    if (/\b(english|spoken)\b/i.test(q)) {
      return "Spoken English Coaching is ₹900/month (₹9,200/year). Visit /course/spoken-english for details.";
    }
    if (/\b(address|location|where|muradnagar|kahan|contact|phone|whatsapp|call)\b/i.test(q)) {
      return "Yuitor Smart Classes is at Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, UP. Call/WhatsApp: +91 78-2728-9292 | inquiry@yuitor.com.";
    }
    return isHindi
      ? "Main Yuitor Smart Classes ke 19 courses, fees (/fee-calculator), admission (/admission), Referral & Payouts, aur OTP login (/login) mein madad kar sakti hoon. Call/WhatsApp: +91 78-2728-9292."
      : "I can help with Yuitor Smart Classes courses (/courses), fees (/fee-calculator), admissions (/admission), Referral & Payouts, and OTP login (/login). For direct counselling, call +91 78-2728-9292.";
  }

  function getCsrfToken() {
    try {
      const m = document.cookie.match(/(?:^|;\s*)yu_csrf=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : "";
    } catch {
      return "";
    }
  }

  async function safeFetchJson(url, payload) {
    const headers = { "Content-Type": "application/json", Accept: "application/json" };
    const csrf = getCsrfToken();
    if (csrf) headers["X-CSRF-Token"] = csrf;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers,
      body: JSON.stringify(payload || {}),
    });
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { ok: res.ok, status: res.status, data };
  }

  async function ensureSession() {
    try {
      const { ok, data } = await safeFetchJson("/api/public/chatbot/session", { conversationId, visitorId });
      if (!ok) return;
      if (data?.conversation?.id) {
        conversationId = data.conversation.id;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      if (Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      }
    } catch {
      // Keep local intro visible cleanly
    }
  }

  async function sendMessage(text) {
    const clean = String(text || "").trim();
    if (!clean || busy) return;
    busy = true;
    input.disabled = true;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.style.opacity = "0.65";
    }
    try {
      sessionStorage.setItem("yuitor_shreya_interacted", "1");
    } catch {
      // Ignore storage restrictions
    }

    localMessages.push({ sender: "user", message: clean });

    const chipRow = msgsEl.querySelector("div > button")?.parentElement;
    if (chipRow) chipRow.remove();

    const uBubble = document.createElement("div");
    uBubble.style.cssText =
      "align-self:flex-end;background:#7A0F28;color:#fff;padding:9px 11px;border-radius:12px;max-width:88%;white-space:pre-line;word-break:break-word;";
    uBubble.textContent = clean;
    msgsEl.appendChild(uBubble);

    const typing = document.createElement("div");
    typing.style.cssText =
      "align-self:flex-start;background:#fff;border:1px solid #EADFE2;color:#6E5A60;padding:7px 11px;border-radius:12px;font-size:12px;";
    typing.textContent = "Shreya is typing...";
    msgsEl.appendChild(typing);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    input.value = "";

    try {
      if (!conversationId) await ensureSession();
      const payload = {
        conversationId,
        message: clean,
        visitorName: box.querySelector("#yu-v-name").value.trim() || undefined,
        visitorPhone: box.querySelector("#yu-v-phone").value.trim() || undefined,
        visitorEmail: box.querySelector("#yu-v-email").value.trim() || undefined,
      };
      let { ok, data } = await safeFetchJson("/api/public/chatbot/message", payload);
      if (!ok && conversationId) {
        conversationId = "";
        sessionStorage.removeItem("yuitor_shreya_conv_id");
        ({ ok, data } = await safeFetchJson("/api/public/chatbot/message", { ...payload, conversationId: "" }));
      }
      if (data?.conversationId) {
        conversationId = data.conversationId;
        sessionStorage.setItem("yuitor_shreya_conv_id", conversationId);
      }
      isEscalated = Boolean(data?.escalated);
      if (ok && Array.isArray(data?.messages) && data.messages.length) {
        renderMessages(data.messages);
      } else if (ok && data?.reply) {
        appendRichMessageText(typing, data.reply);
        typing.style.color = "#0f172a";
      } else if (data?.error) {
        typing.textContent = data.error;
        typing.style.color = "#991b1b";
      } else {
        const reply = localFallbackReply(clean);
        localMessages.push({ sender: "assistant", message: reply });
        appendRichMessageText(typing, reply);
        typing.style.color = "#0f172a";
      }
    } catch {
      const reply = localFallbackReply(clean);
      localMessages.push({ sender: "assistant", message: reply });
      appendRichMessageText(typing, reply);
      typing.style.color = "#0f172a";
    } finally {
      busy = false;
      input.disabled = false;
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.opacity = "1";
      }
      input.focus();
    }
  }

  function openShreyaBox() {
    box.hidden = false;
    box.style.display = "flex";
    try {
      sessionStorage.setItem("yuitor_shreya_interacted", "1");
    } catch {
      // Ignore storage restrictions
    }
    document.getElementById("yu-shreya-doubt-popup")?.remove();
    ensureSession();
    window.setTimeout(() => input.focus(), 60);
  }

  function closeShreyaBox() {
    box.hidden = true;
    box.style.display = "none";
  }

  window.YuitorShreya = {
    open: openShreyaBox,
    close: closeShreyaBox,
    toggle() {
      if (box.hidden) openShreyaBox();
      else closeShreyaBox();
    },
    isOpen() {
      return !box.hidden;
    },
  };

  toggle.addEventListener("click", () => {
    window.YuitorShreya.toggle();
  });
  closeBtn.addEventListener("click", () => {
    closeShreyaBox();
  });
  newBtn?.addEventListener("click", async () => {
    conversationId = "";
    isEscalated = false;
    sessionStorage.removeItem("yuitor_shreya_conv_id");
    localMessages.length = 0;
    localMessages.push({ sender: "assistant", message: SHREYA_INTRO });
    renderMessages(localMessages);
    await ensureSession();
    input.focus();
  });
  infoBtn.addEventListener("click", () => {
    contactPanel.hidden = !contactPanel.hidden;
    contactPanel.style.display = contactPanel.hidden ? "none" : "grid";
  });
  rateBtn.addEventListener("click", () => {
    rateForm.hidden = !rateForm.hidden;
    rateForm.style.display = rateForm.hidden ? "none" : "grid";
  });
  rateForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      if (!conversationId) await ensureSession();
      await safeFetchJson("/api/public/chatbot/feedback", {
        conversationId,
        rating: currentRating,
        feedback: box.querySelector("#yu-fb-text").value.trim(),
        resolved: currentRating >= 4,
      });
    } catch {
      // Keep UI responsive
    }
    rateForm.hidden = true;
    rateForm.style.display = "none";
    const note = document.createElement("div");
    note.style.cssText =
      "align-self:center;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;padding:5px 10px;border-radius:999px;font-size:11.5px;font-weight:700;";
    note.textContent = `Thank you! Feedback saved (${currentRating}/5).`;
    msgsEl.appendChild(note);
    msgsEl.scrollTop = msgsEl.scrollHeight;
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendMessage(input.value);
  });
})();
