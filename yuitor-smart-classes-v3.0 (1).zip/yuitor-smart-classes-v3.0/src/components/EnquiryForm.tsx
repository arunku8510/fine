import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import type { BackendBranch, BackendCourse } from '../types';
import { submitPublicInquiry } from '../hooks/useBootstrap';
import { validateInquiryPayload } from '../utils/catalog';

interface EnquiryFormProps {
  heading?: string;
  subheading?: string;
  ctaLabel?: string;
  defaultCourse?: string;
  source?: string;
  courses?: BackendCourse[];
  branches?: BackendBranch[];
  showDemoFields?: boolean;
  compact?: boolean;
  onSuccess?: () => void;
}

const DEFAULT_PROGRAM_OPTIONS = [
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10',
  'Class 11',
  'Class 12',
  'CBSE Board Coaching',
  'UP Board Coaching',
  'ICSE Coaching',
  'State Board Coaching',
  'NEET Coaching',
  'JEE Coaching',
  'CUET Coaching',
  'NDA Coaching',
  'SSC Coaching',
  'Banking Coaching',
  'Computer Classes',
  'Spoken English',
  'Coding Classes',
];

export function EnquiryForm({
  heading = 'Book Your Free 2-Day Demo Class',
  subheading = 'Speak with our Muradnagar academic counsellor for batch timings, fee structure & scholarship test.',
  ctaLabel = 'Request Free Demo & Callback',
  defaultCourse = 'Class 10',
  source = 'website_enquiry',
  courses = [],
  branches = [],
  showDemoFields = false,
  compact = false,
  onSuccess,
}: EnquiryFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [course, setCourse] = useState(defaultCourse);
  const [branchId, setBranchId] = useState('');
  const [demoDate, setDemoDate] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverSuccess, setServerSuccess] = useState('');
  const [serverError, setServerError] = useState('');

  const courseOptions = Array.from(
    new Set([defaultCourse, ...DEFAULT_PROGRAM_OPTIONS])
  ).filter(Boolean);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setServerError('');
    setServerSuccess('');

    const payload = {
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim() || undefined,
      class_or_course: course,
      message: message.trim() || undefined,
      source,
      branch_id: branchId || undefined,
      demoDate: demoDate || undefined,
    };

    const validation = validateInquiryPayload(payload);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    setSubmitting(true);
    try {
      const res = await submitPublicInquiry(payload);
      setServerSuccess(res.message);
      setName('');
      setPhone('');
      setEmail('');
      setMessage('');
      setDemoDate('');
      onSuccess?.();
    } catch (err) {
      setServerError(err instanceof Error ? err.message : 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="bg-white border border-[#EADFE2] rounded-2xl p-6 sm:p-7 shadow-[0_14px_36px_rgba(45,5,14,0.08)]">
      {heading && (
        <div className="mb-5">
          <h3 className="font-editorial text-2xl font-bold text-[#1D1014] leading-snug">
            {heading}
          </h3>
          {subheading && (
            <p className="mt-1.5 text-sm text-[#5E4B51] leading-relaxed">{subheading}</p>
          )}
        </div>
      )}

      {serverSuccess && (
        <div
          role="status"
          className="mb-4 flex items-start gap-2.5 rounded-xl bg-emerald-50 border border-emerald-200 p-3.5 text-sm text-emerald-900"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" aria-hidden="true" />
          <span>{serverSuccess}</span>
        </div>
      )}

      {serverError && (
        <div
          role="alert"
          className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 p-3.5 text-sm text-red-900"
        >
          <AlertCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" aria-hidden="true" />
          <span>{serverError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-3.5">
        <div>
          <label htmlFor={`enq-name-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
            Full Name *
          </label>
          <input
            id={`enq-name-${source}`}
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your full name"
            className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] placeholder:text-[#8E7B81] focus:border-[#7A0F28] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#7A0F28]/15"
            required
          />
          {errors.name && <p className="mt-1 text-xs text-red-700">{errors.name}</p>}
        </div>

        <div className={compact ? 'grid grid-cols-1 gap-3.5' : 'grid grid-cols-1 sm:grid-cols-2 gap-3.5'}>
          <div>
            <label htmlFor={`enq-phone-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
              Mobile / WhatsApp Number *
            </label>
            <input
              id={`enq-phone-${source}`}
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 98765 43210"
              className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] placeholder:text-[#8E7B81] focus:border-[#7A0F28] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#7A0F28]/15"
              required
            />
            {errors.phone && <p className="mt-1 text-xs text-red-700">{errors.phone}</p>}
          </div>

          <div>
            <label htmlFor={`enq-email-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
              Email Address
            </label>
            <input
              id={`enq-email-${source}`}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] placeholder:text-[#8E7B81] focus:border-[#7A0F28] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#7A0F28]/15"
            />
            {errors.email && <p className="mt-1 text-xs text-red-700">{errors.email}</p>}
          </div>
        </div>

        <div>
          <label htmlFor={`enq-course-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
            Select Program / Course *
          </label>
          <select
            id={`enq-course-${source}`}
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] focus:border-[#7A0F28] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#7A0F28]/15"
          >
            {courseOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errors.class_or_course && (
            <p className="mt-1 text-xs text-red-700">{errors.class_or_course}</p>
          )}
        </div>

        {showDemoFields && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {branches.length > 0 && (
              <div>
                <label htmlFor={`enq-branch-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
                  Preferred Campus / Center
                </label>
                <select
                  id={`enq-branch-${source}`}
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] focus:border-[#7A0F28] focus:bg-white focus:outline-none"
                >
                  <option value="">Online Live / Nearest Hub</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label htmlFor={`enq-date-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
                Preferred Demo / Counselling Date
              </label>
              <input
                id={`enq-date-${source}`}
                type="date"
                value={demoDate}
                onChange={(e) => setDemoDate(e.target.value)}
                className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2.5 text-sm text-[#1D1014] focus:border-[#7A0F28] focus:bg-white focus:outline-none"
              />
            </div>
          </div>
        )}

        {!compact && (
          <div>
            <label htmlFor={`enq-msg-${source}`} className="block text-xs font-semibold text-[#4B3B40] mb-1">
              Questions or Academic Background (Optional)
            </label>
            <textarea
              id={`enq-msg-${source}`}
              rows={2}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Share your qualification, target exam window, or scholarship query..."
              className="w-full rounded-xl border border-[#DFD1D5] bg-[#FCFAF8] px-3.5 py-2 text-sm text-[#1D1014] placeholder:text-[#8E7B81] focus:border-[#7A0F28] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#7A0F28]/15"
            />
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#7A0F28] px-5 py-3 text-sm font-semibold text-white hover:bg-[#58091B] disabled:opacity-60 transition-colors cursor-pointer whitespace-nowrap"
        >
          <span>{submitting ? 'Submitting Enquiry...' : ctaLabel}</span>
          <ArrowRight className="w-4 h-4" aria-hidden="true" />
        </button>

        <p className="text-[11px] text-[#76646A] text-center">
          Saved directly to our Admissions CRM. Zero spam — verified academic counselling only.
        </p>
      </form>
    </div>
  );
}
