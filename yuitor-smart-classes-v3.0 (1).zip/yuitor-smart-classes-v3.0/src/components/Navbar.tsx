import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Menu, X, ShoppingBag, Phone } from 'lucide-react';
import {
  BOARD_LINKS,
  BRAND_INFO,
  CLASS_LINKS,
  EXAM_LINKS,
  SKILL_LINKS,
} from '../data/siteContent';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onOpenEnquiry: (course?: string) => void;
}

const RESOURCE_LINKS = [
  { label: 'All Courses & Fees', path: '/courses' },
  { label: 'Subjects Directory', path: '/subjects' },
  { label: 'Fee Calculator', path: '/fee-calculator' },
  { label: 'Scholarships', path: '/scholarship' },
  { label: 'Why Yuitor (Comparison)', path: '/comparison' },
  { label: 'Results & Toppers', path: '/results' },
  { label: 'Teachers & Mentors', path: '/teachers' },
  { label: 'Campus Gallery', path: '/gallery' },
  { label: 'Study Blog & Tips', path: '/blog' },
  { label: 'Student Testimonials', path: '/testimonials' },
  { label: 'FAQs', path: '/faqs' },
];

export function Navbar({ currentPath, onNavigate, onOpenEnquiry }: NavbarProps) {
  const [openMenu, setOpenMenu] = useState<'programs' | 'resources' | 'portals' | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [ribbonVisible, setRibbonVisible] = useState(true);
  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    setOpenMenu(null);
    setMobileOpen(false);
    onNavigate(path);
  }

  return (
    <div ref={navRef} className="yu-shared-header w-full">
      {/* Non-sticky top announcement ribbon (Simandhar reference visual hierarchy) */}
      {ribbonVisible && (
        <div className="bg-[#58091B] text-white text-xs sm:text-[13px]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex items-center justify-between gap-4">
            <a
              href="/admission"
              onClick={(e) => go(e, '/admission')}
              className="flex items-center gap-2.5 truncate hover:text-[#F3CF7A] transition-colors"
            >
              <span className="truncate font-medium">
                Admissions Open 2026–27 · Classes 6–12, CBSE, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking &amp; Skill Courses
              </span>
              <span className="hidden sm:inline-block shrink-0 rounded bg-white text-[#7A0F28] font-bold px-2.5 py-0.5 text-[11px]">
                Book Free Demo
              </span>
            </a>
            <button
              type="button"
              onClick={() => setRibbonVisible(false)}
              aria-label="Dismiss announcement banner"
              className="shrink-0 text-white/80 hover:text-white p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Sticky single-row 3-zone top navigation bar */}
      <header className="sticky top-0 z-40 bg-white/97 backdrop-blur border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-5">
          {/* Zone 1: Authentic Yuitor Smart Classes Logo + Wordmark & Tagline */}
          <a
            href="/"
            onClick={(e) => go(e, '/')}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 group"
          >
            <img
              src={BRAND_INFO.logo}
              alt="Yuitor Smart Classes Logo"
              className="w-10 h-10 rounded-full object-contain bg-white border border-[#EADFE2] p-0.5 shadow-xs shrink-0"
            />
            <span className="flex flex-col leading-none">
              <span className="font-editorial text-base sm:text-lg font-bold tracking-tight text-[#7A0F28]">
                {BRAND_INFO.name}
              </span>
              <span className="font-editorial italic text-[11px] text-[#6B4A52] tracking-wide mt-0.5">
                Ek Kadam Safalta Ki Our
              </span>
            </span>
          </a>

          {/* Zone 2: Clean single-line navigation controls */}
          <nav
            aria-label="Primary navigation"
            className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#2A181D]"
          >
            <div className="relative">
              <button
                type="button"
                aria-expanded={openMenu === 'programs'}
                onClick={() => setOpenMenu(openMenu === 'programs' ? null : 'programs')}
                className={`inline-flex items-center gap-1 py-1 hover:text-[#7A0F28] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  currentPath.startsWith('/class/') ||
                  currentPath.startsWith('/board/') ||
                  currentPath.startsWith('/exam/') ||
                  currentPath.startsWith('/course') ||
                  currentPath === '/subjects'
                    ? 'text-[#7A0F28] font-semibold'
                    : ''
                }`}
              >
                <span>Classes &amp; Courses</span>
                <ChevronDown className="w-4 h-4" aria-hidden="true" />
              </button>
              {openMenu === 'programs' && (
                <div className="absolute left-0 top-full mt-3 w-[760px] max-w-[92vw] rounded-2xl bg-white border border-[#EADFE2] shadow-[0_24px_60px_rgba(45,5,14,0.16)] p-5 grid grid-cols-3 gap-5 z-50">
                  {/* Col 1: Classes 6-12 & Boards */}
                  <div>
                    <div className="text-[11px] font-bold uppercase tracking-wider text-[#7A0F28] mb-2.5 px-2">
                      School Classes (6–12)
                    </div>
                    <div className="grid grid-cols-2 gap-1">
                      {CLASS_LINKS.map((item) => (
                        <a
                          key={item.path}
                          href={item.path}
                          onClick={(e) => go(e, item.path)}
                          className="rounded-lg px-2.5 py-2 text-sm font-medium text-[#1D1014] hover:bg-[#FAF7F5] hover:text-[#7A0F28] transition-colors"
                        >
                          {item.label}
                        </a>
                      ))}
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-[#F0E6E9]">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#7A0F28] mb-1.5 px-2">
                        Boards Coaching
                      </div>
                      {BOARD_LINKS.map((item) => (
                        <a
                          key={item.path}
                          href={item.path}
                          onClick={(e) => go(e, item.path)}
                          className="block rounded-lg px-2.5 py-1.5 text-sm text-[#2A181D] hover:bg-[#FAF7F5] hover:text-[#7A0F28] transition-colors"
                        >
                          {item.label}
                        </a>
                      ))}
                    </div>
                  </div>

                  {/* Col 2: Competitive Exams */}
                  <div>
                    <div className="text-[11px] font-bold uppercase tracking-wider text-[#7A0F28] mb-2.5 px-2">
                      Boards &amp; Competitive Exams
                    </div>
                    <div className="space-y-1">
                      {EXAM_LINKS.map((item) => (
                        <a
                          key={item.path}
                          href={item.path}
                          onClick={(e) => go(e, item.path)}
                          className="block rounded-lg px-2.5 py-2 hover:bg-[#FAF7F5] transition-colors"
                        >
                          <div className="text-sm font-semibold text-[#1D1014]">{item.label}</div>
                          <div className="text-[11px] text-[#6B585E] line-clamp-1">{item.desc}</div>
                        </a>
                      ))}
                    </div>
                  </div>

                  {/* Col 3: Skill Courses */}
                  <div className="flex flex-col justify-between">
                    <div>
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#7A0F28] mb-2.5 px-2">
                        Skill Courses
                      </div>
                      <div className="space-y-1">
                        {SKILL_LINKS.map((item) => (
                          <a
                            key={item.path}
                            href={item.path}
                            onClick={(e) => go(e, item.path)}
                            className="block rounded-lg px-2.5 py-2 hover:bg-[#FAF7F5] transition-colors"
                          >
                            <div className="text-sm font-semibold text-[#1D1014]">{item.label}</div>
                            <div className="text-[11px] text-[#6B585E] line-clamp-1">{item.desc}</div>
                          </a>
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 pt-3 border-t border-[#F0E6E9] space-y-1.5">
                      <a
                        href="/courses"
                        onClick={(e) => go(e, '/courses')}
                        className="block text-center rounded-xl bg-[#7A0F28] hover:bg-[#58091B] text-white text-xs font-semibold py-2.5 transition-colors"
                      >
                        View All Courses &amp; Fees →
                      </a>
                      <a
                        href="/subjects"
                        onClick={(e) => go(e, '/subjects')}
                        className="block text-center rounded-xl border border-[#EADFE2] hover:border-[#7A0F28] text-[#7A0F28] text-xs font-semibold py-2 transition-colors"
                      >
                        Browse Subjects Directory
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <a
              href="/about"
              onClick={(e) => go(e, '/about')}
              className={`py-1 hover:text-[#7A0F28] transition-colors whitespace-nowrap shrink-0 ${
                currentPath.startsWith('/about') ? 'text-[#7A0F28] font-semibold' : ''
              }`}
            >
              About Us
            </a>

            <a
              href="/results"
              onClick={(e) => go(e, '/results')}
              className={`py-1 hover:text-[#7A0F28] transition-colors whitespace-nowrap shrink-0 ${
                currentPath === '/results' || currentPath === '/alumni' ? 'text-[#7A0F28] font-semibold' : ''
              }`}
            >
              Results
            </a>

            <div className="relative">
              <button
                type="button"
                aria-expanded={openMenu === 'resources'}
                onClick={() => setOpenMenu(openMenu === 'resources' ? null : 'resources')}
                className="inline-flex items-center gap-1 py-1 hover:text-[#7A0F28] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Resources</span>
                <ChevronDown className="w-4 h-4" aria-hidden="true" />
              </button>
              {openMenu === 'resources' && (
                <div className="absolute left-0 top-full mt-3 w-64 rounded-2xl bg-white border border-[#EADFE2] shadow-[0_20px_50px_rgba(45,5,14,0.14)] p-2 z-50">
                  {RESOURCE_LINKS.map((item) => (
                    <a
                      key={item.path}
                      href={item.path}
                      onClick={(e) => go(e, item.path)}
                      className="block rounded-lg px-3 py-2 text-sm text-[#2A181D] hover:bg-[#FAF7F5] hover:text-[#7A0F28] transition-colors"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href="/contact"
              onClick={(e) => go(e, '/contact')}
              className={`py-1 hover:text-[#7A0F28] transition-colors whitespace-nowrap shrink-0 ${
                currentPath.startsWith('/contact') || currentPath === '/admission'
                  ? 'text-[#7A0F28] font-semibold'
                  : ''
              }`}
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: Separate Student/Parent & Teacher Portal Access + Cart + Primary Action */}
          <div className="hidden lg:flex items-center gap-2.5 shrink-0">
            <div className="relative">
              <button
                type="button"
                aria-expanded={openMenu === 'portals'}
                onClick={() => setOpenMenu(openMenu === 'portals' ? null : 'portals')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-semibold text-[#7A0F28] border border-[#7A0F28]/35 rounded-lg hover:bg-[#FAF7F5] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Portal Login</span>
                <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
              {openMenu === 'portals' && (
                <div className="absolute right-0 top-full mt-2.5 w-60 rounded-2xl bg-white border border-[#EADFE2] shadow-[0_20px_50px_rgba(45,5,14,0.14)] p-2 z-50">
                  <a
                    href="/student/login"
                    onClick={(e) => go(e, '/student/login')}
                    className="block rounded-xl px-3 py-2.5 hover:bg-[#FAF7F5] transition-colors"
                  >
                    <div className="text-sm font-bold text-[#1D1014]">Student &amp; Parent Login</div>
                    <div className="text-[11px] text-[#6B585E]">Sign in or Register as Student / Parent</div>
                  </a>
                  <a
                    href="/teacher/login"
                    onClick={(e) => go(e, '/teacher/login')}
                    className="block rounded-xl px-3 py-2.5 hover:bg-[#FAF7F5] transition-colors mt-0.5"
                  >
                    <div className="text-sm font-bold text-[#1D1014]">Teacher / Faculty Login</div>
                    <div className="text-[11px] text-[#6B585E]">Dedicated Faculty Login &amp; Registration</div>
                  </a>
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={() => {
                if (window.YuitorAddons?.openCartDrawer) {
                  window.YuitorAddons.openCartDrawer();
                } else {
                  onNavigate('/courses');
                }
              }}
              aria-label="Open course cart"
              className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-[#EADFE2] text-[#4B3B40] hover:border-[#7A0F28] hover:text-[#7A0F28] transition-colors cursor-pointer shrink-0"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onOpenEnquiry()}
              className="px-4 py-2 text-sm font-semibold text-white bg-[#7A0F28] rounded-lg hover:bg-[#58091B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Book Free Demo
            </button>
          </div>

          {/* Mobile Menu Trigger */}
          <div className="flex lg:hidden items-center gap-2 shrink-0">
            <a
              href={BRAND_INFO.phoneHref}
              aria-label={`Call ${BRAND_INFO.name}`}
              className="inline-flex items-center justify-center w-10 h-10 rounded-lg border border-[#EADFE2] text-[#7A0F28]"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              type="button"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label={mobileOpen ? 'Close menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-[#7A0F28] text-white cursor-pointer"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-[#EADFE2] bg-white px-4 py-5 space-y-5 max-h-[82vh] overflow-y-auto">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#7A0F28] mb-2">
                School Classes (6–12)
              </p>
              <div className="grid grid-cols-4 gap-2">
                {CLASS_LINKS.map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-lg border border-[#EADFE2] px-2 py-2 text-center text-xs font-semibold text-[#1D1014] hover:border-[#7A0F28]"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#7A0F28] mb-2">
                Boards &amp; Competitive Exams
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {[...BOARD_LINKS, ...EXAM_LINKS].map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-lg border border-[#EADFE2] px-3 py-2 text-xs font-semibold text-[#1D1014] hover:border-[#7A0F28]"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#7A0F28] mb-2">
                Skill Courses &amp; Explore
              </p>
              <div className="grid grid-cols-2 gap-1.5 text-sm">
                {[
                  ...SKILL_LINKS,
                  { label: 'About Us', path: '/about' },
                  { label: 'Contact & Address', path: '/contact' },
                  { label: 'Admissions & Demo', path: '/admission' },
                  ...RESOURCE_LINKS,
                ].map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-lg px-2.5 py-2 text-xs font-medium text-[#2A181D] hover:bg-[#FAF7F5]"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="space-y-2.5 pt-2 border-t border-[#EADFE2]">
              <div className="grid grid-cols-2 gap-2.5">
                <a
                  href="/student/login"
                  onClick={(e) => go(e, '/student/login')}
                  className="text-center rounded-lg border border-[#7A0F28] px-3 py-2.5 text-xs font-semibold text-[#7A0F28]"
                >
                  Student / Parent Login
                </a>
                <a
                  href="/teacher/login"
                  onClick={(e) => go(e, '/teacher/login')}
                  className="text-center rounded-lg border border-[#24040C] px-3 py-2.5 text-xs font-semibold text-[#24040C]"
                >
                  Teacher Login
                </a>
              </div>
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenEnquiry();
                }}
                className="w-full rounded-lg bg-[#7A0F28] px-4 py-2.5 text-sm font-semibold text-white cursor-pointer"
              >
                Book Free Demo
              </button>
            </div>
          </div>
        )}
      </header>
    </div>
  );
}
