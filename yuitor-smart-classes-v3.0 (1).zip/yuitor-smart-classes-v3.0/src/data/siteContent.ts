import type { BlogPost } from '../types';

export const BRAND_INFO = {
  name: 'Yuitor Smart Classes',
  shortName: 'Yuitor Smart Classes',
  logo: '/assets/aistudio/yuitor-smart-classes-logo_d50885d8.png',
  ogImage: '/opengraph-yuitor.jpg',
  phoneDisplay: '+91 78-2728-9292',
  phoneHref: 'tel:+917827289292',
  whatsappHref: 'https://wa.me/917827289292',
  email: 'inquiry@yuitor.com',
  complaintsEmail: 'Complaints@yuitor.com',
  address: 'Trimurti Vihar, Near Venus Academy, Muradnagar - 201206, Uttar Pradesh, India',
  cityShort: 'Muradnagar, Ghaziabad (UP)',
  timings: 'Mon – Sat · 8:00 AM – 8:00 PM IST',
};

export const BRAND_IMAGES = {
  heroCampus: '/assets/images/teacher-led-class.webp',
  classroomGuidance: '/assets/images/teacher-classroom-guidance.webp',
  smallGroup: '/assets/images/teacher-small-group.webp',
  campusExterior: '/assets/images/campus-exterior.webp',
  campusGroups: '/assets/images/campus-groups.webp',
  awardCeremony: '/assets/images/award-ceremony.webp',
  mathBoard: '/assets/images/math-board.webp',
  scienceLab: '/assets/images/science-lab.webp',
  scienceLabGuidance: '/assets/images/science-lab-guidance.webp',
  handsOnScience: '/assets/images/hands-on-science.webp',
  biologyModel: '/assets/images/biology-model.webp',
  scienceProject: '/assets/images/science-project.webp',
  codingWorkshop: '/assets/images/coding-workshop.webp',
  computerClass: '/assets/images/computer-class.webp',
  computerStudy: '/assets/images/computer-study.webp',
  electronicsWorkshop: '/assets/images/electronics-workshop.webp',
  examWriting: '/assets/images/exam-writing.webp',
  groupStudy: '/assets/images/group-study.webp',
  libraryStudy: '/assets/images/library-study.webp',
  studentBooks: '/assets/images/student-books.webp',
  studentLibrary: '/assets/images/student-library.webp',
  studentPresentation: '/assets/images/student-presentation.webp',
  studentProject: '/assets/images/student-project.webp',
  studyDesk: '/assets/images/study-desk.webp',
  studyNotes: '/assets/images/study-notes.webp',
  founder: '/assets/images/founder-owner.webp',
  facultyPriya: '/assets/images/faculty-priya-illustrative.webp',
  facultyRamesh: '/assets/images/faculty-ramesh-illustrative.webp',
  facultySunita: '/assets/images/faculty-sunita-illustrative.webp',
  facultyVikas: '/assets/images/faculty-vikas-illustrative.webp',
};

export interface ProgramDetail {
  slug: string;
  shortCode: string;
  title: string;
  subtitle: string;
  category: 'Classes 6–12' | 'Boards' | 'Competitive Exams' | 'Skill Courses';
  partnerNote: string;
  duration: string;
  examsCount: string;
  placementHighlight: string;
  passRate: string;
  avgSalary: string;
  monthlyFee: number;
  totalFee: number;
  heroImage: string;
  overview: string;
  eligibility: string[];
  syllabus: { code: string; title: string; focus: string }[];
  journeySteps: { step: string; title: string; detail: string }[];
  faqs: { q: string; a: string }[];
}

// EXACT School Classes (Class 6 to Class 12 ONLY)
export const CLASS_LINKS = [
  { label: 'Class 6', path: '/class/6', desc: 'Strong foundation in Maths, Science, English & Computer' },
  { label: 'Class 7', path: '/class/7', desc: 'Analytical Maths, Science concepts & Grammar mastery' },
  { label: 'Class 8', path: '/class/8', desc: 'High-school bridge & Olympiad/Foundation readiness' },
  { label: 'Class 9', path: '/class/9', desc: 'Board-aligned Maths, Science, English & Social Studies' },
  { label: 'Class 10', path: '/class/10', desc: '95%+ Board Exam Mastery · Weekly Mocks & PYQs' },
  { label: 'Class 11', path: '/class/11', desc: 'Science (PCM/PCB) & Commerce with Entrance Foundations' },
  { label: 'Class 12', path: '/class/12', desc: 'Board Excellence + NEET, JEE & CUET Sync' },
];

// Exact Boards (CBSE, UP Board, ICSE, State Board)
export const BOARD_LINKS = [
  { label: 'CBSE Board Coaching', path: '/board/cbse', desc: 'Complete NCERT mastery, CBSE competency questions, sample papers & weekly mocks' },
  { label: 'UP Board Coaching', path: '/board/up-board', desc: 'Bilingual Hindi/English notes, UPMSP model papers & writing drills' },
  { label: 'ICSE Coaching', path: '/board/icse', desc: 'Deep concept coverage for ICSE/ISC Science, Maths & English' },
  { label: 'State Board Coaching', path: '/board/state-board', desc: 'Structured syllabus mastery & regular chapter tests' },
];

// EXACT Competitive Exams (NEET, JEE, CUET, NDA, SSC, Banking ONLY)
export const EXAM_LINKS = [
  { label: 'NEET Coaching', path: '/exam/neet', desc: 'NCERT Biology, Chemistry & Physics with OMR mock tests' },
  { label: 'JEE Coaching', path: '/exam/jee', desc: 'IIT-JEE Main & Advanced PCM drills & CBT test series' },
  { label: 'CUET Coaching', path: '/exam/cuet', desc: 'Domain Subjects, General Test & Language for DU/BHU' },
  { label: 'NDA Coaching', path: '/exam/nda', desc: 'UPSC NDA Maths, GAT & SSB Officer Personality Prep' },
  { label: 'SSC Coaching', path: '/exam/ssc', desc: 'SSC CGL, CHSL, MTS Quant, Reasoning, GS & English' },
  { label: 'Banking Coaching', path: '/exam/banking', desc: 'IBPS PO/Clerk, SBI & RBI speed-accuracy mastery' },
];

// EXACT Skill Courses (Computer Classes, Spoken English, Coding Classes ONLY)
export const SKILL_LINKS = [
  { label: 'Computer Classes', path: '/course/computer', desc: 'DCA, Tally Prime with GST, CCC, MS Office & Practical Lab' },
  { label: 'Spoken English', path: '/course/spoken-english', desc: 'Fluency, Grammar, Public Speaking & Interview Skills' },
  { label: 'Coding Classes', path: '/course/coding', desc: 'Python, HTML/CSS, JavaScript & Real Web Projects' },
];

export const HERO_METRICS = [
  { value: '95%+', label: 'Board Toppers' },
  { value: '6th–12th', label: 'All Streams & Boards' },
  { value: '15–20', label: 'Small Batch Size' },
  { value: '4.9★', label: 'Parent Trust Rating' },
];

export const BOARD_PARTNERS = [
  'CBSE Board Coaching',
  'UP Board Coaching',
  'ICSE Coaching',
  'State Board Coaching',
  'NEET Coaching',
  'JEE Coaching',
  'CUET Coaching',
  'NDA Coaching',
  'SSC Coaching',
  'Banking Coaching',
  'Computer Classes',
  'Spoken English',
  'Coding Classes',
];

export const TOP_ACHIEVERS = [
  { name: 'Riya Chaudhary', credential: 'Class 12 · ICSE Science', company: '97.4% Aggregate · 99 in Maths', score: '97.4%' },
  { name: 'Aditya Sharma', credential: 'Class 10 · UP Board Topper', company: '98.2% Aggregate · 100 in Science', score: '98.2%' },
  { name: 'Karan Tyagi', credential: 'JEE Coaching Qualifier', company: '98.6 Percentile · PCM Target Batch', score: '98.6%ile' },
  { name: 'Neha Verma', credential: 'NEET Coaching Achiever', company: '645 / 720 · Biology 345/360', score: '645/720' },
  { name: 'Vanshika Garg', credential: 'Class 12 · UP Board Commerce', company: '95.8% · District Merit + Tally Prime', score: '95.8%' },
  { name: 'Harshvardhan Malik', credential: 'CUET & Spoken English', company: 'Admitted to Delhi University (North Campus)', score: '99.1%ile' },
];

export const CORE_PROGRAMS: ProgramDetail[] = [
  {
    slug: 'class-10',
    shortCode: 'Class 10',
    title: 'Class 10 Coaching (CBSE / UP Board / ICSE / State Board)',
    subtitle: 'Score 95%+ in Class 10 Board Exams with NCERT conceptual clarity, weekly full-length mocks, answer presentation rubrics, and live Parent Portal tracking.',
    category: 'Classes 6–12',
    partnerNote: 'Muradnagar Campus · Small Batches (15–20 Students)',
    duration: '12 Months (Academic Session)',
    examsCount: 'Weekly Chapter Tests + 12 Full Board Mocks',
    placementHighlight: '95%+ Consistent Board Distinctions',
    passRate: '100% Board Pass Track',
    avgSalary: 'Maths · Science · English · SST · Computer',
    monthlyFee: 800,
    totalFee: 8640,
    heroImage: BRAND_IMAGES.mathBoard,
    overview:
      'Designed specifically for Class 10 students across CBSE, UP Board, ICSE, and State Board streams in Muradnagar. Every chapter is taught from NCERT basics up to board exam questions, supported by printed chapter notes, step-marking answer reviews, and weekly parent progress alerts.',
    eligibility: [
      'Students promoted to or currently enrolled in Class 10 (CBSE, UP Board, ICSE, or State Board).',
      'Separate Hindi-medium and English-medium support batches available.',
      'Free diagnostic test & 2-day demo class before enrollment.',
    ],
    syllabus: [
      { code: 'MATHS', title: 'Mathematics', focus: 'Real Numbers, Quadratics, Trigonometry, Coordinate Geometry, Surface Areas & Statistics.' },
      { code: 'SCIENCE', title: 'Physics, Chemistry & Biology', focus: 'Light, Electricity, Chemical Reactions, Carbon Compounds, Life Processes & Heredity.' },
      { code: 'ENGLISH', title: 'English Language & Literature', focus: 'Reading comprehension, grammar precision, formal writing formats, and literature extracts.' },
      { code: 'SST & COMP', title: 'Social Science & Computer Applications', focus: 'Structured timeline notes, map work mastery, and board computer scoring drills.' },
    ],
    journeySteps: [
      { step: '01', title: 'Concept Mastery', detail: 'Daily classroom teaching with visual smart-board demonstrations and printed chapter notes.' },
      { step: '02', title: 'Doubt & Practice Clinics', detail: 'Same-day doubt resolution plus weak-topic revision worksheets.' },
      { step: '03', title: 'Weekly Unit Tests', detail: 'Board-pattern tests every Sunday with instant marks published on the Parent Portal.' },
      { step: '04', title: 'Pre-Board Sprint', detail: '12 full-length timed mock exams and 10-year PYQ mastery before final boards.' },
    ],
    faqs: [
      { q: 'Are CBSE, UP Board, ICSE and State Board Class 10 batches taught according to board patterns?', a: 'Yes, our faculty tailor NCERT notes, CBSE/UPMSP model papers, and weekly tests to match CBSE, UP Board, ICSE, and State Board blueprints.' },
      { q: 'How do parents track attendance and test marks?', a: 'Every parent receives login access to the Yuitor Smart Classes Parent Portal to monitor daily attendance, weekly test scores, ranks, and fee receipts.' },
    ],
  },
  {
    slug: 'class-12',
    shortCode: 'Class 12',
    title: 'Class 12 Coaching — Science & Commerce + Entrance Sync',
    subtitle: 'Master Physics, Chemistry, Maths, Biology, Accountancy & Economics for 95%+ Board scores while preparing seamlessly for NEET, JEE, and CUET.',
    category: 'Classes 6–12',
    partnerNote: 'PCM · PCB · Commerce Streams · Muradnagar Campus',
    duration: '12 Months (Full Academic Year)',
    examsCount: 'Chapterwise Tests + Practical Viva + 15 Full Mocks',
    placementHighlight: 'Top Board Merit + University & Medical/Engg Admissions',
    passRate: '98% First Division & Distinctions',
    avgSalary: 'Physics · Chemistry · Maths · Bio · Accounts · Eco',
    monthlyFee: 900,
    totalFee: 9720,
    heroImage: BRAND_IMAGES.scienceLabGuidance,
    overview:
      'Class 12 determines both Board merit and university entrance outcomes. Our senior subject faculty teach complete derivations, numericals, case studies, and practical viva preparation while integrating MCQ drills for CUET, JEE, and NEET.',
    eligibility: [
      'Students entering Class 12 in Science (PCM / PCB) or Commerce streams (CBSE, UP Board, ICSE, State Board).',
      'Dedicated revision bridge provided for students needing Class 11 prerequisite strengthening.',
    ],
    syllabus: [
      { code: 'PCM', title: 'Physics, Chemistry & Mathematics', focus: 'Electrostatics, Optics, Modern Physics, Organic Mechanisms, Calculus, Vectors & 3D Geometry.' },
      { code: 'PCB', title: 'Biology + Physics & Chemistry', focus: 'Genetics, Biotechnology, Human Reproduction, Ecology, and crisp diagram mastery.' },
      { code: 'COMMERCE', title: 'Accountancy, Economics & Business Studies', focus: 'Partnership, Company Accounts, Cash Flow Analysis, Macroeconomics & Indian Economy.' },
      { code: 'ENTRANCE', title: 'Board + NEET / JEE / CUET Alignment', focus: 'Objective MCQ sheets mapped directly to each board chapter for dual success.' },
    ],
    journeySteps: [
      { step: '01', title: 'Syllabus Completion by Oct', detail: 'Early structured coverage leaving 3+ full months for intensive revision and mocks.' },
      { step: '02', title: 'Numerical & Case Labs', detail: 'Daily practice problems (DPPs) and step-wise board answer presentation workshops.' },
      { step: '03', title: 'Practical & Viva Prep', detail: 'Hands-on lab guidance, project file review, and mock viva sessions.' },
      { step: '04', title: 'Pre-Board & Entrance Test Series', detail: 'Full board mock series alongside CUET/JEE/NEET timed CBT/OMR drills.' },
    ],
    faqs: [
      { q: 'Can I join for selected subjects like Physics & Maths or Accountancy only?', a: 'Yes, flexible subject-wise and full-stream enrollment options are available. Use our Fee Calculator or visit our Muradnagar centre.' },
    ],
  },
  {
    slug: 'exam-neet',
    shortCode: 'NEET Coaching',
    title: 'NEET Coaching — Medical Entrance Preparation',
    subtitle: 'NCERT-first Biology, Chemistry, and Physics preparation with daily practice problems, weekly OMR full-length tests, and personal error-log mentorship.',
    category: 'Competitive Exams',
    partnerNote: 'Class 11–12 Foundation & Target Dropper Batches',
    duration: '12–24 Months',
    examsCount: '720-Mark OMR Mock Series + Daily DPPs',
    placementHighlight: '600+ Score Strategy & Medical College Counselling',
    passRate: '94% Qualification Consistency',
    avgSalary: 'Physics · Chemistry · Botany · Zoology',
    monthlyFee: 1800,
    totalFee: 18400,
    heroImage: BRAND_IMAGES.biologyModel,
    overview:
      'Our NEET Coaching program is built around 100% NCERT line-by-line mastery for Biology and Inorganic Chemistry, paired with concept-first numerical problem solving in Physics and Physical Chemistry. Every Sunday OMR test generates an individual accuracy report.',
    eligibility: [
      'Class 11 & Class 12 PCB students (2-year and 1-year integrated batches).',
      'Class 12 passed medical aspirants joining our intensive Target Dropper batch.',
    ],
    syllabus: [
      { code: 'BIOLOGY', title: 'Botany & Zoology (360 Marks)', focus: 'Line-by-line NCERT assertion-reason, diagrams, genetics, human & plant physiology.' },
      { code: 'CHEMISTRY', title: 'Physical, Organic & Inorganic (180 Marks)', focus: 'Reaction mechanisms, named reactions, coordination compounds & fast stoichiometry.' },
      { code: 'PHYSICS', title: 'Mechanics to Modern Physics (180 Marks)', focus: 'Formula intuition, high-yield PYQ patterns, and speed calculation shortcuts.' },
      { code: 'OMR LAB', title: 'Full-Length 720-Mark Test Series', focus: 'Weekly part-tests & 20+ NTA-pattern full-syllabus OMR mocks with negative-marking control.' },
    ],
    journeySteps: [
      { step: '01', title: 'NCERT Deep Dive', detail: 'Structured classroom lectures decoding every NCERT figure, table, and summary box.' },
      { step: '02', title: 'Daily DPP Drills', detail: '45–60 curated NEET-level questions solved and discussed every day.' },
      { step: '03', title: 'Sunday OMR Tests', detail: 'Real exam environment testing with OMR bubbling speed and time-split coaching.' },
      { step: '04', title: 'Error-Log Revision', detail: 'Targeted re-testing of weak chapters until accuracy crosses 85%+.' },
    ],
    faqs: [
      { q: 'Does NEET coaching clash with Class 11–12 board exams?', a: 'Not at all — our syllabus calendar aligns closely with CBSE, UP Board, ICSE, and State Board chapters so your board score and NEET rank improve together.' },
    ],
  },
  {
    slug: 'exam-jee',
    shortCode: 'JEE Coaching',
    title: 'JEE Coaching (Main & Advanced)',
    subtitle: 'High-rigor Physics, Chemistry, and Mathematics mentoring with daily numerical sheets, CBT mock tests, and personalized rank strategy.',
    category: 'Competitive Exams',
    partnerNote: 'Class 11–12 Integrated & Target JEE Batches',
    duration: '12–24 Months',
    examsCount: 'NTA CBT Pattern Mocks + 15-Year PYQ Archive',
    placementHighlight: 'NIT, IIIT & IIT Engineering Entrance Focus',
    passRate: '92% JEE Main Qualification Rate',
    avgSalary: 'Physics · Chemistry · Mathematics',
    monthlyFee: 1800,
    totalFee: 18400,
    heroImage: BRAND_IMAGES.handsOnScience,
    overview:
      'Build deep mathematical and physical problem-solving intuition for JEE Main and Advanced. We emphasize multi-concept application, structured DPP solving, computer-based test (CBT) practice, and one-on-one doubt clinics.',
    eligibility: [
      'Class 11 & 12 PCM students aiming for IITs, NITs, IIITs, and top engineering institutes.',
      'Class 12 passed students joining the 1-year JEE Target batch.',
    ],
    syllabus: [
      { code: 'PHYSICS', title: 'Mechanics, Electrodynamics, Optics & Modern Physics', focus: 'Free-body rigor, rotational dynamics, circuits, and multi-concept graphical analysis.' },
      { code: 'MATHS', title: 'Calculus, Coordinate Geometry & Algebra', focus: 'Functions, definite integration, conics, matrices, probability & complex numbers.' },
      { code: 'CHEMISTRY', title: 'Physical, Organic & Inorganic Chemistry', focus: 'Thermodynamics, electrochemistry, stereochemistry, reaction pathways & inorganic mastery.' },
      { code: 'CBT MOCKS', title: 'NTA Computer-Based Test Series', focus: '3-hour timed mocks with question-selection strategy and percentile benchmarking.' },
    ],
    journeySteps: [
      { step: '01', title: 'Fundamental Theory', detail: 'First-principles derivations and visual demonstrations before touching shortcuts.' },
      { step: '02', title: 'Graded Problem Sets', detail: 'Level-1 (Boards), Level-2 (JEE Main), and Level-3 (JEE Advanced) worksheets.' },
      { step: '03', title: 'Doubt Clinics', detail: 'Dedicated faculty doubt counters so no numerical remains unsolved.' },
      { step: '04', title: 'CBT Mock Analytics', detail: 'Time-per-question diagnostics to maximize Jan & April JEE Main percentiles.' },
    ],
    faqs: [
      { q: 'Are study modules and previous year question banks included?', a: 'Yes, printed chapterwise DPPs, formula handbooks, and full NTA CBT test access through the Student Portal are included.' },
    ],
  },
  {
    slug: 'exam-cuet',
    shortCode: 'CUET Coaching',
    title: 'CUET Coaching — Central University Entrance',
    subtitle: 'Structured preparation for Domain Subjects, General Test (Quant & Reasoning), and English/Hindi Language for DU, BHU, JNU & top central universities.',
    category: 'Competitive Exams',
    partnerNote: 'Science · Commerce · Humanities Streams',
    duration: '4–6 Months',
    examsCount: 'Domain + General Test + Language CBT Mocks',
    placementHighlight: 'Delhi University, BHU & Central University Admissions',
    passRate: '95% Top-College Cut-Off Success',
    avgSalary: 'Domain Subjects · General Test · Language',
    monthlyFee: 1200,
    totalFee: 6500,
    heroImage: BRAND_IMAGES.examWriting,
    overview:
      'CUET-UG rewards speed, accuracy, and crystal-clear Class 12 command. Our batch covers Domain subjects (Science, Commerce, Humanities), General Test aptitude, and Language comprehension with strict 45-minute speed drills.',
    eligibility: [
      'Class 12 appearing or passed students from Science, Commerce, or Arts/Humanities streams.',
    ],
    syllabus: [
      { code: 'LANGUAGE', title: 'English & Hindi Reading Mastery', focus: 'Reading comprehension passages, vocabulary, idioms, analogies & verbal precision.' },
      { code: 'DOMAINS', title: 'Class 12 Domain Subjects', focus: 'Physics, Chemistry, Maths, Biology, Accounts, Eco, BST, History, Pol. Science & Geography.' },
      { code: 'GEN TEST', title: 'General Test (GT)', focus: 'Quantitative reasoning, logical & analytical reasoning, static GK & current affairs.' },
      { code: 'CBT DRILLS', title: 'Speed-Accuracy Mock Series', focus: '40/50 question selection drills in strict NTA exam interface.' },
    ],
    journeySteps: [
      { step: '01', title: 'Subject Mapping', detail: 'Select the ideal DU/BHU university & course eligibility subject combinations.' },
      { step: '02', title: 'Domain MCQ Drills', detail: 'Chapterwise objective banks covering every Class 12 topic.' },
      { step: '03', title: 'General Test Bootcamp', detail: 'Daily arithmetic, reasoning shortcuts, and monthly current affairs digests.' },
      { step: '04', title: 'Counselling Support', detail: 'CSAS preference-sheet strategy after CUET result declaration.' },
    ],
    faqs: [
      { q: 'When should Class 12 students start CUET coaching?', a: 'Students can join our weekend CUET sync during Class 12 or our intensive post-board crash batch right after March exams.' },
    ],
  },
  {
    slug: 'computer',
    shortCode: 'Computer Classes',
    title: 'Computer Classes (DCA, Tally Prime with GST, CCC & MS Office)',
    subtitle: '100% practical hands-on computer lab training covering MS Office, Advanced Excel, Tally Prime with GST, CCC certification, and digital productivity.',
    category: 'Skill Courses',
    partnerNote: '1-Student-1-PC Practical Lab · Certificate Included',
    duration: '3–6 Months',
    examsCount: 'Lab Practicals + Project Evaluation',
    placementHighlight: 'Job-Ready Office, Accounting & Government Exam Computer Skills',
    passRate: '98% Certification Completion',
    avgSalary: 'DCA · Tally Prime + GST · CCC · Excel',
    monthlyFee: 600,
    totalFee: 3300,
    heroImage: BRAND_IMAGES.computerClass,
    overview:
      'Designed for Class 6–12 students, college learners, and job aspirants in Muradnagar. Every student gets dedicated desktop practice time to master MS Word, PowerPoint, Advanced Excel formulas, Tally Prime GST accounting, and NIELIT CCC preparation.',
    eligibility: [
      'Open to Class 6–12 students, college graduates, and office/job aspirants — no prior computer background required.',
    ],
    syllabus: [
      { code: 'OFFICE', title: 'MS Office & Advanced Excel', focus: 'Word formatting, PowerPoint decks, VLOOKUP/XLOOKUP, Pivot Tables & data charts.' },
      { code: 'TALLY', title: 'Tally Prime with GST & Inventory', focus: 'Company creation, vouchers, GST returns, payroll, bank reconciliation & billing.' },
      { code: 'CCC / DCA', title: 'Computer Fundamentals & NIELIT CCC', focus: 'Operating systems, LibreOffice, digital finance, cybersecurity & CCC exam mocks.' },
      { code: 'PROJECTS', title: 'Practical Portfolio & Typing Speed', focus: 'Real business invoices, Excel dashboards, and Hindi/English typing fluency.' },
    ],
    journeySteps: [
      { step: '01', title: 'Hands-On Basics', detail: 'Daily 1-on-1 lab practice building comfort with keyboard shortcuts and OS tools.' },
      { step: '02', title: 'Applied Office & Tally', detail: 'Create real GST invoices, balance sheets, and automated Excel sheets.' },
      { step: '03', title: 'Practical Assessments', detail: 'Weekly lab tasks evaluated by instructors.' },
      { step: '04', title: 'Course Certification', detail: 'Receive Yuitor Smart Classes verified completion certificate & practical project pack.' },
    ],
    faqs: [
      { q: 'Does every student get an individual computer during lab sessions?', a: 'Yes, we maintain a 1-student-1-PC practical lab policy so every learner practices hands-on every single day.' },
    ],
  },
  {
    slug: 'spoken-english',
    shortCode: 'Spoken English',
    title: 'Spoken English, Grammar & Personality Development',
    subtitle: 'Build fluent spoken English, clear pronunciation, strong grammar foundations, stage confidence, and interview communication skills.',
    category: 'Skill Courses',
    partnerNote: 'Interactive Speaking Labs · School, College & Interview Batches',
    duration: '3–6 Months',
    examsCount: 'Weekly GD, Presentations & Mock Interviews',
    placementHighlight: 'Confident Fluency for School, NDA/SSB & Job Interviews',
    passRate: '96% Fluency Improvement',
    avgSalary: 'Grammar · Vocabulary · Public Speaking · GD',
    monthlyFee: 600,
    totalFee: 2200,
    heroImage: BRAND_IMAGES.studentPresentation,
    overview:
      'Overcome hesitation and think directly in English. Through daily speaking drills, role-plays, debate clubs, pronunciation clinics, and functional grammar lessons, learners gain natural confidence for classrooms, presentations, and interviews.',
    eligibility: [
      'School students (Classes 6–12), college students, homemakers, and competitive/job interview aspirants.',
    ],
    syllabus: [
      { code: 'FOUNDATION', title: 'Functional Grammar & Sentence Building', focus: 'Tenses, modals, active/passive voice, prepositions & everyday conversational idioms.' },
      { code: 'FLUENCY', title: 'Daily Speaking & Pronunciation Lab', focus: 'Phonetics, accent neutralization, hesitation removal & real-life role-plays.' },
      { code: 'STAGE', title: 'Public Speaking, Debates & Presentations', focus: 'Extempore speaking, storytelling, body language & voice modulation.' },
      { code: 'CAREER', title: 'Group Discussions & Interview Prep', focus: 'Self-introduction, HR questions, email etiquette & SSB/campus interview drills.' },
    ],
    journeySteps: [
      { step: '01', title: 'Fluency Assessment', detail: 'Baseline speaking evaluation to place you in Beginner, Intermediate, or Advanced batch.' },
      { step: '02', title: 'Daily Speaking Practice', detail: '70% speaking, 30% structured grammar — zero rote memorization.' },
      { step: '03', title: 'Stage & GD Club', detail: 'Saturday debates, anchored presentations, and peer feedback sessions.' },
      { step: '04', title: 'Mock Interviews', detail: 'Recorded 1-on-1 feedback to polish confidence and body language.' },
    ],
    faqs: [
      { q: 'I understand English but hesitate while speaking. Will this batch help?', a: 'Yes! Our supportive small-group speaking sessions are specifically designed to eliminate hesitation within the first 3–4 weeks.' },
    ],
  },
  {
    slug: 'coding',
    shortCode: 'Coding Classes',
    title: 'Coding Classes — Python, Web Development & Practical Projects',
    subtitle: 'Learn practical programming from scratch: Python, HTML5, CSS3, JavaScript, SQL, school Computer Science, and real portfolio projects.',
    category: 'Skill Courses',
    partnerNote: 'School Coding (Classes 6–12) & College Tech Track',
    duration: '4–6 Months',
    examsCount: '5+ Live Capstone Projects + Code Reviews',
    placementHighlight: 'Board CS/Java/Python Mastery + Future-Ready Software Skills',
    passRate: '100% Project Deployment',
    avgSalary: 'Python · HTML/CSS · JavaScript · SQL',
    monthlyFee: 900,
    totalFee: 4900,
    heroImage: BRAND_IMAGES.codingWorkshop,
    overview:
      'Turn screen time into creation time. Students build real calculators, interactive websites, Python automations, and database apps while also excelling in CBSE, ICSE & UP Board Computer Science and programming curricula.',
    eligibility: [
      'Students from Class 6 to Class 12 and college beginners eager to learn programming practically.',
    ],
    syllabus: [
      { code: 'PYTHON', title: 'Python Programming & Logic Building', focus: 'Variables, loops, functions, OOP, file handling, data structures & practical school projects.' },
      { code: 'WEB DEV', title: 'HTML5, CSS3 & Responsive Design', focus: 'Modern layouts, Flexbox/Grid, forms, animations & building real websites.' },
      { code: 'JAVASCRIPT', title: 'JavaScript & Interactive Apps', focus: 'DOM manipulation, APIs, interactive quizzes, mini-games & debugging skills.' },
      { code: 'DATABASES', title: 'SQL Databases & Logic Projects', focus: 'Relational queries, Python data projects, and clean software debugging workflows.' },
    ],
    journeySteps: [
      { step: '01', title: 'Logic & Syntax', detail: 'Build strong algorithmic thinking through visual puzzles and daily coding labs.' },
      { step: '02', title: 'Guided Mini-Projects', detail: 'Write real working programs every week instead of copying textbook theory.' },
      { step: '03', title: 'Web & Python Portfolio', detail: 'Launch a personal website and Python project repository.' },
      { step: '04', title: 'Demo Day', detail: 'Present your live project to mentors and parents.' },
    ],
    faqs: [
      { q: 'Does this cover Class 9–12 Computer Applications (Python / Java / SQL)?', a: 'Yes, we have dedicated modules covering school programming exams alongside practical Python and Web Development.' },
    ],
  },
];

// Dynamically resolves all 20 official tracks:
// Classes 6–12, CBSE Board, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, Coding Classes
export function getProgramBySlug(rawSlug: string): ProgramDetail {
  const slug = rawSlug.toLowerCase().trim();
  const exact = CORE_PROGRAMS.find((p) => p.slug === slug);
  if (exact) return exact;

  // Classes 6–12 (Muradnagar, Ghaziabad rural/semi-urban affordable fees)
  if (slug.startsWith('class-')) {
    const num = slug.replace('class-', '');
    const n = Number(num) || 8;
    const isSenior = n >= 11;
    const isBoardPrep = n === 9 || n === 10;
    const classFeeMap: Record<number, { monthly: number; yearly: number }> = {
      6: { monthly: 600, yearly: 6480 },
      7: { monthly: 650, yearly: 7020 },
      8: { monthly: 700, yearly: 7560 },
      9: { monthly: 750, yearly: 8100 },
      10: { monthly: 800, yearly: 8640 },
      11: { monthly: 850, yearly: 9180 },
      12: { monthly: 900, yearly: 9720 },
    };
    const feeObj = classFeeMap[n] || { monthly: 700, yearly: 7560 };
    const subjects =
      n <= 8
        ? 'Mathematics · Science · English · Social Studies · Computer'
        : n === 9
          ? 'Maths · Physics · Chemistry · Biology · English · SST'
          : 'Physics · Chemistry · Maths · Biology · Accountancy · Economics';

    return {
      slug,
      shortCode: `Class ${num}`,
      title: `Class ${num} Coaching in Muradnagar — All Subjects & Boards`,
      subtitle: isSenior
        ? `In-depth Class ${num} Science (PCM/PCB) & Commerce coaching with NCERT clarity, weekly tests, and NEET/JEE/CUET foundation.`
        : isBoardPrep
          ? `Strong Class ${num} foundation building board-level writing accuracy, NCERT & textbook mastery, and Olympiad readiness.`
          : `Engaging, concept-first Class ${num} coaching in Mathematics, Science, English, and Logical Reasoning with personal mentor attention.`,
      category: 'Classes 6–12',
      partnerNote: 'CBSE · UP Board · ICSE · State Board · Small Batch Mentorship',
      duration: '12 Months (Full Academic Year)',
      examsCount: 'Weekly Unit Tests + Term Mock Exams',
      placementHighlight: 'Strong Concept Foundation & 90%+ School Scores',
      passRate: '98% Student Progress Rate',
      avgSalary: subjects,
      monthlyFee: feeObj.monthly,
      totalFee: feeObj.yearly,
      heroImage: n <= 8 ? BRAND_IMAGES.smallGroup : BRAND_IMAGES.classroomGuidance,
      overview: `Our Class ${num} program at Yuitor Smart Classes (Muradnagar) focuses on building unshakeable conceptual clarity without rote memorization. Small batches of 15–20 students ensure every child asks doubts freely, completes daily homework accurately, and improves consistently through weekly assessments visible on the Parent Portal.`,
      eligibility: [
        `Students entering or studying in Class ${num} across CBSE, UP Board, ICSE, or State Board schools.`,
        'Free 2-day trial classes and baseline concept assessment included.',
      ],
      syllabus: isSenior
        ? [
            { code: 'SCIENCE', title: 'Physics, Chemistry & Maths / Biology', focus: 'Complete Class 11 derivations, numericals, and lab concepts.' },
            { code: 'COMMERCE', title: 'Accountancy, Economics & Business Studies', focus: 'Journal, ledger, BRS, financial statements, statistics & microeconomics.' },
            { code: 'FOUNDATION', title: 'Early Entrance Alignment', focus: 'Objective MCQ sheets preparing students early for NEET, JEE & CUET.' },
            { code: 'PORTAL', title: 'Weekly Tests & Parent ERP Tracking', focus: 'Sunday unit tests, attendance logs & mentor feedback for parents.' },
          ]
        : [
            { code: 'MATHS', title: `Class ${num} Mathematics`, focus: 'Step-by-step NCERT + reference problem solving & mental calculation speed.' },
            { code: 'SCIENCE', title: `Class ${num} Science`, focus: 'Visual demonstrations, diagrams, experiments & crisp keyword answers.' },
            { code: 'ENGLISH', title: 'English Grammar, Reading & Writing', focus: 'Strong grammar rules, comprehension skills, essays & spoken confidence.' },
            { code: 'SST & COMP', title: 'Social Studies, Computer & Olympiads', focus: 'Timeline memory maps, computer basics & Olympiad reasoning practice.' },
          ],
      journeySteps: [
        { step: '01', title: 'Diagnostic Baseline', detail: 'Identify previous-class gaps and tailor personal revision worksheets.' },
        { step: '02', title: 'Daily Smart Classes', detail: 'Interactive board explanations with printed chapter notes.' },
        { step: '03', title: 'Sunday Tests & Doubt Desk', detail: 'Regular written tests with checked answer sheets shared with parents.' },
        { step: '04', title: 'Exam Revision Marathons', detail: 'Complete syllabus revisions & sample papers before Half-Yearly and Finals.' },
      ],
      faqs: [
        { q: `What is the batch size for Class ${num} at Yuitor Smart Classes?`, a: 'We strictly cap batches at 15–20 students so teachers know every student by name and monitor copy work daily.' },
        { q: 'Are evening batches available after school hours?', a: 'Yes, convenient afternoon and evening slots (3:00 PM – 7:30 PM) are available for all school students.' },
      ],
    };
  }

  // Exact 4 Boards: CBSE, UP Board, ICSE, State Board (Muradnagar rural-area affordable fees)
  if (slug.startsWith('board-')) {
    const key = slug.replace('board-', '');
    const boardMeta: Record<string, { label: string; medium: string; focus: string; img: string; monthly: number; yearly: number; rangeText: string }> = {
      cbse: {
        label: 'CBSE Board Coaching',
        medium: 'NCERT & CBSE Curriculum · Classes 6–12 (English Medium)',
        focus: 'Line-by-line NCERT + Exemplar mastery, CBSE competency & case-study questions, sample papers, Maths, Science, SST, English & Computer Science.',
        img: BRAND_IMAGES.classroomGuidance,
        monthly: 800,
        yearly: 8640,
        rangeText: 'Class 6th–8th: ₹600–₹700/mo · Class 9th–10th: ₹750–₹800/mo · Class 11th–12th: ₹850–₹900/mo (10% OFF Yearly)',
      },
      'up-board': {
        label: 'UP Board Coaching',
        medium: 'Hindi & English Medium · Classes 6–12',
        focus: 'Bilingual concept notes, UPMSP model papers, neat Hindi/English answer presentation, and numerical rigor.',
        img: BRAND_IMAGES.mathBoard,
        monthly: 800,
        yearly: 8640,
        rangeText: 'Class 6th–8th: ₹600–₹700/mo · Class 9th–10th: ₹750–₹800/mo · Class 11th–12th: ₹850–₹900/mo (10% OFF Yearly)',
      },
      icse: {
        label: 'ICSE Coaching',
        medium: 'CISCE / ICSE & ISC Curriculum · Classes 6–12',
        focus: 'Deep analytical syllabus coverage for ICSE Physics, Chemistry, Biology, Maths, Computer (Java/Python) & English Literature.',
        img: BRAND_IMAGES.libraryStudy,
        monthly: 800,
        yearly: 8640,
        rangeText: 'Class 6th–8th: ₹600–₹700/mo · Class 9th–10th: ₹750–₹800/mo · Class 11th–12th: ₹850–₹900/mo (10% OFF Yearly)',
      },
      'state-board': {
        label: 'State Board Coaching',
        medium: 'State Board Curriculum · Classes 6–12',
        focus: 'Structured chapter-wise syllabus completion, bilingual notes, weekly written tests, and full board revision series.',
        img: BRAND_IMAGES.groupStudy,
        monthly: 800,
        yearly: 8640,
        rangeText: 'Class 6th–8th: ₹600–₹700/mo · Class 9th–10th: ₹750–₹800/mo · Class 11th–12th: ₹850–₹900/mo (10% OFF Yearly)',
      },
    };
    const info = boardMeta[key] || boardMeta['cbse'];

    return {
      slug,
      shortCode: info.label,
      title: `${info.label} in Muradnagar (Classes 6–12)`,
      subtitle: `${info.focus} Backed by small-group faculty mentorship and live Parent ERP tracking.`,
      category: 'Boards',
      partnerNote: info.medium,
      duration: '12 Months (Academic Session)',
      examsCount: 'Weekly Chapter Tests + Full Board Pre-Boards',
      placementHighlight: '95%+ Board Distinction & Merit Track Record',
      passRate: '100% Board Pass Track',
      avgSalary: info.rangeText,
      monthlyFee: info.monthly,
      totalFee: info.yearly,
      heroImage: info.img,
      overview: `Yuitor Smart Classes offers specialized ${info.label} in Muradnagar, Ghaziabad tailored to the exact textbook syllabus, blueprint, and step-marking guidelines of the board — at affordable rural-friendly fees (${info.rangeText}). Students master concepts early, practice 10 years of previous board papers, and receive detailed written feedback on every mock exam.`,
      eligibility: [
        `Students studying in Classes 6 to 12 under ${info.label.replace(' Coaching', '')}.`,
        'Both offline classroom (Trimurti Vihar, Muradnagar) and printed/digital notes included.',
      ],
      syllabus: [
        { code: 'CORE', title: 'Complete Textbook & Reference Mastery', focus: info.focus },
        { code: 'WRITING', title: 'Board Answer Presentation Drills', focus: 'Keyword highlighting, labeled diagrams, step-wise numericals & time management.' },
        { code: 'PYQ BANK', title: '10-Year Previous Papers & Sample Sets', focus: 'Exhaustive solved paper banks and high-weightage chapter focus.' },
        { code: 'TRACKING', title: 'Parent & Student ERP Dashboard', focus: 'Live attendance, marks graphs, homework tracker & direct teacher messaging.' },
      ],
      journeySteps: [
        { step: '01', title: 'Board Blueprint Plan', detail: 'Month-by-month syllabus calendar aligned with school unit tests and pre-boards.' },
        { step: '02', title: 'Concept + Notes', detail: 'Clear classroom explanation with crisp, exam-ready handwritten & printed notes.' },
        { step: '03', title: 'Weekly Evaluation', detail: 'Sunday written exams graded on real board step-marking criteria.' },
        { step: '04', title: 'Final Revision Bootcamp', detail: 'Full syllabus mock series and 1-on-1 doubt clinics before final exams.' },
      ],
      faqs: [
        { q: `What are the monthly fees for ${info.label} in Muradnagar?`, a: `Affordable Muradnagar fee slabs: ${info.rangeText}. Annual lump-sum (10% extra off) and up to 50% merit scholarship are also available.` },
        { q: `Do you provide separate study notes for ${info.label}?`, a: 'Yes, every student receives structured chapter summaries, formula sheets, and board-specific practice sets.' },
      ],
    };
  }

  // Competitive Exams: NDA, SSC, Banking (Muradnagar rural-area affordable fees)
  const examKey = slug.replace('exam-', '');
  const examMeta: Record<string, { label: string; title: string; sub: string; subjects: string; fee: number; dur: string; img: string }> = {
    nda: {
      label: 'NDA Coaching',
      title: 'NDA Coaching — UPSC NDA & NA Defence Entrance',
      sub: 'Comprehensive UPSC NDA Mathematics, General Ability Test (GAT — English, Physics, Chemistry, History, Polity, Current Affairs) & SSB personality grooming.',
      subjects: 'NDA Mathematics (300) · GAT (600) · SSB Prep',
      fee: 1500,
      dur: '6–12 Months',
      img: BRAND_IMAGES.campusGroups,
    },
    ssc: {
      label: 'SSC Coaching',
      title: 'SSC Coaching (CGL, CHSL, MTS, CPO & GD)',
      sub: 'Speed-accuracy mastery in Quantitative Aptitude, General Intelligence & Reasoning, English Comprehension, and General Awareness with Tier-1 & Tier-2 CBT mocks.',
      subjects: 'Quant · Reasoning · English · General Awareness',
      fee: 1000,
      dur: '6–12 Months',
      img: BRAND_IMAGES.examWriting,
    },
    banking: {
      label: 'Banking Coaching',
      title: 'Banking Coaching (IBPS PO/Clerk, SBI & RBI)',
      sub: 'Master high-speed Puzzles, Data Interpretation, Quantitative Shortcuts, English Comprehension, and Banking & Financial Awareness for Prelims and Mains.',
      subjects: 'DI & Quant · Puzzles & Reasoning · English · Banking GA',
      fee: 1000,
      dur: '6–12 Months',
      img: BRAND_IMAGES.studyDesk,
    },
  };
  const ex = examMeta[examKey] || examMeta['nda'];

  return {
    slug,
    shortCode: ex.label,
    title: ex.title,
    subtitle: ex.sub,
    category: 'Competitive Exams',
    partnerNote: 'Muradnagar Campus · Weekly Speed Tests & Doubt Desks',
    duration: ex.dur,
    examsCount: 'Sectional Speed Drills + Full-Length Mock Series',
    placementHighlight: 'Structured Selection Roadmap & Interview Guidance',
    passRate: '90%+ Mock Cut-Off Readiness',
    avgSalary: ex.subjects,
    monthlyFee: ex.fee,
    totalFee: ex.fee * 6,
    heroImage: ex.img,
    overview: `${ex.title} at Yuitor Smart Classes builds exam temperament, calculation speed, and conceptual accuracy. Our batches combine daily concept lectures, shortcut workshops, bilingual practice sheets, and timed full-length test series with detailed rank analytics.`,
    eligibility: [
      'Class 11–12 students, graduates, and competitive exam aspirants preparing for upcoming notifications.',
      'Free demo class and diagnostic speed test available at our Muradnagar centre.',
    ],
    syllabus: [
      { code: 'QUANT / MATHS', title: 'Quantitative Aptitude & Mathematics', focus: 'Arithmetic, algebra, trigonometry, data interpretation & Vedic speed calculation drills.' },
      { code: 'REASONING', title: 'Logical Reasoning & Analytical Ability', focus: 'Puzzles, seating arrangements, syllogisms, coding-decoding & non-verbal drills.' },
      { code: 'ENGLISH', title: 'English Grammar & Comprehension', focus: 'Error spotting, cloze tests, reading passages, vocabulary & sentence improvement.' },
      { code: 'GA / GK', title: 'General Awareness & Current Affairs', focus: 'Static GK, Polity, Economy, Science, Banking/Defence updates & monthly capsules.' },
    ],
    journeySteps: [
      { step: '01', title: 'Foundation & Speed Math', detail: 'Build strong fundamentals before introducing exam-tested time-saving methods.' },
      { step: '02', title: 'Topic-Wise Practice Sheets', detail: 'Solve 1,500+ previous-year and latest-pattern questions with faculty solutions.' },
      { step: '03', title: 'Weekly Full-Length Mocks', detail: 'Timed tests to master sectional cut-offs and accuracy under pressure.' },
      { step: '04', title: 'Interview / SSB / Skill Prep', detail: 'Personality development, Spoken English & document readiness for final selection.' },
    ],
    faqs: [
      { q: `Are Hindi and English bilingual notes provided for ${ex.label}?`, a: 'Yes, all question sheets and classroom explanations are delivered bilingually so every aspirant learns comfortably.' },
    ],
  };
}

export const COMPARISON_ROWS = [
  { feature: 'Batch Size & Individual Focus', ours: 'Small Batches (15–20 Students) · Personal Mentorship', others: 'Crowded 60–100 Student Halls' },
  { feature: 'Classes & Boards Covered', ours: 'Classes 6–12 (CBSE, UP Board, ICSE, State Board) + Exams + Skills', others: 'Fragmented Single Track' },
  { feature: 'Competitive Exams Prep', ours: 'NEET, JEE, CUET, NDA, SSC & Banking Under One Roof', others: 'Unstructured Syllabus' },
  { feature: 'Weekly Testing & Evaluation', ours: 'Every Sunday Written/OMR/CBT Test + Checked Copies', others: 'Irregular Monthly Tests' },
  { feature: 'Parent & Student ERP Portal', ours: 'Live Attendance, Marks, Homework & Fee Receipts', others: 'Manual Registers / No Portal' },
  { feature: 'Practical Skill Labs', ours: '1-to-1 Computer Classes, Spoken English & Coding Classes', others: 'Theory Only' },
  { feature: 'Scholarships & Fair Fees', ours: 'Transparent Monthly Fees + Up to 50% Merit Waiver', others: 'Hidden Charges & Rigid Lump-Sum' },
];

export const STUDENT_SUCCESS_STORIES = [
  {
    id: 'st-1',
    name: 'Aditya Sharma',
    role: 'Class 10 UP Board Topper',
    company: '98.2% Aggregate (100 in Science)',
    credential: 'Class 10 Board Mastery',
    city: 'Muradnagar',
    story: 'Weekly Sunday mock tests and step-marking feedback on my Science and Maths copies helped me jump from 78% in pre-boards to 98.2% in final Board exams.',
    outcome: '100/100 in Board Science',
  },
  {
    id: 'st-2',
    name: 'Neha Verma',
    role: 'NEET-UG Achiever',
    company: '645 / 720 Score',
    credential: 'NEET Coaching Batch',
    city: 'Ghaziabad / Muradnagar',
    story: 'Line-by-line NCERT Biology revision and daily Physics doubt clinics removed my fear of numericals. My OMR speed improved dramatically with Sunday full mocks.',
    outcome: 'Govt. Medical Seat Qualified',
  },
  {
    id: 'st-3',
    name: 'Karan Tyagi',
    role: 'JEE Main Qualifier',
    company: '98.6 Percentile (PCM)',
    credential: 'Class 12 + JEE Coaching',
    city: 'Muradnagar',
    story: 'Balancing Class 12 Boards with JEE felt overwhelming until Yuitor Smart Classes faculty aligned our daily DPPs with chapters and tracked my error logs weekly.',
    outcome: '96% Boards + 98.6%ile JEE Main',
  },
  {
    id: 'st-4',
    name: 'Vanshika Garg',
    role: 'Class 12 UP Board Merit',
    company: '95.8% Commerce + Computer Classes',
    credential: 'UP Board + Computer Lab',
    city: 'Muradnagar',
    story: 'Clear bilingual notes for Accountancy and Economics plus practical Tally Prime GST classes gave me both top board marks and practical career confidence.',
    outcome: 'District Merit + Tally Certified',
  },
];

export const LEADERSHIP_COUNCIL = [
  {
    name: 'Radha Singh',
    role: 'Founder & Director — Yuitor Smart Classes',
    image: BRAND_IMAGES.founder,
    bio: 'Committed to bringing disciplined, technology-enabled, and personal-attention coaching for Classes 6–12, Boards, Competitive Exams, and Skill Courses in Muradnagar.',
  },
  {
    name: 'Priya Sharma, M.Sc., B.Ed.',
    role: 'Senior Faculty — Physics & Mathematics',
    image: BRAND_IMAGES.facultyPriya,
    bio: '10+ years guiding Class 9–12 CBSE, UP Board, ICSE, State Board, and JEE aspirants with visual derivations, numerical rigor, and board answer-writing mastery.',
  },
  {
    name: 'Ramesh Verma, M.Sc. (Chemistry & Bio)',
    role: 'Head — NEET & Science Foundation',
    image: BRAND_IMAGES.facultyRamesh,
    bio: 'Specialist in Biology, Organic Chemistry mechanisms, and weekly OMR error-log mentoring for medical and board toppers.',
  },
  {
    name: 'Sunita Iyer, M.A. English & MCA',
    role: 'Lead Mentor — Computer Classes, Spoken English & Coding',
    image: BRAND_IMAGES.facultySunita,
    bio: 'Leads 1-to-1 Computer Classes (DCA/Tally Prime), Python & Web Coding Classes, CUET Language prep, and Spoken English workshops.',
  },
];

export const UPCOMING_WORKSHOPS = [
  {
    id: 'w1',
    title: 'Class 10 & 12 Board 95%+ Strategy Workshop (UP Board, ICSE & State Board)',
    date: 'Every Saturday',
    time: '4:00 PM – 5:30 PM IST',
    speaker: 'Yuitor Senior Board Faculty',
    speakerRole: 'Muradnagar Main Campus & Live Online',
    topicTag: 'Board Exam Mastery',
    summary: 'Learn examiner step-marking rubrics, high-weightage chapters, and a realistic 90-day revision timetable.',
    benefit: 'Free Printed Formula Handbook + Demo Class Pass',
  },
  {
    id: 'w2',
    title: 'NEET, JEE, CUET, NDA, SSC & Banking Career Roadmap',
    date: 'Every Sunday',
    time: '11:00 AM – 12:30 PM IST',
    speaker: 'Competitive Exams Mentorship Desk',
    speakerRole: 'Science, Maths, Aptitude & GK Faculty',
    topicTag: 'Boards & Exams',
    summary: 'How to balance school boards with entrance & government exam preparation without burnout, plus scholarship diagnostic test.',
    benefit: 'Up to 50% Merit Scholarship Eligibility',
  },
  {
    id: 'w3',
    title: 'Hands-On Free Demo: Computer Classes, Spoken English & Coding Classes',
    date: 'Every Wednesday & Friday',
    time: '5:00 PM – 6:30 PM IST',
    speaker: 'Skill Courses Instructors',
    speakerRole: 'Yuitor Practical Computer & Communication Lab',
    topicTag: 'Skill Courses',
    summary: 'Experience 1-to-1 desktop practice, build your first Python mini-program, and join a live confidence-building speaking session.',
    benefit: 'Free Skill Assessment & Lab Trial',
  },
];

export const BATCH_OPENINGS = [
  { id: 'b1', company: 'Classes 6–8 Foundation', role: 'Maths, Science, English, SST & Computer', experience: 'UP Board / ICSE / State Board', location: 'Afternoon & Evening Batches', credential: 'Small Batch (Max 18)', vacancies: 12 },
  { id: 'b2', company: 'Class 9 & 10 Boards', role: 'Complete Syllabus + Weekly Pre-Board Series', experience: 'UP Board / ICSE / State Board', location: 'Trimurti Vihar Campus', credential: '95%+ Score Blueprint', vacancies: 10 },
  { id: 'b3', company: 'Class 11 & 12 Streams', role: 'PCM · PCB · Commerce (Accounts & Eco)', experience: 'Boards + CUET Sync', location: 'Morning & Evening Slots', credential: 'Dedicated Subject Faculty', vacancies: 14 },
  { id: 'b4', company: 'NEET & JEE Coaching', role: 'Foundation (Class 11–12) & 1-Year Target Batch', experience: 'Daily DPPs + Sunday OMR/CBT', location: 'Muradnagar Smart Campus', credential: 'Scholarship Up to 50%', vacancies: 8 },
  { id: 'b5', company: 'CUET, NDA, SSC & Banking', role: 'Quant, Reasoning, English, GAT & GK', experience: 'Bilingual Notes + Speed Mocks', location: 'Morning & Afternoon Batches', credential: 'Selection-Focused Drills', vacancies: 15 },
  { id: 'b6', company: 'Skill Courses', role: 'Computer Classes, Spoken English & Coding Classes', experience: '100% Practical 1-to-1 Lab', location: 'Flexible 1-Hour Daily Slots', credential: 'Certificate Included', vacancies: 20 },
];

export const COMMUNITY_STATS = [
  { value: '2,500+', label: 'Students Mentored' },
  { value: '95%+', label: 'Board Toppers' },
  { value: '6th–12th', label: 'Classes & Streams' },
  { value: '19', label: 'Focused Courses' },
  { value: '4.9★', label: 'Parent Reviews' },
  { value: '100%', label: 'Parent ERP Visibility' },
];

export const AWARDS_AND_HIGHLIGHTS = [
  { source: 'Muradnagar Academic Excellence · 2026', title: 'Consistent 95%+ Toppers Across Class 10 & Class 12 UP Board, ICSE & State Boards' },
  { source: 'Smart Education Initiative · 2025', title: 'Unified Student, Teacher & Parent ERP Portal with Live Attendance & Test Scorecards' },
  { source: 'Practical Skill Wing · 2026', title: '1-Student-1-PC Computer Classes, Spoken English & Coding Classes Lab' },
  { source: 'Scholarship Mission · 2026', title: 'Merit & Need-Based Fee Support Empowering Deserving Local Students Up to 50%' },
];

export const CAMPUS_GALLERY_PREVIEW = [
  {
    slug: 'muradnagar-main',
    city: 'Main Campus',
    regionLabel: 'Trimurti Vihar, Muradnagar (Flagship)',
    address: BRAND_INFO.address,
    phone: BRAND_INFO.phoneDisplay,
    email: BRAND_INFO.email,
    timings: BRAND_INFO.timings,
    image: BRAND_IMAGES.campusExterior,
    credentials: 'Classes 6–12 · UP Board, ICSE, State Board · NEET, JEE, CUET, NDA, SSC, Banking · Skill Courses',
  },
  {
    slug: 'smart-classrooms',
    city: 'Smart Classrooms',
    regionLabel: 'Interactive Board & Small-Batch Teaching',
    address: BRAND_INFO.address,
    phone: BRAND_INFO.phoneDisplay,
    email: BRAND_INFO.email,
    timings: BRAND_INFO.timings,
    image: BRAND_IMAGES.heroCampus,
    credentials: 'Max 15–20 Students/Batch · Visual Concept Learning · Daily Doubt Clinics',
  },
  {
    slug: 'science-lab',
    city: 'Science & NEET/JEE',
    regionLabel: 'Concept Models, Numericals & OMR Drills',
    address: BRAND_INFO.address,
    phone: BRAND_INFO.phoneDisplay,
    email: BRAND_INFO.email,
    timings: BRAND_INFO.timings,
    image: BRAND_IMAGES.scienceLab,
    credentials: 'Physics, Chemistry & Biology Practical Understanding · Weekly Tests',
  },
  {
    slug: 'computer-coding-lab',
    city: 'Computer & Coding Lab',
    regionLabel: '1-to-1 Desktop Lab for Computer & Coding Classes',
    address: BRAND_INFO.address,
    phone: BRAND_INFO.phoneDisplay,
    email: BRAND_INFO.email,
    timings: BRAND_INFO.timings,
    image: BRAND_IMAGES.computerClass,
    credentials: 'Computer Classes (DCA, Tally Prime + GST, CCC) · Coding Classes (Python, HTML/CSS, JS)',
  },
  {
    slug: 'english-library',
    city: 'Spoken English & Library',
    regionLabel: 'Communication Club, GD & Quiet Study Zone',
    address: BRAND_INFO.address,
    phone: BRAND_INFO.phoneDisplay,
    email: BRAND_INFO.email,
    timings: BRAND_INFO.timings,
    image: BRAND_IMAGES.studentPresentation,
    credentials: 'Spoken English · Public Speaking · Interview Prep · Self-Study Library',
  },
];

export const DEPARTMENT_HELPLINES = [
  {
    title: 'Admissions & Free Demo',
    phone: BRAND_INFO.phoneDisplay,
    href: BRAND_INFO.phoneHref,
    detail: 'Classes 6–12, Boards, Exams & Skill Courses',
  },
  {
    title: 'WhatsApp Counselling',
    phone: BRAND_INFO.phoneDisplay,
    href: BRAND_INFO.whatsappHref,
    detail: 'Instant Fee Sheet, Syllabus & Demo Slot',
  },
  {
    title: 'General Inquiries',
    phone: BRAND_INFO.email,
    href: `mailto:${BRAND_INFO.email}`,
    detail: 'Course Details, Scholarships & Portal Help',
  },
  {
    title: 'Complaints & Feedback',
    phone: BRAND_INFO.complaintsEmail,
    href: `mailto:${BRAND_INFO.complaintsEmail}`,
    detail: 'Direct Escalation & Parent Grievance Desk',
  },
];

export const EDITORIAL_BLOGS: BlogPost[] = [
  {
    slug: 'study-tips',
    title: 'Board Exam Study Tips: Active Recall, Error Logs & Weekly Planning',
    category: 'Student Corner',
    excerpt: 'Practical, science-backed study habits for Classes 6–12 students to retain chapters faster and stay calm during exams.',
    date: '2026-02-18',
    author: 'Yuitor Smart Classes Faculty',
    readTime: '5 min read',
    image: BRAND_IMAGES.studyNotes,
    content:
      'High-scoring students rarely study 14 hours a day — instead, they replace passive re-reading with active recall and weekly written testing.\n\n1. Use the 45-10 Focus Cycle: Study one focused concept for 45 minutes, close the book, and write key formulas or points from memory for 10 minutes.\n\n2. Maintain a Single Error Notebook: Every mistake from Sunday unit tests goes into one notebook. Reviewing this notebook before pre-boards boosts accuracy by 20–30%.\n\n3. Teach It Back: Explaining a Science derivation or Maths theorem aloud immediately exposes hidden conceptual gaps.',
  },
  {
    slug: 'jee-preparation',
    title: 'JEE Preparation Guide for Class 11 & 12 Students (Balancing Boards + IIT-JEE)',
    category: 'Competitive Exams',
    excerpt: 'A realistic chapterwise roadmap to master Physics, Chemistry, and Mathematics for JEE Main & Advanced without sacrificing school board scores.',
    date: '2026-02-12',
    author: 'Priya Sharma, Senior Physics & Maths Faculty',
    readTime: '6 min read',
    image: BRAND_IMAGES.handsOnScience,
    content:
      'The biggest mistake Class 11 students make is treating JEE and Board exams as two unrelated worlds. In reality, over 80% of JEE Main Chemistry and foundational Physics comes directly from thorough textbook understanding.\n\nStart every chapter with clean theory and solved examples, then move immediately to graded DPPs (Level 1 to Level 3) and the last 10 years of JEE Main PYQs.\n\nTake timed CBT mocks every alternate week to practice question selection — knowing which lengthy numerical to skip in Round 1 often adds 25+ extra marks.',
  },
  {
    slug: 'neet-tips',
    title: 'NEET-UG Preparation Strategy: How to Score 340+ in Biology & 650+ Overall',
    category: 'Competitive Exams',
    excerpt: 'Master NCERT Biology line-by-line, avoid negative marking traps, and build speed in Physics and Chemistry numericals.',
    date: '2026-02-05',
    author: 'Ramesh Verma, Head of Science & NEET',
    readTime: '6 min read',
    image: BRAND_IMAGES.biologyModel,
    content:
      'In NEET-UG, Biology carries 360 out of 720 marks, making NCERT Biology your single highest-return textbook. Read every diagram label, caption, scientist name, and summary paragraph at least 5 times before May.\n\nFor Physics, focus on standard formulas and high-frequency chapters like Modern Physics, Current Electricity, Electrostatics, and Optics rather than chasing obscure olympiad problems.\n\nPractice bubbling full OMR sheets in 2 hours 40 minutes so you always keep 20 minutes to review marked questions and prevent silly negative marking.',
  },
  {
    slug: 'coding-career',
    title: 'Coding Classes for School Students: Why Starting Python & Web Dev Early Matters',
    category: 'Skill Courses',
    excerpt: 'From Class 6 logic puzzles to Class 12 Python/SQL projects and real websites — how practical coding builds problem-solving confidence.',
    date: '2026-01-28',
    author: 'Sunita Iyer, Coding & Computer Lab Lead',
    readTime: '5 min read',
    image: BRAND_IMAGES.codingWorkshop,
    content:
      'Learning to code early is not just about becoming a software engineer — it trains structured thinking, debugging patience, and mathematical clarity across every school subject.\n\nStudents starting with Python and HTML/CSS in Classes 6–12 build tangible apps, websites, and automation scripts while effortlessly scoring 95+ in school Computer Science exams.\n\nAt Yuitor Smart Classes, every coding student works on an individual computer to build and present 5+ real projects.',
  },
  {
    slug: 'board-preparation',
    title: 'UP Board, ICSE & State Board Guide: How to Score 95%+ in Class 10 & 12 Boards',
    category: 'Board Exams',
    excerpt: 'Examiner step-marking secrets, neat presentation checklists, diagram rules, and a 3-stage pre-board revision blueprint.',
    date: '2026-01-20',
    author: 'Yuitor Smart Classes Board Mentorship Cell',
    readTime: '5 min read',
    image: BRAND_IMAGES.examWriting,
    content:
      'Board examiners evaluate hundreds of answer scripts per week. Clean structure, underlined keywords, boxed final numerical answers, and neat pencil-drawn labeled diagrams directly convert average answers into full marks.\n\nComplete your first full syllabus reading by October, solve at least 10 previous years of board question papers in November–December, and sit for 8+ strict 3-hour mock exams in January.\n\nOur Parent Portal shares test performance trends weekly so families always know which subject needs extra support.',
  },
  {
    slug: 'english-speaking',
    title: 'Spoken English & Communication: 5 Daily Habits to Speak Without Hesitation',
    category: 'Skill Courses',
    excerpt: 'Simple everyday speaking routines, vocabulary drills, and group discussion habits to build confident English fluency in 90 days.',
    date: '2026-01-11',
    author: 'Sunita Iyer, Communication Mentor',
    readTime: '4 min read',
    image: BRAND_IMAGES.studentPresentation,
    content:
      'Most students know English grammar rules well enough to score in written exams yet freeze when asked to speak aloud. Fluency comes from speaking muscle memory, not memorizing thick dictionaries.\n\nPractice 5 minutes of daily mirror speaking on a simple topic, replace translation-in-head with short direct English phrases, and participate in weekly Group Discussions where mistakes are welcomed as stepping stones.\n\nWithin 60–90 days of guided speaking labs, learners speak naturally in classrooms, debates, and interviews.',
  },
];

export const GALLERY_ITEMS = [
  { id: 'g1', title: 'Yuitor Smart Classes Main Campus', category: 'Campus & Facilities', location: 'Trimurti Vihar, Muradnagar', image: BRAND_IMAGES.campusExterior, caption: 'Our dedicated academic campus near Venus Academy, Trimurti Vihar, Muradnagar.' },
  { id: 'g2', title: 'Interactive Smart Classroom Session', category: 'Classrooms & Teaching', location: 'Muradnagar Campus', image: BRAND_IMAGES.heroCampus, caption: 'Small-batch faculty-led lectures ensuring individual attention to every learner.' },
  { id: 'g3', title: 'Mathematics Board Problem Solving', category: 'Classrooms & Teaching', location: 'Board Mastery Wing', image: BRAND_IMAGES.mathBoard, caption: 'Step-by-step board and JEE mathematical derivation practice.' },
  { id: 'g4', title: 'Hands-On Science & Biology Lab', category: 'Science & Labs', location: 'NEET / Board Science Wing', image: BRAND_IMAGES.scienceLab, caption: 'Visual models and practical demonstrations for deep conceptual clarity.' },
  { id: 'g5', title: '1-to-1 Practical Computer Lab', category: 'Computer & Coding Lab', location: 'Skill Courses Wing', image: BRAND_IMAGES.computerClass, caption: 'Dedicated desktops for DCA, Tally Prime with GST, CCC, and MS Office.' },
  { id: 'g6', title: 'Python & Web Coding Workshop', category: 'Computer & Coding Lab', location: 'Coding Classes Lab', image: BRAND_IMAGES.codingWorkshop, caption: 'Students building live Python programs and responsive web projects.' },
  { id: 'g7', title: 'Spoken English & Presentation Club', category: 'Student Activities', location: 'Communication Lab', image: BRAND_IMAGES.studentPresentation, caption: 'Weekly stage presentations, debates, and interview confidence workshops.' },
  { id: 'g8', title: 'Annual Toppers Felicitation Ceremony', category: 'Toppers & Events', location: 'Muradnagar Campus', image: BRAND_IMAGES.awardCeremony, caption: 'Celebrating 95%+ Board toppers, NEET/JEE achievers, and scholarship winners.' },
];
