import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BILLING_CYCLES,
  CLASS_FEE_PLANS,
  calculateClassFeePlan,
  calculateFeeSummary,
  filterBackendCourses,
  formatINR,
  isPortalPath,
  resolveRoute,
  validateInquiryPayload,
} from './catalog';
import { BOARD_LINKS, CLASS_LINKS, EXAM_LINKS, SKILL_LINKS, getProgramBySlug } from '../data/siteContent';

test('isPortalPath detects backend portal and admin gate paths accurately', () => {
  assert.equal(isPortalPath('/login'), true);
  assert.equal(isPortalPath('/register/student'), true);
  assert.equal(isPortalPath('/student/dashboard'), true);
  assert.equal(isPortalPath('/teacher/'), true);
  assert.equal(isPortalPath('/parent/'), true);
  assert.equal(isPortalPath('/staff/'), true);
  assert.equal(isPortalPath('/erp'), true);
  assert.equal(isPortalPath('/secret-admin-gate/panel', '/secret-admin-gate'), true);
  assert.equal(isPortalPath('/courses'), false);
  assert.equal(isPortalPath('/class/10'), false);
  assert.equal(isPortalPath('/about'), false);
});

test('catalog contains all 20 official subjects including CBSE and rejects removed subjects', () => {
  assert.equal(CLASS_LINKS.length, 7);
  assert.equal(BOARD_LINKS.length, 4);
  assert.equal(EXAM_LINKS.length, 6);
  assert.equal(SKILL_LINKS.length, 3);

  // Removed subjects MUST NOT resolve
  assert.deepEqual(resolveRoute('/class/5'), { page: 'not-found' });
  assert.deepEqual(resolveRoute('/ai-learning'), { page: 'not-found' });

  // Exact Classes 6 to 12
  for (let cls = 6; cls <= 12; cls++) {
    const resolved = resolveRoute(`/class/${cls}`);
    assert.deepEqual(resolved, { page: 'program', slug: `class-${cls}` });
    const prog = getProgramBySlug(`class-${cls}`);
    assert.ok(prog.title.includes(`Class ${cls}`), `Program title should mention Class ${cls}`);
  }

  // Exact Boards (CBSE, UP Board, ICSE, State Board)
  for (const board of ['cbse', 'up-board', 'icse', 'state-board']) {
    const resolved = resolveRoute(`/board/${board}`);
    assert.deepEqual(resolved, { page: 'program', slug: `board-${board}` });
    const prog = getProgramBySlug(`board-${board}`);
    assert.ok(prog.title.length > 5);
  }

  // Exact Competitive Exams
  for (const exam of ['neet', 'jee', 'cuet', 'nda', 'ssc', 'banking']) {
    const resolved = resolveRoute(`/exam/${exam}`);
    assert.deepEqual(resolved, { page: 'program', slug: `exam-${exam}` });
    const prog = getProgramBySlug(`exam-${exam}`);
    assert.ok(prog.title.length > 5);
  }

  // Exact Skill Courses
  assert.deepEqual(resolveRoute('/course/computer'), { page: 'program', slug: 'computer' });
  assert.deepEqual(resolveRoute('/computer-courses'), { page: 'program', slug: 'computer' });
  assert.deepEqual(resolveRoute('/course/spoken-english'), { page: 'program', slug: 'spoken-english' });
  assert.deepEqual(resolveRoute('/english-speaking'), { page: 'program', slug: 'spoken-english' });
  assert.deepEqual(resolveRoute('/course/coding'), { page: 'program', slug: 'coding' });

  // Core Website & Portal Pages
  assert.deepEqual(resolveRoute('/'), { page: 'home' });
  assert.deepEqual(resolveRoute('/courses'), { page: 'courses', presetCategory: 'All' });
  assert.deepEqual(resolveRoute('/subjects'), { page: 'courses', presetCategory: 'Subjects' });
  assert.deepEqual(resolveRoute('/about'), { page: 'about', tab: 'about' });
  assert.deepEqual(resolveRoute('/teachers'), { page: 'about', tab: 'teachers' });
  assert.deepEqual(resolveRoute('/contact'), { page: 'contact' });
  assert.deepEqual(resolveRoute('/admission'), { page: 'contact', isAdmission: true });
  assert.deepEqual(resolveRoute('/results'), { page: 'alumni', tab: 'results' });
  assert.deepEqual(resolveRoute('/testimonials'), { page: 'alumni', tab: 'testimonials' });
  assert.deepEqual(resolveRoute('/gallery'), { page: 'gallery' });
  assert.deepEqual(resolveRoute('/fee-calculator'), { page: 'fee-calculator' });
  assert.deepEqual(resolveRoute('/scholarship'), { page: 'scholarship' });
  assert.deepEqual(resolveRoute('/comparison'), { page: 'comparison' });
  assert.deepEqual(resolveRoute('/faqs'), { page: 'faqs' });
  assert.deepEqual(resolveRoute('/blog/study-tips'), { page: 'blogs', slug: 'study-tips' });
  assert.deepEqual(resolveRoute('/privacy'), { page: 'legal', doc: 'privacy' });
  assert.deepEqual(resolveRoute('/terms'), { page: 'legal', doc: 'terms' });
  assert.deepEqual(resolveRoute('/refund'), { page: 'legal', doc: 'refund' });
  assert.deepEqual(resolveRoute('/cookie-policy'), { page: 'legal', doc: 'cookies' });
  assert.deepEqual(resolveRoute('/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/student/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/teacher/login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/student-login'), { page: 'portal' });
  assert.deepEqual(resolveRoute('/teacher-login'), { page: 'portal' });

  // Zero-404 Course & Info Aliases
  assert.deepEqual(resolveRoute('/course/class-10'), { page: 'program', slug: 'class-10' });
  assert.deepEqual(resolveRoute('/course/exam-neet'), { page: 'program', slug: 'exam-neet' });
  assert.deepEqual(resolveRoute('/course/board-up-board'), { page: 'program', slug: 'board-up-board' });
  assert.deepEqual(resolveRoute('/classes/12'), { page: 'program', slug: 'class-12' });
  assert.deepEqual(resolveRoute('/admissions'), { page: 'contact', isAdmission: true });
  assert.deepEqual(resolveRoute('/faq'), { page: 'faqs' });
  assert.deepEqual(resolveRoute('/fees'), { page: 'fee-calculator' });
  assert.deepEqual(resolveRoute('/faculty'), { page: 'about', tab: 'teachers' });
});

test('validateInquiryPayload rejects invalid fields and accepts valid submissions', () => {
  const invalid = validateInquiryPayload({
    name: 'A',
    phone: '12345',
    email: 'not-an-email',
    class_or_course: '',
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.phone);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.class_or_course);

  const valid = validateInquiryPayload({
    name: 'Ananya Verma',
    phone: '+91 78272 89292',
    email: 'inquiry@yuitor.com',
    class_or_course: 'Class 10',
  });
  assert.equal(valid.valid, true);
  assert.deepEqual(valid.errors, {});
});

test('calculateFeeSummary computes lump-sum discount, scholarship, and installments deterministically', () => {
  const result = calculateFeeSummary({
    baseTotalFee: 20000,
    plan: 'lump-sum',
    months: 12,
    scholarshipPercent: 20,
    includeEvalSupport: false,
  });
  assert.equal(result.grossFee, 20000);
  assert.equal(result.scholarshipDiscount, 4000);
  assert.equal(result.planDiscount, 1600);
  assert.equal(result.evalSupportFee, 0);
  assert.equal(result.netPayable, 14400);
  assert.equal(result.installmentCount, 1);
  assert.equal(formatINR(result.netPayable), '₹14,400');
});

test('Class 6th-12th fee plans and 5 billing cycles match exact v3.0 fee schedule', () => {
  assert.equal(CLASS_FEE_PLANS.length, 7);
  assert.equal(BILLING_CYCLES.length, 5);
  const expected: Array<[number, number, number, number, number, number, number]> = [
    [6, 600, 1800, 3600, 5400, 6480, 720],
    [7, 650, 1950, 3900, 5850, 7020, 780],
    [8, 700, 2100, 4200, 6300, 7560, 840],
    [9, 750, 2250, 4500, 6750, 8100, 900],
    [10, 800, 2400, 4800, 7200, 8640, 960],
    [11, 850, 2550, 5100, 7650, 9180, 1020],
    [12, 900, 2700, 5400, 8100, 9720, 1080],
  ];
  for (const [cls, m1, m3, m6, m9, yr, save] of expected) {
    assert.equal(calculateClassFeePlan(cls, '1m').totalPayable, m1);
    assert.equal(calculateClassFeePlan(cls, '3m').totalPayable, m3);
    assert.equal(calculateClassFeePlan(cls, '6m').totalPayable, m6);
    assert.equal(calculateClassFeePlan(cls, '9m').totalPayable, m9);
    const yearly = calculateClassFeePlan(cls, 'yearly');
    assert.equal(yearly.totalPayable, yr);
    assert.equal(yearly.savings, save);
    assert.equal(yearly.discountPercent, 10);
    assert.equal(getProgramBySlug(`class-${cls}`).monthlyFee, m1);
    assert.equal(getProgramBySlug(`class-${cls}`).totalFee, yr);
  }
});

test('filterBackendCourses filters by category and search query', () => {
  const sample = [
    { id: 1, title: 'Class 10 UP Board Mastery', category: 'Classes 6-12', monthly_fee: 800 },
    { id: 2, title: 'NEET Coaching Batch', category: 'Competitive', monthly_fee: 1800 },
    { id: 3, title: 'Coding Classes (Python)', category: 'Coding', monthly_fee: 900 },
  ];
  assert.equal(filterBackendCourses(sample, 'all', '').length, 3);
  assert.equal(filterBackendCourses(sample, 'Competitive', '').length, 1);
  assert.equal(filterBackendCourses(sample, 'all', 'python').length, 1);
});
