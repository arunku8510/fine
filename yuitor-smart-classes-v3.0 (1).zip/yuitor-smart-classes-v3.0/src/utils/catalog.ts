import type { BackendCourse, InquiryPayload } from '../types';

export function normalizePathname(raw: string): string {
  const cleaned = String(raw || '/')
    .split(/[?#]/)[0]
    .replace(/\/+/g, '/')
    .replace(/\/+$/, '');
  return cleaned || '/';
}

const PORTAL_PREFIXES = [
  '/student',
  '/teacher',
  '/parent',
  '/staff',
  '/erp',
  '/login',
  '/register',
  '/ref',
  '/unsubscribe',
];

const PORTAL_EXACT = new Set([
  '/login.php',
  '/register.php',
  '/teacher-apply.php',
  '/student-login',
  '/teacher-login',
  '/parent-login',
  '/student-register',
  '/teacher-register',
  '/parent-register',
]);

export function isPortalPath(pathname: string, adminGateBase = ''): boolean {
  const path = normalizePathname(pathname).toLowerCase();
  const gate = normalizePathname(adminGateBase).toLowerCase();
  if (gate && gate !== '/' && (path === gate || path.startsWith(`${gate}/`))) {
    return true;
  }
  if (PORTAL_EXACT.has(path)) return true;
  return PORTAL_PREFIXES.some((prefix) => path === prefix || path.startsWith(`${prefix}/`));
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

export function validateInquiryPayload(payload: InquiryPayload): ValidationResult {
  const errors: Record<string, string> = {};
  const name = (payload.name || '').trim();
  const digits = (payload.phone || '').replace(/\D/g, '');
  const email = (payload.email || '').trim();
  const course = (payload.class_or_course || '').trim();

  if (name.length < 2) {
    errors.name = 'Please enter your full name (at least 2 characters).';
  }
  if (digits.length < 10 || digits.length > 13) {
    errors.phone = 'Please enter a valid 10-digit mobile number.';
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!course) {
    errors.class_or_course = 'Please select a program or course.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export interface FeeCalculationInput {
  baseTotalFee: number;
  plan: 'lump-sum' | 'quarterly' | 'monthly';
  months: number;
  scholarshipPercent: number;
  includeEvalSupport: boolean;
}

export interface FeeCalculationOutput {
  grossFee: number;
  scholarshipDiscount: number;
  planDiscount: number;
  evalSupportFee: number;
  netPayable: number;
  installmentAmount: number;
  installmentCount: number;
}

export function calculateFeeSummary(input: FeeCalculationInput): FeeCalculationOutput {
  const grossFee = Math.max(0, Math.round(input.baseTotalFee));
  const clampedScholarship = Math.min(50, Math.max(0, input.scholarshipPercent));
  const scholarshipDiscount = Math.round((grossFee * clampedScholarship) / 100);
  const afterScholarship = grossFee - scholarshipDiscount;
  const planDiscount = input.plan === 'lump-sum' ? Math.round(afterScholarship * 0.1) : 0;
  const evalSupportFee = input.includeEvalSupport ? 1500 : 0;
  const netPayable = Math.max(0, afterScholarship - planDiscount + evalSupportFee);

  const safeMonths = Math.max(1, Math.round(input.months));
  const installmentCount =
    input.plan === 'lump-sum'
      ? 1
      : input.plan === 'quarterly'
        ? Math.max(2, Math.ceil(safeMonths / 3))
        : safeMonths;
  const installmentAmount = Math.round(netPayable / installmentCount);

  return {
    grossFee,
    scholarshipDiscount,
    planDiscount,
    evalSupportFee,
    netPayable,
    installmentAmount,
    installmentCount,
  };
}

export type BillingCycleId = '1m' | '3m' | '6m' | '9m' | 'yearly';

export interface BillingCycleOption {
  id: BillingCycleId;
  label: string;
  shortLabel: string;
  months: number;
  discountPercent: number;
}

export interface ClassFeePlan {
  classNumber: number;
  classLabel: string;
  monthly: number;
  m1: number;
  m3: number;
  m6: number;
  m9: number;
  yearlyGross: number;
  yearlySavings: number;
  yearlyTotal: number;
}

export interface ClassFeeCalculation {
  classNumber: number;
  classLabel: string;
  cycle: BillingCycleId;
  cycleLabel: string;
  months: number;
  monthlyRate: number;
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  savings: number;
  totalPayable: number;
}

export const BILLING_CYCLES: BillingCycleOption[] = [
  { id: '1m', label: '1 Month', shortLabel: '1m', months: 1, discountPercent: 0 },
  { id: '3m', label: '3 Months', shortLabel: '3m', months: 3, discountPercent: 0 },
  { id: '6m', label: '6 Months', shortLabel: '6m', months: 6, discountPercent: 0 },
  { id: '9m', label: '9 Months', shortLabel: '9m', months: 9, discountPercent: 0 },
  { id: 'yearly', label: 'Yearly (10% OFF)', shortLabel: 'Yearly', months: 12, discountPercent: 10 },
];

export const CLASS_FEE_PLANS: ClassFeePlan[] = [
  { classNumber: 6, classLabel: 'Class 6th', monthly: 600, m1: 600, m3: 1800, m6: 3600, m9: 5400, yearlyGross: 7200, yearlySavings: 720, yearlyTotal: 6480 },
  { classNumber: 7, classLabel: 'Class 7th', monthly: 650, m1: 650, m3: 1950, m6: 3900, m9: 5850, yearlyGross: 7800, yearlySavings: 780, yearlyTotal: 7020 },
  { classNumber: 8, classLabel: 'Class 8th', monthly: 700, m1: 700, m3: 2100, m6: 4200, m9: 6300, yearlyGross: 8400, yearlySavings: 840, yearlyTotal: 7560 },
  { classNumber: 9, classLabel: 'Class 9th', monthly: 750, m1: 750, m3: 2250, m6: 4500, m9: 6750, yearlyGross: 9000, yearlySavings: 900, yearlyTotal: 8100 },
  { classNumber: 10, classLabel: 'Class 10th', monthly: 800, m1: 800, m3: 2400, m6: 4800, m9: 7200, yearlyGross: 9600, yearlySavings: 960, yearlyTotal: 8640 },
  { classNumber: 11, classLabel: 'Class 11th', monthly: 850, m1: 850, m3: 2550, m6: 5100, m9: 7650, yearlyGross: 10200, yearlySavings: 1020, yearlyTotal: 9180 },
  { classNumber: 12, classLabel: 'Class 12th', monthly: 900, m1: 900, m3: 2700, m6: 5400, m9: 8100, yearlyGross: 10800, yearlySavings: 1080, yearlyTotal: 9720 },
];

export function calculateClassFeePlan(classNumber: number, cycle: BillingCycleId): ClassFeeCalculation {
  const plan = CLASS_FEE_PLANS.find((p) => p.classNumber === classNumber) || CLASS_FEE_PLANS[4];
  const cycleMeta = BILLING_CYCLES.find((c) => c.id === cycle) || BILLING_CYCLES[0];
  const subtotal = plan.monthly * cycleMeta.months;
  const discountAmount = cycleMeta.discountPercent > 0 ? Math.round((subtotal * cycleMeta.discountPercent) / 100) : 0;
  const totalPayable = subtotal - discountAmount;
  return {
    classNumber: plan.classNumber,
    classLabel: plan.classLabel,
    cycle: cycleMeta.id,
    cycleLabel: cycleMeta.label,
    months: cycleMeta.months,
    monthlyRate: plan.monthly,
    subtotal,
    discountPercent: cycleMeta.discountPercent,
    discountAmount,
    savings: discountAmount,
    totalPayable,
  };
}

export function formatINR(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `₹${safe.toLocaleString('en-IN')}`;
}

export function filterBackendCourses(
  courses: BackendCourse[],
  category: string,
  searchQuery: string
): BackendCourse[] {
  const q = searchQuery.trim().toLowerCase();
  const cat = category.trim().toLowerCase();

  return courses.filter((course) => {
    const matchesCat =
      !cat ||
      cat === 'all' ||
      (course.category || '').toLowerCase().includes(cat) ||
      (course.class_level || '').toLowerCase().includes(cat) ||
      (course.title || '').toLowerCase().includes(cat);

    if (!matchesCat) return false;
    if (!q) return true;

    const haystack = [
      course.title,
      course.category,
      course.class_level,
      course.board,
      course.description,
      course.teacher_name,
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    return haystack.includes(q);
  });
}

export type ResolvedRoute =
  | { page: 'portal' }
  | { page: 'home' }
  | { page: 'about'; tab?: 'about' | 'teachers' }
  | { page: 'courses'; presetCategory?: string }
  | { page: 'program'; slug: string }
  | { page: 'contact'; citySlug?: string; isAdmission?: boolean }
  | { page: 'gallery' }
  | { page: 'alumni'; tab?: 'alumni' | 'results' | 'testimonials' }
  | { page: 'webinars' }
  | { page: 'corporate'; section?: 'journey' | 'events' | 'tie-ups' }
  | { page: 'blogs'; slug?: string; category?: string }
  | { page: 'fee-calculator' }
  | { page: 'scholarship' }
  | { page: 'comparison' }
  | { page: 'faqs' }
  | { page: 'legal'; doc: 'privacy' | 'terms' | 'refund' | 'cookies' }
  | { page: 'not-found' };

const VALID_CLASSES = new Set(['6', '7', '8', '9', '10', '11', '12']);
const VALID_BOARDS = new Set(['cbse', 'up-board', 'icse', 'state-board']);
const VALID_EXAMS = new Set(['neet', 'jee', 'cuet', 'nda', 'ssc', 'banking']);

function resolveProgramAlias(rawSeg: string): string | null {
  const seg = rawSeg.replace(/\/+$/, '').replace(/-coaching$/, '').replace(/-classes$/, '');
  if (VALID_CLASSES.has(seg)) return `class-${seg}`;
  if (seg.startsWith('class-') && VALID_CLASSES.has(seg.slice(6))) return seg;
  if (VALID_BOARDS.has(seg)) return `board-${seg}`;
  if (seg.startsWith('board-') && VALID_BOARDS.has(seg.slice(6))) return seg;
  if (seg === 'cbse' || seg === 'cbseboard' || seg === 'cbse-board') return 'board-cbse';
  if (seg === 'up' || seg === 'upboard') return 'board-up-board';
  if (seg === 'state' || seg === 'stateboard') return 'board-state-board';
  if (VALID_EXAMS.has(seg)) return `exam-${seg}`;
  if (seg.startsWith('exam-') && VALID_EXAMS.has(seg.slice(5))) return seg;
  if (seg === 'computer' || seg === 'computer-course' || seg === 'computer-courses' || seg === 'dca-tally') return 'computer';
  if (seg === 'spoken-english' || seg === 'english' || seg === 'english-speaking') return 'spoken-english';
  if (seg === 'coding' || seg === 'python-coding' || seg === 'web-coding') return 'coding';
  return null;
}

export function resolveRoute(rawPathname: string, adminGateBase = ''): ResolvedRoute {
  const path = normalizePathname(rawPathname);
  const lower = path.toLowerCase();

  if (isPortalPath(lower, adminGateBase)) return { page: 'portal' };
  if (lower === '/' || lower === '/home' || lower === '/index.html') return { page: 'home' };

  if (lower === '/about' || lower === '/about-us' || lower === '/about-simandhar') {
    return { page: 'about', tab: 'about' };
  }
  if (lower === '/teachers' || lower === '/faculty' || lower === '/mentors') {
    return { page: 'about', tab: 'teachers' };
  }

  if (lower === '/courses' || lower === '/subjects' || lower === '/programs' || lower === '/batches') {
    return { page: 'courses', presetCategory: lower === '/subjects' ? 'Subjects' : 'All' };
  }
  if (lower === '/computer-courses' || lower === '/computer-classes') {
    return { page: 'program', slug: 'computer' };
  }
  if (lower === '/english-speaking' || lower === '/spoken-english') {
    return { page: 'program', slug: 'spoken-english' };
  }
  if (lower === '/coding-classes' || lower === '/coding') {
    return { page: 'program', slug: 'coding' };
  }

  // /course/<slug> or /courses/<slug> (handles computer, spoken-english, coding, class-6..12, exam-*, board-*)
  if (lower.startsWith('/course/') || lower.startsWith('/courses/')) {
    const seg = lower.replace(/^\/courses?\//, '');
    const resolvedSlug = resolveProgramAlias(seg);
    if (resolvedSlug) return { page: 'program', slug: resolvedSlug };
    return { page: 'courses', presetCategory: 'All' };
  }

  // Exact School Classes: Class 6 to Class 12 ONLY
  if (lower.startsWith('/class/') || lower.startsWith('/classes/')) {
    const cls = lower.replace(/^\/class(?:es)?\//, '').replace(/^class-/, '');
    if (VALID_CLASSES.has(cls)) {
      return { page: 'program', slug: `class-${cls}` };
    }
    return { page: 'not-found' };
  }

  // Exact Boards: CBSE, UP Board, ICSE, State Board
  if (lower.startsWith('/board/') || lower.startsWith('/boards/')) {
    const brd = lower.replace(/^\/boards?\//, '');
    const resolvedSlug = resolveProgramAlias(brd);
    if (resolvedSlug && resolvedSlug.startsWith('board-')) {
      return { page: 'program', slug: resolvedSlug };
    }
    return { page: 'not-found' };
  }

  // Exact Competitive Exams: NEET, JEE, CUET, NDA, SSC, Banking ONLY
  if (lower.startsWith('/exam/') || lower.startsWith('/exams/')) {
    const ex = lower.replace(/^\/exams?\//, '');
    const resolvedSlug = resolveProgramAlias(ex);
    if (resolvedSlug && resolvedSlug.startsWith('exam-')) {
      return { page: 'program', slug: resolvedSlug };
    }
    return { page: 'not-found' };
  }

  // Direct top-level program shortcuts like /neet, /jee, /cuet, /nda, /ssc, /banking, /up-board, /icse, /state-board
  const directAlias = resolveProgramAlias(lower.slice(1));
  if (directAlias) {
    return { page: 'program', slug: directAlias };
  }

  // Contact, Admissions & Regional Hubs
  if (lower === '/contact' || lower === '/contact-us' || lower === '/contact-simandhar') {
    return { page: 'contact' };
  }
  if (lower === '/admission' || lower === '/admissions' || lower === '/demo' || lower === '/book-demo' || lower === '/enquiry') {
    return { page: 'contact', isAdmission: true };
  }
  if (lower.startsWith('/finance-courses-')) {
    return { page: 'contact', citySlug: lower.replace('/finance-courses-', '') };
  }

  // Gallery, Alumni, Results, Testimonials
  if (lower === '/gallery' || lower === '/campus-gallery') return { page: 'gallery' };
  if (lower === '/alumni') return { page: 'alumni', tab: 'alumni' };
  if (lower === '/results' || lower === '/toppers') return { page: 'alumni', tab: 'results' };
  if (lower === '/testimonials' || lower === '/reviews') return { page: 'alumni', tab: 'testimonials' };

  // Webinars & Corporate
  if (lower === '/webinars' || lower === '/workshops') return { page: 'webinars' };
  if (lower === '/corporate-journey') return { page: 'corporate', section: 'journey' };
  if (lower === '/corporate-events') return { page: 'corporate', section: 'events' };
  if (lower === '/tie-ups' || lower === '/corporate-tie-ups') return { page: 'corporate', section: 'tie-ups' };

  // Blogs
  if (lower === '/blog' || lower === '/blogs') return { page: 'blogs' };
  if (lower === '/blogs/category/student-corner' || lower === '/blog/category/student-corner') {
    return { page: 'blogs', category: 'Student Corner' };
  }
  if (lower.startsWith('/blog/') || lower.startsWith('/blogs/')) {
    const slug = lower.replace(/^\/blogs?\//, '');
    return { page: 'blogs', slug };
  }

  // Utilities & Policies
  if (lower === '/fee-calculator' || lower === '/fees' || lower === '/fee-structure') return { page: 'fee-calculator' };
  if (lower === '/scholarship' || lower === '/scholarships') return { page: 'scholarship' };
  if (lower === '/comparison' || lower === '/why-yuitor') return { page: 'comparison' };
  if (lower === '/faqs' || lower === '/faq' || lower === '/help') return { page: 'faqs' };
  if (lower === '/privacy' || lower === '/privacy-policy') return { page: 'legal', doc: 'privacy' };
  if (lower === '/terms' || lower === '/terms-of-service' || lower === '/terms-and-conditions') return { page: 'legal', doc: 'terms' };
  if (lower === '/refund' || lower === '/refund-policy') return { page: 'legal', doc: 'refund' };
  if (lower === '/cookie-policy' || lower === '/cookies') return { page: 'legal', doc: 'cookies' };

  return { page: 'not-found' };
}
