export interface BackendCourse {
  id: number;
  title: string;
  slug?: string;
  category?: string;
  class_level?: string;
  board?: string;
  description?: string;
  monthly_fee: number;
  yearly_fee?: number;
  duration_months?: number;
  mode?: string;
  is_featured?: number;
  is_active?: number;
  teacher_name?: string;
}

export interface BackendSubject {
  id: number;
  name: string;
  class_level?: string;
  course_id?: number;
  description?: string;
}

export interface BackendTeacher {
  id: number;
  full_name: string;
  qualification?: string;
  experience_years?: number;
  bio?: string;
  subjects?: string[];
  avatar_url?: string;
}

export interface BackendFaq {
  id: number;
  question: string;
  answer: string;
  category?: string;
}

export interface BackendTestimonial {
  id: number;
  student_name: string;
  course_or_class?: string;
  quote: string;
  rating?: number;
  achievement?: string;
}

export interface BackendBlogPost {
  id?: number | string;
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  author?: string;
  readTime?: string;
  date?: string;
  published_at?: string;
  image?: string;
}

export type BlogPost = BackendBlogPost;

export interface BackendAnnouncement {
  id: number;
  title: string;
  message: string;
  audience?: string;
  created_at?: string;
}

export interface BackendBranch {
  id: number;
  name: string;
  city?: string;
  address?: string;
  phone?: string;
}

export interface BackendBatch {
  id: number;
  name: string;
  timing?: string;
  course_id?: number;
}

export interface BootstrapData {
  courses: BackendCourse[];
  subjects: BackendSubject[];
  teachers: BackendTeacher[];
  faqs: BackendFaq[];
  testimonials: BackendTestimonial[];
  announcements: BackendAnnouncement[];
  blogs: BackendBlogPost[];
  branches: BackendBranch[];
  batches: BackendBatch[];
  departmentEmails?: Record<string, string>;
  settings?: Record<string, string>;
}

export interface ProgramDetail {
  slug: string;
  shortCode: string;
  title: string;
  subtitle: string;
  category: 'Classes 6–12' | 'Boards' | 'Competitive Exams' | 'Skill Courses';
  partnerNote: string;
  duration: string;
  examsCount: string;
  placementHighlight: string;
  passRate: string;
  avgSalary: string;
  monthlyFee: number;
  totalFee: number;
  heroImage: string;
  overview: string;
  eligibility: string[];
  syllabus: { code: string; title: string; focus: string }[];
  journeySteps: { step: string; title: string; detail: string }[];
  faqs: { q: string; a: string }[];
}

export interface OfficeLocation {
  slug: string;
  city: string;
  regionLabel: string;
  address: string;
  phone: string;
  email: string;
  timings: string;
  credentials: string;
  image: string;
}

export interface WebinarEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  speaker: string;
  speakerRole: string;
  topicTag: string;
  benefit: string;
  summary: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Convocation & Toppers' | 'Corporate Seminars' | 'AI & Smart Labs' | 'Campus Life';
  image: string;
  caption: string;
  location: string;
}

export interface AlumniStory {
  id: string;
  name: string;
  credential: string;
  role: string;
  company: string;
  city: string;
  story: string;
  outcome: string;
}

export interface JobVacancy {
  id: string;
  role: string;
  company: string;
  vacancies: number;
  experience: string;
  location: string;
  credential: string;
}

export interface InquiryPayload {
  name: string;
  phone: string;
  email?: string;
  class_or_course: string;
  message?: string;
  source?: string;
  branch_id?: string | number;
  demoDate?: string;
  demoTimeSlot?: string;
}

declare global {
  interface Window {
    __YU_ADMIN_GATE__?: {
      basePath: string;
      apiBase: string;
    };
    YuitorAddons?: {
      addCourseToCart?: (courseId: number | string) => Promise<void> | void;
      openCartDrawer?: () => Promise<void> | void;
      refreshCartBadge?: () => Promise<void> | void;
      initReferralCapture?: () => void;
    };
  }
}
