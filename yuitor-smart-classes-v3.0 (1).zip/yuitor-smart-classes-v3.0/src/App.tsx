import { useCallback, useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { EnquiryModal } from './components/EnquiryModal';
import { HomePage } from './pages/HomePage';
import { ProgramDetailPage } from './pages/ProgramDetailPage';
import { CoursesCatalogPage } from './pages/CoursesCatalogPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import {
  AlumniResultsPage,
  BlogsPage,
  ComparisonPage,
  CorporatePage,
  FaqsPage,
  FeeCalculatorPage,
  GalleryPage,
  LegalPage,
  ScholarshipPage,
  WebinarsPage,
} from './pages/CommunityPages';
import { useBootstrap } from './hooks/useBootstrap';
import { isPortalPath, normalizePathname, resolveRoute } from './utils/catalog';

function getAdminGateBase(): string {
  return window.__YU_ADMIN_GATE__?.basePath || '';
}

export default function App() {
  const [pathname, setPathname] = useState<string>(() =>
    normalizePathname(window.location.pathname)
  );
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [enquiryCourse, setEnquiryCourse] = useState<string | undefined>(undefined);
  const { data: boot } = useBootstrap();

  useEffect(() => {
    const syncPath = () => {
      setPathname(normalizePathname(window.location.pathname));
    };
    window.addEventListener('popstate', syncPath);
    window.addEventListener('yuitor:route-changed', syncPath);
    return () => {
      window.removeEventListener('popstate', syncPath);
      window.removeEventListener('yuitor:route-changed', syncPath);
    };
  }, []);

  const navigate = useCallback((nextPath: string) => {
    const normalized = normalizePathname(nextPath);
    const gateBase = getAdminGateBase();

    // Navigating into or out of portals.js-managed routes triggers clean pushState + portals.js observer
    if (normalized !== normalizePathname(window.location.pathname)) {
      window.history.pushState({}, '', nextPath);
    }
    setPathname(normalized);

    if (!isPortalPath(normalized, gateBase)) {
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    }
  }, []);

  const openEnquiry = useCallback((course?: string) => {
    setEnquiryCourse(course);
    setEnquiryOpen(true);
  }, []);

  const resolved = resolveRoute(pathname, getAdminGateBase());

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F5] text-[#1D1014]">
      <Navbar
        currentPath={pathname}
        onNavigate={navigate}
        onOpenEnquiry={openEnquiry}
      />

      {resolved.page === 'portal' ? (
        <main className="flex-1 portal-main">
          <div data-yu-portal-host="" />
        </main>
      ) : (
        <main className="flex-1">
          {resolved.page === 'home' && (
            <HomePage boot={boot} onNavigate={navigate} onOpenEnquiry={openEnquiry} />
          )}
          {resolved.page === 'program' && (
            <ProgramDetailPage slug={resolved.slug} boot={boot} onNavigate={navigate} />
          )}
          {resolved.page === 'courses' && (
            <CoursesCatalogPage
              boot={boot}
              isSubjectsPage={resolved.presetCategory === 'Subjects'}
              onNavigate={navigate}
              onOpenEnquiry={openEnquiry}
            />
          )}
          {resolved.page === 'about' && (
            <AboutPage
              boot={boot}
              defaultTab={resolved.tab}
              onNavigate={navigate}
              onOpenEnquiry={openEnquiry}
            />
          )}
          {resolved.page === 'contact' && (
            <ContactPage
              boot={boot}
              citySlug={resolved.citySlug}
              isAdmission={resolved.isAdmission}
              onNavigate={navigate}
            />
          )}
          {resolved.page === 'gallery' && <GalleryPage />}
          {resolved.page === 'alumni' && (
            <AlumniResultsPage
              boot={boot}
              tab={resolved.tab}
              onOpenEnquiry={openEnquiry}
            />
          )}
          {resolved.page === 'webinars' && <WebinarsPage boot={boot} />}
          {resolved.page === 'corporate' && (
            <CorporatePage boot={boot} section={resolved.section} />
          )}
          {resolved.page === 'blogs' && (
            <BlogsPage
              boot={boot}
              slug={resolved.slug}
              presetCategory={resolved.category}
              onNavigate={navigate}
            />
          )}
          {resolved.page === 'fee-calculator' && <FeeCalculatorPage boot={boot} />}
          {resolved.page === 'scholarship' && <ScholarshipPage boot={boot} />}
          {resolved.page === 'comparison' && <ComparisonPage onOpenEnquiry={openEnquiry} />}
          {resolved.page === 'faqs' && <FaqsPage boot={boot} />}
          {resolved.page === 'legal' && <LegalPage doc={resolved.doc} />}
          {resolved.page === 'not-found' && (
            <section className="py-24 text-center px-4">
              <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">404 · Page Not Found</p>
              <h1 className="mt-2 font-editorial text-4xl font-bold text-[#1D1014]">
                We Couldn&apos;t Find That Page
              </h1>
              <p className="mt-3 text-sm text-[#5E4B51] max-w-md mx-auto">
                Explore Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, and Coding Classes or return to the homepage.
              </p>
              <div className="mt-7 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => navigate('/')}
                  className="rounded-full bg-[#7A0F28] px-6 py-2.5 text-sm font-semibold text-white cursor-pointer"
                >
                  Back to Home
                </button>
                <button
                  type="button"
                  onClick={() => navigate('/courses')}
                  className="rounded-full border border-[#7A0F28] px-6 py-2.5 text-sm font-semibold text-[#7A0F28] cursor-pointer"
                >
                  Browse Courses
                </button>
              </div>
            </section>
          )}
        </main>
      )}

      <Footer onNavigate={navigate} />

      <EnquiryModal
        open={enquiryOpen}
        defaultCourse={enquiryCourse}
        courses={boot.courses}
        branches={boot.branches}
        onClose={() => setEnquiryOpen(false)}
      />
    </div>
  );
}
