import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Award,
  BookOpen,
  ShoppingBag,
  Sparkles,
  Users,
  GraduationCap,
  Laptop,
  Megaphone,
  Phone,
  MapPin,
} from 'lucide-react';
import type { BootstrapData } from '../types';
import {
  AWARDS_AND_HIGHLIGHTS,
  BATCH_OPENINGS,
  BOARD_LINKS,
  BOARD_PARTNERS,
  BRAND_IMAGES,
  BRAND_INFO,
  CLASS_LINKS,
  COMMUNITY_STATS,
  COMPARISON_ROWS,
  CORE_PROGRAMS,
  EDITORIAL_BLOGS,
  EXAM_LINKS,
  HERO_METRICS,
  LEADERSHIP_COUNCIL,
  SKILL_LINKS,
  STUDENT_SUCCESS_STORIES,
  TOP_ACHIEVERS,
} from '../data/siteContent';
import { SafeImage } from '../components/SafeImage';
import { EnquiryForm } from '../components/EnquiryForm';
import { formatINR } from '../utils/catalog';

interface HomePageProps {
  boot: BootstrapData;
  onNavigate: (path: string) => void;
  onOpenEnquiry: (course?: string) => void;
}

const PATH_SHORTCUTS = [
  { label: 'Class 6–8', path: '/class/8' },
  { label: 'Class 9–10', path: '/class/10' },
  { label: 'Class 11–12', path: '/class/12' },
  { label: 'CBSE / UP / ICSE / State Board', path: '/board/cbse' },
  { label: 'NEET & JEE', path: '/exam/neet' },
  { label: 'CUET / NDA / SSC / Banking', path: '/exam/cuet' },
  { label: 'Computer & Coding', path: '/course/computer' },
  { label: 'Spoken English', path: '/course/spoken-english' },
];

function cleanBatchTitle(title: string): string {
  return title
    .replace(/AI Learning\s*&\s*/gi, '')
    .replace(/\bAI Learning\b/gi, 'Coding')
    .trim();
}

export function HomePage({ boot, onNavigate, onOpenEnquiry }: HomePageProps) {
  const [cartNotice, setCartNotice] = useState<string>('');

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  async function handleAddToCart(courseId: number, title: string) {
    if (window.YuitorAddons?.addCourseToCart) {
      await window.YuitorAddons.addCourseToCart(courseId);
      setCartNotice(`Added "${title}" to your enrollment cart.`);
      setTimeout(() => setCartNotice(''), 3500);
    } else {
      onOpenEnquiry(title);
    }
  }

  const combinedBlogs = [...(boot.blogs || []), ...EDITORIAL_BLOGS].slice(0, 3);
  const featuredBackendCourses = (boot.courses || []).slice(0, 6);

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      {/* 1. HERO SECTION — Full-bleed Dark Burgundy Editorial Stage */}
      <section className="relative overflow-hidden bg-[#24040C] text-white">
        <div className="absolute inset-0">
          <SafeImage
            src={BRAND_IMAGES.heroCampus}
            alt="Teacher mentoring students in a Yuitor Smart Classes classroom in Muradnagar"
            className="w-full h-full object-cover object-center opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#24040C] via-[#3A0612]/90 to-[#24040C]/45" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#160207] via-transparent to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-10 lg:pt-14 lg:pb-12">
          <div className="max-w-3xl">
            <h1 className="font-editorial text-4xl sm:text-5xl lg:text-[3.45rem] font-bold leading-[1.08] tracking-tight text-white">
              Muradnagar&apos;s Smart Coaching Institute for{' '}
              <em className="italic font-semibold text-[#F3CF7A]">Classes 6th to 12th</em>
            </h1>

            {/* Gold Track Strip */}
            <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-sm sm:text-base font-bold tracking-wide text-[#E6B450]">
              {[
                { label: 'CBSE · UP Board · ICSE · State Board', path: '/board/cbse' },
                { label: 'NEET & JEE', path: '/exam/neet' },
                { label: 'CUET · NDA · SSC · Banking', path: '/exam/cuet' },
                { label: 'Computer & Coding', path: '/course/coding' },
                { label: 'Spoken English', path: '/course/spoken-english' },
              ].map((item, idx) => (
                <React.Fragment key={item.path}>
                  {idx > 0 && <span className="text-white/30" aria-hidden="true">|</span>}
                  <a
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </React.Fragment>
              ))}
            </div>

            <p className="mt-3.5 text-base sm:text-lg text-white/85 max-w-xl leading-relaxed">
              Small batches, expert subject teachers, weekly Board &amp; Competitive mocks, practical Computer, Spoken English &amp; Coding labs, and live Student &amp; Parent ERP tracking at Trimurti Vihar, Muradnagar.
            </p>

            {/* Secondary Skill Courses Link */}
            <div className="mt-3.5">
              <a
                href="/course/coding"
                onClick={(e) => go(e, '/course/coding')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#F3CF7A] border-b border-[#F3CF7A]/50 pb-0.5 hover:text-white hover:border-white transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Explore Practical Computer, Spoken English &amp; Coding Classes</span>
                <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
              </a>
            </div>

            {/* Primary CTA */}
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => onOpenEnquiry()}
                className="inline-flex items-center gap-2 rounded-full bg-[#8C102B] hover:bg-[#A61434] px-7 py-3.5 text-sm sm:text-base font-semibold text-white shadow-[0_12px_28px_rgba(0,0,0,0.35)] transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Book Free 2-Day Demo</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
              <a
                href="/courses"
                onClick={(e) => go(e, '/courses')}
                className="inline-flex items-center gap-2 rounded-full border border-white/30 hover:border-[#F3CF7A] hover:text-[#F3CF7A] px-6 py-3.5 text-sm sm:text-base font-semibold text-white transition-colors whitespace-nowrap"
              >
                Explore All Courses
              </a>
            </div>

            {/* 4-Column Hero Proof Metric Boxes */}
            <div className="mt-7 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl">
              {HERO_METRICS.map((m) => (
                <div
                  key={m.label}
                  className="rounded-xl border border-white/15 bg-black/30 backdrop-blur-xs px-4 py-3"
                >
                  <div className="font-mono tabular-nums text-xl sm:text-2xl font-bold text-[#F3CF7A]">
                    {m.value}
                  </div>
                  <div className="text-xs text-white/80 mt-0.5">{m.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Pick Your Path Interactive Bar */}
        <div className="relative bg-[#130307]/95 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="text-sm font-semibold text-white mr-2 whitespace-nowrap">
                I&apos;m Here For
              </span>
              {PATH_SHORTCUTS.map((item) => (
                <a
                  key={item.path}
                  href={item.path}
                  onClick={(e) => go(e, item.path)}
                  className="rounded-full border border-white/25 px-4 py-1.5 text-xs sm:text-sm font-medium text-white/90 hover:border-[#E6B450] hover:bg-[#7A0F28] hover:text-white transition-colors whitespace-nowrap"
                >
                  {item.label}
                </a>
              ))}
            </div>
            <span className="text-xs text-white/55 hidden md:inline">Pick Your Class or Goal</span>
          </div>
        </div>
      </section>

      {/* Live Backend Announcements Bar */}
      {boot.announcements.length > 0 && (
        <section aria-label="Latest Announcements" className="bg-[#FFF9EB] border-b border-[#EFE0BC]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-3 overflow-x-auto">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#7A0F28] shrink-0">
              <Megaphone className="w-3.5 h-3.5" aria-hidden="true" />
              Latest Notice
            </span>
            <span className="text-[#D4A13E]" aria-hidden="true">·</span>
            <div className="flex items-center gap-6 text-xs sm:text-sm text-[#3A1E24] whitespace-nowrap">
              {boot.announcements.slice(0, 3).map((ann) => (
                <span key={ann.id}>
                  <strong className="font-semibold text-[#1D1014]">{ann.title}:</strong> {ann.message}
                </span>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 2. BOARD TOPPERS & EXAM ACHIEVERS — Dark Editorial Band */}
      <section className="bg-[#0B0407] text-white py-16 lg:py-20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-xs font-semibold tracking-wider text-[#E6B450]">Our Star Achievers</p>
            <h2 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-white">
              Board Toppers &amp; Competitive Exam Qualifiers
            </h2>
            <p className="mt-3 text-sm sm:text-base text-white/70">
              Consistent 95%+ distinctions across UP Board, ICSE &amp; State Boards alongside NEET, JEE, CUET, NDA, SSC &amp; Banking selections from Muradnagar.
            </p>
          </div>

          {/* Achiever Cards Row */}
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {TOP_ACHIEVERS.map((topper) => (
              <div
                key={topper.name}
                className="rounded-xl border border-white/12 bg-white/[0.04] p-5 flex items-center justify-between gap-4 hover:border-[#E6B450]/50 transition-colors"
              >
                <div>
                  <div className="text-xs text-[#E6B450] font-semibold">{topper.credential}</div>
                  <div className="mt-1 text-base font-bold text-white">{topper.name}</div>
                  <div className="text-xs text-white/70 mt-0.5">{topper.company}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-mono tabular-nums text-sm font-bold text-[#F3CF7A]">{topper.score}</div>
                  <div className="text-[11px] text-white/50">Verified Result</div>
                </div>
              </div>
            ))}
          </div>

          {/* Boards, Exams & Skill Marquee */}
          <div className="mt-12 overflow-hidden py-4 border-y border-white/10">
            <div className="sim-marquee-track gap-6">
              {[...BOARD_PARTNERS, ...BOARD_PARTNERS].map((item, idx) => (
                <div
                  key={`${item}-${idx}`}
                  className="mx-3 px-7 py-3.5 rounded-xl bg-white/[0.05] border border-white/10 text-white/90 font-semibold tracking-wide text-sm sm:text-base whitespace-nowrap"
                >
                  {item}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
            <a
              href="/results"
              onClick={(e) => go(e, '/results')}
              className="rounded-full bg-[#7A0F28] hover:bg-[#9B1536] px-7 py-3 text-sm font-semibold text-white transition-colors"
            >
              Explore Full Results
            </a>
            <a
              href="/testimonials"
              onClick={(e) => go(e, '/testimonials')}
              className="rounded-full border border-white/25 hover:border-[#E6B450] hover:text-[#E6B450] px-7 py-3 text-sm font-semibold text-white transition-colors"
            >
              Student &amp; Parent Reviews
            </a>
          </div>
        </div>
      </section>

      {/* 3. CHOOSE YOUR ACADEMIC TRACK (Signature 3 Burgundy Medallions + Complete Directory) */}
      <section className="py-18 lg:py-24 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014]">
              Choose Your Learning Track
            </h2>
            <p className="mt-2 font-editorial italic text-xl sm:text-2xl text-[#7A0F28] font-semibold">
              Learn Deeply. Practice Weekly. Top Your Exams.
            </p>
            <p className="mt-3 text-sm sm:text-base text-[#5E4B51]">
              Structured coaching for Classes 6 to 12 across UP Board, ICSE &amp; State Boards, competitive entrance exams, and hands-on Computer Classes, Spoken English &amp; Coding Classes.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Three Signature Burgundy Medallions */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-5">
              {[
                {
                  code: 'Classes 6–12',
                  sub: 'School & Board Mastery',
                  desc: 'UP Board · ICSE · State Board',
                  points: ['Maths & Science', 'Commerce Streams', 'Weekly Unit Tests'],
                  path: '/class/10',
                },
                {
                  code: 'Boards & Exams',
                  sub: 'Medical, Engg & Govt',
                  desc: 'NEET · JEE · CUET · NDA · SSC · Banking',
                  points: ['Daily DPPs', 'OMR & CBT Mocks', 'Rank Mentorship'],
                  path: '/exam/neet',
                },
                {
                  code: 'Skill Courses',
                  sub: '1-to-1 Practical Labs',
                  desc: 'Computer Classes · Spoken English · Coding',
                  points: ['DCA & Tally GST', 'Python & Web Dev', 'Fluency & GD Club'],
                  path: '/course/computer',
                },
              ].map((card) => (
                <a
                  key={card.code}
                  href={card.path}
                  onClick={(e) => go(e, card.path)}
                  className="group rounded-3xl bg-gradient-to-b from-[#8C102B] to-[#58091B] text-white p-6 text-center shadow-[0_16px_34px_rgba(122,15,40,0.22)] ring-4 ring-[#7A0F28]/15 hover:-translate-y-1 transition-transform flex flex-col justify-between"
                >
                  <div>
                    <h3 className="font-editorial text-2xl font-bold text-white">{card.code}</h3>
                    <p className="text-xs font-semibold text-[#F3CF7A] mt-1">{card.sub}</p>
                    <p className="text-xs text-white/80 mt-2 leading-relaxed">{card.desc}</p>
                  </div>
                  <div className="mt-5 space-y-2">
                    {card.points.map((pt) => (
                      <div
                        key={pt}
                        className="rounded-full bg-white text-[#7A0F28] text-xs font-bold py-1.5 px-3"
                      >
                        {pt}
                      </div>
                    ))}
                  </div>
                </a>
              ))}
            </div>

            {/* Editorial "Why Yuitor?" Card */}
            <div className="lg:col-span-4 rounded-2xl bg-[#F9EFF1] border border-[#EBD5DA] p-7">
              <h3 className="font-editorial text-2xl font-bold text-[#7A0F28] leading-snug">
                Why Students &amp; Parents Trust Yuitor Smart Classes?
              </h3>
              <ul className="mt-5 space-y-3.5 text-sm text-[#3A2429]">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#7A0F28] shrink-0 mt-1" aria-hidden="true" />
                  <span>Small batches (15–20 students) ensuring personal copy checks &amp; doubt clearance.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#7A0F28] shrink-0 mt-1" aria-hidden="true" />
                  <span>Every Sunday Board/OMR/CBT tests with marks updated directly on Parent Portal.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#7A0F28] shrink-0 mt-1" aria-hidden="true" />
                  <span>1-student-1-PC Computer &amp; Coding lab plus interactive Spoken English club.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#7A0F28] shrink-0 mt-1" aria-hidden="true" />
                  <span>24/7 Shreya AI bilingual tutor &amp; transparent monthly fees with up to 50% scholarship.</span>
                </li>
              </ul>
              <div className="mt-6 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onOpenEnquiry()}
                  className="rounded-full bg-[#7A0F28] hover:bg-[#58091B] px-6 py-2.5 text-sm font-semibold text-white transition-colors cursor-pointer"
                >
                  Book Free Demo
                </button>
                <a
                  href="/fee-calculator"
                  onClick={(e) => go(e, '/fee-calculator')}
                  className="text-sm font-semibold text-[#7A0F28] underline underline-offset-4 hover:text-[#58091B]"
                >
                  Fee Calculator
                </a>
              </div>
            </div>
          </div>

          {/* Complete Quick-Access Directory for EVERY Class 6–12, Board, Exam & Skill Course */}
          <div className="mt-14 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#7A0F28]">
                <GraduationCap className="w-4 h-4" aria-hidden="true" />
                <span>School Classes (6th to 12th)</span>
              </div>
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2">
                {CLASS_LINKS.map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-xl bg-white border border-[#EADFE2] hover:border-[#7A0F28] hover:text-[#7A0F28] px-3 py-2.5 text-sm font-semibold text-center transition-colors"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#7A0F28]">
                <BookOpen className="w-4 h-4" aria-hidden="true" />
                <span>Boards &amp; Exams</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {[...BOARD_LINKS, ...EXAM_LINKS].map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-xl bg-white border border-[#EADFE2] hover:border-[#7A0F28] hover:text-[#7A0F28] px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#7A0F28]">
                <Laptop className="w-4 h-4" aria-hidden="true" />
                <span>Skill Courses</span>
              </div>
              <div className="mt-4 space-y-2">
                {SKILL_LINKS.map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="flex items-center justify-between rounded-xl bg-white border border-[#EADFE2] hover:border-[#7A0F28] px-4 py-2.5 transition-colors group"
                  >
                    <div>
                      <div className="text-sm font-semibold text-[#1D1014] group-hover:text-[#7A0F28]">
                        {item.label}
                      </div>
                      <div className="text-[11px] text-[#6B585E]">{item.desc}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#7A0F28] shrink-0" aria-hidden="true" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. LIVE BACKEND COURSE CATALOG (Synced directly with SQLite /api/public/bootstrap) */}
      <section className="py-18 lg:py-22 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
                Live Enrollment Catalog · Instant Student Portal Access
              </p>
              <h2 className="mt-1.5 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014]">
                Featured Batches &amp; Monthly Fee Plans
              </h2>
            </div>
            <a
              href="/courses"
              onClick={(e) => go(e, '/courses')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0F28] hover:text-[#58091B]"
            >
              <span>View All Courses &amp; Batches</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </a>
          </div>

          {cartNotice && (
            <div
              role="status"
              className="mt-5 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-900 flex items-center justify-between"
            >
              <span>{cartNotice}</span>
              <button
                type="button"
                onClick={() => window.YuitorAddons?.openCartDrawer?.()}
                className="font-semibold underline cursor-pointer"
              >
                Open Cart
              </button>
            </div>
          )}

          <div className="mt-9 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredBackendCourses.length > 0
              ? featuredBackendCourses.map((course) => (
                  <div
                    key={course.id}
                    className="rounded-2xl bg-white border border-[#EADFE2] p-6 flex flex-col justify-between hover:border-[#7A0F28]/45 transition-colors"
                  >
                    <div>
                      <div className="text-xs text-[#76646A] flex items-center gap-2">
                        <span>{cleanBatchTitle(course.category || 'Coaching Batch')}</span>
                        {course.class_level && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{course.class_level}</span>
                          </>
                        )}
                        {course.mode && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{course.mode}</span>
                          </>
                        )}
                      </div>
                      <h3 className="mt-2 font-editorial text-xl font-bold text-[#1D1014]">
                        {cleanBatchTitle(course.title)}
                      </h3>
                      <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed line-clamp-3">
                        {cleanBatchTitle(
                          course.description ||
                            'Structured classroom teaching, weekly tests, doubt clearing, and Parent Portal tracking.'
                        )}
                      </p>
                    </div>

                    <div className="mt-6 pt-4 border-t border-[#F0E6E9] flex items-center justify-between gap-3">
                      <div>
                        <div className="font-mono tabular-nums text-lg font-bold text-[#7A0F28]">
                          {formatINR(course.monthly_fee)}
                          <span className="text-xs font-normal text-[#76646A]"> / month</span>
                        </div>
                        {course.duration_months && (
                          <div className="text-xs text-[#76646A]">
                            {course.duration_months} months duration
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleAddToCart(course.id, course.title)}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-[#7A0F28] hover:bg-[#58091B] px-3.5 py-2 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Add to Cart</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenEnquiry(course.title)}
                          className="rounded-lg border border-[#EADFE2] hover:border-[#7A0F28] px-3 py-2 text-xs font-semibold text-[#1D1014] hover:text-[#7A0F28] transition-colors cursor-pointer whitespace-nowrap"
                        >
                          Enquire
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              : CORE_PROGRAMS.slice(0, 6).map((prog) => {
                  const progHref = prog.slug.startsWith('class-')
                    ? `/class/${prog.slug.replace('class-', '')}`
                    : prog.slug.startsWith('board-')
                      ? `/board/${prog.slug.replace('board-', '')}`
                      : prog.slug.startsWith('exam-')
                        ? `/exam/${prog.slug.replace('exam-', '')}`
                        : `/course/${prog.slug}`;
                  return (
                    <div
                      key={prog.slug}
                      className="rounded-2xl bg-white border border-[#EADFE2] p-6 flex flex-col justify-between hover:border-[#7A0F28]/45 transition-colors"
                    >
                      <div>
                        <div className="text-xs text-[#76646A]">
                          {prog.category} · {prog.duration}
                        </div>
                        <h3 className="mt-2 font-editorial text-xl font-bold text-[#1D1014]">
                          {prog.title}
                        </h3>
                        <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed">{prog.subtitle}</p>
                      </div>
                      <div className="mt-6 pt-4 border-t border-[#F0E6E9] flex items-center justify-between">
                        <span className="font-mono tabular-nums text-sm font-bold text-[#7A0F28]">
                          {formatINR(prog.monthlyFee)}/mo
                        </span>
                        <a
                          href={progHref}
                          onClick={(e) => go(e, progHref)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#7A0F28] hover:underline"
                        >
                          <span>View Details</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  );
                })}
          </div>
        </div>
      </section>

      {/* 5. PRACTICAL SKILL COURSES SPOTLIGHT */}
      <section className="py-18 lg:py-24 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
              1-Student-1-PC Labs · Career-Ready Communication
            </p>
            <h2 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014] leading-tight">
              Practical <span className="text-[#7A0F28] italic">Skill Courses</span> for School &amp; Career Growth
            </h2>
            <p className="mt-4 text-base text-[#4B3B40] leading-relaxed">
              Alongside school and competitive coaching, {BRAND_INFO.name} runs dedicated 1-to-1 practical labs for Computer Classes, Spoken English, and Coding Classes in Muradnagar.
            </p>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { title: 'Computer Classes', desc: 'Daily desktop lab for DCA, Tally Prime with GST, CCC & MS Office.', path: '/course/computer' },
                { title: 'Spoken English', desc: 'Fluent speaking, grammar, debates, stage confidence & interview prep.', path: '/course/spoken-english' },
                { title: 'Coding Classes', desc: 'Build real websites, Python programs, SQL & school coding projects.', path: '/course/coding' },
              ].map((item) => (
                <a
                  key={item.title}
                  href={item.path}
                  onClick={(e) => go(e, item.path)}
                  className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] hover:border-[#7A0F28] p-4 transition-colors"
                >
                  <div className="text-sm font-bold text-[#7A0F28]">{item.title}</div>
                  <p className="mt-1 text-xs text-[#5E4B51] leading-relaxed">{item.desc}</p>
                </a>
              ))}
            </div>
            <div className="mt-7 flex flex-wrap gap-3">
              <a
                href="/course/computer"
                onClick={(e) => go(e, '/course/computer')}
                className="inline-flex items-center gap-2 rounded-full bg-[#7A0F28] hover:bg-[#58091B] px-6 py-3 text-sm font-semibold text-white transition-colors"
              >
                <span>Explore Skill Courses</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="/fee-calculator"
                onClick={(e) => go(e, '/fee-calculator')}
                className="inline-flex items-center gap-2 rounded-full border border-[#DFD1D5] hover:border-[#7A0F28] px-6 py-3 text-sm font-semibold text-[#1D1014] hover:text-[#7A0F28] transition-colors"
              >
                Calculate Monthly Fees
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[340px] rounded-2xl overflow-hidden border border-[#EADFE2]">
              <SafeImage
                src={BRAND_IMAGES.codingWorkshop}
                alt="Students practicing coding and AI-assisted study at Yuitor Smart Classes lab"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 6. ABOUT & SIDE-BY-SIDE COMPARISON MATRIX */}
      <section className="py-18 lg:py-24 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">About {BRAND_INFO.name}</p>
            <h2 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014] leading-tight">
              Disciplined Mentorship. Transparent Parent Tracking.
            </h2>
            <p className="mt-4 text-sm sm:text-base text-[#4B3B40] leading-relaxed">
              Located at Trimurti Vihar, Near Venus Academy in Muradnagar, Yuitor Smart Classes brings structured teaching standards to Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, and Coding Classes.
            </p>
            <p className="mt-4 text-sm sm:text-base text-[#4B3B40] leading-relaxed">
              Unlike crowded coaching halls, we cap batch sizes, grade written papers every Sunday, and connect parents directly to attendance, test scores, and fee receipts through our unified ERP portal.
            </p>
            <div className="mt-6 rounded-xl bg-[#FFF9EB] border border-[#EED9A4] px-4 py-3.5 text-sm font-semibold text-[#6F4C08]">
              Free 2-Day Demo Class &amp; Up to 50% Merit Scholarship Available
            </div>
            <div className="mt-6">
              <a
                href="/about"
                onClick={(e) => go(e, '/about')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0F28] hover:underline"
              >
                <span>Read More About Our Campus &amp; Vision</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-7 overflow-x-auto">
            <div className="rounded-2xl bg-white border border-[#EADFE2] overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-[#24040C] text-white">
                    <th className="py-3.5 px-4 font-semibold">Feature</th>
                    <th className="py-3.5 px-4 font-semibold text-[#F3CF7A]">{BRAND_INFO.name}</th>
                    <th className="py-3.5 px-4 font-semibold text-white/70">Typical Coaching</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F0E6E9]">
                  {COMPARISON_ROWS.map((row) => (
                    <tr key={row.feature} className="hover:bg-[#FAF7F5]">
                      <td className="py-3.5 px-4 font-semibold text-[#1D1014]">{row.feature}</td>
                      <td className="py-3.5 px-4 text-[#7A0F28] font-semibold">✓ {row.ours}</td>
                      <td className="py-3.5 px-4 text-[#76646A]">{row.others}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* 7. STUDENT & PARENT STORIES — DARK EDITORIAL BAND */}
      <section className="py-18 lg:py-24 bg-[#120408] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-xs font-semibold tracking-wider text-[#E6B450]">Student Voices</p>
            <h2 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-white">
              From Classroom Doubts to{' '}
              <span className="text-[#F3CF7A]">95%+ Board &amp; Entrance Success</span>
            </h2>
            <p className="mt-3 text-sm sm:text-base text-white/70">
              How structured notes, weekly Sunday mocks, and caring subject mentors transform student confidence.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div className="lg:col-span-5 rounded-2xl overflow-hidden border border-white/15">
              <SafeImage
                src={BRAND_IMAGES.awardCeremony}
                alt="Yuitor Smart Classes students receiving academic topper awards"
                className="w-full h-full object-cover min-h-[280px]"
              />
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {STUDENT_SUCCESS_STORIES.map((st) => (
                <div
                  key={st.id}
                  className="rounded-2xl bg-white/[0.05] border border-white/12 p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-[#F3CF7A]">
                      {st.credential} · {st.city}
                    </div>
                    <h3 className="mt-1.5 font-editorial text-lg font-bold text-white">{st.name}</h3>
                    <div className="text-xs text-white/65">
                      {st.role} · {st.company}
                    </div>
                    <p className="mt-3 text-sm text-white/80 leading-relaxed">{st.story}</p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-white/10 text-xs font-semibold text-[#E6B450]">
                    Achievement: {st.outcome}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 8. FACULTY COUNCIL & OPEN BATCHES */}
      <section className="py-18 lg:py-24 bg-[#FAF7F5] border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">Dedicated Faculty</p>
            <h2 className="mt-2 font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014]">
              Mentored by Experienced Subject Specialists
            </h2>
          </div>

          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {LEADERSHIP_COUNCIL.map((leader) => (
              <div
                key={leader.name}
                className="rounded-2xl bg-white border border-[#EADFE2] overflow-hidden flex flex-col"
              >
                <div className="aspect-[4/3] overflow-hidden bg-[#24040C]">
                  <SafeImage
                    src={leader.image}
                    alt={leader.name}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div className="p-5 flex-1">
                  <h3 className="font-editorial text-lg font-bold text-[#1D1014]">{leader.name}</h3>
                  <div className="text-xs font-semibold text-[#7A0F28] mt-0.5">{leader.role}</div>
                  <p className="mt-2.5 text-xs text-[#5E4B51] leading-relaxed">{leader.bio}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Open Batches & Seat Availability */}
          <div className="mt-20">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
                  2026–27 Session · Limited Seats Per Batch
                </p>
                <h2 className="mt-1.5 font-editorial text-3xl font-bold text-[#1D1014]">
                  Active Admissions &amp; Open Batches
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onOpenEnquiry('New Batch Admission 2026–27')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0F28] hover:underline cursor-pointer"
              >
                <span>Reserve Your Demo Seat</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {BATCH_OPENINGS.map((b) => (
                <div
                  key={b.id}
                  className="rounded-2xl bg-white border border-[#EADFE2] p-5 hover:border-[#7A0F28]/45 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 text-xs text-[#76646A]">
                    <span className="font-semibold text-[#7A0F28]">{b.company}</span>
                    <span className="font-mono tabular-nums">{b.vacancies} Seats Open</span>
                  </div>
                  <h3 className="mt-2 text-base font-bold text-[#1D1014]">{b.role}</h3>
                  <div className="mt-3 text-xs text-[#5E4B51] space-y-1">
                    <div>{b.experience} · {b.location}</div>
                    <div>Highlight: {b.credential}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 9. COMMUNITY STATS BANNER */}
      <section className="bg-gradient-to-r from-[#4A0817] via-[#7A0F28] to-[#4A0817] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-8">
            <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-white">
              {BRAND_INFO.name} Impact in Numbers
            </h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
            {COMMUNITY_STATS.map((stat) => (
              <div
                key={stat.label}
                className="rounded-xl bg-white/10 border border-white/15 px-3 py-5"
              >
                <div className="font-mono tabular-nums text-2xl sm:text-3xl font-bold text-[#F3CF7A]">
                  {stat.value}
                </div>
                <div className="mt-1 text-xs text-white/85">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. HIGHLIGHTS & LATEST STUDY BLOGS */}
      <section className="py-18 lg:py-24 bg-white border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Highlights */}
            <div className="lg:col-span-5">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#7A0F28]">
                <Award className="w-4 h-4" aria-hidden="true" />
                <span>Why Families Choose Us</span>
              </div>
              <h2 className="mt-2 font-editorial text-3xl font-bold text-[#1D1014]">
                Milestones &amp; Campus Highlights
              </h2>
              <div className="mt-6 space-y-4">
                {AWARDS_AND_HIGHLIGHTS.map((item) => (
                  <div
                    key={item.title}
                    className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] p-4"
                  >
                    <div className="text-xs font-semibold text-[#7A0F28]">{item.source}</div>
                    <div className="mt-1 text-sm font-bold text-[#1D1014]">{item.title}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Study Guides & Blog */}
            <div className="lg:col-span-7">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#7A0F28]">
                    <BookOpen className="w-4 h-4" aria-hidden="true" />
                    <span>Study Tips &amp; Exam Blueprints</span>
                  </div>
                  <h2 className="mt-2 font-editorial text-3xl font-bold text-[#1D1014]">
                    Latest Articles from Our Faculty
                  </h2>
                </div>
                <a
                  href="/blog"
                  onClick={(e) => go(e, '/blog')}
                  className="text-sm font-semibold text-[#7A0F28] hover:underline whitespace-nowrap"
                >
                  All Articles →
                </a>
              </div>

              <div className="mt-6 space-y-4">
                {combinedBlogs.map((post) => (
                  <a
                    key={post.slug}
                    href={`/blog/${post.slug}`}
                    onClick={(e) => go(e, `/blog/${post.slug}`)}
                    className="group rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-5 flex flex-col sm:flex-row gap-4 hover:border-[#7A0F28]/45 transition-colors"
                  >
                    {post.image && (
                      <div className="sm:w-36 h-28 rounded-xl overflow-hidden shrink-0">
                        <SafeImage
                          src={post.image}
                          alt={post.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-[#76646A]">
                        {post.category} · {post.readTime || '5 min read'}
                      </div>
                      <h3 className="mt-1 font-editorial text-lg font-bold text-[#1D1014] group-hover:text-[#7A0F28] transition-colors">
                        {post.title}
                      </h3>
                      <p className="mt-1.5 text-xs sm:text-sm text-[#5E4B51] line-clamp-2">
                        {post.excerpt}
                      </p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 11. LIVE COUNSELLING & MURADNAGAR ADMISSION FORM BAND */}
      <section className="py-18 lg:py-24 bg-[#FAF7F5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
              Visit Our Muradnagar Campus or Book Online
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#1D1014] leading-tight">
              Book Your Free 2-Day Demo Class Today
            </h2>
            <p className="text-base text-[#4B3B40] leading-relaxed">
              Looking for the right batch for Classes 6–12, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, or Coding Classes? Submit your details and our Muradnagar counselling desk will guide you with batch timings, fee structure, and scholarship discounts.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="rounded-xl bg-white border border-[#EADFE2] p-4 flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-sm font-bold text-[#1D1014]">Phone / WhatsApp</div>
                  <a href={BRAND_INFO.phoneHref} className="font-mono tabular-nums text-xs font-semibold text-[#7A0F28] mt-0.5 block">
                    {BRAND_INFO.phoneDisplay}
                  </a>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-[#EADFE2] p-4 flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-sm font-bold text-[#1D1014]">Campus Address</div>
                  <div className="text-xs text-[#5E4B51] mt-0.5">{BRAND_INFO.address}</div>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-[#EADFE2] p-4 flex items-start gap-3 sm:col-span-2">
                <Users className="w-5 h-5 text-[#7A0F28] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-sm font-bold text-[#1D1014]">Unified Student, Teacher &amp; Parent ERP Portal</div>
                  <div className="text-xs text-[#5E4B51] mt-0.5">
                    Daily attendance alerts, weekly Sunday test marks, homework notes, online quizzes &amp; digital fee receipts.
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <EnquiryForm
              heading="Book Free Demo Class & Counselling"
              subheading="Direct submission to our Muradnagar Admissions Team — we call back promptly."
              ctaLabel="Schedule Free Demo"
              source="homepage_bottom_form"
              courses={boot.courses}
              branches={boot.branches}
              showDemoFields
            />
          </div>
        </div>
      </section>
    </div>
  );
}
