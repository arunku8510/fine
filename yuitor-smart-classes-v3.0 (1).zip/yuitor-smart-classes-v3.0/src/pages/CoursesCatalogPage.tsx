import React, { useState } from 'react';
import { Search, ShoppingBag, ArrowRight } from 'lucide-react';
import type { BootstrapData } from '../types';
import {
  BOARD_LINKS,
  CLASS_LINKS,
  EXAM_LINKS,
  SKILL_LINKS,
} from '../data/siteContent';
import { filterBackendCourses, formatINR } from '../utils/catalog';

interface CoursesCatalogPageProps {
  boot: BootstrapData;
  isSubjectsPage?: boolean;
  onNavigate: (path: string) => void;
  onOpenEnquiry: (course?: string) => void;
}

export function CoursesCatalogPage({
  boot,
  isSubjectsPage = false,
  onNavigate,
  onOpenEnquiry,
}: CoursesCatalogPageProps) {
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');

  function go(e: React.MouseEvent, path: string) {
    e.preventDefault();
    onNavigate(path);
  }

  const filteredBackend = filterBackendCourses(boot.courses || [], category, search);

  async function addCart(courseId: number, title: string) {
    if (window.YuitorAddons?.addCourseToCart) {
      await window.YuitorAddons.addCourseToCart(courseId);
      setNotice(`Added "${title}" to your enrollment cart.`);
      setTimeout(() => setNotice(''), 3500);
    } else {
      onOpenEnquiry(title);
    }
  }

  return (
    <div className="bg-[#FAF7F5] text-[#1D1014]">
      {/* Dark Burgundy Page Banner */}
      <section className="bg-[#24040C] text-white py-14 lg:py-18 border-b border-[#4A0817]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-xs font-semibold tracking-wider text-[#E6B450]">
            {isSubjectsPage
              ? 'Complete Academic & Skill Directory'
              : 'Classes 6–12 · Boards & Exams · Skill Courses'}
          </p>
          <h1 className="mt-2 font-editorial text-4xl sm:text-5xl font-bold text-white">
            {isSubjectsPage
              ? 'Classes 6–12, Boards & Exams & Skill Courses'
              : 'All Courses & Live Batches'}
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl">
            Explore dedicated coaching for Class 6 to Class 12, CBSE, UP Board, ICSE, State Board, NEET, JEE, CUET, NDA, SSC, Banking, Computer Classes, Spoken English, and Coding Classes — synced live with affordable Muradnagar fees.
          </p>

          {/* Search & Category Filter Controls */}
          <div className="mt-8 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
            <div className="flex flex-wrap items-center gap-1.5 bg-white/10 p-1 rounded-xl">
              {['All', 'Classes 6-12', 'Competitive', 'Computer', 'English', 'Coding'].map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setCategory(tab)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    category === tab
                      ? 'bg-white text-[#7A0F28]'
                      : 'text-white/85 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-72">
              <Search
                className="w-4 h-4 text-white/60 absolute left-3.5 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search Class 10, CBSE, UP Board, NEET, Coding..."
                aria-label="Search courses"
                className="w-full rounded-xl bg-white/10 border border-white/20 pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-white/60 focus:bg-white/15 focus:outline-none focus:border-[#E6B450]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Complete Dedicated Pages Directory (Classes 6-12, Boards & Exams, Skill Courses) */}
      <section className="py-14 border-b border-[#EADFE2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-10">
          {/* Classes 6-12 */}
          <div>
            <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-[#1D1014]">
              School Classes (Class 6 to Class 12)
            </h2>
            <p className="mt-1 text-sm text-[#5E4B51]">
              Small batches with concept clarity, daily homework tracking, and weekly Sunday tests.
            </p>
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {CLASS_LINKS.map((item) => (
                <a
                  key={item.path}
                  href={item.path}
                  onClick={(e) => go(e, item.path)}
                  className="group rounded-2xl bg-white border border-[#EADFE2] hover:border-[#7A0F28] p-5 transition-colors flex flex-col justify-between"
                >
                  <div>
                    <div className="font-editorial text-xl font-bold text-[#7A0F28]">
                      {item.label}
                    </div>
                    <p className="mt-1.5 text-xs text-[#5E4B51] leading-relaxed">{item.desc}</p>
                  </div>
                  <div className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-[#1D1014] group-hover:text-[#7A0F28]">
                    <span>View Syllabus &amp; Fees</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Boards & Competitive Exams */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="rounded-2xl bg-white border border-[#EADFE2] p-7">
              <h2 className="font-editorial text-2xl font-bold text-[#1D1014]">
                Boards Coaching
              </h2>
              <p className="mt-1 text-sm text-[#5E4B51]">
                Board-specific notes, step-marking answer writing, and 10-year PYQs.
              </p>
              <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {BOARD_LINKS.map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] hover:border-[#7A0F28] p-4 transition-colors"
                  >
                    <div className="font-bold text-sm text-[#7A0F28]">{item.label}</div>
                    <p className="mt-1 text-xs text-[#5E4B51]">{item.desc}</p>
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-white border border-[#EADFE2] p-7">
              <h2 className="font-editorial text-2xl font-bold text-[#1D1014]">
                Competitive Exams Coaching
              </h2>
              <p className="mt-1 text-sm text-[#5E4B51]">
                Daily practice sheets, OMR/CBT mock tests, and personalized rank mentoring.
              </p>
              <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {EXAM_LINKS.map((item) => (
                  <a
                    key={item.path}
                    href={item.path}
                    onClick={(e) => go(e, item.path)}
                    className="rounded-xl bg-[#FAF7F5] border border-[#EADFE2] hover:border-[#7A0F28] p-4 transition-colors"
                  >
                    <div className="font-bold text-sm text-[#7A0F28]">{item.label}</div>
                    <p className="mt-1 text-xs text-[#5E4B51]">{item.desc}</p>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Skill Courses */}
          <div>
            <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-[#1D1014]">
              Skill Courses
            </h2>
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {SKILL_LINKS.map((item) => (
                <a
                  key={item.path}
                  href={item.path}
                  onClick={(e) => go(e, item.path)}
                  className="group rounded-2xl bg-white border border-[#EADFE2] hover:border-[#7A0F28] p-5 transition-colors flex flex-col justify-between"
                >
                  <div>
                    <div className="font-editorial text-xl font-bold text-[#7A0F28]">
                      {item.label}
                    </div>
                    <p className="mt-1.5 text-xs text-[#5E4B51] leading-relaxed">{item.desc}</p>
                  </div>
                  <div className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-[#1D1014] group-hover:text-[#7A0F28]">
                    <span>Explore Lab &amp; Syllabus</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Live SQLite Backend Courses with Add-to-Cart */}
      <section className="py-14 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold tracking-wider text-[#7A0F28]">
                Direct Enrollment · Live Institute Catalog
              </p>
              <h2 className="mt-1 font-editorial text-2xl sm:text-3xl font-bold text-[#1D1014]">
                Enrollable Batches ({filteredBackend.length})
              </h2>
            </div>
            <button
              type="button"
              onClick={() => window.YuitorAddons?.openCartDrawer?.()}
              className="inline-flex items-center gap-2 rounded-lg border border-[#7A0F28] px-4 py-2 text-xs font-semibold text-[#7A0F28] hover:bg-[#FAF7F5] cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>View Enrollment Cart</span>
            </button>
          </div>

          {notice && (
            <div role="status" className="mt-4 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-900">
              {notice}
            </div>
          )}

          {filteredBackend.length === 0 ? (
            <div className="mt-8 rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-8 text-center">
              <p className="text-sm text-[#5E4B51]">
                No live batches matched your current filter. Clear search to view all active courses.
              </p>
              <button
                type="button"
                onClick={() => {
                  setCategory('All');
                  setSearch('');
                }}
                className="mt-4 rounded-lg bg-[#7A0F28] px-5 py-2 text-xs font-semibold text-white cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="mt-7 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBackend.map((c) => {
                const cleanText = (v?: string) =>
                  (v || '')
                    .replace(/AI Learning\s*&\s*/gi, '')
                    .replace(/\bAI Learning\b/gi, 'Coding')
                    .trim();
                const displayTitle = cleanText(c.title);
                const metaLine = [cleanText(c.category), c.class_level, cleanText(c.board), c.mode]
                  .filter(Boolean)
                  .join(' · ');
                return (
                  <div
                    key={c.id}
                    className="rounded-2xl bg-[#FAF7F5] border border-[#EADFE2] p-6 flex flex-col justify-between"
                  >
                    <div>
                      <div className="text-xs text-[#76646A]">{metaLine}</div>
                      <h3 className="mt-1.5 font-editorial text-lg font-bold text-[#1D1014]">
                        {displayTitle}
                      </h3>
                      <p className="mt-2 text-sm text-[#5E4B51] leading-relaxed">
                        {cleanText(c.description) ||
                          'Complete structured syllabus, weekly tests, and live portal support.'}
                      </p>
                    </div>
                    <div className="mt-5 pt-4 border-t border-[#EADFE2] flex items-center justify-between gap-2">
                      <div className="font-mono tabular-nums text-base font-bold text-[#7A0F28]">
                        {formatINR(c.monthly_fee)}/mo
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => addCart(c.id, displayTitle)}
                          className="inline-flex items-center gap-1 rounded-lg bg-[#7A0F28] hover:bg-[#58091B] px-3 py-2 text-xs font-semibold text-white cursor-pointer"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add to Cart</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenEnquiry(displayTitle)}
                          className="rounded-lg border border-[#DFD1D5] px-3 py-2 text-xs font-semibold text-[#1D1014] hover:border-[#7A0F28] hover:text-[#7A0F28] cursor-pointer"
                        >
                          Enquire
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
