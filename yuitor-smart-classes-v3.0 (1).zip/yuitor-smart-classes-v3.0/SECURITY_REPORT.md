# Security Audit & Hardening Report — Yuitor Smart Classes

**Audit Scope:** Node.js + Express + SQLite backend (`server.js`, `server/*.mjs`, `database/migrations/`, `public/assets/portals.js`, `public/assets/addons-portal.js`, `.env.example`).  
**Backup Location:** Original unmodified source preserved at `backup_original/` (blocked from HTTP access and excluded from release ZIP).  
**Disclaimer:** Security is an ongoing operational process; this hardening pass significantly reduces risk across critical, high, and medium classes of vulnerabilities, but no production web application can be guaranteed 100% secure.

---

## 1. Fixed Vulnerabilities & Controls Implemented

### Phase 1 — Critical
1. **Parent–Student Link IDOR Blocked (`server.js`)**
   - Removed Roll-Number-only auto-linking during `/api/auth/register` (`role = 'parent'`) and `/api/parent/link-child`.
   - Added `parent_link_requests` table + `'parent_link'` OTP purpose (`otp_tokens` auto-upgraded + updated in `001_unified_portal.sql`).
   - `/api/parent/link-child` now requires **either**:
     - Verified parent mobile (`mobile_verified = 1`) matching `student_profiles.parent_phone` **+ 6-digit OTP** issued via `POST /api/parent/link-child/request-otp`, **or**
     - Explicit Admin approval request (`requestApproval: true` → `202 pendingApproval`), reviewed by Admin via `GET /api/<gate>/parents/link-requests` and `POST /api/<gate>/parents/link-requests/:id/review`.
   - Verified `parent_links` ownership checks on all `/api/parent/*` endpoints (dashboard, messages, child linking).
2. **First Admin Setup Locked Down (`server.js`, `server/security-hardening.mjs`)**
   - `verifySetupKey()` changed from **fail-open** (`if (!expected) return true`) to **fail-closed** (`YU_ADMIN_SETUP_KEY` mandatory, minimum 16 chars, constant-time `timingSafeEqual`).
   - Setup key + rate limit now validated **before** preflight DB checks to prevent unauthenticated state disclosure.
   - Blocked public SMTP override (`req.body.smtp` → `403`) and custom OTP email override (`req.body.otpEmail` → `403`).
   - Installer OTP is sent strictly to server `.env` `OWNER_EMAIL` (or `ADMIN_OTP_EMAIL`), failing closed (`503`) if unset.
   - Added one-time completion lock (`INSTALLER_LOCKED=1` in `system_settings`) and optional expiry window (`YU_ADMIN_SETUP_EXPIRES_AT`). All `/installer/*` routes return `410 Gone` once an admin exists or the setup window expires.
3. **High-Entropy Secret Admin URL (`server.js`, `server/security-hardening.mjs`)**
   - Replaced 4-character slug (`yt-ctrl-xxxx-gate`) with 128-bit CSPRNG slug `g-<32 hex chars>` via `crypto.randomBytes(16)`.
   - Stored with `is_secret = 1`, removed `logs/install-gate-url.txt` generation, removed `console.log` and `install.log` slug printing, and added dynamic slug redaction in `redactSecretsForLog()`.
4. **IP Spoofing Mitigated (`server.js`, `server/security-hardening.mjs`)**
   - `app.set("trust proxy", resolveTrustProxySetting(process.env.TRUST_PROXY))` now defaults to `false` (configurable via `.env` for trusted reverse proxies).
   - Replaced raw `req.headers["x-forwarded-for"]` parsing in `clientIp(req)` with Express `req.ip` / `req.socket.remoteAddress`, preventing spoofed `X-Forwarded-For` headers from bypassing rate limits or `ADMIN_IP_ALLOWLIST`.
5. **CSRF Protection Enforced (`server.js`, `server/security-hardening.mjs`, `public/assets/portals.js`, `public/assets/addons-portal.js`)**
   - State-changing `/api/*` requests (`POST`, `PUT`, `PATCH`, `DELETE`) with **missing** `Origin`/`Referer` are no longer blindly allowed.
   - Requests must pass same-origin `Origin`/`Referer` validation **or** double-submit CSRF verification (`yu_csrf` cookie matching `X-CSRF-Token` header).
   - `/api/payments/webhook` remains exempt from CSRF and protected by HMAC-SHA256 signature verification.
   - CSRF rejections are logged to `audit_logs` (`action = 'csrf_blocked'`).
6. **Payment Verification & Idempotency Hardened (`server.js`, `server/addons-routes.mjs`)**
   - `/api/payments/enroll`: Gateway verification now requires a matching **server-created pending order** belonging to the authenticated student and course, valid HMAC signature, and rejects cross-account payment ID reuse (`409`).
   - `/api/payments/webhook`: Verifies raw-body HMAC signature, checks `paymentEntity.amount` (in paise) equals `row.amount * 100` and currency `INR`, and preserves duplicate idempotency (`duplicate: true`).
   - `/api/cart/checkout/create-order` & `/complete`: Persists server-side `cart_gateway_orders` (order ID, student ID, expected amount), checks ownership, amount integrity, and `gateway_payment_id` uniqueness before marking verified.
   - Admin `/payments/:id/verify` & `/payments/:id/refund` enforce idempotency (`409` on double-verify/double-refund) with full audit logging; `/api/payments/refund-request` blocks duplicate requests and writes audit logs.

### Phase 2 — High
7. **Security Headers & Cookies (`server.js`, `server/addons-routes.mjs`)**
   - Added `Content-Security-Policy` (including `frame-ancestors 'self'`, `object-src 'none'`, `base-uri 'self'`, `form-action 'self'`, allowing Google Fonts, Razorpay checkout/API, and Gemini).
   - Added `Strict-Transport-Security` (when HTTPS/production), `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy`, `Cross-Origin-Opener-Policy: same-origin-allow-popups`, and `app.disable("x-powered-by")`.
   - Enforced `httpOnly`, `sameSite: "lax"`, and proxy-aware `secure` flags on `yu_session` and `ytr_cart_id`; replaced predictable `sha256(process.cwd())` session secret fallback with CSPRNG secret generation.
8. **Auth, Session Regeneration & Public Admin Reset Block (`server.js`)**
   - Login endpoints (`/api/auth/login`, `/api/auth/login-otp/verify`, admin `/auth/verify-otp`) now regenerate session IDs and purge prior session rows (`replaceSessionId`).
   - Logout destroys the DB session row and clears cookie attributes consistently.
   - Blocked `admin` and `super_admin` accounts from public `/api/auth/forgot-password` and `/api/auth/reset-password` (returning non-enumerating responses + audit log).
   - Logged failed user login attempts (`login_failed`) alongside rate-limit lockouts.
9. **Staff Role & Branch Access Isolation (`server.js`, `server/security-hardening.mjs`)**
   - Enforced `branch_id` scoping (`getStaffBranchScope`) across staff dashboard, inquiries, library, fee installments, and overview reports.
   - Strict **Librarian** isolation (`isStrictLibrarian`): strips student `phone`, `roll_number`, `class_level`, and inquiry/academic records from `/api/staff/dashboard` and removes `roll_number` from `/api/staff/library` issues.
   - Added audit logging on `PATCH /users/:id/staff-permissions`.
10. **File Upload Hardening & Private Download Auth (`server.js`, `server/security-hardening.mjs`)**
    - Enforced MIME + magic-bytes validation (`%PDF-`, PNG, JPEG, WebP `RIFF..WEBP`, DOC OLE/RTF, DOCX ZIP with `[Content_Types].xml`/`word/` verification) and blocked double extensions and executable/script payloads (PE/MZ, ELF, Mach-O, `#!`, `<?php`, `<script`, `<svg`, `<html`).
    - Randomized filenames (`crypto.randomBytes`), enforced size limits, blocked path traversal, and applied `chmod 0600`.
    - Replaced public `express.static(UPLOADS_DIR)` with authenticated `/uploads/:filename` handler requiring valid session for PDFs (`Content-Disposition: attachment`, `nosniff`) while blocking `/uploads/resumes` and `/uploads/knowledge` (`403`).
    - Integrated optional ClamAV hook (`scanUploadedFileWithClamAv`).
11. **DB, Secrets, Backups & Error Sanitization (`server.js`)**
    - Added `backup_original`, `tmp`, `security_report.md`, `deploy.md` to `BLOCKED_ROOT_SEGMENTS` (returns `404` alongside `data/`, `backups/`, `logs/`, `.env`, `*.db`, `*.sqlite`, `*.log`).
    - Applied runtime `chmod 0700` on `data/`, `backups/`, `logs/`, `uploads/resumes/`, `uploads/knowledge/` and `chmod 0600` on `data/yuitor.db`, `.env`, and newly created backup `.db` files.
    - Hardened global Express error handler so 5xx errors never leak stack traces, file paths, or secrets.

### Phase 3 — Medium
12. **SQLi / XSS / Command Injection Audit**: Verified all SQL queries use parameterized `?` bindings (added strict identifier validation in `addMissingColumn`), confirmed zero shell/command execution on user input (ClamAV hook uses `execFileSync` with static argv array, no shell), and preserved HTML escaping across server email/HTML templates.
13. **Audit Log Secret Redaction**: `writeAuditLog()` passes details/names through `redactSecretsForLog()` to strip passwords, OTPs, Bearer/session tokens, API keys, and active `ADMIN_PATH`.
14. **Dependency Audit & Production Mode**: Ran `npm audit --omit=dev` — **0 production vulnerabilities** found; `x-powered-by` disabled; documented `NODE_ENV=production` in `.env.example` and `DEPLOY.md`.

---

## 2. Verification & Test Matrix

| # | Security Test Area | Result | Evidence / Notes |
|---|---|---|---|
| 1 | Unit Tests — Security Hardening, Addons, Shreya Guard & Catalog (26 tests) | **PASS** | 21/21 server unit tests + 5/5 frontend tests passed (`node --test` + `tsx --test`) |
| 2 | Security Headers (`CSP`, `frame-ancestors`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`, no `x-powered-by`) | **PASS** | Verified via `scripts/security-smoke-test.mjs` |
| 3 | CSRF Protection (missing `Origin`, cross-origin, `X-CSRF-Token`, webhook exempt) | **PASS** | Missing `Origin` → `403`, cross-origin → `403`, valid token → `401` (passed CSRF), webhook → exempt (`503`/`400`) |
| 4 | Auth Login, Session Regeneration & Logout Invalidation | **PASS** | Re-login issues new token & deletes previous DB session; logout invalidates session |
| 5 | Rate Limit Lockout & `X-Forwarded-For` Spoof Immunity | **PASS** | `429` lockout triggered even when rotating forged `X-Forwarded-For` IPs |
| 6 | Parent–Student Link (Roll-only blocked, IDOR messages blocked, OTP & Admin approval) | **PASS** | Roll-only → `403`, unlinked message → `403`, approval request → `202` (not auto-linked), verified parent OTP request → `200` |
| 7 | First-Admin Setup Hardening (Empty key, public SMTP, custom email blocked + post-setup `410` lock) | **PASS** | `smtp` → `403`, `otpEmail` → `403`, empty `setupKey` → `403`, post-setup all installer routes → `410` |
| 8 | Staff Branch Scoping & Librarian PII/Academic Isolation | **PASS** | Librarian sees zero `phone`/`roll_number`/`class_level`, zero cross-branch students, `/reports/overview` → `403` |
| 9 | Razorpay Webhook Signature, Amount Validation & Duplicate Idempotency (isolated test secrets) | **PASS** | Invalid sig → `400`, wrong amount → ignored (`pending_verification`), exact amount → `verified`, replay → `duplicate: true` |
| 10 | Live Razorpay API Order Creation & Live Webhook Delivery | **NOT TESTED** | `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` not configured in local dev container; endpoint fails closed (`503`) |
| 11 | File Upload Magic-Bytes, Double-Extension Block, Path Traversal & Auth PDF Download | **PASS** | Fake PHP-as-PDF → `400`, `evil.php.pdf` → `400`, valid PDF → `201`, unauth PDF download → `401`, auth download → `200`, `/uploads/resumes` → `403`, traversal → `404` |
| 12 | ClamAV Antivirus Scanning on Uploads | **NOT TESTED** | `clamdscan`/`clamscan` binary is not installed in this container; hook integrated and returns `not_verified` when absent |
| 13 | Sensitive Paths Blocked (`404`), Admin-Only Backup Auth, Admin Public Reset Blocked & `0700`/`0600` Permissions | **PASS** | `/.env`, `/data/yuitor.db`, `/backups/*`, `/backup_original/*`, `/logs/*`, `/server.js` → `404`; unauth/student backup → `403`; `data/` & `backups/` = `700`, `yuitor.db` = `600` |
| 14 | Live SMTP OTP Email Delivery | **NOT TESTED** | External SMTP credentials not configured in local dev container |
| 15 | Browser UI Compatibility under New CSP & CSRF (Chromium) | **PASS** | `/`, `/student/login`, `/teacher/login` rendered with `0` console errors and `0` CSP violations |
| 16 | Production Dependency Audit (`npm audit --omit=dev`) | **PASS** | `0` vulnerabilities reported |

---

## 3. Remaining Risks & Recommendations

1. **ClamAV Not Installed in Runtime Container (`NOT VERIFIED`)**: The upload scanner hook (`scanUploadedFileWithClamAv`) is wired into `/api/uploads` and teacher resume uploads, but requires `clamav-daemon` on the production VPS (see `DEPLOY.md`). On shared cPanel hosting without ClamAV, relies on magic-bytes/MIME/non-executable controls and `Content-Disposition: attachment`.
2. **CSP `'unsafe-inline'`**: Required currently for existing inline portal/page styles and scripts (`portals.js` / shell templates). Migrating inline scripts to per-request cryptographic nonces is recommended in a future frontend refactor.
3. **Production `.env` & Secret Rotation**: Ensure `SESSION_SECRET`, `ADMIN_PATH`, `YU_ADMIN_SETUP_KEY`, `OWNER_EMAIL`, and `TRUST_PROXY` are explicitly configured on the production host before startup; remove `YU_ADMIN_SETUP_KEY` once Super Admin setup completes.
4. **Uploaded Public Images**: Uploaded CMS/avatar images (`.png`, `.jpg`, `.jpeg`, `.webp`) in `/uploads/:filename` remain readable for public website rendering (with `nosniff`), whereas PDFs require authentication and resumes/knowledge docs are strictly `403` publicly.
5. **SQLite Single-Node Limits**: SQLite with WAL mode suits single-instance cPanel/VPS deployments; multi-instance horizontal scaling would require migrating to PostgreSQL/MySQL and a shared session/rate-limit store (e.g. Redis).
6. **Build-Time Packages in `package.json`**: Dev/build packages (`vite`, `@tailwindcss/vite`, `@types/*`) currently live in `dependencies` to preserve the existing hosting build pipeline; when deploying pre-built bundles to a VPS, keep only runtime packages in production builds if desired.
